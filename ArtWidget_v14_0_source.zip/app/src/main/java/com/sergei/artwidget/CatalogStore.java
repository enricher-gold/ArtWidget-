package com.sergei.artwidget;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Локальное хранилище каталога. Каталог больше не сериализуется целиком
 * в SharedPreferences, поэтому чтение/обновление тысяч записей не блокирует UI.
 */
public final class CatalogStore extends SQLiteOpenHelper {
    private static final String DB_NAME = "art_catalog_v12.db";
    private static final int DB_VERSION = 1;
    private static final String TABLE = "artworks";

    public CatalogStore(Context context) {
        super(context.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + "qid TEXT PRIMARY KEY,"
                + "canonical_key TEXT NOT NULL UNIQUE,"
                + "title TEXT NOT NULL,"
                + "artist TEXT NOT NULL,"
                + "description TEXT NOT NULL,"
                + "image_url TEXT NOT NULL,"
                + "original_image_url TEXT NOT NULL,"
                + "source_url TEXT NOT NULL,"
                + "instance_label TEXT NOT NULL,"
                + "material_label TEXT NOT NULL,"
                + "genre_label TEXT NOT NULL,"
                + "added_at INTEGER NOT NULL,"
                + "last_shown_at INTEGER NOT NULL,"
                + "show_count INTEGER NOT NULL,"
                + "explicit_content INTEGER NOT NULL DEFAULT 0"
                + ")");
        db.execSQL("CREATE INDEX idx_artworks_explicit ON " + TABLE + "(explicit_content)");
        db.execSQL("CREATE INDEX idx_artworks_artist_title ON " + TABLE + "(artist, title)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public synchronized boolean isEmpty() {
        return countAll() == 0;
    }

    public synchronized int countAll() {
        return countWhere(null, null);
    }

    public synchronized int countSafe() {
        return countWhere("explicit_content=0", null);
    }

    public synchronized int countExplicit() {
        return countWhere("explicit_content=1", null);
    }

    private int countWhere(String selection, String[] args) {
        try (Cursor cursor = getReadableDatabase().query(TABLE,
                new String[]{"COUNT(*)"}, selection, args, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    public synchronized List<ArtEntry> getAll() {
        List<ArtEntry> out = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(TABLE, null,
                null, null, null, null, "rowid ASC")) {
            while (c.moveToNext()) out.add(fromCursor(c));
        }
        return out;
    }

    public synchronized ArtEntry getByQid(String qid) {
        if (qid == null || qid.trim().isEmpty()) return null;
        try (Cursor c = getReadableDatabase().query(TABLE, null,
                "qid=?", new String[]{qid}, null, null, null, "1")) {
            return c.moveToFirst() ? fromCursor(c) : null;
        }
    }

    public synchronized void replaceAll(List<ArtEntry> entries) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete(TABLE, null, null);
            if (entries != null) {
                for (ArtEntry entry : entries) insertOrReplace(db, entry);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public synchronized int deleteByQidPrefix(String prefix) {
        if (prefix == null || prefix.isEmpty()) return 0;
        return getWritableDatabase().delete(TABLE, "qid LIKE ?", new String[]{prefix + "%"});
    }

    public synchronized int mergeAll(List<ArtEntry> entries) {
        if (entries == null || entries.isEmpty()) return 0;
        SQLiteDatabase db = getWritableDatabase();
        int before = countAll();
        db.beginTransaction();
        try {
            for (ArtEntry entry : entries) insertOrReplace(db, entry);
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return Math.max(0, countAll() - before);
    }

    private void insertOrReplace(SQLiteDatabase db, ArtEntry e) {
        if (e == null) return;
        ContentValues v = new ContentValues();
        v.put("qid", e.qid);
        // UNIQUE используется только как защита от повторного QID. Канонический
        // ключ по названию/автору может совпасть у разных произведений и раньше
        // приводил к молчаливому уменьшению каталога.
        v.put("canonical_key", e.qid);
        v.put("title", e.title);
        v.put("artist", e.artist);
        v.put("description", e.description);
        v.put("image_url", e.imageUrl);
        v.put("original_image_url", e.originalImageUrl);
        v.put("source_url", e.sourceUrl);
        v.put("instance_label", e.instanceLabel);
        v.put("material_label", e.materialLabel);
        v.put("genre_label", e.genreLabel);
        v.put("added_at", e.addedAt);
        v.put("last_shown_at", e.lastShownAt);
        v.put("show_count", e.showCount);
        v.put("explicit_content", e.explicitContent ? 1 : 0);
        db.insertOrThrow(TABLE, null, v);
    }

    private ArtEntry fromCursor(Cursor c) {
        return new ArtEntry(
                getString(c, "qid"),
                getString(c, "title"),
                getString(c, "artist"),
                getString(c, "description"),
                getString(c, "image_url"),
                getString(c, "original_image_url"),
                "",
                getString(c, "source_url"),
                getString(c, "instance_label"),
                getString(c, "material_label"),
                getString(c, "genre_label"),
                getLong(c, "added_at"),
                getLong(c, "last_shown_at"),
                getInt(c, "show_count"),
                getInt(c, "explicit_content") != 0
        );
    }

    private String getString(Cursor c, String column) {
        int index = c.getColumnIndex(column);
        return index < 0 || c.isNull(index) ? "" : c.getString(index);
    }

    private long getLong(Cursor c, String column) {
        int index = c.getColumnIndex(column);
        return index < 0 || c.isNull(index) ? 0L : c.getLong(index);
    }

    private int getInt(Cursor c, String column) {
        int index = c.getColumnIndex(column);
        return index < 0 || c.isNull(index) ? 0 : c.getInt(index);
    }
}
