#!/usr/bin/env python3
"""Offline structural validation for Art Widget 13.0 assets."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"


def load_items(name: str) -> list[dict]:
    data = json.loads((ASSETS / name).read_text(encoding="utf-8"))
    items = data.get("items")
    if not isinstance(items, list):
        raise SystemExit(f"{name}: items is not an array")
    return items


def is_jpeg(path: Path) -> bool:
    data = path.read_bytes()
    return len(data) > 1000 and data.startswith(b"\xff\xd8") and data.endswith(b"\xff\xd9")


def main() -> None:
    general = load_items("filter_catalog.json")
    assert len(general) == 1000, f"filter_catalog.json: {len(general)} instead of 1000"
    general_ids = [str(x.get("stable_id") or x.get("qid") or "").strip() for x in general]
    assert all(general_ids), "filter_catalog.json: empty identity"
    assert len(set(general_ids)) == len(general_ids), "filter_catalog.json: duplicate identity"
    print(f"OK filter_catalog.json: {len(general)}")

    nsfw = load_items("nsfw_catalog.json")
    assert len(nsfw) >= 40, f"nsfw_catalog.json: only {len(nsfw)} strict entries"
    nsfw_ids = [str(x.get("qid") or x.get("stable_id") or "").strip() for x in nsfw]
    assert all(x.startswith("Q") and x[1:].isdigit() for x in nsfw_ids), "nsfw_catalog.json: invalid QID"
    assert len(set(nsfw_ids)) == len(nsfw_ids), "nsfw_catalog.json: duplicate QID"
    for item in nsfw:
        page = str(item.get("source_page_url") or "")
        assert page.startswith(("https://ru.wikipedia.org/wiki/", "https://en.wikipedia.org/wiki/")), \
            f"nsfw_catalog.json: non-exact Wikipedia source: {page}"
        for field in ("title_ru", "title_en", "artist_ru", "artist_en"):
            assert str(item.get(field) or "").strip(), f"nsfw_catalog.json: {item.get('qid')} missing {field}"
        assert item.get("style") == "painting", f"nsfw_catalog.json: {item.get('qid')} is not marked as painting"
        assert item.get("content_mode") == "NSFW", f"nsfw_catalog.json: {item.get('qid')} wrong content mode"
        resolver = item.get("image_resolver") or {}
        assert resolver.get("allow_wikiart") is False, f"nsfw_catalog.json: WikiArt enabled for {item.get('qid')}"
        assert resolver.get("allow_commons_title_search") is False, \
            f"nsfw_catalog.json: Commons title search enabled for {item.get('qid')}"
    direct = sum(bool(x.get("image_url")) for x in nsfw)
    assert direct >= 40, f"nsfw_catalog.json: only {direct} pre-resolved image URLs"
    print(f"OK nsfw_catalog.json: {len(nsfw)}, direct images: {direct}")

    starters = load_items("starter_catalog.json")
    safe = [x for x in starters if not x.get("explicit_content")]
    starter_nsfw = [x for x in starters if x.get("explicit_content")]
    assert len(safe) == 10 and len(starter_nsfw) == 10, f"starters: {len(safe)} + {len(starter_nsfw)}"

    ids: set[str] = set()
    for item in starters:
        qid = str(item.get("qid") or "").strip()
        assert qid and qid not in ids, f"duplicate or empty starter id: {qid}"
        ids.add(qid)
        assert str(item.get("description") or "").strip(), f"{qid}: no description"
        assert "wikipedia.org/wiki/" in str(item.get("source_page_url") or ""), f"{qid}: bad source"
        image = ASSETS / str(item.get("asset_path") or "")
        assert image.is_file() and is_jpeg(image), f"{qid}: invalid starter image {image}"
    print(f"OK starter_catalog.json: {len(safe)} FILTER + {len(starter_nsfw)} NSFW images")


if __name__ == "__main__":
    main()
