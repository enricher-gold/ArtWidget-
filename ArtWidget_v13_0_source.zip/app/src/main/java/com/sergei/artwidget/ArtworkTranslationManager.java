package com.sergei.artwidget;

import android.content.Context;

/**
 * Selects already available localized metadata. Version 13.0 intentionally
 * performs no on-device machine translation and downloads no language models.
 */
public final class ArtworkTranslationManager {
    public interface Callback {
        void onResult(String title, String artist, String description, boolean translated);
    }

    private ArtworkTranslationManager() { }

    public static void localize(Context context, ArtEntry entry, Callback callback) {
        if (entry == null) {
            callback.onResult("", "", "", false);
            return;
        }
        String language = LanguageManager.getLanguage(context);
        callback.onResult(
                entry.localizedTitle(language),
                entry.localizedArtist(language),
                entry.localizedDescription(language),
                false);
    }
}
