package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtworkActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private ArtEntry entry;
    private String qid;
    private ImageView imageView;
    private TextView captionView;
    private TextView descriptionView;
    private Button favoriteButton;
    private Button dislikeButton;
    private Button installButton;
    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        qid = getIntent().getStringExtra("qid");
        setupColors();
        setContentView(createLayout());
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bgColor);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.setFitsSystemWindows(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(16), top + dp(16), dp(16), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        Button back = button("Назад", false);
        back.setOnClickListener(v -> finish());
        LinearLayout.LayoutParams backParams = new LinearLayout.LayoutParams(dp(110), dp(46));
        backParams.setMargins(0, 0, 0, dp(8));
        root.addView(back, backParams);

        imageView = new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        imageView.setBackgroundColor(Color.TRANSPARENT);
        imageView.setOnClickListener(v -> openFullscreen());
        root.addView(imageView, new LinearLayout.LayoutParams(-1, dp(390)));

        captionView = new TextView(this);
        captionView.setTextColor(linkColor);
        captionView.setTextSize(20);
        captionView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        captionView.setGravity(Gravity.CENTER_HORIZONTAL);
        captionView.setPadding(0, dp(8), 0, dp(8));
        captionView.setOnClickListener(v -> openArticle());
        root.addView(captionView, new LinearLayout.LayoutParams(-1, -2));

        TextView about = new TextView(this);
        about.setText("О картине");
        about.setTextSize(18);
        about.setTextColor(textColor);
        about.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        about.setPadding(0, dp(8), 0, dp(8));
        root.addView(about, new LinearLayout.LayoutParams(-1, -2));

        descriptionView = new TextView(this);
        descriptionView.setTextColor(textColor);
        descriptionView.setTextSize(15);
        descriptionView.setLineSpacing(0, 1.16f);
        descriptionView.setPadding(0, 0, 0, dp(16));
        root.addView(descriptionView, new LinearLayout.LayoutParams(-1, -2));

        installButton = button("Установить на виджет", true);
        installButton.setOnClickListener(v -> install());
        root.addView(installButton, buttonParams());

        LinearLayout reactions = new LinearLayout(this);
        reactions.setOrientation(LinearLayout.HORIZONTAL);
        favoriteButton = button("♡ Избранное", false);
        dislikeButton = button("Не нравится", false);
        reactions.addView(favoriteButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams dislikeParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        dislikeParams.setMargins(dp(8), 0, 0, 0);
        reactions.addView(dislikeButton, dislikeParams);
        root.addView(reactions, new LinearLayout.LayoutParams(-1, -2));
        favoriteButton.setOnClickListener(v -> toggleFavorite());
        dislikeButton.setOnClickListener(v -> toggleDislike());
        return scroll;
    }

    private void refresh() {
        entry = new ArtRepository(this).findEntry(qid);
        if (entry == null) {
            captionView.setText("Произведение не найдено");
            descriptionView.setText("Сведения о произведении недоступны.");
            imageView.setImageDrawable(null);
            return;
        }
        captionView.setText(entry.caption());
        descriptionView.setText(entry.description.isEmpty() ? "Краткое описание отсутствует" : entry.description);
        ArtRepository repo = new ArtRepository(this);
        favoriteButton.setText(repo.isFavorite(entry.qid) ? "♥ В избранном" : "♡ Избранное");
        dislikeButton.setText(repo.isDisliked(entry.qid) ? "Убрать дизлайк" : "Не нравится");
        showImage(entry);
    }

    private void showImage(ArtEntry e) {
        imageView.setImageDrawable(null);
        if (e.localPath == null || e.localPath.isEmpty()) return;
        File file = new File(e.localPath);
        if (!file.exists()) return;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(bounds.outWidth, bounds.outHeight) > 2200 ? 2 : 1;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        if (bitmap != null) imageView.setImageBitmap(bitmap);
    }

    private void install() {
        if (entry == null || !UpdateCoordinator.tryBegin()) {
            Toast.makeText(this, "Обновление уже выполняется", Toast.LENGTH_SHORT).show();
            return;
        }
        setButtonsEnabled(false);
        executor.execute(() -> {
            try {
                new ArtRepository(this).installOnWidget(entry.qid);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    Toast.makeText(this, "Картина установлена на виджет", Toast.LENGTH_SHORT).show();
                    refresh();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                UpdateCoordinator.finish();
                runOnUiThread(() -> setButtonsEnabled(true));
            }
        });
    }

    private void toggleFavorite() {
        if (entry == null) return;
        boolean value = new ArtRepository(this).toggleFavorite(entry);
        Toast.makeText(this, value ? "Добавлено в избранное" : "Удалено из избранного", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void toggleDislike() {
        if (entry == null) return;
        ArtRepository repo = new ArtRepository(this);
        boolean newValue = !repo.isDisliked(entry.qid);
        repo.setDisliked(entry, newValue);
        Toast.makeText(this, newValue ? "Картина добавлена в чёрный список" : "Дизлайк снят", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void openArticle() {
        if (entry == null || entry.sourceUrl.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(entry.sourceUrl))); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть статью", Toast.LENGTH_SHORT).show(); }
    }

    private void openFullscreen() {
        if (entry == null) return;
        Intent intent = new Intent(this, FullscreenActivity.class);
        intent.putExtra("qid", entry.qid);
        startActivity(intent);
    }

    private void setButtonsEnabled(boolean enabled) {
        installButton.setEnabled(enabled);
        favoriteButton.setEnabled(enabled);
        dislikeButton.setEnabled(enabled);
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15, primary ? 0xFF007AFF : borderColor));
        b.setMinHeight(0);
        return b;
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, 0, 0, dp(8));
        return p;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFEDEDEF;
        borderColor = dark ? 0xFF38383A : 0xFFD1D1D6;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
