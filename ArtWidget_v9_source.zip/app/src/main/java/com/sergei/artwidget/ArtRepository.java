package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class ArtRepository {
    public static final String PREFS = "art_widget_prefs";
    private static final String KEY_HISTORY = "history";
    private static final String KEY_INDEX = "history_index";
    private static final String KEY_CATALOG = "wikidata_catalog";
    private static final String KEY_QUEUE = "catalog_queue_v9";
    private static final String KEY_QUEUE_INDEX = "catalog_queue_index_v9";
    private static final String KEY_CATALOG_OFFSET = "catalog_offset_v9";
    private static final String KEY_CATALOG_END = "catalog_end_v9";
    private static final String KEY_FAVORITES = "favorites_v9";
    private static final String KEY_DISLIKES = "dislikes_v9";
    private static final String KEY_CONTENT_MODE = "content_mode_v9";
    private static final String KEY_MIGRATED = "migrated_v9";
    private static final String KEY_LAST_FETCH = "last_fetch_millis";
    private static final String KEY_CURRENT = "current_entry_v9";
    private static final String KEY_CATALOG_COUNT = "catalog_count_v9";
    private static final String KEY_HISTORY_COUNT = "history_count_v9";
    private static final String KEY_CACHE_COUNT = "cache_count_v9";

    public static final int CONTENT_FILTER = 0;
    public static final int CONTENT_ALL = 1;
    public static final int CONTENT_ADULT_ONLY = 2;
    public static final int MAX_CACHE_FILES = 1000;
    private static final int MAX_HISTORY_RECORDS = 5000;
    private static final int PAGE_SIZE = 250;
    private static final int MAX_PAGE_ATTEMPTS_PER_UPDATE = 3;
    private static final long MIN_MANUAL_INTERVAL_MS = 1200L;
    private static final String USER_AGENT = "ArtWidget/9.0 Android; Russian art widget; contact enricherusa@gmail.com";

    private static final Object DATA_LOCK = new Object();
    private static final Object NETWORK_LOCK = new Object();

    private final Context context;
    private final SharedPreferences prefs;
    private final Random random = new Random();

    public ArtRepository(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        migrateIfNeeded();
    }

    public ArtEntry getCurrent() {
        synchronized (DATA_LOCK) {
            try {
                String saved = prefs.getString(KEY_CURRENT, "");
                if (saved != null && !saved.trim().isEmpty()) return ArtEntry.fromJson(new JSONObject(saved));
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                int index = prefs.getInt(KEY_INDEX, -1);
                if (index < 0 || index >= history.size()) return null;
                ArtEntry entry = history.get(index);
                prefs.edit().putString(KEY_CURRENT, entry.toJson().toString()).apply();
                return entry;
            } catch (Exception e) {
                AppLogger.log(context, "getCurrent", "error", e.getMessage());
                return null;
            }
        }
    }

    public ArtEntry fetchNextArtwork() throws IOException, JSONException {
        long start = System.currentTimeMillis();
        synchronized (NETWORK_LOCK) {
            long now = System.currentTimeMillis();
            long last = prefs.getLong(KEY_LAST_FETCH, 0L);
            if (now - last < MIN_MANUAL_INTERVAL_MS) {
                ArtEntry current = getCurrent();
                if (current != null) return current;
            }
            prefs.edit().putLong(KEY_LAST_FETCH, now).apply();

            if (!hasNetwork()) {
                ArtEntry current = getCurrent();
                if (current != null) return current;
                throw new IOException("Нет подключения к интернету");
            }

            Exception lastError = null;
            for (int attempt = 0; attempt < 8; attempt++) {
                ArtEntry candidate;
                try {
                    candidate = nextCatalogCandidate();
                } catch (Exception e) {
                    lastError = e;
                    break;
                }
                if (candidate == null) break;
                try {
                    ArtEntry downloaded = downloadArtwork(candidate);
                    if (!matchesContentMode(downloaded, getContentMode()) || isUnwanted(downloaded)) {
                        deleteFileQuietly(downloaded.localPath);
                        continue;
                    }
                    appendHistory(downloaded);
                    enforceCacheLimit();
                    AppLogger.log(context, "next", "ok", downloaded.qid + " | " + (System.currentTimeMillis() - start) + " ms");
                    return downloaded;
                } catch (Exception e) {
                    lastError = e;
                    AppLogger.log(context, "candidate", "skip", candidate.qid + " | " + friendlyMessage(e));
                    if (isRateLimit(e)) break;
                }
            }

            String message = lastError == null ? "Новые произведения временно не найдены" : friendlyMessage(lastError);
            AppLogger.log(context, "next", "error", message);
            if (lastError instanceof JSONException) throw (JSONException) lastError;
            throw new IOException(message);
        }
    }

    public ArtEntry goPrevious() throws IOException, JSONException {
        return navigateHistory(-1);
    }

    public ArtEntry goForward() throws IOException, JSONException {
        return navigateHistory(1);
    }

    private ArtEntry navigateHistory(int delta) throws IOException, JSONException {
        synchronized (NETWORK_LOCK) {
            int targetIndex;
            ArtEntry target;
            synchronized (DATA_LOCK) {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                int index = prefs.getInt(KEY_INDEX, -1);
                targetIndex = index + delta;
                if (history.isEmpty() || targetIndex < 0 || targetIndex >= history.size()) return getCurrent();
                target = history.get(targetIndex);
            }
            ArtEntry ready = ensureLocalImage(target).markedShown();
            synchronized (DATA_LOCK) {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                if (targetIndex < 0 || targetIndex >= history.size()) return getCurrent();
                history.set(targetIndex, ready);
                writeEntries(KEY_HISTORY, history);
                updateStatsLocked(history);
                prefs.edit().putInt(KEY_INDEX, targetIndex)
                        .putString(KEY_CURRENT, ready.toJson().toString()).apply();
            }
            return ready;
        }
    }

    public ArtEntry installOnWidget(String qid) throws IOException, JSONException {
        synchronized (NETWORK_LOCK) {
            ArtEntry found = findEntry(qid);
            if (found == null) throw new IOException("Произведение не найдено");
            found = ensureLocalImage(found).markedShown();
            appendHistory(found);
            enforceCacheLimit();
            return found;
        }
    }

    public ArtEntry dislikeCurrentAndFetchNext() throws IOException, JSONException {
        ArtEntry current = getCurrent();
        if (current == null) return fetchNextArtwork();
        addDislikeRecord(current);
        ArtEntry next = fetchNextArtwork();
        if (next != null && !next.qid.equals(current.qid)) {
            synchronized (DATA_LOCK) {
                deleteFileQuietly(current.localPath);
                clearLocalPathInHistory(current.qid);
            }
        }
        return next;
    }

    public boolean toggleFavorite(ArtEntry entry) {
        if (entry == null) return false;
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> list = readEntries(KEY_FAVORITES);
                int idx = indexOf(list, entry.qid);
                boolean nowFavorite;
                if (idx >= 0) {
                    list.remove(idx);
                    nowFavorite = false;
                } else {
                    list.add(entry);
                    nowFavorite = true;
                }
                writeEntries(KEY_FAVORITES, list);
                return nowFavorite;
            } catch (Exception e) {
                AppLogger.log(context, "favorite", "error", e.getMessage());
                return false;
            }
        }
    }

    public void setDisliked(ArtEntry entry, boolean disliked) {
        if (entry == null) return;
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> list = readEntries(KEY_DISLIKES);
                int idx = indexOf(list, entry.qid);
                if (disliked && idx < 0) {
                    list.add(entry.withLocalPath(""));
                } else if (!disliked && idx >= 0) {
                    list.remove(idx);
                }
                writeEntries(KEY_DISLIKES, list);
                if (disliked) {
                    ArtEntry current = getCurrent();
                    if (current == null || !current.qid.equals(entry.qid)) {
                        deleteFileQuietly(entry.localPath);
                        clearLocalPathInHistory(entry.qid);
                    }
                    removeFromQueue(entry.qid);
                }
            } catch (Exception e) {
                AppLogger.log(context, "dislike", "error", e.getMessage());
            }
        }
    }

    private void addDislikeRecord(ArtEntry entry) {
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> list = readEntries(KEY_DISLIKES);
                if (indexOf(list, entry.qid) < 0) {
                    list.add(entry.withLocalPath(""));
                    writeEntries(KEY_DISLIKES, list);
                }
                removeFromQueue(entry.qid);
            } catch (Exception e) {
                AppLogger.log(context, "dislike", "error", e.getMessage());
            }
        }
    }

    public boolean isFavorite(String qid) {
        synchronized (DATA_LOCK) {
            try { return indexOf(readEntries(KEY_FAVORITES), qid) >= 0; }
            catch (Exception e) { return false; }
        }
    }

    public boolean isDisliked(String qid) {
        synchronized (DATA_LOCK) {
            try { return indexOf(readEntries(KEY_DISLIKES), qid) >= 0; }
            catch (Exception e) { return false; }
        }
    }

    public List<ArtEntry> getCachedEntries() {
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                LinkedUniqueMap unique = new LinkedUniqueMap();
                for (int i = history.size() - 1; i >= 0; i--) {
                    ArtEntry e = history.get(i);
                    if (fileExists(e.localPath)) unique.putIfAbsent(e.qid, e);
                }
                return unique.values();
            } catch (Exception e) {
                return new ArrayList<>();
            }
        }
    }

    public List<ArtEntry> getFavoriteEntries() {
        synchronized (DATA_LOCK) {
            try { return readEntries(KEY_FAVORITES); }
            catch (Exception e) { return new ArrayList<>(); }
        }
    }

    public List<ArtEntry> getDislikedEntries() {
        synchronized (DATA_LOCK) {
            try { return readEntries(KEY_DISLIKES); }
            catch (Exception e) { return new ArrayList<>(); }
        }
    }

    public List<ArtEntry> getHistoryEntries() {
        synchronized (DATA_LOCK) {
            try { return readEntries(KEY_HISTORY); }
            catch (Exception e) { return new ArrayList<>(); }
        }
    }

    public ArtEntry findEntry(String qid) {
        if (qid == null || qid.isEmpty()) return null;
        synchronized (DATA_LOCK) {
            try {
                for (String key : new String[]{KEY_HISTORY, KEY_FAVORITES, KEY_DISLIKES, KEY_CATALOG}) {
                    List<ArtEntry> list = readEntries(key);
                    int idx = indexOf(list, qid);
                    if (idx >= 0) return list.get(idx);
                }
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    public int getCacheCount() {
        int value = prefs.getInt(KEY_CACHE_COUNT, -1);
        if (value >= 0) return value;
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                updateStatsLocked(history);
                return prefs.getInt(KEY_CACHE_COUNT, 0);
            } catch (Exception e) { return 0; }
        }
    }

    public long getCacheSizeBytes() {
        long total = 0L;
        for (ArtEntry e : getCachedEntries()) {
            try { total += new File(e.localPath).length(); } catch (Exception ignored) { }
        }
        return total;
    }

    public int getCatalogCount() {
        int value = prefs.getInt(KEY_CATALOG_COUNT, -1);
        if (value >= 0) return value;
        synchronized (DATA_LOCK) {
            try {
                int count = readEntries(KEY_CATALOG).size();
                prefs.edit().putInt(KEY_CATALOG_COUNT, count).apply();
                return count;
            } catch (Exception e) { return 0; }
        }
    }

    public int getHistoryIndex() {
        return prefs.getInt(KEY_INDEX, -1);
    }

    public int getHistoryCount() {
        int value = prefs.getInt(KEY_HISTORY_COUNT, -1);
        if (value >= 0) return value;
        synchronized (DATA_LOCK) {
            try {
                int count = readEntries(KEY_HISTORY).size();
                prefs.edit().putInt(KEY_HISTORY_COUNT, count).apply();
                return count;
            } catch (Exception e) { return 0; }
        }
    }

    public int getContentMode() {
        int mode = prefs.getInt(KEY_CONTENT_MODE, CONTENT_FILTER);
        return mode < CONTENT_FILTER || mode > CONTENT_ADULT_ONLY ? CONTENT_FILTER : mode;
    }

    public void setContentMode(int mode) {
        if (mode < CONTENT_FILTER || mode > CONTENT_ADULT_ONLY) mode = CONTENT_FILTER;
        prefs.edit().putInt(KEY_CONTENT_MODE, mode).remove(KEY_QUEUE).putInt(KEY_QUEUE_INDEX, 0).apply();
    }

    public void deleteLocalFile(String qid) {
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                for (int i = 0; i < history.size(); i++) {
                    ArtEntry e = history.get(i);
                    if (e.qid.equals(qid)) {
                        deleteFileQuietly(e.localPath);
                        history.set(i, e.withLocalPath(""));
                    }
                }
                writeEntries(KEY_HISTORY, history);
                updateStatsLocked(history);
                refreshCurrentFromHistoryLocked(history);
            } catch (Exception ignored) { }
        }
    }

    public void clearOrdinaryCache() {
        synchronized (DATA_LOCK) {
            try {
                Set<String> favorites = idSet(readEntries(KEY_FAVORITES));
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                for (int i = 0; i < history.size(); i++) {
                    ArtEntry e = history.get(i);
                    if (!favorites.contains(e.qid)) {
                        deleteFileQuietly(e.localPath);
                        history.set(i, e.withLocalPath(""));
                    }
                }
                writeEntries(KEY_HISTORY, history);
                updateStatsLocked(history);
                refreshCurrentFromHistoryLocked(history);
                clearDirectory(new File(context.getCacheDir(), "art_temp"));
                clearDirectory(new File(context.getCacheDir(), "gallery_thumbs"));
            } catch (Exception e) {
                AppLogger.log(context, "clearCache", "error", e.getMessage());
            }
        }
    }

    public void clearHistory() {
        synchronized (DATA_LOCK) {
            prefs.edit().putString(KEY_HISTORY, "[]").putInt(KEY_INDEX, -1).remove(KEY_CURRENT)
                    .putInt(KEY_HISTORY_COUNT, 0).putInt(KEY_CACHE_COUNT, 0)
                    .remove(KEY_QUEUE).putInt(KEY_QUEUE_INDEX, 0).apply();
        }
    }

    public File downloadTemporaryThumbnail(ArtEntry entry) throws IOException {
        if (entry == null || entry.imageUrl.isEmpty()) throw new IOException("Миниатюра недоступна");
        File dir = new File(context.getCacheDir(), "gallery_thumbs");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать временную папку");
        File file = new File(dir, safeFileName(entry.qid) + ".img");
        if (file.exists() && file.length() > 0) return file;
        downloadFile(entry.imageUrl, file);
        return file;
    }

    public void clearTemporaryThumbnails() {
        clearDirectory(new File(context.getCacheDir(), "gallery_thumbs"));
    }

    private ArtEntry nextCatalogCandidate() throws IOException, JSONException {
        for (int pageAttempt = 0; pageAttempt < MAX_PAGE_ATTEMPTS_PER_UPDATE; pageAttempt++) {
            ArtEntry candidate = takeFromQueue();
            if (candidate != null) return candidate;

            boolean end = prefs.getBoolean(KEY_CATALOG_END, false);
            if (!end) {
                int added = fetchAndAppendCatalogPage();
                if (added > 0) {
                    rebuildQueue(false);
                    candidate = takeFromQueue();
                    if (candidate != null) return candidate;
                }
            } else {
                break;
            }
        }

        synchronized (DATA_LOCK) {
            if (readEntries(KEY_CATALOG).isEmpty()) addFallbackCatalogLocked();
        }
        rebuildQueue(true);
        ArtEntry repeated = takeFromQueue();
        if (repeated == null) throw new IOException("Подходящие произведения не найдены");
        return repeated;
    }

    private ArtEntry takeFromQueue() throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> catalog = readEntries(KEY_CATALOG);
            Map<String, ArtEntry> byId = new HashMap<>();
            for (ArtEntry e : catalog) byId.put(e.qid, e);
            JSONArray queue = new JSONArray(prefs.getString(KEY_QUEUE, "[]"));
            int index = prefs.getInt(KEY_QUEUE_INDEX, 0);
            Set<String> disliked = idSet(readEntries(KEY_DISLIKES));
            int mode = getContentMode();
            while (index < queue.length()) {
                String qid = queue.optString(index++, "");
                prefs.edit().putInt(KEY_QUEUE_INDEX, index).apply();
                ArtEntry e = byId.get(qid);
                if (e == null || disliked.contains(qid)) continue;
                if (!matchesContentMode(e, mode) || isUnwanted(e)) continue;
                return e;
            }
            return null;
        }
    }

    private void rebuildQueue(boolean allowRepeats) throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> catalog = readEntries(KEY_CATALOG);
            Set<String> shown = allowRepeats ? new HashSet<>() : idSet(readEntries(KEY_HISTORY));
            Set<String> disliked = idSet(readEntries(KEY_DISLIKES));
            int mode = getContentMode();
            List<String> ids = new ArrayList<>();
            for (ArtEntry e : catalog) {
                if (disliked.contains(e.qid) || shown.contains(e.qid)) continue;
                if (isUnwanted(e) || !matchesContentMode(e, mode)) continue;
                ids.add(e.qid);
            }
            Collections.shuffle(ids, random);
            JSONArray queue = new JSONArray();
            for (String id : ids) queue.put(id);
            prefs.edit().putString(KEY_QUEUE, queue.toString()).putInt(KEY_QUEUE_INDEX, 0).apply();
        }
    }

    private int fetchAndAppendCatalogPage() throws IOException, JSONException {
        int offset = prefs.getInt(KEY_CATALOG_OFFSET, 0);
        String sparql = "SELECT ?item ?itemLabel ?itemDescription ?image ?creatorLabel ?article ?instanceLabel ?materialLabel ?genreLabel WHERE { "
                + "?item wdt:P31/wdt:P279* wd:Q3305213. "
                + "?item wdt:P18 ?image. "
                + "?article schema:about ?item; schema:isPartOf <https://ru.wikipedia.org/>. "
                + "OPTIONAL { ?item wdt:P170 ?creator. } "
                + "OPTIONAL { ?item wdt:P31 ?instance. } "
                + "OPTIONAL { ?item wdt:P186 ?material. } "
                + "OPTIONAL { ?item wdt:P136 ?genre. } "
                + "SERVICE wikibase:label { bd:serviceParam wikibase:language \"ru,en\". } "
                + "} ORDER BY ?item LIMIT " + PAGE_SIZE + " OFFSET " + offset;
        String body = "query=" + urlEncode(sparql) + "&format=json";
        JSONObject json = readJsonPost("https://query.wikidata.org/sparql", body,
                "application/x-www-form-urlencoded; charset=UTF-8");
        JSONObject results = json.optJSONObject("results");
        JSONArray bindings = results == null ? null : results.optJSONArray("bindings");
        if (bindings == null) bindings = new JSONArray();

        List<ArtEntry> page = new ArrayList<>();
        Set<String> pageIds = new HashSet<>();
        for (int i = 0; i < bindings.length(); i++) {
            JSONObject b = bindings.optJSONObject(i);
            if (b == null) continue;
            String itemUrl = bindingValue(b, "item");
            String qid = qidFromUrl(itemUrl);
            String title = bindingValue(b, "itemLabel");
            String artist = ArtEntry.sanitizeArtist(bindingValue(b, "creatorLabel"));
            String description = bindingValue(b, "itemDescription");
            String image = bindingValue(b, "image");
            String article = bindingValue(b, "article");
            String instance = bindingValue(b, "instanceLabel");
            String material = bindingValue(b, "materialLabel");
            String genre = bindingValue(b, "genreLabel");
            if (qid.isEmpty() || title.isEmpty() || title.matches("Q\\d+") || article.isEmpty() || image.isEmpty()) continue;
            if (image.toLowerCase(Locale.ROOT).endsWith(".svg")) continue;
            if (!pageIds.add(qid)) continue;
            ArtEntry e = ArtEntry.catalog(qid, title, artist,
                    description.isEmpty() ? "" : description, normalizedImageUrl(image), article,
                    instance, material, genre, classifyExplicit(title, description, genre));
            if (!isUnwanted(e)) page.add(e);
        }

        int added;
        synchronized (DATA_LOCK) {
            List<ArtEntry> catalog = readEntries(KEY_CATALOG);
            Set<String> existing = idSet(catalog);
            added = 0;
            for (ArtEntry e : page) {
                if (existing.add(e.qid)) {
                    catalog.add(e);
                    added++;
                }
            }
            writeEntries(KEY_CATALOG, catalog);
            SharedPreferences.Editor editor = prefs.edit().putInt(KEY_CATALOG_OFFSET, offset + PAGE_SIZE)
                    .putInt(KEY_CATALOG_COUNT, catalog.size());
            if (bindings.length() < PAGE_SIZE) editor.putBoolean(KEY_CATALOG_END, true);
            editor.apply();
        }
        AppLogger.log(context, "catalog", "page", "offset=" + offset + ", rows=" + bindings.length() + ", added=" + added);
        return added;
    }

    private ArtEntry downloadArtwork(ArtEntry candidate) throws IOException, JSONException {
        String pageTitle = pageTitleFromArticle(candidate.sourceUrl, candidate.title);
        String apiUrl = "https://ru.wikipedia.org/w/api.php?action=query"
                + "&format=json&formatversion=2&redirects=1"
                + "&prop=extracts%7Cpageimages"
                + "&exintro=1&explaintext=1"
                + "&piprop=thumbnail%7Coriginal%7Cname"
                + "&pithumbsize=1600"
                + "&titles=" + urlEncode(pageTitle);
        JSONObject json = readJson(apiUrl);
        JSONObject query = json.optJSONObject("query");
        JSONArray pages = query == null ? null : query.optJSONArray("pages");
        JSONObject page = pages == null || pages.length() == 0 ? null : pages.optJSONObject(0);

        String description = candidate.description;
        String standardUrl = "";
        String originalUrl = "";
        String finalSource = candidate.sourceUrl;
        if (page != null && !page.optBoolean("missing", false)) {
            description = shortDescription(page.optString("extract", description));
            JSONObject thumb = page.optJSONObject("thumbnail");
            JSONObject original = page.optJSONObject("original");
            if (thumb != null) standardUrl = thumb.optString("source", "");
            if (original != null) originalUrl = original.optString("source", "");
            if (standardUrl.isEmpty()) standardUrl = originalUrl;
            if (originalUrl.isEmpty()) originalUrl = standardUrl;
            String finalTitle = page.optString("title", pageTitle);
            finalSource = "https://ru.wikipedia.org/wiki/" + encodePath(finalTitle.replace(' ', '_'));
        }
        if (standardUrl.isEmpty()) standardUrl = candidate.imageUrl;
        if (originalUrl.isEmpty()) originalUrl = standardUrl;
        if (standardUrl.isEmpty()) throw new IOException("У страницы нет подходящего изображения");
        if (standardUrl.toLowerCase(Locale.ROOT).endsWith(".svg")) throw new IOException("Векторный файл пропущен");

        File dir = new File(context.getFilesDir(), "art_cache");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку кэша");
        File tmp = new File(dir, safeFileName(candidate.qid) + "_" + System.currentTimeMillis() + ".tmp");
        downloadFile(standardUrl, tmp);
        File stem = new File(dir, safeFileName(candidate.qid) + "_" + System.currentTimeMillis());
        File processed;
        try {
            processed = ImageProcessor.processToStandard(tmp, stem);
        } finally {
            deleteFileQuietly(tmp.getAbsolutePath());
        }
        return new ArtEntry(candidate.qid, candidate.title, candidate.artist,
                description.isEmpty() ? "Краткое описание отсутствует" : description,
                standardUrl, originalUrl, processed.getAbsolutePath(), finalSource,
                candidate.instanceLabel, candidate.materialLabel, candidate.genreLabel,
                System.currentTimeMillis(), System.currentTimeMillis(), 1,
                candidate.explicitContent || classifyExplicit(candidate.title, description, candidate.genreLabel));
    }

    private ArtEntry ensureLocalImage(ArtEntry entry) throws IOException, JSONException {
        if (entry == null) return null;
        if (fileExists(entry.localPath)) return entry;
        return downloadArtwork(entry);
    }

    private void appendHistory(ArtEntry entry) throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> history = readEntries(KEY_HISTORY);
            history.add(entry);
            while (history.size() > MAX_HISTORY_RECORDS) history.remove(0);
            writeEntries(KEY_HISTORY, history);
            updateStatsLocked(history);
            prefs.edit().putInt(KEY_INDEX, history.size() - 1)
                    .putString(KEY_CURRENT, entry.toJson().toString()).apply();
        }
    }

    private void replaceHistoryEntry(ArtEntry entry) throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> history = readEntries(KEY_HISTORY);
            int index = prefs.getInt(KEY_INDEX, -1);
            if (index >= 0 && index < history.size()) {
                history.set(index, entry);
                writeEntries(KEY_HISTORY, history);
                updateStatsLocked(history);
                prefs.edit().putString(KEY_CURRENT, entry.toJson().toString()).apply();
            }
        }
    }

    private void enforceCacheLimit() throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> history = readEntries(KEY_HISTORY);
            Set<String> favorites = idSet(readEntries(KEY_FAVORITES));
            Set<String> dislikes = idSet(readEntries(KEY_DISLIKES));
            int currentIndex = prefs.getInt(KEY_INDEX, -1);
            while (countFiles(history) > MAX_CACHE_FILES) {
                int victim = findVictim(history, dislikes, favorites, currentIndex, true);
                if (victim < 0) victim = findVictim(history, dislikes, favorites, currentIndex, false);
                if (victim < 0) break;
                ArtEntry e = history.get(victim);
                deleteFileQuietly(e.localPath);
                history.set(victim, e.withLocalPath(""));
            }
            writeEntries(KEY_HISTORY, history);
            updateStatsLocked(history);
            refreshCurrentFromHistoryLocked(history);
        }
    }

    private int findVictim(List<ArtEntry> history, Set<String> dislikes, Set<String> favorites,
                           int currentIndex, boolean dislikedOnly) {
        int victim = -1;
        long oldest = Long.MAX_VALUE;
        for (int i = 0; i < history.size(); i++) {
            ArtEntry e = history.get(i);
            if (!fileExists(e.localPath) || i == currentIndex || favorites.contains(e.qid)) continue;
            if (dislikedOnly && !dislikes.contains(e.qid)) continue;
            if (!dislikedOnly && dislikes.contains(e.qid)) continue;
            if (e.lastShownAt < oldest) {
                oldest = e.lastShownAt;
                victim = i;
            }
        }
        return victim;
    }

    private void clearLocalPathInHistory(String qid) throws JSONException {
        List<ArtEntry> history = readEntries(KEY_HISTORY);
        for (int i = 0; i < history.size(); i++) {
            ArtEntry e = history.get(i);
            if (e.qid.equals(qid)) history.set(i, e.withLocalPath(""));
        }
        writeEntries(KEY_HISTORY, history);
        updateStatsLocked(history);
        refreshCurrentFromHistoryLocked(history);
    }

    private void removeFromQueue(String qid) {
        try {
            JSONArray queue = new JSONArray(prefs.getString(KEY_QUEUE, "[]"));
            JSONArray out = new JSONArray();
            for (int i = 0; i < queue.length(); i++) {
                String id = queue.optString(i, "");
                if (!qid.equals(id)) out.put(id);
            }
            prefs.edit().putString(KEY_QUEUE, out.toString()).putInt(KEY_QUEUE_INDEX, 0).apply();
        } catch (Exception ignored) { }
    }

    private void migrateIfNeeded() {
        if (prefs.getBoolean(KEY_MIGRATED, false)) return;
        synchronized (DATA_LOCK) {
            if (prefs.getBoolean(KEY_MIGRATED, false)) return;
            try {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                writeEntries(KEY_HISTORY, history);
                updateStatsLocked(history);
                refreshCurrentFromHistoryLocked(history);
                List<ArtEntry> catalog = readEntries(KEY_CATALOG);
                if (catalog.isEmpty()) addFallbackCatalogLocked();
                else {
                    List<ArtEntry> unique = uniqueById(catalog);
                    writeEntries(KEY_CATALOG, unique);
                    prefs.edit().putInt(KEY_CATALOG_COUNT, unique.size()).apply();
                }
                if (!prefs.contains(KEY_CATALOG_OFFSET)) {
                    int oldCount = catalog.size();
                    prefs.edit().putInt(KEY_CATALOG_OFFSET, oldCount >= 800 ? 1000 : 0).apply();
                }
                prefs.edit().putBoolean(KEY_MIGRATED, true).remove(KEY_QUEUE).putInt(KEY_QUEUE_INDEX, 0).apply();
            } catch (Exception e) {
                AppLogger.log(context, "migration", "error", e.getMessage());
                prefs.edit().putBoolean(KEY_MIGRATED, true).apply();
            }
        }
    }

    private void addFallbackCatalogLocked() throws JSONException {
        List<ArtEntry> catalog = readEntries(KEY_CATALOG);
        Set<String> ids = idSet(catalog);
        for (ArtEntry e : fallbackCatalog()) if (ids.add(e.qid)) catalog.add(e);
        writeEntries(KEY_CATALOG, catalog);
        prefs.edit().putInt(KEY_CATALOG_COUNT, catalog.size()).apply();
    }

    private List<ArtEntry> fallbackCatalog() {
        List<ArtEntry> out = new ArrayList<>();
        out.add(fallback("Q12418", "Мона Лиза", "Леонардо да Винчи", "Мона Лиза"));
        out.add(fallback("Q151047", "Сотворение Адама", "Микеланджело", "Сотворение Адама"));
        out.add(fallback("Q185372", "Рождение Венеры", "Сандро Боттичелли", "Рождение Венеры"));
        out.add(fallback("Q166713", "Девушка с жемчужной серёжкой", "Ян Вермеер", "Девушка с жемчужной серёжкой"));
        out.add(fallback("Q219831", "Ночной дозор", "Рембрандт", "Ночной дозор"));
        out.add(fallback("Q160112", "Менины", "Диего Веласкес", "Менины"));
        out.add(fallback("Q178426", "Плот „Медузы“", "Теодор Жерико", "Плот «Медузы»"));
        out.add(fallback("Q219344", "Свобода, ведущая народ", "Эжен Делакруа", "Свобода, ведущая народ"));
        out.add(fallback("Q188855", "Звёздная ночь", "Винсент ван Гог", "Звёздная ночь"));
        out.add(fallback("Q130994", "Крик", "Эдвард Мунк", "Крик (картина)"));
        out.add(fallback("Q45585", "Девятый вал", "Иван Айвазовский", "Девятый вал"));
        out.add(fallback("Q394558", "Бурлаки на Волге", "Илья Репин", "Бурлаки на Волге"));
        out.add(fallback("Q321303", "Чёрный квадрат", "Казимир Малевич", "Чёрный квадрат"));
        return out;
    }

    private ArtEntry fallback(String qid, String title, String artist, String pageTitle) {
        String source = "https://ru.wikipedia.org/wiki/" + pageTitle.replace(' ', '_');
        return ArtEntry.catalog(qid, title, artist, "", "", source, "картина", "", "", false);
    }

    private boolean isUnwanted(ArtEntry e) {
        String text = (e.title + " " + e.instanceLabel + " " + e.materialLabel + " " + e.genreLabel).toLowerCase(Locale.ROOT);
        if (isFamousMonumental(e)) return false;
        String[] always = new String[]{
                "алтар", "altarpiece", "retable", "ретабло", "церковный интерьер", "church interior",
                "архитектурный фрагмент", "architectural fragment", "museum interior", "экспозици",
                "предмет прикладного", "decorative object", "археологический объект"
        };
        for (String s : always) if (text.contains(s)) return true;
        String[] conditional = new String[]{
                "икон", "icon", "фреск", "fresco", "mural", "настенная роспись", "wall painting",
                "мозаик", "mosaic", "триптих", "triptych", "полиптих", "polyptych",
                "декоративная панель", "археологический фрагмент"
        };
        for (String s : conditional) {
            if (text.contains(s) && ArtEntry.isUnknownArtist(e.artist)) return true;
            if ((text.contains("икон") || text.contains("altarpiece") || text.contains("алтар")) && text.contains(s)) return true;
        }
        return false;
    }

    private boolean isFamousMonumental(ArtEntry e) {
        String t = e.title.toLowerCase(Locale.ROOT);
        return t.contains("сотворение адама") || t.contains("тайная вечеря")
                || t.contains("страшный суд") || t.contains("афинская школа");
    }

    private boolean matchesContentMode(ArtEntry e, int mode) {
        if (mode == CONTENT_ALL) return true;
        if (mode == CONTENT_ADULT_ONLY) return e.explicitContent;
        return !e.explicitContent;
    }

    private boolean classifyExplicit(String title, String description, String genre) {
        String text = (safe(title) + " " + safe(description) + " " + safe(genre)).toLowerCase(Locale.ROOT);
        String[] terms = new String[]{
                "происхождение мира", "l'origine du monde", "генитал", "половой акт", "sexual intercourse",
                "эротичес", "erotic", "обнажённая", "обнаженная", "обнажённый", "обнаженный",
                "nude", "nudity", "ню ", "акт (живопись)"
        };
        for (String s : terms) if (text.contains(s)) return true;
        return false;
    }

    private String shortDescription(String extract) {
        String text = safe(extract).replaceAll("\\s+", " ").trim();
        if (text.isEmpty()) return "Краткое описание отсутствует";
        String[] sentences = text.split("(?<=[.!?])\\s+");
        StringBuilder sb = new StringBuilder();
        for (String sentence : sentences) {
            String s = sentence.trim();
            if (s.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(s);
            if (sb.length() >= 420 || countSentenceEnds(sb.toString()) >= 5) break;
        }
        String result = sb.length() == 0 ? text : sb.toString();
        if (result.length() > 760) result = result.substring(0, 760).trim() + "…";
        return result;
    }

    private int countSentenceEnds(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '.' || s.charAt(i) == '!' || s.charAt(i) == '?') count++;
        return count;
    }

    private List<ArtEntry> readEntries(String key) throws JSONException {
        JSONArray array = new JSONArray(prefs.getString(key, "[]"));
        List<ArtEntry> list = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject o = array.optJSONObject(i);
            if (o != null) list.add(ArtEntry.fromJson(o));
        }
        return list;
    }

    private void writeEntries(String key, List<ArtEntry> list) throws JSONException {
        JSONArray array = new JSONArray();
        for (ArtEntry e : list) array.put(e.toJson());
        prefs.edit().putString(key, array.toString()).apply();
    }

    private List<ArtEntry> uniqueById(List<ArtEntry> list) {
        LinkedUniqueMap map = new LinkedUniqueMap();
        for (ArtEntry e : list) map.putIfAbsent(e.qid, e);
        return map.values();
    }

    private int indexOf(List<ArtEntry> list, String qid) {
        if (qid == null) return -1;
        for (int i = 0; i < list.size(); i++) if (qid.equals(list.get(i).qid)) return i;
        return -1;
    }

    private Set<String> idSet(List<ArtEntry> list) {
        Set<String> set = new HashSet<>();
        for (ArtEntry e : list) set.add(e.qid);
        return set;
    }

    private int countFiles(List<ArtEntry> history) {
        Set<String> paths = new HashSet<>();
        for (ArtEntry e : history) if (fileExists(e.localPath)) paths.add(e.localPath);
        return paths.size();
    }

    private String pageTitleFromArticle(String articleUrl, String fallback) {
        try {
            if (articleUrl != null && articleUrl.contains("/wiki/")) {
                String part = articleUrl.substring(articleUrl.indexOf("/wiki/") + 6);
                return URLDecoder.decode(part, "UTF-8").replace('_', ' ');
            }
        } catch (Exception ignored) { }
        return fallback;
    }

    private String bindingValue(JSONObject binding, String key) {
        JSONObject o = binding.optJSONObject(key);
        return o == null ? "" : o.optString("value", "").trim();
    }

    private String qidFromUrl(String value) {
        if (value == null) return "";
        int slash = value.lastIndexOf('/');
        String qid = slash >= 0 ? value.substring(slash + 1) : value;
        return qid.matches("Q\\d+") ? qid : "";
    }

    private JSONObject readJson(String url) throws IOException, JSONException {
        return new JSONObject(readText(url));
    }

    private JSONObject readJsonPost(String url, String body, String contentType) throws IOException, JSONException {
        return new JSONObject(readTextPost(url, body, contentType));
    }

    private String readText(String urlString) throws IOException {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(urlString).openConnection();
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setRequestProperty("Accept", "application/json,text/plain,*/*");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(16000);
            int code = conn.getResponseCode();
            InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            byte[] bytes = input == null ? new byte[0] : readAll(input);
            if (code < 200 || code >= 300) throw httpException(code, conn);
            return new String(bytes, "UTF-8");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private String readTextPost(String urlString, String body, String contentType) throws IOException {
        HttpURLConnection conn = null;
        try {
            byte[] data = body.getBytes("UTF-8");
            conn = (HttpURLConnection) new URL(urlString).openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setRequestProperty("Accept", "application/sparql-results+json,application/json");
            conn.setRequestProperty("Content-Type", contentType);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(26000);
            try (OutputStream out = conn.getOutputStream()) { out.write(data); }
            int code = conn.getResponseCode();
            InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            byte[] bytes = input == null ? new byte[0] : readAll(input);
            if (code < 200 || code >= 300) throw httpException(code, conn);
            return new String(bytes, "UTF-8");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void downloadFile(String urlString, File outFile) throws IOException {
        HttpURLConnection conn = null;
        File tmp = new File(outFile.getAbsolutePath() + ".part");
        deleteFileQuietly(tmp.getAbsolutePath());
        try {
            conn = (HttpURLConnection) new URL(normalizedImageUrl(urlString)).openConnection();
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(9000);
            conn.setReadTimeout(22000);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw httpException(code, conn);
            String type = conn.getContentType();
            if (type != null && !type.toLowerCase(Locale.ROOT).startsWith("image/")) {
                throw new IOException("Сервер вернул не изображение");
            }
            try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(tmp))) {
                byte[] buffer = new byte[16384];
                int read;
                long total = 0;
                while ((read = in.read(buffer)) != -1) {
                    total += read;
                    if (total > 35L * 1024L * 1024L) throw new IOException("Изображение слишком большое");
                    out.write(buffer, 0, read);
                }
            }
            if (outFile.exists()) outFile.delete();
            if (!tmp.renameTo(outFile)) throw new IOException("Не удалось сохранить изображение");
        } finally {
            if (conn != null) conn.disconnect();
            deleteFileQuietly(tmp.getAbsolutePath());
        }
    }

    private IOException httpException(int code, HttpURLConnection conn) {
        if (code == 429) {
            String retry = conn == null ? null : conn.getHeaderField("Retry-After");
            return new IOException("Слишком частые запросы. Повторите позже" + (retry == null ? "" : " (через " + retry + " с)"));
        }
        if (code == 404) return new IOException("Изображение или статья не найдены");
        if (code >= 500) return new IOException("Сервис временно недоступен");
        return new IOException("Ошибка сети: HTTP " + code);
    }

    private byte[] readAll(InputStream input) throws IOException {
        try (BufferedInputStream in = new BufferedInputStream(input);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            return out.toByteArray();
        }
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private boolean isRateLimit(Exception e) {
        return e != null && e.getMessage() != null && e.getMessage().contains("Слишком частые запросы");
    }

    private String friendlyMessage(Exception e) {
        String msg = e == null ? "Неизвестная ошибка" : e.getMessage();
        if (msg == null || msg.trim().isEmpty()) return "Не удалось загрузить изображение";
        if (msg.length() > 220) return msg.substring(0, 220).trim() + "…";
        return msg;
    }

    private boolean fileExists(String path) {
        if (path == null || path.trim().isEmpty()) return false;
        File f = new File(path);
        return f.exists() && f.length() > 0;
    }

    private void deleteFileQuietly(String path) {
        try {
            if (path != null && !path.trim().isEmpty()) new File(path).delete();
        } catch (Exception ignored) { }
    }

    private void clearDirectory(File dir) {
        try {
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) f.delete();
        } catch (Exception ignored) { }
    }

    private String normalizedImageUrl(String value) {
        String s = safe(value);
        if (s.startsWith("http://")) s = "https://" + s.substring(7);
        if (s.contains("/wiki/Special:FilePath/") && !s.contains("?")) s += "?width=1600";
        return s;
    }

    private String safeFileName(String value) {
        String s = safe(value).replaceAll("[^A-Za-z0-9._-]", "_");
        return s.isEmpty() ? "art" : s;
    }

    private String urlEncode(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8");
    }

    private String encodePath(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
    }

    private String safe(String value) {
        return value == null ? "" : value.replace('\n', ' ').replace('\r', ' ').trim();
    }


    private void updateStatsLocked(List<ArtEntry> history) {
        Set<String> paths = new HashSet<>();
        for (ArtEntry e : history) if (fileExists(e.localPath)) paths.add(e.localPath);
        prefs.edit().putInt(KEY_HISTORY_COUNT, history.size()).putInt(KEY_CACHE_COUNT, paths.size()).apply();
    }

    private void refreshCurrentFromHistoryLocked(List<ArtEntry> history) {
        try {
            int index = prefs.getInt(KEY_INDEX, -1);
            if (index >= 0 && index < history.size()) {
                prefs.edit().putString(KEY_CURRENT, history.get(index).toJson().toString()).apply();
            } else {
                prefs.edit().remove(KEY_CURRENT).apply();
            }
        } catch (Exception ignored) { }
    }

    private static class LinkedUniqueMap {
        private final Map<String, ArtEntry> map = new java.util.LinkedHashMap<>();
        void putIfAbsent(String key, ArtEntry value) { if (!map.containsKey(key)) map.put(key, value); }
        List<ArtEntry> values() { return new ArrayList<>(map.values()); }
    }
}
