package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Фоново добавляет в кэш одно произведение, не меняя текущую картину. */
public class CatalogUpdateWorker extends Worker {
    public static final String KEY_ADULT = "adult";
    public static final String KEY_FORCE = "force";

    public CatalogUpdateWorker(@NonNull Context context,
                               @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            repo.initializeStorageInBackground();
            repo.prefetchOneArtwork();
            return Result.success();
        } catch (Exception e) {
            // Ошибка фоновой загрузки не должна запускать бесконечные повторы
            // и никак не влияет на показ уже встроенных изображений.
            AppLogger.log(getApplicationContext(), "cache-prefetch", "error", e.getMessage());
            return Result.success();
        }
    }
}
