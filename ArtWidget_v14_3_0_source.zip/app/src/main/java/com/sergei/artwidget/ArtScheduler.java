package com.sergei.artwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public final class ArtScheduler {
    public static final String PREFS = "art_widget_prefs";
    public static final String KEY_INTERVAL_SECONDS = "interval_seconds";
    public static final String KEY_NEXT_AT_MILLIS = "next_update_at_millis";
    public static final String KEY_ENABLED = "automatic_updates_enabled_v14_2";
    public static final int DEFAULT_INTERVAL_SECONDS = 12 * 60 * 60;
    public static final int MIN_INTERVAL_SECONDS = 10;
    public static final int MAX_INTERVAL_SECONDS = 60 * 60 * 24 * 30;

    private ArtScheduler() { }

    public static boolean isEnabled(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) scheduleNext(context);
        else cancel(context);
    }

    public static int getIntervalSeconds(Context context) {
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int seconds = prefs.getInt(KEY_INTERVAL_SECONDS, DEFAULT_INTERVAL_SECONDS);
        if (!prefs.contains(KEY_INTERVAL_SECONDS) && prefs.contains("interval_hours")) {
            seconds = Math.max(1, prefs.getInt("interval_hours", 12)) * 3600;
            prefs.edit().putInt(KEY_INTERVAL_SECONDS, seconds).apply();
        }
        if (seconds < MIN_INTERVAL_SECONDS || seconds > MAX_INTERVAL_SECONDS) return DEFAULT_INTERVAL_SECONDS;
        return seconds;
    }

    public static void setIntervalSeconds(Context context, int seconds) {
        int value = Math.max(MIN_INTERVAL_SECONDS, Math.min(MAX_INTERVAL_SECONDS, seconds));
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putInt(KEY_INTERVAL_SECONDS, value).apply();
        scheduleNext(context);
    }

    public static void scheduleNext(Context context) {
        Context app = context.getApplicationContext();
        if (!isEnabled(app)) {
            cancel(app);
            return;
        }
        AlarmManager manager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        PendingIntent pi = pendingIntent(app);
        manager.cancel(pi);
        long triggerAt = System.currentTimeMillis() + getIntervalSeconds(app) * 1000L;
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putLong(KEY_NEXT_AT_MILLIS, triggerAt).apply();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (manager.canScheduleExactAlarms()) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                else manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                manager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (SecurityException e) {
            manager.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            AppLogger.log(app, "scheduler", "fallback", e.getMessage());
        }
    }

    public static void cancel(Context context) {
        Context app = context.getApplicationContext();
        AlarmManager manager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(pendingIntent(app));
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_NEXT_AT_MILLIS).apply();
    }

    public static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager manager = (AlarmManager) context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        return manager != null && manager.canScheduleExactAlarms();
    }

    public static long getNextAtMillis(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_NEXT_AT_MILLIS, 0L);
    }

    public static String nextUpdateDisplay(Context context) {
        boolean english = LanguageManager.isEnglish(context);
        if (!isEnabled(context)) return I18n.t(context,
                "Автообновление выключено",
                "Automatic updates are off");
        long next = getNextAtMillis(context);
        if (next <= 0L) return I18n.t(context,
                "Следующее обновление не запланировано",
                "The next update is not scheduled");
        Calendar now = Calendar.getInstance();
        Calendar target = Calendar.getInstance();
        target.setTimeInMillis(next);
        boolean sameDay = now.get(Calendar.ERA) == target.get(Calendar.ERA)
                && now.get(Calendar.YEAR) == target.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR);
        Locale locale = english ? Locale.ENGLISH : Locale.getDefault();
        if (sameDay) {
            return I18n.t(context, "Следующее обновление: сегодня в ", "Next update: today at ")
                    + new SimpleDateFormat("HH:mm", locale).format(new Date(next));
        }
        String pattern = english ? "MMMM d 'at' HH:mm" : "d MMMM 'в' HH:mm";
        return I18n.t(context, "Следующее обновление: ", "Next update: ")
                + new SimpleDateFormat(pattern, locale).format(new Date(next));
    }

    public static String intervalText(int seconds) {
        if (seconds < 60) return seconds + " сек.";
        if (seconds % 3600 == 0) return seconds / 3600 + " ч.";
        if (seconds % 60 == 0) return seconds / 60 + " мин.";
        return seconds + " сек.";
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, ScheduledUpdateReceiver.class);
        intent.setAction(ArtWidgetProvider.ACTION_SCHEDULED_UPDATE);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, 12001, intent, flags);
    }
}
