package com.sergei.artwidget;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SettingsActivity extends LocalizedActivity {
    private static final int SPACE = 8;
    private static final int OUTER = 16;

    private final ExecutorService statsExecutor = Executors.newSingleThreadExecutor();

    private Button filterButton;
    private Button allButton;
    private Button nsfwButton;
    private Button languageRuButton;
    private Button languageEnButton;
    private Button saveIntervalButton;
    private Button updateCatalogButton;
    private Button widgetButton;
    private Button exactAlarmButton;
    private EditText intervalValue;
    private Spinner unitSpinner;
    private TextView nextUpdateView;
    private TextView statusView;
    private TextView cacheValueView;
    private TextView cacheUsageView;
    private SeekBar cacheSeekBar;
    private Switch wifiOnlySwitch;
    private Switch onlyNewSwitch;
    private Switch autoUpdateSwitch;
    private boolean updatingUi;

    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        setContentView(createLayout());
        updateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUi();
    }

    @Override
    protected void onDestroy() {
        statsExecutor.shutdownNow();
        super.onDestroy();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(OUTER), dp(OUTER), dp(OUTER), dp(24));
        root.setBackgroundColor(bgColor);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(OUTER), top + dp(OUTER), dp(OUTER), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout appBar = horizontalRow();
        Button back = AppNavigation.backButton(this, textColor, v -> finish());
        back.setContentDescription(tr("Назад", "Back"));
        appBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = textView(22, true, textColor);
        title.setText(tr("Настройки", "Settings"));
        title.setGravity(Gravity.CENTER_VERTICAL);
        appBar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams appBarParams = matchWrap();
        appBarParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(appBar, appBarParams);

        statusView = textView(14, false, subTextColor);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackground(rounded(fieldColor, 13, borderColor, 1));
        statusView.setVisibility(View.GONE);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.setMargins(0, 0, 0, dp(12));
        root.addView(statusView, statusParams);

        LinearLayout contentCard = sectionCard();
        contentCard.addView(sectionTitle(tr("Контент", "Content")), matchWrap());
        LinearLayout segment = horizontalRow();
        filterButton = makeSegment(tr("Фильтр", "Filter"));
        allButton = makeSegment(tr("Все", "All"));
        nsfwButton = makeSegment(tr("Обнажённая натура", "Nude art"));
        segment.addView(filterButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        segment.addView(allButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        segment.addView(nsfwButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams segmentParams = matchWrap();
        segmentParams.setMargins(0, dp(SPACE), 0, 0);
        contentCard.addView(segment, segmentParams);
        TextView contentHint = textView(13, false, subTextColor);
        contentHint.setText(tr(
                "Фильтр скрывает картины с обнажённой натурой, но не является детским режимом.",
                "The filter hides nude artworks, but it is not a child-safe mode."));
        LinearLayout.LayoutParams contentHintParams = matchWrap();
        contentHintParams.setMargins(0, dp(SPACE), 0, 0);
        contentCard.addView(contentHint, contentHintParams);

        updateCatalogButton = makeButton(tr("Обновить каталог категории", "Update category catalog"), false);
        LinearLayout.LayoutParams updateCatalogParams = new LinearLayout.LayoutParams(-1, dp(50));
        updateCatalogParams.setMargins(0, dp(SPACE), 0, 0);
        contentCard.addView(updateCatalogButton, updateCatalogParams);
        updateCatalogButton.setOnClickListener(v -> updateCurrentCategoryCatalog());

        root.addView(contentCard, sectionParams());
        filterButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_FILTER));
        allButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_ALL));
        nsfwButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_ADULT_ONLY));

        LinearLayout cacheCard = sectionCard();
        LinearLayout cacheHeader = horizontalRow();
        cacheHeader.addView(sectionTitle(tr("Галерея кэша", "Cache gallery")), new LinearLayout.LayoutParams(0, -2, 1f));
        cacheValueView = textView(15, true, textColor);
        cacheValueView.setGravity(Gravity.END);
        cacheHeader.addView(cacheValueView, new LinearLayout.LayoutParams(0, -2, 1f));
        cacheCard.addView(cacheHeader, matchWrap());

        Button galleryButton = makeButton(tr("Открыть галерею кэша", "Open cache gallery"), false);
        LinearLayout.LayoutParams galleryParams = new LinearLayout.LayoutParams(-1, dp(50));
        galleryParams.setMargins(0, dp(SPACE), 0, 0);
        cacheCard.addView(galleryButton, galleryParams);
        galleryButton.setOnClickListener(v -> startActivity(new Intent(this, GalleryActivity.class)));

        cacheSeekBar = new SeekBar(this);
        cacheSeekBar.setMax(ArtRepository.GALLERY_CACHE_LIMIT_MAX_STEP);
        LinearLayout.LayoutParams cacheSeekParams = matchWrap();
        cacheSeekParams.setMargins(0, dp(SPACE), 0, 0);
        cacheCard.addView(cacheSeekBar, cacheSeekParams);
        cacheUsageView = textView(13, false, subTextColor);
        LinearLayout.LayoutParams cacheUsageParams = matchWrap();
        cacheUsageParams.setMargins(dp(4), dp(4), dp(4), 0);
        cacheCard.addView(cacheUsageView, cacheUsageParams);
        cacheSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                cacheValueView.setText(cacheLabel(progress));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                if (updatingUi) return;
                new ArtRepository(SettingsActivity.this).setGalleryCacheLimitStep(seekBar.getProgress());
                refreshCacheUsage();
            }
        });
        root.addView(cacheCard, sectionParams());

        LinearLayout networkCard = sectionCard();
        networkCard.addView(sectionTitle(tr("Сеть", "Network")), matchWrap());
        wifiOnlySwitch = makeSwitch(tr("Только Wi-Fi", "Wi-Fi only"));
        onlyNewSwitch = makeSwitch(tr("Показывать только новые картины", "Show only new artworks"));
        networkCard.addView(wifiOnlySwitch, new LinearLayout.LayoutParams(-1, dp(52)));
        networkCard.addView(onlyNewSwitch, new LinearLayout.LayoutParams(-1, dp(52)));
        wifiOnlySwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            if (updatingUi) return;
            new ArtRepository(this).setWifiOnly(checked);
        });
        onlyNewSwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            if (updatingUi) return;
            new ArtRepository(this).setOnlyNewMode(checked);
        });
        root.addView(networkCard, sectionParams());

        LinearLayout intervalCard = sectionCard();
        autoUpdateSwitch = makeSwitch(tr("Автообновление", "Automatic updates"));
        autoUpdateSwitch.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        autoUpdateSwitch.setTextSize(17);
        intervalCard.addView(autoUpdateSwitch, new LinearLayout.LayoutParams(-1, dp(48)));
        autoUpdateSwitch.setOnCheckedChangeListener((buttonView, checked) -> {
            if (updatingUi) return;
            ArtScheduler.setEnabled(this, checked);
            setIntervalControlsEnabled(checked);
            nextUpdateView.setText(ArtScheduler.nextUpdateDisplay(this));
            exactAlarmButton.setVisibility(checked && !ArtScheduler.canScheduleExact(this) ? View.VISIBLE : View.GONE);
        });

        LinearLayout intervalRow = horizontalRow();
        intervalValue = new EditText(this);
        intervalValue.setInputType(InputType.TYPE_CLASS_NUMBER);
        intervalValue.setSingleLine(true);
        intervalValue.setTextColor(textColor);
        intervalValue.setTextSize(16);
        intervalValue.setPadding(dp(14), 0, dp(14), 0);
        intervalValue.setBackground(rounded(fieldColor, 13, borderColor, 1));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        inputParams.setMargins(0, 0, dp(SPACE), 0);
        intervalRow.addView(intervalValue, inputParams);

        unitSpinner = new Spinner(this);
        String[] units = new String[]{tr("секунд", "seconds"), tr("минут", "minutes"), tr("часов", "hours")};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, units) {
            @Override public View getView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                if (view instanceof TextView) {
                    ((TextView) view).setTextColor(textColor);
                    ((TextView) view).setTextSize(16);
                }
                return view;
            }
            @Override public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                if (view instanceof TextView) ((TextView) view).setTextColor(textColor);
                view.setBackgroundColor(bgColor);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitSpinner.setAdapter(adapter);
        unitSpinner.setBackground(rounded(fieldColor, 13, borderColor, 1));
        intervalRow.addView(unitSpinner, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams intervalRowParams = matchWrap();
        intervalRowParams.setMargins(0, dp(SPACE), 0, dp(SPACE));
        intervalCard.addView(intervalRow, intervalRowParams);

        saveIntervalButton = makeButton(tr("Сохранить интервал", "Save interval"), true);
        intervalCard.addView(saveIntervalButton, new LinearLayout.LayoutParams(-1, dp(50)));
        saveIntervalButton.setOnClickListener(v -> saveInterval());

        nextUpdateView = textView(14, false, subTextColor);
        LinearLayout.LayoutParams nextParams = matchWrap();
        nextParams.setMargins(dp(4), dp(SPACE), dp(4), 0);
        intervalCard.addView(nextUpdateView, nextParams);

        exactAlarmButton = makeButton(tr("Разрешить точное автообновление", "Allow exact automatic updates"), false);
        LinearLayout.LayoutParams exactParams = new LinearLayout.LayoutParams(-1, dp(50));
        exactParams.setMargins(0, dp(SPACE), 0, 0);
        intervalCard.addView(exactAlarmButton, exactParams);
        exactAlarmButton.setOnClickListener(v -> openExactAlarmSettings());
        root.addView(intervalCard, sectionParams());

        LinearLayout languageCard = sectionCard();
        languageCard.addView(sectionTitle("Язык приложения / App language"), matchWrap());
        LinearLayout languageSegment = horizontalRow();
        languageRuButton = makeSegment("RU");
        languageEnButton = makeSegment("EN");
        languageSegment.addView(languageRuButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        languageSegment.addView(languageEnButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams languageParams = matchWrap();
        languageParams.setMargins(0, dp(SPACE), 0, 0);
        languageCard.addView(languageSegment, languageParams);
        root.addView(languageCard, sectionParams());

        LinearLayout widgetCard = sectionCard();
        widgetCard.addView(sectionTitle(tr("Виджет", "Widget")), matchWrap());
        widgetButton = makeButton(tr("Добавить виджет на экран", "Add widget to home screen"), false);
        LinearLayout.LayoutParams widgetParams = new LinearLayout.LayoutParams(-1, dp(50));
        widgetParams.setMargins(0, dp(SPACE), 0, 0);
        widgetCard.addView(widgetButton, widgetParams);
        TextView widgetHint = textView(13, false, subTextColor);
        widgetHint.setText(tr("Если виджет уже есть, будет добавлен ещё один экземпляр.", "If a widget already exists, another instance will be added."));
        LinearLayout.LayoutParams widgetHintParams = matchWrap();
        widgetHintParams.setMargins(dp(4), dp(SPACE), dp(4), 0);
        widgetCard.addView(widgetHint, widgetHintParams);
        widgetButton.setOnClickListener(v -> WidgetPinHelper.requestPinWidgetConfirmed(this, widgetButton));
        root.addView(widgetCard, sectionParams());

        languageRuButton.setOnClickListener(v -> setArtworkLanguage(LanguageManager.RU));
        languageEnButton.setOnClickListener(v -> setArtworkLanguage(LanguageManager.EN));

        applyIntervalToControls(ArtScheduler.getIntervalSeconds(this));
        return scroll;
    }

    private Switch makeSwitch(String text) {
        Switch value = new Switch(this);
        value.setText(text);
        value.setTextColor(textColor);
        value.setTextSize(15);
        value.setGravity(Gravity.CENTER_VERTICAL);
        value.setPadding(0, 0, 0, 0);
        return value;
    }

    private void setArtworkLanguage(String language) {
        LanguageManager.setLanguage(this, language);
        ArtWidgetProvider.updateAllWidgets(this);
        recreate();
    }

    private void setContentMode(int mode) {
        new ArtRepository(this).setContentMode(mode);
        updateSegments(mode);
    }

    private void updateCurrentCategoryCatalog() {
        if (updateCatalogButton == null || statsExecutor.isShutdown()) return;
        updateCatalogButton.setEnabled(false);
        updateCatalogButton.setAlpha(0.55f);
        showStatus(tr("Обновляю каталог категории…", "Updating category catalog…"));
        statsExecutor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(getApplicationContext());
                boolean adult = repo.getContentMode() == ArtRepository.CONTENT_ADULT_ONLY;
                String result = repo.updateCatalogPart(adult);
                runOnUiThread(() -> {
                    showStatus(result);
                    refreshCacheUsage();
                    updateCatalogButton.setEnabled(true);
                    updateCatalogButton.setAlpha(1f);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    showStatus(e.getMessage() == null ? tr("Не удалось обновить каталог", "Could not update the catalog") : e.getMessage());
                    updateCatalogButton.setEnabled(true);
                    updateCatalogButton.setAlpha(1f);
                });
            }
        });
    }

    private void saveInterval() {
        int value;
        try {
            value = Integer.parseInt(intervalValue.getText().toString().trim());
        } catch (Exception e) {
            showStatus(tr("Введите число для интервала автообновления", "Enter a number for the automatic update interval"));
            return;
        }
        if (value <= 0) {
            showStatus(tr("Интервал должен быть больше нуля", "The interval must be greater than zero"));
            return;
        }
        long seconds = value;
        int unit = unitSpinner.getSelectedItemPosition();
        if (unit == 1) seconds *= 60L;
        if (unit == 2) seconds *= 3600L;
        seconds = Math.max(ArtScheduler.MIN_INTERVAL_SECONDS, Math.min(ArtScheduler.MAX_INTERVAL_SECONDS, seconds));
        ArtScheduler.setIntervalSeconds(this, (int) seconds);
        applyIntervalToControls((int) seconds);
        nextUpdateView.setText(ArtScheduler.nextUpdateDisplay(this));
        hideStatus();
        Toast.makeText(this, tr("Интервал сохранён", "Interval saved"), Toast.LENGTH_SHORT).show();
    }

    private void updateUi() {
        ArtRepository repo = new ArtRepository(this);
        updatingUi = true;
        updateSegments(repo.getContentMode());
        updateLanguageSegments(LanguageManager.getLanguage(this));
        wifiOnlySwitch.setChecked(repo.isWifiOnly());
        onlyNewSwitch.setChecked(repo.isOnlyNewMode());
        autoUpdateSwitch.setChecked(ArtScheduler.isEnabled(this));
        int cacheStep = repo.getGalleryCacheLimitStep();
        cacheSeekBar.setProgress(cacheStep);
        cacheValueView.setText(cacheLabel(cacheStep));
        updatingUi = false;
        setIntervalControlsEnabled(ArtScheduler.isEnabled(this));
        nextUpdateView.setText(ArtScheduler.nextUpdateDisplay(this));
        exactAlarmButton.setVisibility(ArtScheduler.isEnabled(this) && !ArtScheduler.canScheduleExact(this)
                ? View.VISIBLE : View.GONE);
        if (widgetButton != null) {
            widgetButton.setText(WidgetPinHelper.hasActiveWidgets(this)
                    ? tr("Добавить ещё один виджет", "Add another widget")
                    : tr("Добавить виджет на экран", "Add widget to home screen"));
        }
        refreshCacheUsage();
    }

    private void refreshCacheUsage() {
        if (statsExecutor.isShutdown()) return;
        statsExecutor.execute(() -> {
            ArtRepository.CacheStats stats = new ArtRepository(getApplicationContext()).collectCacheStats();
            runOnUiThread(() -> {
                if (isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) return;
                cacheUsageView.setText(tr("Использовано: ", "Used: ") + formatBytes(stats.bytes)
                        + tr(" · картин: ", " · artworks: ") + stats.files);
            });
        });
    }

    private String cacheLabel(int step) {
        if (step >= ArtRepository.GALLERY_CACHE_INFINITY_STEP) {
            return tr("∞ / Без ограничения", "∞ / Unlimited");
        }
        if (step <= 0) return tr("0 ГБ", "0 GB");
        float gb = step * ArtRepository.GALLERY_CACHE_STEP_MB / 1000f;
        return String.format(Locale.getDefault(), tr("%.1f ГБ", "%.1f GB"), gb);
    }

    private String formatBytes(long value) {
        if (value < 1024L * 1024L) return String.format(Locale.getDefault(), tr("%.1f КБ", "%.1f KB"), value / 1024f);
        if (value < 1024L * 1024L * 1024L) return String.format(Locale.getDefault(), tr("%.1f МБ", "%.1f MB"), value / (1024f * 1024f));
        return String.format(Locale.getDefault(), tr("%.2f ГБ", "%.2f GB"), value / (1024f * 1024f * 1024f));
    }

    private void setIntervalControlsEnabled(boolean enabled) {
        intervalValue.setEnabled(enabled);
        unitSpinner.setEnabled(enabled);
        saveIntervalButton.setEnabled(enabled);
        intervalValue.setAlpha(enabled ? 1f : 0.45f);
        unitSpinner.setAlpha(enabled ? 1f : 0.45f);
        saveIntervalButton.setAlpha(enabled ? 1f : 0.45f);
    }

    private void updateSegments(int mode) {
        styleSegment(filterButton, mode == ArtRepository.CONTENT_FILTER, true, false);
        styleSegment(allButton, mode == ArtRepository.CONTENT_ALL, false, false);
        styleSegment(nsfwButton, mode == ArtRepository.CONTENT_ADULT_ONLY, false, true);
    }

    private void updateLanguageSegments(String language) {
        if (languageRuButton == null || languageEnButton == null) return;
        styleSegment(languageRuButton, !LanguageManager.EN.equals(language), true, false);
        styleSegment(languageEnButton, LanguageManager.EN.equals(language), false, true);
    }

    private void styleSegment(Button button, boolean active, boolean first, boolean last) {
        int color = active ? 0xFF007AFF : fieldColor;
        int stroke = active ? 0xFF007AFF : borderColor;
        button.setTextColor(active ? Color.WHITE : textColor);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setStroke(dp(1), stroke);
        float r = dp(13);
        shape.setCornerRadii(new float[]{first ? r : 0, first ? r : 0, last ? r : 0, last ? r : 0,
                last ? r : 0, last ? r : 0, first ? r : 0, first ? r : 0});
        button.setBackground(shape);
    }

    private Button makeSegment(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setMinHeight(0);
        b.setMinWidth(0);
        return b;
    }

    private void showStatus(String text) {
        statusView.setText(text == null ? "" : text);
        statusView.setVisibility(View.VISIBLE);
    }

    private void hideStatus() {
        statusView.setVisibility(View.GONE);
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void applyIntervalToControls(int seconds) {
        if (seconds < 60) {
            intervalValue.setText(String.valueOf(seconds));
            unitSpinner.setSelection(0);
        } else if (seconds % 3600 == 0) {
            intervalValue.setText(String.valueOf(seconds / 3600));
            unitSpinner.setSelection(2);
        } else {
            intervalValue.setText(String.valueOf(Math.max(1, seconds / 60)));
            unitSpinner.setSelection(1);
        }
    }

    private Button makeButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15,
                primary ? 0xFF007AFF : borderColor, 1));
        return b;
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(rounded(fieldColor, 18, borderColor, 1));
        return card;
    }

    private TextView sectionTitle(String title) {
        TextView tv = textView(17, true, textColor);
        tv.setText(title);
        return tv;
    }

    private LinearLayout.LayoutParams sectionParams() {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private TextView textView(int size, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setTextSize(size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        borderColor = dark ? 0xFF38383A : 0xFFD9D9DE;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
