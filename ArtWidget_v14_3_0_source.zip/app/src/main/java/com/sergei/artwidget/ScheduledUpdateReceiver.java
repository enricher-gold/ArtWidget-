package com.sergei.artwidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Внутренний receiver планового обновления. Не экспортируется наружу. */
public final class ScheduledUpdateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ArtWidgetProvider.ACTION_SCHEDULED_UPDATE.equals(intent.getAction())) return;
        ArtWidgetProvider.performScheduledUpdate(context, goAsync());
    }
}
