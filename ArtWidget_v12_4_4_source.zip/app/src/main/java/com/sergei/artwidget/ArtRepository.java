package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;

public class ArtRepository {
    public static final String PREFS = "art_widget_prefs";
    private static final String KEY_HISTORY = "history";
    private static final String KEY_INDEX = "history_index";
    private static final String KEY_CATALOG = "wikidata_catalog";
    private static final String KEY_QUEUE = "catalog_queue_v9"; // legacy
    private static final String KEY_QUEUE_INDEX = "catalog_queue_index_v9"; // legacy
    private static final String KEY_QUEUE_FILTER = "catalog_queue_filter_v10";
    private static final String KEY_QUEUE_ALL = "catalog_queue_all_v10";
    private static final String KEY_QUEUE_ADULT = "catalog_queue_adult_v10";
    private static final String KEY_QUEUE_FILTER_INDEX = "catalog_queue_filter_index_v10";
    private static final String KEY_QUEUE_ALL_INDEX = "catalog_queue_all_index_v10";
    private static final String KEY_QUEUE_ADULT_INDEX = "catalog_queue_adult_index_v10";
    private static final String KEY_V10_READY = "v10_ready";
    private static final String KEY_V11_2_READY = "v11_2_ready";
    private static final String KEY_V11_3_READY = "v11_3_ready";
    private static final String KEY_V11_4_READY = "v11_4_ready";
    private static final String KEY_ADULT_CATALOG_OFFSET = "adult_catalog_offset_v11_4";
    private static final String KEY_ADULT_CATALOG_END = "adult_catalog_end_v11_4";
    private static final String KEY_ADULT_CONFIRMED = "adult_confirmed_v11_4";
    private static final String KEY_UNAVAILABLE_IMAGES = "unavailable_images_v11_5";
    private static final String KEY_CATALOG_OFFSET = "catalog_offset_v9";
    private static final String KEY_CATALOG_END = "catalog_end_v9";
    private static final String KEY_FAVORITES = "favorites_v9";
    private static final String KEY_DISLIKES = "dislikes_v9";
    private static final String KEY_CONTENT_MODE = "content_mode_v9";
    private static final String KEY_MIGRATED = "migrated_v9";
    private static final String KEY_LAST_FETCH = "last_fetch_millis";
    private static final String KEY_CURRENT = "current_entry_v9";
    private static final String KEY_CATALOG_COUNT = "catalog_count_v9";
    private static final String KEY_HISTORY_COUNT = "history_count_v9";
    private static final String KEY_CACHE_COUNT = "cache_count_v9";
    private static final String KEY_CACHE_INDEX = "cache_index_v12_3_3";
    private static final String KEY_WIFI_ONLY = "wifi_only_v11_8";
    private static final String KEY_MANUAL_NETWORK_ONLY = "manual_network_only_v12_4_3";
    private static final String KEY_CATALOG_UPDATE_STATUS = "catalog_update_status_v11_8";
    private static final String KEY_CATALOG_UPDATE_AT = "catalog_update_at_v11_8";
    private static final String KEY_CATALOG_GENERAL_STATUS = "catalog_general_status_v11_8";
    private static final String KEY_CATALOG_ADULT_STATUS = "catalog_adult_status_v11_8";
    private static final String KEY_LAST_CATALOG_PREFETCH = "last_catalog_prefetch_v11_8";
    private static final String KEY_MANUAL_PREFETCH_STATUS = "manual_prefetch_status_v12_4";
    private static final String KEY_V12_INITIALIZED = "v12_initialized";
    private static final String KEY_V12_1_CATALOGS_IMPORTED = "v12_1_catalogs_imported";
    private static final String KEY_V12_2_CATALOGS_IMPORTED = "v12_2_catalogs_imported";
    private static final String KEY_V12_3_SEARCH_FIX = "v12_3_search_fix";
    private static final String KEY_V12_3_WIKIPEDIA_DESCRIPTIONS = "v12_3_wikipedia_descriptions";
    private static final String KEY_V12_3_1_BUNDLED_CATALOGS = "v12_3_1_bundled_catalogs";
    private static final String KEY_V12_3_2_CATALOG_REPAIR = "v12_3_2_catalog_repair";
    private static final String KEY_V12_3_3_DIRECT_CATALOG = "v12_3_3_direct_catalog";
    private static final String KEY_FILTER_CATALOG_COUNT = "filter_catalog_count_v12";
    private static final String KEY_NSFW_CATALOG_COUNT = "nsfw_catalog_count_v12";

    public static final int CONTENT_FILTER = 0;
    public static final int CONTENT_ALL = 1;
    public static final int CONTENT_ADULT_ONLY = 2;
    public static final int MAX_CACHE_FILES = 1000;
    private static final int MAX_HISTORY_RECORDS = 5000;
    private static final int PAGE_SIZE = 80;
    private static final int ADULT_PAGE_SIZE = 40;
    private static final int MAX_PAGE_ATTEMPTS_PER_UPDATE = 3;
    private static final int MAX_ADULT_PAGE_ATTEMPTS_PER_UPDATE = 1;
    private static final int MAX_GENERAL_CANDIDATE_ATTEMPTS = 12;
    private static final int MAX_ADULT_CANDIDATE_ATTEMPTS = 30;
    private static final long MIN_MANUAL_INTERVAL_MS = 0L;
    private static final String USER_AGENT = "ArtWidget/12.4.4 Android; Russian art widget; contact enricherusa@gmail.com";

    private static final Object DATA_LOCK = new Object();
    private static final Object NETWORK_LOCK = new Object();
    private static final Object INIT_LOCK = new Object();

    private final Context context;
    private final SharedPreferences prefs;
    private final CatalogStore catalogStore;
    private final Random random = new Random();

    public ArtRepository(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        this.catalogStore = new CatalogStore(this.context);
    }

    /**
     * Проверяет встроенный каталог, но не импортирует его в SQLite.
     * Assets остаются неизменяемым резервным источником и читаются напрямую.
     */
    public void initializeStorageInBackground() throws Exception {
        synchronized (INIT_LOCK) {
            List<ArtEntry> bundled = PreloadedCatalogImporter.loadAll(context);
            int safeCount = 0;
            int adultCount = 0;
            for (ArtEntry entry : bundled) {
                if (entry.explicitContent) adultCount++;
                else safeCount++;
            }
            if (safeCount == 0 || adultCount == 0) {
                throw new IllegalStateException("Встроенный каталог пуст");
            }

            List<ArtEntry> starters = ensureStarterArtworkInstalled();
            int starterSafe = 0;
            int starterAdult = 0;
            for (ArtEntry entry : starters) {
                if (entry.explicitContent) starterAdult++;
                else starterSafe++;
            }

            if (!prefs.getBoolean(KEY_V12_3_3_DIRECT_CATALOG, false)) {
                // Старые пользовательские данные и уже загруженные изображения
                // сохраняются. База каталога больше не является обязательной.
                try { migrateIfNeeded(); } catch (Exception ignored) { }
                try { ensureV10Ready(); } catch (Exception ignored) { }
                try { ensureV11_2Ready(); } catch (Exception ignored) { }
                try { ensureV11_3Ready(); } catch (Exception ignored) { }
                try { ensureV11_4Ready(); } catch (Exception ignored) { }
                synchronized (DATA_LOCK) { clearModeQueuesLocked(); }
                prefs.edit()
                        .putBoolean(KEY_V12_INITIALIZED, true)
                        .putBoolean(KEY_V12_3_SEARCH_FIX, true)
                        .putBoolean(KEY_V12_3_WIKIPEDIA_DESCRIPTIONS, true)
                        .putBoolean(KEY_V12_3_3_DIRECT_CATALOG, true)
                        .remove(KEY_V12_3_1_BUNDLED_CATALOGS)
                        .remove(KEY_V12_3_2_CATALOG_REPAIR)
                        .apply();
            }

            prefs.edit()
                    .putInt(KEY_CATALOG_COUNT, safeCount + adultCount)
                    .putInt(KEY_FILTER_CATALOG_COUNT, safeCount)
                    .putInt(KEY_NSFW_CATALOG_COUNT, adultCount)
                    .apply();
            setCatalogPartStatus(false, "встроено " + safeCount + " записей, готовых изображений " + starterSafe);
            setCatalogPartStatus(true, "встроено " + adultCount + " записей, готовых изображений " + starterAdult);
            setCatalogUpdateStatus("Каталог доступен напрямую; стартовый кэш установлен");
        }
    }

    /** Сбрасывает только очередь показа. Каталог в assets не нуждается в восстановлении. */
    public String repairBundledCatalog() throws Exception {
        initializeStorageInBackground();
        synchronized (DATA_LOCK) {
            clearModeQueuesLocked();
        }
        return "Очередь каталога будет сформирована заново";
    }

    private List<ArtEntry> getBundledCatalogEntries() throws IOException {
        try {
            return PreloadedCatalogImporter.loadAll(context);
        } catch (Exception e) {
            throw new IOException("Не удалось прочитать встроенный каталог", e);
        }
    }

    private boolean hasUsableCatalogForMode(int mode) {
        int safe = PreloadedCatalogImporter.count(context, false);
        int adult = PreloadedCatalogImporter.count(context, true);
        if (mode == CONTENT_ADULT_ONLY) return adult > 0;
        if (mode == CONTENT_FILTER) return safe > 0;
        return safe + adult > 0;
    }

    private void invalidateLegacyWikiArtCacheLocked() {
        try {
            List<ArtEntry> history = readEntries(KEY_HISTORY);
            for (int i = 0; i < history.size(); i++) {
                ArtEntry entry = history.get(i);
                if (!entry.qid.startsWith("wikiart:")) continue;
                deleteFileQuietly(entry.localPath);
                history.set(i, entry.withLocalPath(""));
            }
            writeEntries(KEY_HISTORY, history);

            List<ArtEntry> favorites = readEntries(KEY_FAVORITES);
            for (int i = 0; i < favorites.size(); i++) {
                ArtEntry entry = favorites.get(i);
                if (!entry.qid.startsWith("wikiart:")) continue;
                deleteFileQuietly(entry.localPath);
                favorites.set(i, entry.withLocalPath(""));
            }
            writeEntries(KEY_FAVORITES, favorites);

            ArtEntry current = getCurrent();
            if (current != null && current.qid.startsWith("wikiart:")) {
                prefs.edit().remove(KEY_CURRENT).putInt(KEY_INDEX, -1).apply();
            }
            updateStatsLocked(history);
        } catch (Exception e) {
            AppLogger.log(context, "v12.1-cache-reset", "error", friendlyMessage(e));
        }
    }

    private void refreshCatalogCounters() {
        int safe = PreloadedCatalogImporter.count(context, false);
        int adult = PreloadedCatalogImporter.count(context, true);
        prefs.edit()
                .putInt(KEY_CATALOG_COUNT, safe + adult)
                .putInt(KEY_FILTER_CATALOG_COUNT, safe)
                .putInt(KEY_NSFW_CATALOG_COUNT, adult)
                .apply();
    }

    public ArtEntry getCurrent() {
        try {
            String saved = prefs.getString(KEY_CURRENT, "");
            if (saved != null && !saved.trim().isEmpty()) return ArtEntry.fromJson(new JSONObject(saved));

            // Первый экран формируется из файлов внутри APK. Сеть, WorkManager
            // и импорт каталога для этого не нужны.
            ArtEntry starter = bootstrapCurrentFromStarters();
            if (starter != null) return starter;

            CatalogWorkScheduler.ensureInitialized(context);
            return null;
        } catch (Exception e) {
            AppLogger.log(context, "getCurrent", "error", e.getMessage());
            CatalogWorkScheduler.ensureInitialized(context);
            return null;
        }
    }

    private List<ArtEntry> ensureStarterArtworkInstalled() {
        try {
            List<ArtEntry> starters = StarterArtworkInstaller.install(context);
            synchronized (DATA_LOCK) {
                Map<String, ArtEntry> existing = new HashMap<>();
                for (ArtEntry old : readEntries(KEY_CACHE_INDEX)) {
                    if (fileExists(old.localPath)) existing.put(old.canonicalKey(), old);
                }
                List<ArtEntry> merged = new ArrayList<>(starters.size());
                for (ArtEntry starter : starters) {
                    ArtEntry old = existing.get(starter.canonicalKey());
                    ArtEntry entry = old == null ? starter : new ArtEntry(
                            starter.qid, starter.title, starter.artist, starter.description,
                            starter.imageUrl, starter.originalImageUrl, starter.localPath,
                            starter.sourceUrl, starter.instanceLabel, starter.materialLabel,
                            starter.genreLabel, old.addedAt, old.lastShownAt,
                            old.showCount, starter.explicitContent);
                    upsertCacheIndexLocked(entry);
                    merged.add(entry);
                }
                return merged;
            }
        } catch (Exception e) {
            AppLogger.log(context, "starter-cache", "error", friendlyMessage(e));
            return new ArrayList<>();
        }
    }

    private ArtEntry bootstrapCurrentFromStarters() throws JSONException {
        synchronized (DATA_LOCK) {
            String saved = prefs.getString(KEY_CURRENT, "");
            if (saved != null && !saved.trim().isEmpty()) {
                return ArtEntry.fromJson(new JSONObject(saved));
            }

            List<ArtEntry> starters = ensureStarterArtworkInstalled();
            int mode = getContentMode();
            ArtEntry selected = null;
            for (ArtEntry entry : starters) {
                if (matchesContentMode(entry, mode) && fileExists(entry.localPath)) {
                    selected = entry.markedShown();
                    break;
                }
            }
            if (selected == null) return null;

            List<ArtEntry> history = readEntries(KEY_HISTORY);
            history.add(selected);
            while (history.size() > MAX_HISTORY_RECORDS) history.remove(0);
            writeEntries(KEY_HISTORY, history);
            upsertCacheIndexLocked(selected);
            prefs.edit()
                    .putInt(KEY_INDEX, history.size() - 1)
                    .putInt(KEY_HISTORY_COUNT, history.size())
                    .putString(KEY_CURRENT, selected.toJson().toString())
                    .apply();
            AppLogger.log(context, "starter-cache", "initial", selected.qid);
            return selected;
        }
    }

    /**
     * Ручное обновление с главного экрана. При включённом режиме проверки сети
     * локальный кэш полностью игнорируется: картина должна быть получена через
     * интернет, иначе текущая картина остаётся без изменений.
     */
    public ArtEntry fetchNextArtworkForManualRequest() throws IOException, JSONException {
        return isManualNetworkOnly() ? fetchNextArtworkFromNetworkOnly() : fetchNextArtwork();
    }

    private ArtEntry fetchNextArtworkFromNetworkOnly() throws IOException, JSONException {
        ensureStarterArtworkInstalled();
        int mode = getContentMode();
        Exception catalogError = null;
        if (!hasUsableCatalogForMode(mode)) {
            try {
                initializeStorageInBackground();
            } catch (Exception e) {
                catalogError = e;
                AppLogger.log(context, "catalog-init", "error", friendlyMessage(e));
            }
        } else {
            CatalogWorkScheduler.ensureInitialized(context);
        }
        if (!hasUsableCatalogForMode(mode)) {
            throw new IOException("Локальный каталог недоступен", catalogError);
        }

        long start = System.currentTimeMillis();
        synchronized (NETWORK_LOCK) {
            if (!isDownloadNetworkAllowed()) {
                if (isWifiOnly() && hasNetwork()) throw new IOException("Разрешена загрузка только по Wi-Fi");
                throw new IOException("Нет подключения к интернету. Кэш отключён для кнопки «Новая»");
            }
            prefs.edit().putLong(KEY_LAST_FETCH, System.currentTimeMillis()).apply();

            List<ArtEntry> candidates = networkOnlyCandidates(mode);
            Exception lastError = null;
            int maxCandidateAttempts = mode == CONTENT_ADULT_ONLY
                    ? MAX_ADULT_CANDIDATE_ATTEMPTS
                    : MAX_GENERAL_CANDIDATE_ATTEMPTS;
            int attempts = Math.min(maxCandidateAttempts, candidates.size());
            for (int attempt = 0; attempt < attempts; attempt++) {
                ArtEntry candidate = candidates.get(attempt);
                try {
                    AppLogger.log(context, "network-only", "start", candidate.qid + " | mode=" + mode);
                    // Намеренно не вызываем findReusableLocalEntry(): даже если файл уже
                    // есть в кэше, этот режим обязан выполнить реальную сетевую загрузку.
                    ArtEntry downloaded = downloadArtwork(candidate, mode == CONTENT_ADULT_ONLY);
                    if (!matchesContentMode(downloaded, mode) || isUnwanted(downloaded)) {
                        deleteFileQuietly(downloaded.localPath);
                        continue;
                    }
                    appendHistory(downloaded);
                    enforceCacheLimit();
                    maybeScheduleCatalogPrefetch(mode);
                    AppLogger.log(context, "network-only", "ok",
                            downloaded.qid + " | " + (System.currentTimeMillis() - start) + " ms");
                    return downloaded;
                } catch (Exception e) {
                    lastError = e;
                    AppLogger.log(context, "network-only", "skip",
                            candidate.qid + " | " + friendlyMessage(e));
                    if (isImageUnavailableError(e)) {
                        markImageUnavailable(candidate);
                        continue;
                    }
                    if (isRateLimit(e) || isConnectionFailure(e)) break;
                }
            }

            String message = lastError == null
                    ? "Не удалось загрузить новую картину из интернета"
                    : friendlyMessage(lastError);
            AppLogger.log(context, "network-only", "error", message);
            if (lastError instanceof JSONException) throw (JSONException) lastError;
            throw new IOException(message);
        }
    }

    /**
     * Список для режима «только интернет». Сначала идут произведения, которых
     * ещё нет в локальном кэше, затем остальные. Текущая картина, дизлайки и
     * недоступные изображения исключаются. Очередь обычного режима не меняется.
     */
    private List<ArtEntry> networkOnlyCandidates(int mode) throws IOException, JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> catalog = getBundledCatalogEntries();
            Set<String> disliked = identitySet(readEntries(KEY_DISLIKES));
            Set<String> unavailable = readStringArraySet(KEY_UNAVAILABLE_IMAGES);
            Set<String> cached = new HashSet<>();
            for (ArtEntry entry : readEntries(KEY_CACHE_INDEX)) {
                if (fileExists(entry.localPath)) cached.add(entry.canonicalKey());
            }
            ArtEntry current = getCurrent();
            String currentKey = current == null ? "" : current.canonicalKey();
            Set<String> unique = new HashSet<>();
            List<ArtEntry> fresh = new ArrayList<>();
            List<ArtEntry> repeated = new ArrayList<>();
            for (ArtEntry entry : catalog) {
                String identity = entry.canonicalKey();
                if (!unique.add(identity) || disliked.contains(identity) || unavailable.contains(identity)) continue;
                if (!currentKey.isEmpty() && currentKey.equals(identity)) continue;
                if (mode == CONTENT_ADULT_ONLY && !isVerifiedAdult(entry)) continue;
                if (!matchesContentMode(entry, mode) || isUnwanted(entry)) continue;
                if (cached.contains(identity)) repeated.add(entry);
                else fresh.add(entry);
            }
            Collections.shuffle(fresh, random);
            Collections.shuffle(repeated, random);
            fresh.addAll(repeated);
            return fresh;
        }
    }

    public ArtEntry fetchNextArtwork() throws IOException, JSONException {
        // Локальные стартовые файлы восстанавливаются до любой проверки сети
        // или состояния основного каталога.
        ensureStarterArtworkInstalled();
        int mode = getContentMode();
        Exception catalogError = null;
        if (!hasUsableCatalogForMode(mode)) {
            try {
                initializeStorageInBackground();
            } catch (Exception e) {
                catalogError = e;
                AppLogger.log(context, "catalog-init", "error", friendlyMessage(e));
            }
        } else {
            // Проверка полного комплекта выполняется отдельно и никогда не должна
            // блокировать кнопку «Новая».
            CatalogWorkScheduler.ensureInitialized(context);
        }

        if (!hasUsableCatalogForMode(mode)) {
            ArtEntry cached = activateRandomCachedArtwork("catalog-unavailable");
            if (cached != null) return cached;
            throw new IOException("Локальный каталог недоступен", catalogError);
        }

        long start = System.currentTimeMillis();
        synchronized (NETWORK_LOCK) {
            // Кнопка «Новая» никогда не ждёт сеть, пока есть другая
            // подходящая картина в локальном кэше. Пополнение запускается
            // отдельно через WorkManager после мгновенного переключения.
            ArtEntry cachedFirst = activateRandomCachedArtwork("cache-first");
            if (cachedFirst != null) {
                maybeScheduleCatalogPrefetch(mode);
                return cachedFirst;
            }

            long now = System.currentTimeMillis();
            long last = prefs.getLong(KEY_LAST_FETCH, 0L);
            if (MIN_MANUAL_INTERVAL_MS > 0 && now - last < MIN_MANUAL_INTERVAL_MS) {
                ArtEntry current = getCurrent();
                if (hasUsableLocalImage(current)) return current;
            }
            prefs.edit().putLong(KEY_LAST_FETCH, now).apply();

            if (!isDownloadNetworkAllowed()) {
                ArtEntry cached = activateRandomCachedArtwork("network-policy");
                if (cached != null) return cached;
                if (isWifiOnly() && hasNetwork()) throw new IOException("Разрешена загрузка только по Wi-Fi");
                throw new IOException("Нет подключения к интернету");
            }

            Exception lastError = null;
            int maxCandidateAttempts = mode == CONTENT_ADULT_ONLY
                    ? MAX_ADULT_CANDIDATE_ATTEMPTS
                    : MAX_GENERAL_CANDIDATE_ATTEMPTS;
            for (int attempt = 0; attempt < maxCandidateAttempts; attempt++) {
                ArtEntry candidate;
                try {
                    candidate = nextCatalogCandidate();
                } catch (Exception e) {
                    lastError = e;
                    if (mode == CONTENT_ADULT_ONLY && isAdultQueueExhaustedError(e)) break;
                    break;
                }
                if (candidate == null) break;

                try {
                    AppLogger.log(context, "candidate", "start", candidate.qid + " | mode=" + mode);
                    ArtEntry downloaded = findReusableLocalEntry(candidate);
                    if (downloaded != null && needsWikipediaDescription(downloaded)) {
                        downloaded = resolveWikipediaMetadata(downloaded, mode == CONTENT_ADULT_ONLY);
                    }
                    if (downloaded == null) downloaded = downloadArtwork(candidate, mode == CONTENT_ADULT_ONLY);
                    if (!matchesContentMode(downloaded, getContentMode()) || isUnwanted(downloaded)) {
                        deleteFileQuietly(downloaded.localPath);
                        continue;
                    }
                    appendHistory(downloaded);
                    enforceCacheLimit();
                    maybeScheduleCatalogPrefetch(mode);
                    AppLogger.log(context, "next", "ok", downloaded.qid + " | " + (System.currentTimeMillis() - start) + " ms");
                    return downloaded;
                } catch (Exception e) {
                    lastError = e;
                    AppLogger.log(context, "candidate", "skip", candidate.qid + " | " + friendlyMessage(e));
                    if (isImageUnavailableError(e)) {
                        // Запись помечается один раз и текущая очередь продолжает
                        // двигаться дальше без дорогого перемешивания после каждого отказа.
                        markImageUnavailable(candidate);
                        continue;
                    }
                    if (isRateLimit(e) || isConnectionFailure(e)) break;
                }
            }

            String message;
            if (mode == CONTENT_ADULT_ONLY && isAdultQueueExhaustedError(lastError)) {
                message = "Новых доступных произведений пока нет";
            } else if (lastError == null || isImageUnavailableError(lastError)) {
                message = "Не удалось загрузить новое произведение. Повторите обновление";
            } else {
                message = friendlyMessage(lastError);
            }
            AppLogger.log(context, "next", "error", message);
            // Любая ошибка каталога или сети не должна оставлять экран на той же
            // картине, когда в галерее уже есть другие исправные файлы.
            ArtEntry cached = activateRandomCachedArtwork("operation-error");
            if (cached != null) return cached;
            if (lastError instanceof JSONException) throw (JSONException) lastError;
            throw new IOException(message);
        }
    }

    public ArtEntry goPrevious() throws IOException, JSONException {
        return navigateHistory(-1);
    }

    public ArtEntry goForward() throws IOException, JSONException {
        return navigateHistory(1);
    }

    private ArtEntry navigateHistory(int delta) throws IOException, JSONException {
        synchronized (NETWORK_LOCK) {
            int targetIndex;
            ArtEntry target;
            synchronized (DATA_LOCK) {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                int index = prefs.getInt(KEY_INDEX, -1);
                targetIndex = index + delta;
                if (history.isEmpty() || targetIndex < 0 || targetIndex >= history.size()) return getCurrent();
                target = history.get(targetIndex);
            }
            ArtEntry ready = ensureLocalImage(target).markedShown();
            synchronized (DATA_LOCK) {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                if (targetIndex < 0 || targetIndex >= history.size()) return getCurrent();
                history.set(targetIndex, ready);
                writeEntries(KEY_HISTORY, history);
                updateStatsLocked(history);
                prefs.edit().putInt(KEY_INDEX, targetIndex)
                        .putString(KEY_CURRENT, ready.toJson().toString()).apply();
            }
            return ready;
        }
    }

    public ArtEntry installOnWidget(String qid) throws IOException, JSONException {
        synchronized (NETWORK_LOCK) {
            ArtEntry found = findEntry(qid);
            if (found == null) throw new IOException("Произведение не найдено");
            found = ensureLocalImage(found).markedShown();
            appendHistory(found);
            enforceCacheLimit();
            return found;
        }
    }

    public ArtEntry dislikeCurrentAndFetchNext() throws IOException, JSONException {
        ArtEntry current = getCurrent();
        if (current == null) return fetchNextArtwork();
        addDislikeRecord(current);
        ArtEntry next = fetchNextArtwork();
        if (next != null && !next.sameArtwork(current)) {
            synchronized (DATA_LOCK) {
                deleteFileQuietly(current.localPath);
                clearLocalPathInHistory(current.qid);
            }
        }
        return next;
    }

    public boolean toggleFavorite(ArtEntry entry) {
        if (entry == null) return false;
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> list = readEntries(KEY_FAVORITES);
                int idx = indexOfEquivalent(list, entry);
                boolean nowFavorite;
                if (idx >= 0) {
                    list.remove(idx);
                    nowFavorite = false;
                } else {
                    list.add(entry);
                    nowFavorite = true;
                    List<ArtEntry> dislikes = readEntries(KEY_DISLIKES);
                    int dislikedIndex = indexOfEquivalent(dislikes, entry);
                    if (dislikedIndex >= 0) {
                        dislikes.remove(dislikedIndex);
                        writeEntries(KEY_DISLIKES, dislikes);
                        clearModeQueuesLocked();
                    }
                }
                writeEntries(KEY_FAVORITES, list);
                return nowFavorite;
            } catch (Exception e) {
                AppLogger.log(context, "favorite", "error", e.getMessage());
                return false;
            }
        }
    }

    public void setDisliked(ArtEntry entry, boolean disliked) {
        if (entry == null) return;
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> list = readEntries(KEY_DISLIKES);
                int idx = indexOfEquivalent(list, entry);
                if (disliked && idx < 0) {
                    list.add(entry.withLocalPath(""));
                    List<ArtEntry> favorites = readEntries(KEY_FAVORITES);
                    int favoriteIndex = indexOfEquivalent(favorites, entry);
                    if (favoriteIndex >= 0) {
                        favorites.remove(favoriteIndex);
                        writeEntries(KEY_FAVORITES, favorites);
                    }
                } else if (!disliked && idx >= 0) {
                    list.remove(idx);
                    clearModeQueuesLocked();
                }
                writeEntries(KEY_DISLIKES, list);
                if (disliked) {
                    ArtEntry current = getCurrent();
                    if (current == null || !current.sameArtwork(entry)) {
                        deleteFileQuietly(entry.localPath);
                        clearLocalPathInHistory(entry.qid);
                    }
                    removeFromQueue(entry.qid);
                }
            } catch (Exception e) {
                AppLogger.log(context, "dislike", "error", e.getMessage());
            }
        }
    }

    private void addDislikeRecord(ArtEntry entry) {
        synchronized (DATA_LOCK) {
            try {
                List<ArtEntry> list = readEntries(KEY_DISLIKES);
                if (indexOfEquivalent(list, entry) < 0) {
                    list.add(entry.withLocalPath(""));
                    writeEntries(KEY_DISLIKES, list);
                }
                List<ArtEntry> favorites = readEntries(KEY_FAVORITES);
                int favoriteIndex = indexOfEquivalent(favorites, entry);
                if (favoriteIndex >= 0) {
                    favorites.remove(favoriteIndex);
                    writeEntries(KEY_FAVORITES, favorites);
                }
                removeFromQueue(entry.qid);
            } catch (Exception e) {
                AppLogger.log(context, "dislike", "error", e.getMessage());
            }
        }
    }

    public boolean isFavorite(ArtEntry entry) {
        if (entry == null) return false;
        synchronized (DATA_LOCK) {
            try {
                return indexOfEquivalent(readEntries(KEY_FAVORITES), entry) >= 0;
            } catch (Exception e) { return false; }
        }
    }

    public boolean isFavorite(String qid) {
        return isFavorite(findEntry(qid));
    }

    public boolean isDisliked(ArtEntry entry) {
        if (entry == null) return false;
        synchronized (DATA_LOCK) {
            try {
                return indexOfEquivalent(readEntries(KEY_DISLIKES), entry) >= 0;
            } catch (Exception e) { return false; }
        }
    }

    public boolean isDisliked(String qid) {
        return isDisliked(findEntry(qid));
    }

    public List<ArtEntry> getCachedEntries() {
        ensureStarterArtworkInstalled();
        synchronized (DATA_LOCK) {
            try {
                LinkedUniqueMap unique = new LinkedUniqueMap();
                for (String key : new String[]{KEY_CACHE_INDEX, KEY_HISTORY, KEY_FAVORITES}) {
                    List<ArtEntry> entries = readEntries(key);
                    for (int i = entries.size() - 1; i >= 0; i--) {
                        ArtEntry entry = entries.get(i);
                        if (fileExists(entry.localPath)) {
                            unique.putIfAbsent(entry.canonicalKey(), entry);
                        }
                    }
                }
                ArtEntry current = getCurrent();
                if (current != null && fileExists(current.localPath)) {
                    unique.putIfAbsent(current.canonicalKey(), current);
                }
                List<ArtEntry> result = unique.values();
                writeEntries(KEY_CACHE_INDEX, result);
                prefs.edit().putInt(KEY_CACHE_COUNT, result.size()).apply();
                return result;
            } catch (Exception e) {
                return new ArrayList<>();
            }
        }
    }

    public List<ArtEntry> getFavoriteEntries() {
        synchronized (DATA_LOCK) {
            try { return readEntries(KEY_FAVORITES); }
            catch (Exception e) { return new ArrayList<>(); }
        }
    }

    public List<ArtEntry> getDislikedEntries() {
        synchronized (DATA_LOCK) {
            try { return readEntries(KEY_DISLIKES); }
            catch (Exception e) { return new ArrayList<>(); }
        }
    }

    public List<ArtEntry> getHistoryEntries() {
        synchronized (DATA_LOCK) {
            try { return readEntries(KEY_HISTORY); }
            catch (Exception e) { return new ArrayList<>(); }
        }
    }

    public ArtEntry findEntry(String qid) {
        if (qid == null || qid.isEmpty()) return null;
        synchronized (DATA_LOCK) {
            try {
                for (String key : new String[]{KEY_CACHE_INDEX, KEY_HISTORY, KEY_FAVORITES, KEY_DISLIKES}) {
                    List<ArtEntry> list = readEntries(key);
                    int idx = indexOf(list, qid);
                    if (idx >= 0) return list.get(idx);
                }
                for (ArtEntry entry : getBundledCatalogEntries()) {
                    if (qid.equals(entry.qid)) return entry;
                }
                return catalogStore.getByQid(qid);
            } catch (Exception ignored) {
            }
        }
        return null;
    }

    public int getCacheCount() {
        return getCachedEntries().size();
    }

    public int getCachedCountFast() {
        int stored = prefs.getInt(KEY_CACHE_COUNT, -1);
        return stored >= 0 ? stored : getCacheCount();
    }

    public long getCacheSizeBytes() {
        long total = 0L;
        for (ArtEntry e : getCachedEntries()) {
            try { total += new File(e.localPath).length(); } catch (Exception ignored) { }
        }
        return total;
    }

    public boolean isWifiOnly() {
        return prefs.getBoolean(KEY_WIFI_ONLY, false);
    }

    public boolean isManualNetworkOnly() {
        return prefs.getBoolean(KEY_MANUAL_NETWORK_ONLY, false);
    }

    public void setManualNetworkOnly(boolean value) {
        prefs.edit().putBoolean(KEY_MANUAL_NETWORK_ONLY, value).apply();
    }

    public void setWifiOnly(boolean value) {
        prefs.edit().putBoolean(KEY_WIFI_ONLY, value).apply();
        CatalogWorkScheduler.ensureInitialized(context);
    }

    public boolean isDownloadNetworkAllowed() {
        if (!hasNetwork()) return false;
        return !isWifiOnly() || isWifiConnected();
    }

    public String getCatalogUpdateStatus() {
        String summary = prefs.getString(KEY_CATALOG_UPDATE_STATUS, "не запускался");
        String general = prefs.getString(KEY_CATALOG_GENERAL_STATUS, "не запускался");
        String adult = prefs.getString(KEY_CATALOG_ADULT_STATUS, "не запускался");
        return summary + "\nФильтр: " + general + "\nNSFW: " + adult;
    }

    public void setCatalogUpdateStatus(String status) {
        prefs.edit().putString(KEY_CATALOG_UPDATE_STATUS, status == null ? "" : status)
                .putLong(KEY_CATALOG_UPDATE_AT, System.currentTimeMillis()).apply();
    }

    public void setCatalogPartStatus(boolean adult, String status) {
        prefs.edit().putString(adult ? KEY_CATALOG_ADULT_STATUS : KEY_CATALOG_GENERAL_STATUS,
                        status == null ? "" : status)
                .putLong(KEY_CATALOG_UPDATE_AT, System.currentTimeMillis()).apply();
    }

    public String getManualPrefetchStatus() {
        return prefs.getString(KEY_MANUAL_PREFETCH_STATUS, "Ручное пополнение ещё не запускалось");
    }

    public void setManualPrefetchStatus(String status) {
        prefs.edit().putString(KEY_MANUAL_PREFETCH_STATUS,
                status == null || status.trim().isEmpty() ? "Статус недоступен" : status.trim()).apply();
    }

    public int getCatalogCount() {
        return PreloadedCatalogImporter.count(context, false)
                + PreloadedCatalogImporter.count(context, true);
    }

    /** Проверяет доступность встроенных файлов каталога без сетевого обновления. */
    public String updateCatalogNow() throws IOException, JSONException {
        String general = updateCatalogPart(false);
        String adult = updateCatalogPart(true);
        return general + "; " + adult;
    }

    public String updateCatalogPart(boolean adult) throws IOException, JSONException {
        try { initializeStorageInBackground(); }
        catch (JSONException | IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Не удалось проверить встроенный каталог", e); }
        refreshCatalogCounters();
        int count = PreloadedCatalogImporter.count(context, adult);
        int starters = StarterArtworkInstaller.count(context, adult);
        ensureStarterArtworkInstalled();
        String result = (adult ? "NSFW-каталог" : "Каталог «Фильтр»")
                + ": встроено " + count + " записей, готовых изображений " + starters;
        setCatalogPartStatus(adult, "готов, " + count + " записей, изображений в APK " + starters);
        setCatalogUpdateStatus("Встроенный каталог проверен");
        return result;
    }

    public String getTechnicalCatalogStats() {
        int filterCount = PreloadedCatalogImporter.count(context, false);
        int nsfwCount = PreloadedCatalogImporter.count(context, true);
        int total = filterCount + nsfwCount;
        int mode = getContentMode();
        int remaining = getRemainingForMode(mode, false);
        int unavailable = readStringArraySet(KEY_UNAVAILABLE_IMAGES).size();
        int starterFilter = StarterArtworkInstaller.count(context, false);
        int starterNsfw = StarterArtworkInstaller.count(context, true);
        String activeMode = mode == CONTENT_FILTER ? "Фильтр" : mode == CONTENT_ALL ? "Все" : "NSFW";
        return "Встроенный каталог (читается напрямую): " + total
                + "\nФильтр: " + filterCount + " (готовых изображений " + starterFilter + ")"
                + "\nNSFW: " + nsfwCount + " (готовых изображений " + starterNsfw + ")"
                + "\nЕщё не показано в режиме «" + activeMode + "»: " + remaining
                + "\nНедоступные файлы изображений: " + unavailable;
    }

    public int getRemainingForMode(int mode, boolean rebuildIfEmpty) {
        try {
            JSONArray queue = new JSONArray(prefs.getString(queueKey(mode), "[]"));
            int index = Math.max(0, prefs.getInt(queueIndexKey(mode), 0));
            int remaining = Math.max(0, queue.length() - index);
            if (remaining == 0 && rebuildIfEmpty) {
                rebuildQueue(mode, false);
                queue = new JSONArray(prefs.getString(queueKey(mode), "[]"));
                index = Math.max(0, prefs.getInt(queueIndexKey(mode), 0));
                remaining = Math.max(0, queue.length() - index);
            }
            return remaining;
        } catch (Exception e) {
            return 0;
        }
    }

    public boolean canContinueCatalogUpdate(boolean adult) {
        return false;
    }

    public int getHistoryIndex() {
        return prefs.getInt(KEY_INDEX, -1);
    }

    public int getHistoryCount() {
        int value = prefs.getInt(KEY_HISTORY_COUNT, -1);
        if (value >= 0) return value;
        CatalogWorkScheduler.ensureInitialized(context);
        return 0;
    }

    public boolean canGoPrevious() {
        int index = getHistoryIndex();
        return index > 0 && getHistoryCount() > 0;
    }

    public boolean canGoForward() {
        int index = getHistoryIndex();
        int count = getHistoryCount();
        return index >= 0 && index < count - 1;
    }

    public int getContentMode() {
        int mode = prefs.getInt(KEY_CONTENT_MODE, CONTENT_FILTER);
        return mode < CONTENT_FILTER || mode > CONTENT_ADULT_ONLY ? CONTENT_FILTER : mode;
    }

    public void setContentMode(int mode) {
        if (mode < CONTENT_FILTER || mode > CONTENT_ADULT_ONLY) mode = CONTENT_FILTER;
        prefs.edit().putInt(KEY_CONTENT_MODE, mode).apply();
    }

    public void deleteLocalFile(String qid) {
        synchronized (DATA_LOCK) {
            try {
                ArtEntry target = findEntry(qid);
                String identity = target == null ? "" : target.canonicalKey();
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                for (int i = 0; i < history.size(); i++) {
                    ArtEntry e = history.get(i);
                    if (e.qid.equals(qid) || (!identity.isEmpty() && identity.equals(e.canonicalKey()))) {
                        deleteFileQuietly(e.localPath);
                        history.set(i, e.withLocalPath(""));
                    }
                }
                writeEntries(KEY_HISTORY, history);
                List<ArtEntry> cacheIndex = readEntries(KEY_CACHE_INDEX);
                for (int i = 0; i < cacheIndex.size(); i++) {
                    ArtEntry entry = cacheIndex.get(i);
                    if (entry.qid.equals(qid) || (!identity.isEmpty() && identity.equals(entry.canonicalKey()))) {
                        cacheIndex.set(i, entry.withLocalPath(""));
                    }
                }
                writeEntries(KEY_CACHE_INDEX, cacheIndex);
                updateStatsLocked(history);
                refreshCurrentFromHistoryLocked(history);
            } catch (Exception ignored) { }
        }
    }

    public void clearOrdinaryCache() {
        synchronized (DATA_LOCK) {
            try {
                Set<String> protectedIds = identitySet(readEntries(KEY_FAVORITES));
                ArtEntry current = getCurrent();
                if (current != null) protectedIds.add(current.canonicalKey());

                List<ArtEntry> history = readEntries(KEY_HISTORY);
                for (int i = 0; i < history.size(); i++) {
                    ArtEntry entry = history.get(i);
                    if (!protectedIds.contains(entry.canonicalKey())) {
                        deleteFileQuietly(entry.localPath);
                        history.set(i, entry.withLocalPath(""));
                    }
                }
                writeEntries(KEY_HISTORY, history);

                List<ArtEntry> cacheIndex = readEntries(KEY_CACHE_INDEX);
                List<ArtEntry> kept = new ArrayList<>();
                for (ArtEntry entry : cacheIndex) {
                    if (protectedIds.contains(entry.canonicalKey()) && fileExists(entry.localPath)) {
                        kept.add(entry);
                    } else {
                        deleteFileQuietly(entry.localPath);
                    }
                }
                writeEntries(KEY_CACHE_INDEX, kept);
                updateStatsLocked(history);
                refreshCurrentFromHistoryLocked(history);
                prefs.edit().putLong(KEY_LAST_FETCH, 0L).apply();
                clearDirectory(new File(context.getCacheDir(), "art_temp"));
                clearDirectory(new File(context.getCacheDir(), "gallery_thumbs"));
                AppLogger.log(context, "clearCache", "ok", "current and favorites preserved");
            } catch (Exception e) {
                AppLogger.log(context, "clearCache", "error", e.getMessage());
            }
        }
    }

    public void clearHistory() {
        synchronized (DATA_LOCK) {
            prefs.edit().putString(KEY_HISTORY, "[]").putInt(KEY_INDEX, -1).remove(KEY_CURRENT)
                    .putInt(KEY_HISTORY_COUNT, 0)
                    .remove(KEY_QUEUE).putInt(KEY_QUEUE_INDEX, 0)
                    .remove(KEY_QUEUE_FILTER).remove(KEY_QUEUE_ALL).remove(KEY_QUEUE_ADULT)
                    .putInt(KEY_QUEUE_FILTER_INDEX, 0).putInt(KEY_QUEUE_ALL_INDEX, 0).putInt(KEY_QUEUE_ADULT_INDEX, 0)
                    .apply();
        }
    }

    public File downloadTemporaryThumbnail(ArtEntry entry) throws IOException {
        if (entry == null || entry.imageUrl.isEmpty()) throw new IOException("Миниатюра недоступна");
        if (!isDownloadNetworkAllowed()) {
            if (isWifiOnly() && hasNetwork()) throw new IOException("Загрузка разрешена только по Wi-Fi");
            throw new IOException("Нет подключения к интернету");
        }
        File dir = new File(context.getCacheDir(), "gallery_thumbs");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать временную папку");
        File file = new File(dir, safeFileName(entry.qid) + ".img");
        if (file.exists() && file.length() > 0) return file;
        downloadFile(entry.imageUrl, file);
        return file;
    }

    public void clearTemporaryThumbnails() {
        clearDirectory(new File(context.getCacheDir(), "gallery_thumbs"));
    }

    private void maybeScheduleCatalogPrefetch(int mode) {
        if (getCacheCount() < MAX_CACHE_FILES) {
            CatalogWorkScheduler.schedulePrefetch(context);
        }
    }

    /** Загружает одну новую картину в кэш, не меняя текущий экран и историю. */
    public boolean prefetchOneArtwork() {
        ensureStarterArtworkInstalled();
        if (!isDownloadNetworkAllowed() || getCacheCount() >= MAX_CACHE_FILES) return false;

        synchronized (NETWORK_LOCK) {
            Exception lastError = null;
            int mode = getContentMode();
            int maxAttempts = mode == CONTENT_ADULT_ONLY ? 12 : 8;
            for (int attempt = 0; attempt < maxAttempts; attempt++) {
                try {
                    ArtEntry candidate = nextCatalogCandidate();
                    if (candidate == null) break;
                    ArtEntry existing = findReusableLocalEntry(candidate);
                    if (existing != null && fileExists(existing.localPath)) continue;
                    ArtEntry downloaded = downloadArtwork(candidate, mode == CONTENT_ADULT_ONLY);
                    if (!matchesContentMode(downloaded, mode) || isUnwanted(downloaded)) {
                        deleteFileQuietly(downloaded.localPath);
                        continue;
                    }
                    synchronized (DATA_LOCK) {
                        upsertCacheIndexLocked(downloaded);
                    }
                    AppLogger.log(context, "cache-prefetch", "ok", downloaded.qid);
                    return true;
                } catch (Exception e) {
                    lastError = e;
                    if (isImageUnavailableError(e)) continue;
                    if (isRateLimit(e) || isConnectionFailure(e)) break;
                }
            }
            if (lastError != null) {
                AppLogger.log(context, "cache-prefetch", "skip", friendlyMessage(lastError));
            }
            return false;
        }
    }

    private ArtEntry activateRandomCachedArtwork(String reason) throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> cached = getCachedEntries();
            if (cached.isEmpty()) return null;
            ArtEntry current = getCurrent();
            Set<String> disliked = identitySet(readEntries(KEY_DISLIKES));
            int mode = getContentMode();
            List<ArtEntry> eligible = new ArrayList<>();
            for (ArtEntry entry : cached) {
                if (!fileExists(entry.localPath) || disliked.contains(entry.canonicalKey())) continue;
                if (current != null && entry.sameArtwork(current)) continue;
                if (!matchesContentMode(entry, mode)) continue;
                eligible.add(entry);
            }
            if (eligible.isEmpty()) return null;
            // Берём давно не показывавшуюся картину. Это даёт предсказуемое
            // переключение по кэшу и не зацикливает несколько последних файлов.
            Collections.sort(eligible, Comparator.comparingLong(e -> e.lastShownAt));
            ArtEntry selected = eligible.get(0).markedShown();
            appendHistory(selected);
            AppLogger.log(context, "cache-fallback", "ok", reason + " | " + selected.qid);
            return selected;
        }
    }

    private ArtEntry nextCatalogCandidate() throws IOException, JSONException {
        int mode = getContentMode();
        ArtEntry candidate = takeFromQueue(mode);
        if (candidate != null) return candidate;

        rebuildQueue(mode, false);
        candidate = takeFromQueue(mode);
        if (candidate != null) return candidate;

        // После показа всех встроенных произведений очередь запускается заново.
        // Сетевой поиск и ожидание пополнения каталога не используются.
        rebuildQueue(mode, true);
        candidate = takeFromQueue(mode);
        if (candidate != null) return candidate;
        throw new IOException("Встроенный каталог повреждён или пуст");
    }

    private ArtEntry takeFromQueue(int mode) throws IOException, JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> catalog = getBundledCatalogEntries();
            Map<String, ArtEntry> byId = new HashMap<>();
            for (ArtEntry e : catalog) byId.put(e.qid, e);
            JSONArray queue = new JSONArray(prefs.getString(queueKey(mode), "[]"));
            int index = prefs.getInt(queueIndexKey(mode), 0);
            Set<String> disliked = identitySet(readEntries(KEY_DISLIKES));
            Set<String> unavailable = readStringArraySet(KEY_UNAVAILABLE_IMAGES);
            Set<String> consumedIdentities = new HashSet<>();
            while (index < queue.length()) {
                String qid = queue.optString(index++, "");
                prefs.edit().putInt(queueIndexKey(mode), index).apply();
                ArtEntry e = byId.get(qid);
                if (e == null) continue;
                String identity = e.canonicalKey();
                if (!consumedIdentities.add(identity) || disliked.contains(identity) || unavailable.contains(identity)) continue;
                if (mode == CONTENT_ADULT_ONLY && !isVerifiedAdult(e)) continue;
                if (!matchesContentMode(e, mode) || isUnwanted(e)) continue;
                return e;
            }
            return null;
        }
    }

    private void rebuildQueue(int mode, boolean allowRepeats) throws IOException, JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> catalog = getBundledCatalogEntries();
            Set<String> shown = allowRepeats ? new HashSet<>() : identitySet(readEntries(KEY_HISTORY));
            shown.addAll(identitySet(readEntries(KEY_CACHE_INDEX)));
            Set<String> disliked = identitySet(readEntries(KEY_DISLIKES));
            Set<String> unavailable = readStringArraySet(KEY_UNAVAILABLE_IMAGES);
            Set<String> queued = new HashSet<>();
            List<String> priorityIds = new ArrayList<>();
            List<String> searchIds = new ArrayList<>();
            for (ArtEntry e : catalog) {
                String identity = e.canonicalKey();
                if (disliked.contains(identity) || shown.contains(identity) || unavailable.contains(identity) || !queued.add(identity)) continue;
                if (mode == CONTENT_ADULT_ONLY && !isVerifiedAdult(e)) continue;
                if (isUnwanted(e) || !matchesContentMode(e, mode)) continue;
                if (hasDirectResolutionMetadata(e)) priorityIds.add(e.qid);
                else searchIds.add(e.qid);
            }
            Collections.shuffle(priorityIds, random);
            Collections.shuffle(searchIds, random);
            priorityIds.addAll(searchIds);
            JSONArray queue = new JSONArray();
            for (String id : priorityIds) queue.put(id);
            prefs.edit().putString(queueKey(mode), queue.toString()).putInt(queueIndexKey(mode), 0).apply();
        }
    }

    private boolean hasDirectResolutionMetadata(ArtEntry entry) {
        if (entry == null) return false;
        String source = safe(entry.sourceUrl).toLowerCase(Locale.ROOT);
        return isCuratedAdultId(entry.qid)
                || isRealQid(entry.qid)
                || !safe(entry.imageUrl).isEmpty()
                || source.contains("ru.wikipedia.org/wiki/")
                || source.contains("en.wikipedia.org/wiki/");
    }

    private String queueKey(int mode) {
        if (mode == CONTENT_ADULT_ONLY) return KEY_QUEUE_ADULT;
        if (mode == CONTENT_ALL) return KEY_QUEUE_ALL;
        return KEY_QUEUE_FILTER;
    }

    private String queueIndexKey(int mode) {
        if (mode == CONTENT_ADULT_ONLY) return KEY_QUEUE_ADULT_INDEX;
        if (mode == CONTENT_ALL) return KEY_QUEUE_ALL_INDEX;
        return KEY_QUEUE_FILTER_INDEX;
    }

    private void clearModeQueuesLocked() {
        prefs.edit()
                .remove(KEY_QUEUE_FILTER).remove(KEY_QUEUE_ALL).remove(KEY_QUEUE_ADULT)
                .putInt(KEY_QUEUE_FILTER_INDEX, 0)
                .putInt(KEY_QUEUE_ALL_INDEX, 0)
                .putInt(KEY_QUEUE_ADULT_INDEX, 0)
                .apply();
    }

    // Поиск кандидатов выполняется только по встроенным метаданным.
    // Сеть используется отдельно для загрузки изображения и статьи Wikipedia.org.

    private ArtEntry findReusableLocalEntry(ArtEntry candidate) {
        synchronized (DATA_LOCK) {
            try {
                String identity = candidate.canonicalKey();
                for (String key : new String[]{KEY_CACHE_INDEX, KEY_HISTORY, KEY_FAVORITES}) {
                    List<ArtEntry> entries = readEntries(key);
                    for (int i = entries.size() - 1; i >= 0; i--) {
                        ArtEntry existing = entries.get(i);
                        if (!identity.equals(existing.canonicalKey()) || !fileExists(existing.localPath)) continue;
                        return new ArtEntry(
                                isRealQid(existing.qid) ? existing.qid : candidate.qid,
                                richer(candidate.title, existing.title),
                                ArtEntry.isUnknownArtist(candidate.artist) ? existing.artist : candidate.artist,
                                richer(existing.description, candidate.description),
                                richer(existing.imageUrl, candidate.imageUrl),
                                richer(existing.originalImageUrl, candidate.originalImageUrl),
                                existing.localPath,
                                richer(existing.sourceUrl, candidate.sourceUrl),
                                richer(existing.instanceLabel, candidate.instanceLabel),
                                richer(existing.materialLabel, candidate.materialLabel),
                                richer(existing.genreLabel, candidate.genreLabel),
                                existing.addedAt,
                                System.currentTimeMillis(),
                                existing.showCount + 1,
                                existing.explicitContent || candidate.explicitContent);
                    }
                }
            } catch (Exception ignored) { }
        }
        return null;
    }

    private ArtEntry downloadArtwork(ArtEntry candidate) throws IOException, JSONException {
        return downloadArtwork(candidate, false);
    }

    private ArtEntry downloadArtwork(ArtEntry candidate, boolean quickNetwork) throws IOException, JSONException {
        ArtEntry resolved = hasBundledWikipediaPayload(candidate)
                ? candidate
                : resolveWikipediaMetadata(candidate, quickNetwork);
        String standardUrl = resolved.imageUrl;
        String originalUrl = resolved.originalImageUrl;

        if (originalUrl == null || originalUrl.isEmpty()) originalUrl = standardUrl;
        if (standardUrl == null || standardUrl.isEmpty()) {
            throw new IOException("Изображение произведения не найдено");
        }
        if (standardUrl.toLowerCase(Locale.ROOT).matches(".*\\.svg(?:\\?.*)?$")) {
            throw new IOException("Векторный файл пропущен");
        }

        File dir = new File(context.getFilesDir(), "art_cache");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Не удалось создать папку кэша");
        String cacheBase = "art_" + Integer.toHexString(candidate.canonicalKey().hashCode());
        File tmp = new File(dir, cacheBase + "_" + System.currentTimeMillis() + ".tmp");
        downloadFile(standardUrl, tmp, quickNetwork);
        File stem = new File(dir, cacheBase);
        deleteFileQuietly(stem.getAbsolutePath() + ".jpg");
        deleteFileQuietly(stem.getAbsolutePath() + ".png");
        File processed;
        try {
            processed = ImageProcessor.processToStandard(tmp, stem);
        } finally {
            deleteFileQuietly(tmp.getAbsolutePath());
        }
        return resolved.withDownloadedData(resolved.description, standardUrl, originalUrl,
                processed.getAbsolutePath());
    }

    private boolean hasBundledWikipediaPayload(ArtEntry entry) {
        if (entry == null) return false;
        String source = safe(entry.sourceUrl).toLowerCase(Locale.ROOT);
        String image = safe(entry.imageUrl).toLowerCase(Locale.ROOT);
        String genre = safe(entry.genreLabel).toLowerCase(Locale.ROOT);
        boolean exactArticle = source.startsWith("https://ru.wikipedia.org/wiki/")
                || source.startsWith("https://en.wikipedia.org/wiki/");
        boolean raster = !image.isEmpty() && !image.matches(".*\\.(svg|tif|tiff|pdf|djvu)(?:\\?.*)?$");
        boolean marker = genre.contains("bundled-filter") || genre.contains("bundled-nsfw");
        return marker && exactArticle && raster && !safe(entry.description).trim().isEmpty();
    }

    private ArtEntry resolveWikipediaMetadata(ArtEntry candidate, boolean quickNetwork)
            throws IOException, JSONException {
        // Единственная цепочка разрешения: точная статья в русской Википедии,
        // затем точная статья в английской Википедии. Описание всегда берётся
        // из вступления найденной статьи, а не составляется из тегов каталога.
        WikipediaInfo wikipedia = resolveWikipediaInfo(candidate, quickNetwork);
        if (wikipedia == null || wikipedia.sourceUrl.isEmpty()) {
            throw new IOException("Статья произведения не найдена");
        }
        if (wikipedia.description.trim().isEmpty()) {
            throw new IOException("Описание произведения не найдено");
        }

        String title = wikipedia.pageTitle.isEmpty() ? candidate.title : wikipedia.pageTitle;
        String standard = wikipedia.standardUrl.isEmpty() ? candidate.imageUrl : wikipedia.standardUrl;
        String original = wikipedia.originalUrl.isEmpty() ? candidate.originalImageUrl : wikipedia.originalUrl;
        if (original == null || original.isEmpty()) original = standard;

        return candidate.withResolvedWikipedia(title, wikipedia.description,
                wikipedia.language, standard, original, wikipedia.sourceUrl);
    }

    private WikipediaInfo resolveWikipediaInfo(ArtEntry candidate, boolean quickNetwork)
            throws IOException, JSONException {
        WikipediaInfo russian = null;
        WikipediaInfo english = null;

        boolean curatedExact = safe(candidate.genreLabel).toLowerCase(Locale.ROOT).contains("bundled-nsfw")
                || safe(candidate.genreLabel).toLowerCase(Locale.ROOT).contains("verified-wikipedia");
        if (candidate.sourceUrl.contains("ru.wikipedia.org/wiki/")) {
            String title = pageTitleFromArticle(candidate.sourceUrl, candidate.title);
            russian = fetchWikipediaInfo("ru", title, quickNetwork);
            if (!curatedExact && !isWikipediaMatch(candidate, russian)) russian = null;
        } else if (candidate.sourceUrl.contains("en.wikipedia.org/wiki/")) {
            String title = pageTitleFromArticle(candidate.sourceUrl, candidate.title);
            english = fetchWikipediaInfo("en", title, quickNetwork);
            if (!curatedExact && !isWikipediaMatch(candidate, english)) english = null;
        }

        if (russian == null) {
            String ruTitle = searchWikipediaTitle(candidate, "ru", quickNetwork);
            if (!ruTitle.isEmpty()) {
                WikipediaInfo value = fetchWikipediaInfo("ru", ruTitle, quickNetwork);
                if (isWikipediaMatch(candidate, value)) russian = value;
            }
        }

        // Русская статья имеет приоритет. Если статья найдена, но у неё нет
        // изображения, английская статья используется только как источник
        // изображения, а ссылка и описание остаются русскими.
        if (russian != null && russian.hasRasterImage() && !russian.description.isEmpty()) return russian;

        if (english == null) {
            String enTitle = searchWikipediaTitle(candidate, "en", quickNetwork);
            if (!enTitle.isEmpty()) {
                WikipediaInfo value = fetchWikipediaInfo("en", enTitle, quickNetwork);
                if (isWikipediaMatch(candidate, value)) english = value;
            }
        }

        if (russian != null && !russian.description.isEmpty()
                && english != null && english.hasRasterImage()) {
            return new WikipediaInfo("ru", russian.pageTitle, russian.description,
                    english.standardUrl, english.originalUrl, russian.sourceUrl,
                    russian.qid.isEmpty() ? english.qid : russian.qid,
                    russian.categories + " " + english.categories);
        }
        if (english != null && english.hasRasterImage() && !english.description.isEmpty()) return english;
        return russian != null && !russian.description.isEmpty() ? russian : english;
    }

    private String searchWikipediaTitle(ArtEntry candidate, String language, boolean quickNetwork)
            throws IOException, JSONException {
        String title = ArtEntry.titleForWidget(candidate.title).trim();
        String artist = candidate.artist.trim();
        String queryText = "\"" + title + "\" " + artist;
        String url = "https://" + language + ".wikipedia.org/w/api.php?action=query"
                + "&format=json&formatversion=2&list=search&srlimit=8&srnamespace=0"
                + "&srprop=snippet&srsearch=" + urlEncode(queryText);
        JSONObject root = readJson(url, quickNetwork);
        JSONObject query = root.optJSONObject("query");
        JSONArray results = query == null ? null : query.optJSONArray("search");
        if (results == null || results.length() == 0) {
            queryText = (title + " " + artist).trim();
            url = "https://" + language + ".wikipedia.org/w/api.php?action=query"
                    + "&format=json&formatversion=2&list=search&srlimit=8&srnamespace=0"
                    + "&srprop=snippet&srsearch=" + urlEncode(queryText);
            root = readJson(url, quickNetwork);
            query = root.optJSONObject("query");
            results = query == null ? null : query.optJSONArray("search");
        }
        if (results == null) return "";
        String bestTitle = "";
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < results.length(); i++) {
            JSONObject row = results.optJSONObject(i);
            if (row == null) continue;
            String resultTitle = row.optString("title", "");
            String snippet = row.optString("snippet", "").replaceAll("<[^>]+>", " ");
            int score = wikipediaSearchScore(candidate, resultTitle, snippet);
            if (score > bestScore) {
                bestScore = score;
                bestTitle = resultTitle;
            }
        }
        return bestScore >= 12 ? bestTitle : "";
    }

    private int wikipediaSearchScore(ArtEntry candidate, String resultTitle, String snippet) {
        String expected = normalizeForMatch(ArtEntry.titleForWidget(candidate.title));
        String found = normalizeForMatch(resultTitle);
        String contextText = normalizeForMatch(resultTitle + " " + snippet);
        int score = 0;
        if (!expected.isEmpty() && expected.equals(found)) score += 14;
        else if (!expected.isEmpty() && (found.contains(expected) || expected.contains(found))) score += 8;

        int matchedTitleTokens = 0;
        int meaningfulTitleTokens = 0;
        for (String token : expected.split(" ")) {
            if (token.length() < 4) continue;
            meaningfulTitleTokens++;
            if (contextText.contains(token)) {
                score += 2;
                matchedTitleTokens++;
            }
        }
        String artist = normalizeForMatch(candidate.artist);
        boolean artistMatched = false;
        for (String token : artist.split(" ")) {
            if (token.length() >= 4 && contextText.contains(token)) {
                score += 6;
                artistMatched = true;
                break;
            }
        }
        if (meaningfulTitleTokens > 0 && matchedTitleTokens == 0) score -= 12;
        if (meaningfulTitleTokens <= 1 && !artistMatched) score -= 12;
        return score;
    }

    private WikipediaInfo fetchWikipediaInfo(String language, String pageTitle, boolean quickNetwork)
            throws IOException, JSONException {
        String apiUrl = "https://" + language + ".wikipedia.org/w/api.php?action=query"
                + "&format=json&formatversion=2&redirects=1"
                + "&prop=extracts%7Cpageimages%7Cpageprops%7Ccategories"
                + "&exintro=1&explaintext=1&cllimit=max&clshow=!hidden"
                + "&piprop=thumbnail%7Coriginal%7Cname"
                + "&pithumbsize=1600"
                + "&titles=" + urlEncode(pageTitle);
        JSONObject json = readJson(apiUrl, quickNetwork);
        JSONObject query = json.optJSONObject("query");
        JSONArray pages = query == null ? null : query.optJSONArray("pages");
        JSONObject page = pages == null || pages.length() == 0 ? null : pages.optJSONObject(0);
        if (page == null || page.optBoolean("missing", false)) return null;
        String extract = page.optString("extract", "").trim();
        JSONObject thumb = page.optJSONObject("thumbnail");
        JSONObject original = page.optJSONObject("original");
        String standard = thumb == null ? "" : thumb.optString("source", "");
        String originalUrl = original == null ? "" : original.optString("source", "");
        if (standard.isEmpty()) standard = originalUrl;
        if (originalUrl.isEmpty()) originalUrl = standard;
        String finalTitle = page.optString("title", pageTitle);
        String source = "https://" + language + ".wikipedia.org/wiki/"
                + encodePath(finalTitle.replace(' ', '_'));
        JSONObject props = page.optJSONObject("pageprops");
        String qid = props == null ? "" : props.optString("wikibase_item", "");
        if (standard.isEmpty() && qid.matches("Q\\d+")) {
            String[] p18 = resolveExactP18(qid, quickNetwork);
            standard = p18[0];
            originalUrl = p18[1];
        }
        JSONArray categoriesArray = page.optJSONArray("categories");
        StringBuilder categories = new StringBuilder();
        if (categoriesArray != null) {
            for (int i = 0; i < categoriesArray.length(); i++) {
                JSONObject category = categoriesArray.optJSONObject(i);
                if (category == null) continue;
                if (categories.length() > 0) categories.append(' ');
                categories.append(category.optString("title", ""));
            }
        }
        return new WikipediaInfo(language, finalTitle,
                extract.isEmpty() ? "" : shortDescription(extract),
                standard, originalUrl, source, qid, categories.toString());
    }

    private String[] resolveExactP18(String qid, boolean quickNetwork)
            throws IOException, JSONException {
        String url = "https://www.wikidata.org/w/api.php?action=wbgetentities"
                + "&format=json&ids=" + urlEncode(qid) + "&props=claims";
        JSONObject root = readJson(url, quickNetwork);
        JSONObject entities = root.optJSONObject("entities");
        JSONObject entity = entities == null ? null : entities.optJSONObject(qid);
        JSONObject claims = entity == null ? null : entity.optJSONObject("claims");
        JSONArray images = claims == null ? null : claims.optJSONArray("P18");
        JSONObject claim = images == null || images.length() == 0 ? null : images.optJSONObject(0);
        JSONObject mainsnak = claim == null ? null : claim.optJSONObject("mainsnak");
        JSONObject datavalue = mainsnak == null ? null : mainsnak.optJSONObject("datavalue");
        String filename = datavalue == null ? "" : datavalue.optString("value", "").trim();
        if (filename.isEmpty()) return new String[]{"", ""};
        String encoded = encodePath(filename.replace(' ', '_'));
        String original = "https://commons.wikimedia.org/wiki/Special:Redirect/file/" + encoded;
        String standard = original + "?width=1600";
        return new String[]{standard, original};
    }

    private boolean isWikipediaMatch(ArtEntry candidate, WikipediaInfo info) {
        if (info == null) return false;
        String expectedTitle = normalizeForMatch(ArtEntry.titleForWidget(candidate.title));
        String pageTitle = normalizeForMatch(info.pageTitle);
        String haystack = normalizeForMatch(info.pageTitle + " " + info.description + " " + info.categories);

        int titleMatches = 0;
        int titleTokens = 0;
        for (String token : expectedTitle.split(" ")) {
            if (token.length() < 4) continue;
            titleTokens++;
            if (haystack.contains(token)) titleMatches++;
        }
        boolean titleExact = !expectedTitle.isEmpty()
                && (expectedTitle.equals(pageTitle) || pageTitle.contains(expectedTitle) || expectedTitle.contains(pageTitle));

        boolean artistMatched = ArtEntry.isUnknownArtist(candidate.artist);
        for (String token : normalizeForMatch(candidate.artist).split(" ")) {
            if (token.length() >= 4 && haystack.contains(token)) {
                artistMatched = true;
                break;
            }
        }
        boolean painting = containsPaintingMarker(haystack);
        boolean titleStrong = titleExact || (titleTokens >= 2 && titleMatches >= Math.min(2, titleTokens));
        if (!painting || !titleStrong || !artistMatched) return false;

        boolean explicitMarker = containsExplicitArtMarker(haystack);
        if (candidate.explicitContent && !explicitMarker) return false;
        if (!candidate.explicitContent && explicitMarker) return false;
        return true;
    }

    private boolean containsPaintingMarker(String text) {
        return text.contains(" картина") || text.contains(" картины")
                || text.contains(" живопис") || text.contains(" полотно")
                || text.contains(" painting") || text.contains(" paintings")
                || text.contains(" painted") || text.contains(" oil on canvas")
                || text.contains(" oil on panel");
    }

    private boolean containsExplicitArtMarker(String text) {
        String[] markers = new String[]{
                "обнаж", "эрот", "ню ", "купаль", "одалиск", "венер", "дана",
                "леда", "сусанна", "вирсав", "андромед", "адам и ева", "нимф",
                " nude", "nudity", "erotic", "bather", "bathing", "odalisque",
                "venus", "danae", "leda", "susanna", "bathsheba", "andromeda",
                "adam and eve", "nymph"
        };
        for (String marker : markers) if (text.contains(marker)) return true;
        return false;
    }

    private String normalizeForMatch(String value) {
        return (value == null ? "" : value.toLowerCase(Locale.ROOT))
                .replace('ё', 'е')
                .replaceAll("[^\\p{L}\\p{N}]+", " ")
                .trim();
    }

    private static final class WikipediaInfo {
        final String language;
        final String pageTitle;
        final String description;
        final String standardUrl;
        final String originalUrl;
        final String sourceUrl;
        final String qid;
        final String categories;

        WikipediaInfo(String language, String pageTitle, String description,
                      String standardUrl, String originalUrl, String sourceUrl,
                      String qid, String categories) {
            this.language = language == null ? "" : language;
            this.pageTitle = pageTitle == null ? "" : pageTitle;
            this.description = description == null ? "" : description;
            this.standardUrl = standardUrl == null ? "" : standardUrl;
            this.originalUrl = originalUrl == null ? this.standardUrl : originalUrl;
            this.sourceUrl = sourceUrl == null ? "" : sourceUrl;
            this.qid = qid == null ? "" : qid;
            this.categories = categories == null ? "" : categories;
        }

        boolean hasRasterImage() {
            String lower = standardUrl.toLowerCase(Locale.ROOT);
            return !standardUrl.isEmpty() && !lower.matches(".*\\.svg(?:\\?.*)?$");
        }
    }

    public boolean needsWikipediaDescription(ArtEntry entry) {
        if (entry == null) return false;
        String source = safe(entry.sourceUrl).toLowerCase(Locale.ROOT);
        if (!source.contains("wikipedia.org/wiki/")) return false;
        return safe(entry.description).isEmpty() || isPreparedCatalogDescription(entry.description);
    }

    public ArtEntry refreshCurrentWikipediaDescription() throws IOException, JSONException {
        try { initializeStorageInBackground(); }
        catch (JSONException | IOException e) { throw e; }
        catch (Exception e) { throw new IOException("Не удалось подготовить локальный каталог", e); }

        synchronized (NETWORK_LOCK) {
            ArtEntry current = getCurrent();
            if (current == null || !needsWikipediaDescription(current)) return current;
            ArtEntry refreshed = resolveWikipediaMetadata(current, false);
            synchronized (DATA_LOCK) {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                int index = prefs.getInt(KEY_INDEX, -1);
                if (index >= 0 && index < history.size()) {
                    ArtEntry old = history.get(index);
                    refreshed = copyWikipediaMetadata(refreshed, old.localPath,
                            old.addedAt, old.lastShownAt, old.showCount);
                    history.set(index, refreshed);
                    writeEntries(KEY_HISTORY, history);
                    updateStatsLocked(history);
                }
                refreshFavoriteMetadataLocked(current, refreshed);
                prefs.edit().putString(KEY_CURRENT, refreshed.toJson().toString()).apply();
            }
            return refreshed;
        }
    }

    private ArtEntry copyWikipediaMetadata(ArtEntry source, String localPath,
                                           long addedAt, long lastShownAt, int showCount) {
        return new ArtEntry(source.qid, source.title, source.artist, source.description,
                source.titleRu, source.titleEn, source.artistRu, source.artistEn,
                source.descriptionRu, source.descriptionEn, source.sourceLanguage,
                source.imageUrl, source.originalImageUrl, localPath, source.sourceUrl,
                source.instanceLabel, source.materialLabel, source.genreLabel,
                addedAt, lastShownAt, showCount, source.explicitContent);
    }

    private void refreshFavoriteMetadataLocked(ArtEntry oldEntry, ArtEntry refreshed) throws JSONException {
        List<ArtEntry> favorites = readEntries(KEY_FAVORITES);
        boolean changed = false;
        String oldKey = oldEntry.canonicalKey();
        for (int i = 0; i < favorites.size(); i++) {
            ArtEntry favorite = favorites.get(i);
            if (!favorite.qid.equals(oldEntry.qid) && !favorite.canonicalKey().equals(oldKey)) continue;
            favorites.set(i, copyWikipediaMetadata(refreshed, favorite.localPath,
                    favorite.addedAt, favorite.lastShownAt, favorite.showCount));
            changed = true;
        }
        if (changed) writeEntries(KEY_FAVORITES, favorites);
    }

    private boolean isPreparedCatalogDescription(String description) {
        String text = safe(description).toLowerCase(Locale.ROOT);
        return (text.startsWith("«") && text.contains("» — произведение художника "))
                || text.contains("в произведении присутствует изображение обнажённого тела")
                || text.contains("основные темы:")
                || text.contains("произведение относят к")
                || text.contains("темы и стиль:");
    }

    private void clearPreparedDescriptionsLocked(String key) throws JSONException {
        List<ArtEntry> entries = readEntries(key);
        boolean changed = false;
        for (int i = 0; i < entries.size(); i++) {
            ArtEntry entry = entries.get(i);
            if (!isPreparedCatalogDescription(entry.description)) continue;
            entries.set(i, new ArtEntry(entry.qid, entry.title, entry.artist, "",
                    entry.imageUrl, entry.originalImageUrl, entry.localPath, entry.sourceUrl,
                    entry.instanceLabel, entry.materialLabel, entry.genreLabel,
                    entry.addedAt, entry.lastShownAt, entry.showCount, entry.explicitContent));
            changed = true;
        }
        if (changed) writeEntries(key, entries);
    }

    private void clearPreparedCurrentDescriptionLocked() {
        try {
            String raw = prefs.getString(KEY_CURRENT, "");
            if (raw == null || raw.trim().isEmpty()) return;
            ArtEntry entry = ArtEntry.fromJson(new JSONObject(raw));
            if (!isPreparedCatalogDescription(entry.description)) return;
            ArtEntry cleaned = new ArtEntry(entry.qid, entry.title, entry.artist, "",
                    entry.imageUrl, entry.originalImageUrl, entry.localPath, entry.sourceUrl,
                    entry.instanceLabel, entry.materialLabel, entry.genreLabel,
                    entry.addedAt, entry.lastShownAt, entry.showCount, entry.explicitContent);
            prefs.edit().putString(KEY_CURRENT, cleaned.toJson().toString()).apply();
        } catch (Exception e) {
            AppLogger.log(context, "description-migration", "skip", friendlyMessage(e));
        }
    }

    private ArtEntry ensureLocalImage(ArtEntry entry) throws IOException, JSONException {
        if (entry == null) return null;
        if (fileExists(entry.localPath)) {
            return needsWikipediaDescription(entry) ? resolveWikipediaMetadata(entry, false) : entry;
        }
        return downloadArtwork(entry);
    }

    private void upsertCacheIndexLocked(ArtEntry entry) throws JSONException {
        if (entry == null || !fileExists(entry.localPath)) return;
        List<ArtEntry> index = readEntries(KEY_CACHE_INDEX);
        String identity = entry.canonicalKey();
        for (int i = index.size() - 1; i >= 0; i--) {
            ArtEntry old = index.get(i);
            if (identity.equals(old.canonicalKey()) || !fileExists(old.localPath)) {
                index.remove(i);
            }
        }
        index.add(entry);
        writeEntries(KEY_CACHE_INDEX, index);
        prefs.edit().putInt(KEY_CACHE_COUNT, index.size()).apply();
    }

    private void appendHistory(ArtEntry entry) throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> history = readEntries(KEY_HISTORY);
            history.add(entry);
            while (history.size() > MAX_HISTORY_RECORDS) history.remove(0);
            writeEntries(KEY_HISTORY, history);
            upsertCacheIndexLocked(entry);
            updateStatsLocked(history);
            prefs.edit().putInt(KEY_INDEX, history.size() - 1)
                    .putString(KEY_CURRENT, entry.toJson().toString()).apply();
        }
    }

    private void replaceHistoryEntry(ArtEntry entry) throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> history = readEntries(KEY_HISTORY);
            int index = prefs.getInt(KEY_INDEX, -1);
            if (index >= 0 && index < history.size()) {
                history.set(index, entry);
                writeEntries(KEY_HISTORY, history);
                upsertCacheIndexLocked(entry);
                updateStatsLocked(history);
                prefs.edit().putString(KEY_CURRENT, entry.toJson().toString()).apply();
            }
        }
    }

    private void enforceCacheLimit() throws JSONException {
        synchronized (DATA_LOCK) {
            List<ArtEntry> history = readEntries(KEY_HISTORY);
            Set<String> favorites = identitySet(readEntries(KEY_FAVORITES));
            Set<String> dislikes = identitySet(readEntries(KEY_DISLIKES));
            int currentIndex = prefs.getInt(KEY_INDEX, -1);
            while (countFiles(history) > MAX_CACHE_FILES) {
                int victim = findVictim(history, dislikes, favorites, currentIndex, true);
                if (victim < 0) victim = findVictim(history, dislikes, favorites, currentIndex, false);
                if (victim < 0) break;
                ArtEntry e = history.get(victim);
                deleteFileQuietly(e.localPath);
                history.set(victim, e.withLocalPath(""));
            }
            writeEntries(KEY_HISTORY, history);
            updateStatsLocked(history);
            refreshCurrentFromHistoryLocked(history);
        }
    }

    private int findVictim(List<ArtEntry> history, Set<String> dislikes, Set<String> favorites,
                           int currentIndex, boolean dislikedOnly) {
        int victim = -1;
        long oldest = Long.MAX_VALUE;
        for (int i = 0; i < history.size(); i++) {
            ArtEntry e = history.get(i);
            String identity = e.canonicalKey();
            if (!fileExists(e.localPath) || i == currentIndex || favorites.contains(identity)) continue;
            if (dislikedOnly && !dislikes.contains(identity)) continue;
            if (!dislikedOnly && dislikes.contains(identity)) continue;
            if (e.lastShownAt < oldest) {
                oldest = e.lastShownAt;
                victim = i;
            }
        }
        return victim;
    }

    private void clearLocalPathInHistory(String qid) throws JSONException {
        ArtEntry target = findEntry(qid);
        String identity = target == null ? "" : target.canonicalKey();
        List<ArtEntry> history = readEntries(KEY_HISTORY);
        for (int i = 0; i < history.size(); i++) {
            ArtEntry e = history.get(i);
            if (e.qid.equals(qid) || (!identity.isEmpty() && identity.equals(e.canonicalKey()))) {
                history.set(i, e.withLocalPath(""));
            }
        }
        writeEntries(KEY_HISTORY, history);
        updateStatsLocked(history);
        refreshCurrentFromHistoryLocked(history);
    }

    private void removeFromQueue(String qid) {
        synchronized (DATA_LOCK) {
            ArtEntry target = findEntry(qid);
            String identity = target == null ? "" : target.canonicalKey();
            Map<String, String> identitiesById = new HashMap<>();
            try {
                for (ArtEntry e : getBundledCatalogEntries()) identitiesById.put(e.qid, e.canonicalKey());
            } catch (Exception ignored) { }
            for (int mode : new int[]{CONTENT_FILTER, CONTENT_ALL, CONTENT_ADULT_ONLY}) {
                try {
                    String key = queueKey(mode);
                    JSONArray queue = new JSONArray(prefs.getString(key, "[]"));
                    JSONArray out = new JSONArray();
                    for (int i = 0; i < queue.length(); i++) {
                        String id = queue.optString(i, "");
                        String queuedIdentity = identitiesById.get(id);
                        if (qid.equals(id)) continue;
                        if (!identity.isEmpty() && identity.equals(queuedIdentity)) continue;
                        out.put(id);
                    }
                    prefs.edit().putString(key, out.toString()).putInt(queueIndexKey(mode), 0).apply();
                } catch (Exception ignored) { }
            }
        }
    }

    private void migrateIfNeeded() {
        if (prefs.getBoolean(KEY_MIGRATED, false)) return;
        synchronized (DATA_LOCK) {
            if (prefs.getBoolean(KEY_MIGRATED, false)) return;
            try {
                List<ArtEntry> history = readEntries(KEY_HISTORY);
                writeEntries(KEY_HISTORY, history);
                updateStatsLocked(history);
                refreshCurrentFromHistoryLocked(history);
                List<ArtEntry> catalog = readEntries(KEY_CATALOG);
                if (catalog.isEmpty()) addFallbackCatalogLocked();
                else {
                    List<ArtEntry> unique = uniqueById(catalog);
                    writeEntries(KEY_CATALOG, unique);
                    prefs.edit().putInt(KEY_CATALOG_COUNT, unique.size()).apply();
                }
                if (!prefs.contains(KEY_CATALOG_OFFSET)) {
                    int oldCount = catalog.size();
                    prefs.edit().putInt(KEY_CATALOG_OFFSET, oldCount >= 800 ? 1000 : 0).apply();
                }
                prefs.edit().putBoolean(KEY_MIGRATED, true).remove(KEY_QUEUE).putInt(KEY_QUEUE_INDEX, 0).apply();
            } catch (Exception e) {
                AppLogger.log(context, "migration", "error", e.getMessage());
                prefs.edit().putBoolean(KEY_MIGRATED, true).apply();
            }
        }
    }

    private void ensureV10Ready() {
        if (prefs.getBoolean(KEY_V10_READY, false)) return;
        synchronized (DATA_LOCK) {
            if (prefs.getBoolean(KEY_V10_READY, false)) return;
            try {
                List<ArtEntry> catalog = readEntries(KEY_CATALOG);
                List<ArtEntry> cleaned = new ArrayList<>();
                for (ArtEntry e : catalog) {
                    boolean adult = isCuratedAdultId(e.qid) || classifyExplicit(e.title, e.description, e.genreLabel);
                    cleaned.add(new ArtEntry(e.qid, e.title, e.artist, e.description, e.imageUrl,
                            e.originalImageUrl, e.localPath, e.sourceUrl, e.instanceLabel,
                            e.materialLabel, e.genreLabel, e.addedAt, e.lastShownAt, e.showCount, adult));
                }
                Set<String> ids = idSet(cleaned);
                for (ArtEntry e : curatedAdultCatalog()) {
                    if (ids.add(e.qid)) cleaned.add(e);
                }
                cleaned = uniqueById(cleaned);
                writeEntries(KEY_CATALOG, cleaned);
                clearModeQueuesLocked();
                prefs.edit().putInt(KEY_CATALOG_COUNT, cleaned.size())
                        .putBoolean(KEY_V10_READY, true)
                        .remove(KEY_QUEUE).putInt(KEY_QUEUE_INDEX, 0)
                        .apply();
                AppLogger.log(context, "migration", "v10", "catalog=" + cleaned.size());
            } catch (Exception e) {
                AppLogger.log(context, "migration", "v10 error", e.getMessage());
                prefs.edit().putBoolean(KEY_V10_READY, true).apply();
            }
        }
    }

    private void ensureV11_2Ready() {
        if (prefs.getBoolean(KEY_V11_2_READY, false)) return;
        synchronized (DATA_LOCK) {
            if (prefs.getBoolean(KEY_V11_2_READY, false)) return;
            try {
                ArtEntry current = getCurrent();
                String currentIdentity = current == null ? "" : current.canonicalKey();

                List<ArtEntry> catalog = mergeEquivalentEntries(readEntries(KEY_CATALOG), false);
                List<ArtEntry> favorites = mergeEquivalentEntries(readEntries(KEY_FAVORITES), false);
                List<ArtEntry> dislikes = mergeEquivalentEntries(readEntries(KEY_DISLIKES), true);
                List<ArtEntry> history = mergeEquivalentEntries(readEntries(KEY_HISTORY), false);

                writeEntries(KEY_CATALOG, catalog);
                writeEntries(KEY_FAVORITES, favorites);
                writeEntries(KEY_DISLIKES, dislikes);
                writeEntries(KEY_HISTORY, history);

                int newIndex = history.isEmpty() ? -1 : history.size() - 1;
                if (!currentIdentity.isEmpty()) {
                    for (int i = 0; i < history.size(); i++) {
                        if (currentIdentity.equals(history.get(i).canonicalKey())) newIndex = i;
                    }
                }
                SharedPreferences.Editor editor = prefs.edit()
                        .putInt(KEY_INDEX, newIndex)
                        .putInt(KEY_CATALOG_COUNT, catalog.size())
                        .putBoolean(KEY_V11_2_READY, true);
                if (newIndex >= 0) editor.putString(KEY_CURRENT, history.get(newIndex).toJson().toString());
                else editor.remove(KEY_CURRENT);
                editor.apply();

                clearModeQueuesLocked();
                updateStatsLocked(history);
                deleteOrphanCacheFiles(history, favorites);
                AppLogger.log(context, "migration", "v11.2", "history=" + history.size() + ", catalog=" + catalog.size());
            } catch (Exception e) {
                AppLogger.log(context, "migration", "v11.2 error", e.getMessage());
                // Не отмечаем миграцию завершённой: при следующем запуске
                // приложение повторит безопасную очистку дублей.
            }
        }
    }

    private void ensureV11_3Ready() {
        if (prefs.getBoolean(KEY_V11_3_READY, false)) return;
        synchronized (DATA_LOCK) {
            if (prefs.getBoolean(KEY_V11_3_READY, false)) return;
            try {
                ensureCuratedAdultCatalogLocked();

                // Сбрасываем старую очередь 18+, которая могла содержать
                // ложноположительные и уже просмотренные записи из v11.2.
                prefs.edit()
                        .remove(KEY_QUEUE_ADULT)
                        .putInt(KEY_QUEUE_ADULT_INDEX, 0)
                        .putBoolean(KEY_V11_3_READY, true)
                        .apply();

                AppLogger.log(context, "migration", "v11.3", "adult queue reset");
            } catch (Exception e) {
                AppLogger.log(context, "migration", "v11.3 error", e.getMessage());
                // Не отмечаем миграцию завершённой, чтобы повторить её безопасно.
            }
        }
    }

    private void ensureV11_4Ready() {
        if (prefs.getBoolean(KEY_V11_4_READY, false)) return;
        synchronized (DATA_LOCK) {
            if (prefs.getBoolean(KEY_V11_4_READY, false)) return;
            try {
                prefs.edit()
                        .remove(KEY_QUEUE_ADULT)
                        .putInt(KEY_QUEUE_ADULT_INDEX, 0)
                        .putInt(KEY_ADULT_CATALOG_OFFSET, 0)
                        .putBoolean(KEY_ADULT_CATALOG_END, false)
                        .putBoolean(KEY_V11_4_READY, true)
                        .apply();
                AppLogger.log(context, "migration", "v11.4", "adult pagination enabled");
            } catch (Exception e) {
                AppLogger.log(context, "migration", "v11.4 error", e.getMessage());
            }
        }
    }

    /** Объединяет одинаковые произведения по статье/метаданным, а не только по QID. */
    private List<ArtEntry> mergeEquivalentEntries(List<ArtEntry> source, boolean stripLocalPath) {
        Map<String, ArtEntry> merged = new java.util.LinkedHashMap<>();
        for (ArtEntry entry : source) {
            ArtEntry value = stripLocalPath ? entry.withLocalPath("") : entry;
            String key = value.canonicalKey();
            ArtEntry old = merged.get(key);
            if (old == null) merged.put(key, value);
            else merged.put(key, mergeEquivalent(old, value, stripLocalPath));
        }
        return new ArrayList<>(merged.values());
    }

    private ArtEntry mergeEquivalent(ArtEntry a, ArtEntry b, boolean stripLocalPath) {
        ArtEntry preferred = preferEntry(a, b);
        ArtEntry other = preferred == a ? b : a;
        String qid = isRealQid(a.qid) ? a.qid : (isRealQid(b.qid) ? b.qid : preferred.qid);
        String path = stripLocalPath ? "" : (fileExists(preferred.localPath) ? preferred.localPath : other.localPath);
        if (!stripLocalPath && fileExists(a.localPath) && fileExists(b.localPath)
                && !a.localPath.equals(b.localPath)) {
            String keep = path;
            String remove = keep.equals(a.localPath) ? b.localPath : a.localPath;
            deleteFileQuietly(remove);
        }
        return new ArtEntry(qid,
                richer(preferred.title, other.title),
                ArtEntry.isUnknownArtist(preferred.artist) ? other.artist : preferred.artist,
                richer(preferred.description, other.description),
                richer(preferred.imageUrl, other.imageUrl),
                richer(preferred.originalImageUrl, other.originalImageUrl),
                path,
                richer(preferred.sourceUrl, other.sourceUrl),
                richer(preferred.instanceLabel, other.instanceLabel),
                richer(preferred.materialLabel, other.materialLabel),
                richer(preferred.genreLabel, other.genreLabel),
                Math.min(a.addedAt, b.addedAt),
                Math.max(a.lastShownAt, b.lastShownAt),
                Math.max(a.showCount, b.showCount),
                a.explicitContent || b.explicitContent);
    }

    private ArtEntry preferEntry(ArtEntry a, ArtEntry b) {
        if (fileExists(a.localPath) != fileExists(b.localPath)) return fileExists(a.localPath) ? a : b;
        if (isRealQid(a.qid) != isRealQid(b.qid)) return isRealQid(a.qid) ? a : b;
        return a.lastShownAt >= b.lastShownAt ? a : b;
    }

    private boolean isRealQid(String value) {
        return value != null && value.matches("(?i)Q\\d+");
    }

    private String richer(String first, String second) {
        String a = safe(first);
        String b = safe(second);
        if (a.isEmpty()) return b;
        if (b.isEmpty()) return a;
        return a.length() >= b.length() ? a : b;
    }

    private void deleteOrphanCacheFiles(List<ArtEntry> history, List<ArtEntry> favorites) {
        Set<String> keep = new HashSet<>();
        for (ArtEntry e : history) if (fileExists(e.localPath)) keep.add(new File(e.localPath).getAbsolutePath());
        for (ArtEntry e : favorites) if (fileExists(e.localPath)) keep.add(new File(e.localPath).getAbsolutePath());
        try {
            for (ArtEntry e : readEntries(KEY_CACHE_INDEX)) {
                if (fileExists(e.localPath)) keep.add(new File(e.localPath).getAbsolutePath());
            }
        } catch (Exception ignored) { }
        File dir = new File(context.getFilesDir(), "art_cache");
        File[] files = dir.listFiles();
        if (files == null) return;
        for (File file : files) {
            if (file.isFile() && !keep.contains(file.getAbsolutePath())) file.delete();
        }
    }

    private void ensureCuratedAdultCatalogLocked() throws JSONException {
        List<ArtEntry> catalog = readEntries(KEY_CATALOG);
        Set<String> identities = identitySet(catalog);
        boolean changed = false;
        for (ArtEntry e : curatedAdultCatalog()) {
            if (identities.add(e.canonicalKey())) {
                catalog.add(e);
                changed = true;
            }
        }
        if (changed) {
            catalog = mergeEquivalentEntries(catalog, false);
            writeEntries(KEY_CATALOG, catalog);
            prefs.edit().putInt(KEY_CATALOG_COUNT, catalog.size()).apply();
            clearModeQueuesLocked();
        }
    }

    private List<ArtEntry> curatedAdultCatalog() {
        List<ArtEntry> out = new ArrayList<>();
        out.add(adultFallback("adult:origin-world", "Происхождение мира", "Гюстав Курбе", "Происхождение мира (картина)"));
        out.add(adultFallback("adult:nude-maja", "Обнажённая маха", "Франсиско Гойя", "Обнажённая маха"));
        out.add(adultFallback("adult:olympia", "Олимпия", "Эдуард Мане", "Олимпия (картина)"));
        out.add(adultFallback("adult:grande-odalisque", "Большая одалиска", "Жан Огюст Доминик Энгр", "Большая одалиска"));
        out.add(adultFallback("adult:venus-urbino", "Венера Урбинская", "Тициан", "Венера Урбинская"));
        out.add(adultFallback("adult:birth-venus", "Рождение Венеры", "Сандро Боттичелли", "Рождение Венеры"));
        out.add(adultFallback("adult:sleeping-venus", "Спящая Венера", "Джорджоне", "Спящая Венера"));
        out.add(adultFallback("adult:rokeby-venus", "Венера перед зеркалом", "Диего Веласкес", "Венера перед зеркалом"));
        out.add(adultFallback("adult:three-graces", "Три грации", "Питер Пауль Рубенс", "Три грации (картина Рубенса)"));
        out.add(adultFallback("adult:turkish-bath", "Турецкая баня", "Жан Огюст Доминик Энгр", "Турецкая баня (картина)"));
        out.add(adultFallback("adult:danae-rembrandt", "Даная", "Рембрандт", "Даная (картина Рембрандта)"));
        out.add(adultFallback("adult:danae-titian", "Даная", "Тициан", "Даная (картина Тициана)"));
        out.add(adultFallback("adult:luncheon-grass", "Завтрак на траве", "Эдуард Мане", "Завтрак на траве (картина Мане)"));
        out.add(adultFallback("adult:bathers-renoir", "Большие купальщицы", "Пьер Огюст Ренуар", "Большие купальщицы (картина Ренуара)"));
        out.add(adultFallback("adult:nana-manet", "Нана", "Эдуард Мане", "Нана (картина)"));
        return out;
    }

    private ArtEntry adultFallback(String qid, String title, String artist, String pageTitle) {
        String source = "https://ru.wikipedia.org/wiki/" + pageTitle.replace(' ', '_');
        return ArtEntry.catalog(qid, title, artist, "", "", source, "картина", "", "ню", true);
    }

    private boolean isCuratedAdultId(String qid) {
        return qid != null && qid.startsWith("adult:");
    }

    private void addFallbackCatalogLocked() throws JSONException {
        List<ArtEntry> catalog = readEntries(KEY_CATALOG);
        Set<String> ids = identitySet(catalog);
        for (ArtEntry e : fallbackCatalog()) if (ids.add(e.canonicalKey())) catalog.add(e);
        writeEntries(KEY_CATALOG, catalog);
        prefs.edit().putInt(KEY_CATALOG_COUNT, catalog.size()).apply();
    }

    private List<ArtEntry> fallbackCatalog() {
        List<ArtEntry> out = new ArrayList<>();
        out.add(fallback("Q12418", "Мона Лиза", "Леонардо да Винчи", "Мона Лиза"));
        out.add(fallback("Q151047", "Сотворение Адама", "Микеланджело", "Сотворение Адама"));
        out.add(fallback("Q185372", "Рождение Венеры", "Сандро Боттичелли", "Рождение Венеры"));
        out.add(fallback("Q166713", "Девушка с жемчужной серёжкой", "Ян Вермеер", "Девушка с жемчужной серёжкой"));
        out.add(fallback("Q219831", "Ночной дозор", "Рембрандт", "Ночной дозор"));
        out.add(fallback("Q160112", "Менины", "Диего Веласкес", "Менины"));
        out.add(fallback("Q178426", "Плот „Медузы“", "Теодор Жерико", "Плот «Медузы»"));
        out.add(fallback("Q219344", "Свобода, ведущая народ", "Эжен Делакруа", "Свобода, ведущая народ"));
        out.add(fallback("Q188855", "Звёздная ночь", "Винсент ван Гог", "Звёздная ночь"));
        out.add(fallback("Q130994", "Крик", "Эдвард Мунк", "Крик (картина)"));
        out.add(fallback("Q45585", "Девятый вал", "Иван Айвазовский", "Девятый вал"));
        out.add(fallback("Q394558", "Бурлаки на Волге", "Илья Репин", "Бурлаки на Волге"));
        out.add(fallback("Q321303", "Чёрный квадрат", "Казимир Малевич", "Чёрный квадрат"));
        return out;
    }

    private ArtEntry fallback(String qid, String title, String artist, String pageTitle) {
        String source = "https://ru.wikipedia.org/wiki/" + pageTitle.replace(' ', '_');
        return ArtEntry.catalog(qid, title, artist, "", "", source, "картина", "", "", false);
    }

    private boolean isUnwanted(ArtEntry e) {
        String text = (e.title + " " + e.instanceLabel + " " + e.materialLabel + " " + e.genreLabel).toLowerCase(Locale.ROOT);
        if (isFamousMonumental(e)) return false;
        String[] always = new String[]{
                "алтар", "altarpiece", "retable", "ретабло", "церковный интерьер", "church interior",
                "архитектурный фрагмент", "architectural fragment", "museum interior", "экспозици",
                "предмет прикладного", "decorative object", "археологический объект"
        };
        for (String s : always) if (text.contains(s)) return true;
        String[] conditional = new String[]{
                "икон", "icon", "фреск", "fresco", "mural", "настенная роспись", "wall painting",
                "мозаик", "mosaic", "триптих", "triptych", "полиптих", "polyptych",
                "декоративная панель", "археологический фрагмент"
        };
        for (String s : conditional) {
            if (text.contains(s) && ArtEntry.isUnknownArtist(e.artist)) return true;
            if ((text.contains("икон") || text.contains("altarpiece") || text.contains("алтар")) && text.contains(s)) return true;
        }
        return false;
    }

    private boolean isFamousMonumental(ArtEntry e) {
        String t = e.title.toLowerCase(Locale.ROOT);
        return t.contains("сотворение адама") || t.contains("тайная вечеря")
                || t.contains("страшный суд") || t.contains("афинская школа");
    }

    private boolean hasUsableLocalImage(ArtEntry entry) {
        return entry != null && fileExists(entry.localPath);
    }

    private boolean isImageUnavailableError(Exception e) {
        String message = e == null || e.getMessage() == null ? "" : e.getMessage().toLowerCase(Locale.ROOT);
        return message.contains("не найдено подходящее изображение")
                || message.contains("статья произведения не найдена")
                || message.contains("описание произведения не найдено")
                || message.contains("изображение произведения не найдено")
                || message.contains("изображение или статья не найдены")
                || message.contains("у страницы нет подходящего изображения")
                || message.contains("у страницы нет изображения")
                || message.contains("векторный файл пропущен");
    }

    private boolean isAdultQueueExhaustedError(Exception e) {
        String message = e == null || e.getMessage() == null ? "" : e.getMessage().toLowerCase(Locale.ROOT);
        return message.contains("подходящие произведения nsfw временно не найдены");
    }

    private void markImageUnavailable(ArtEntry entry) {
        if (entry == null) return;
        synchronized (DATA_LOCK) {
            Set<String> unavailable = readStringArraySet(KEY_UNAVAILABLE_IMAGES);
            String identity = entry.canonicalKey();
            if (!identity.isEmpty() && unavailable.add(identity)) {
                writeStringArraySet(KEY_UNAVAILABLE_IMAGES, unavailable);
                AppLogger.log(context, "image", "unavailable", entry.qid + " | " + identity);
            }
        }
    }

    private boolean isConnectionFailure(Exception e) {
        if (!(e instanceof IOException)) return false;
        IOException io = (IOException) e;
        if (isTransientNetwork(io)) return true;
        String message = io.getMessage() == null ? "" : io.getMessage().toLowerCase(Locale.ROOT);
        return message.contains("нет подключения")
                || message.contains("dns временно недоступен")
                || message.contains("сервер не ответил вовремя");
    }

    private boolean matchesContentMode(ArtEntry e, int mode) {
        if (mode == CONTENT_ALL) return true;
        if (mode == CONTENT_ADULT_ONLY) return isVerifiedAdult(e);
        return !e.explicitContent;
    }

    /**
     * Строгая проверка для режима 18+.
     * В очередь попадают только произведения из проверенной подборки
     * либо реальные Wikidata-записи, совпадающие с ней по каноническому ключу.
     * Простого keyword-флага explicitContent недостаточно: он давал ложные
     * срабатывания и долгий перебор неподходящих записей.
     */
    private boolean isVerifiedAdult(ArtEntry entry) {
        if (entry == null) return false;
        if (isCuratedAdultId(entry.qid)) return true;
        String genre = safe(entry.genreLabel).toLowerCase(Locale.ROOT);
        if (entry.explicitContent && (genre.contains("preloaded-nsfw")
                || genre.contains("bundled-nsfw") || genre.contains("starter-nsfw"))) return true;
        String key = entry.canonicalKey();
        for (ArtEntry curated : curatedAdultCatalog()) {
            if (key.equals(curated.canonicalKey())) return true;
        }
        synchronized (DATA_LOCK) {
            return readStringArraySet(KEY_ADULT_CONFIRMED).contains(key);
        }
    }

    private boolean classifyExplicit(String title, String description, String genre) {
        String t = safe(title).toLowerCase(Locale.ROOT);
        String g = safe(genre).toLowerCase(Locale.ROOT);
        String d = safe(description).toLowerCase(Locale.ROOT);

        String[] knownTitles = new String[]{
                "происхождение мира", "l'origine du monde", "обнажённая маха", "обнаженная маха",
                "большая одалиска", "турецкая баня", "венера урбинская", "спящая венера",
                "венера перед зеркалом", "олимпия"
        };
        for (String value : knownTitles) if (t.contains(value)) return true;

        String[] strongTitleOrGenre = new String[]{
                "эротичес", "erotic", "pornograph", "порнограф", "обнажённая натура",
                "обнаженная натура", "nude painting", "nude art", "ню", "одалиск"
        };
        for (String value : strongTitleOrGenre) {
            if (t.contains(value) || g.contains(value)) return true;
        }

        String[] explicitDescription = new String[]{
                "генитал", "половой акт", "sexual intercourse", "vulva", "vagina", "penis",
                "masturbat", "эротическая сцена", "эротическая картина"
        };
        for (String value : explicitDescription) if (d.contains(value)) return true;

        return false;
    }

    private String shortDescription(String extract) {
        String text = safe(extract).replaceAll("\\s+", " ").trim();
        if (text.isEmpty()) return "Краткое описание отсутствует";
        String[] sentences = text.split("(?<=[.!?])\\s+");
        StringBuilder sb = new StringBuilder();
        for (String sentence : sentences) {
            String s = sentence.trim();
            if (s.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(s);
            if (sb.length() >= 420 || countSentenceEnds(sb.toString()) >= 5) break;
        }
        String result = sb.length() == 0 ? text : sb.toString();
        if (result.length() > 760) result = result.substring(0, 760).trim() + "…";
        return result;
    }

    private int countSentenceEnds(String s) {
        int count = 0;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) == '.' || s.charAt(i) == '!' || s.charAt(i) == '?') count++;
        return count;
    }

    private List<ArtEntry> readEntries(String key) throws JSONException {
        if (KEY_CATALOG.equals(key)) return catalogStore.getAll();
        JSONArray array = new JSONArray(prefs.getString(key, "[]"));
        List<ArtEntry> list = new ArrayList<>();
        for (int i = 0; i < array.length(); i++) {
            JSONObject o = array.optJSONObject(i);
            if (o != null) list.add(ArtEntry.fromJson(o));
        }
        return list;
    }

    private void writeEntries(String key, List<ArtEntry> list) throws JSONException {
        if (KEY_CATALOG.equals(key)) {
            catalogStore.replaceAll(list);
            refreshCatalogCounters();
            return;
        }
        JSONArray array = new JSONArray();
        for (ArtEntry e : list) array.put(e.toJson());
        prefs.edit().putString(key, array.toString()).apply();
    }

    private List<ArtEntry> uniqueById(List<ArtEntry> list) {
        return mergeEquivalentEntries(list, false);
    }

    private int indexOf(List<ArtEntry> list, String qid) {
        if (qid == null) return -1;
        for (int i = 0; i < list.size(); i++) if (qid.equals(list.get(i).qid)) return i;
        return -1;
    }

    private Set<String> identitySet(List<ArtEntry> list) {
        Set<String> set = new HashSet<>();
        for (ArtEntry e : list) set.add(e.canonicalKey());
        return set;
    }

    private int indexOfEquivalent(List<ArtEntry> list, ArtEntry entry) {
        if (entry == null) return -1;
        String key = entry.canonicalKey();
        for (int i = 0; i < list.size(); i++) if (key.equals(list.get(i).canonicalKey())) return i;
        return -1;
    }

    private Set<String> idSet(List<ArtEntry> list) {
        Set<String> set = new HashSet<>();
        for (ArtEntry e : list) set.add(e.qid);
        return set;
    }

    private int countFiles(List<ArtEntry> history) {
        Set<String> paths = new HashSet<>();
        for (ArtEntry e : history) if (fileExists(e.localPath)) paths.add(e.localPath);
        return paths.size();
    }

    private String pageTitleFromArticle(String articleUrl, String fallback) {
        try {
            if (articleUrl != null && articleUrl.contains("/wiki/")) {
                String part = articleUrl.substring(articleUrl.indexOf("/wiki/") + 6);
                return URLDecoder.decode(part, "UTF-8").replace('_', ' ');
            }
        } catch (Exception ignored) { }
        return fallback;
    }

    private String bindingValue(JSONObject binding, String key) {
        JSONObject o = binding.optJSONObject(key);
        return o == null ? "" : o.optString("value", "").trim();
    }

    private Set<String> readStringArraySet(String key) {
        Set<String> out = new HashSet<>();
        try {
            JSONArray array = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty()) out.add(value);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private void writeStringArraySet(String key, Set<String> values) {
        JSONArray array = new JSONArray();
        if (values != null) for (String value : values) if (value != null && !value.trim().isEmpty()) array.put(value);
        prefs.edit().putString(key, array.toString()).apply();
    }

    private String qidFromUrl(String value) {
        if (value == null) return "";
        int slash = value.lastIndexOf('/');
        String qid = slash >= 0 ? value.substring(slash + 1) : value;
        return qid.matches("Q\\d+") ? qid : "";
    }

    private JSONObject readJson(String url) throws IOException, JSONException {
        return readJson(url, false);
    }

    private JSONObject readJson(String url, boolean quickNetwork) throws IOException, JSONException {
        return new JSONObject(readText(url, quickNetwork));
    }

    private JSONObject readJsonPost(String url, String body, String contentType) throws IOException, JSONException {
        return readJsonPost(url, body, contentType, false);
    }

    private JSONObject readJsonPost(String url, String body, String contentType, boolean quickNetwork) throws IOException, JSONException {
        return new JSONObject(readTextPost(url, body, contentType, quickNetwork));
    }

    private String readText(String urlString) throws IOException {
        return readText(urlString, false);
    }

    private String readText(String urlString, boolean quickNetwork) throws IOException {
        IOException last = null;
        int maxAttempts = quickNetwork ? 2 : 3;
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(urlString).openConnection();
                conn.setRequestMethod("GET");
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent", USER_AGENT);
                conn.setRequestProperty("Accept", "application/json,text/plain,*/*");
                conn.setConnectTimeout(quickNetwork ? 9000 : 12000);
                conn.setReadTimeout(quickNetwork ? 16000 : 24000);
                int code = conn.getResponseCode();
                InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                byte[] bytes = input == null ? new byte[0] : readAll(input);
                if (code < 200 || code >= 300) throw httpException(code, conn);
                return new String(bytes, "UTF-8");
            } catch (IOException e) {
                last = e;
                if (!isTransientNetwork(e) || isRateLimit(e) || attempt == maxAttempts - 1) throw friendlyNetworkException(e);
                sleepBeforeRetry(attempt);
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw friendlyNetworkException(last);
    }

    private String readTextPost(String urlString, String body, String contentType) throws IOException {
        return readTextPost(urlString, body, contentType, false);
    }

    private String readTextPost(String urlString, String body, String contentType, boolean quickNetwork) throws IOException {
        IOException last = null;
        byte[] data = body.getBytes("UTF-8");
        int maxAttempts = quickNetwork ? 2 : 3;
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(urlString).openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent", USER_AGENT);
                conn.setRequestProperty("Accept", "application/sparql-results+json,application/json");
                conn.setRequestProperty("Content-Type", contentType);
                conn.setConnectTimeout(quickNetwork ? 12000 : 15000);
                conn.setReadTimeout(quickNetwork ? 30000 : 45000);
                try (OutputStream out = conn.getOutputStream()) { out.write(data); }
                int code = conn.getResponseCode();
                InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
                byte[] bytes = input == null ? new byte[0] : readAll(input);
                if (code < 200 || code >= 300) throw httpException(code, conn);
                return new String(bytes, "UTF-8");
            } catch (IOException e) {
                last = e;
                if (!isTransientNetwork(e) || isRateLimit(e) || attempt == maxAttempts - 1) throw friendlyNetworkException(e);
                sleepBeforeRetry(attempt);
            } finally {
                if (conn != null) conn.disconnect();
            }
        }
        throw friendlyNetworkException(last);
    }

    private void downloadFile(String urlString, File outFile) throws IOException {
        downloadFile(urlString, outFile, false);
    }

    private void downloadFile(String urlString, File outFile, boolean quickNetwork) throws IOException {
        IOException last = null;
        File tmp = new File(outFile.getAbsolutePath() + ".part");
        int maxAttempts = quickNetwork ? 2 : 3;
        for (int attempt = 0; attempt < maxAttempts; attempt++) {
            HttpURLConnection conn = null;
            deleteFileQuietly(tmp.getAbsolutePath());
            try {
                conn = (HttpURLConnection) new URL(normalizedImageUrl(urlString)).openConnection();
                conn.setRequestMethod("GET");
                conn.setInstanceFollowRedirects(true);
                conn.setRequestProperty("User-Agent", USER_AGENT);
                conn.setConnectTimeout(quickNetwork ? 9000 : 12000);
                conn.setReadTimeout(quickNetwork ? 22000 : 35000);
                int code = conn.getResponseCode();
                if (code < 200 || code >= 300) throw httpException(code, conn);
                String type = conn.getContentType();
                if (type != null && !type.toLowerCase(Locale.ROOT).startsWith("image/")) {
                    throw new IOException("Сервер вернул не изображение");
                }
                try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                     BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(tmp))) {
                    byte[] buffer = new byte[16384];
                    int read;
                    long total = 0;
                    while ((read = in.read(buffer)) != -1) {
                        total += read;
                        if (total > 35L * 1024L * 1024L) throw new IOException("Изображение слишком большое");
                        out.write(buffer, 0, read);
                    }
                }
                if (outFile.exists()) outFile.delete();
                if (!tmp.renameTo(outFile)) throw new IOException("Не удалось сохранить изображение");
                return;
            } catch (IOException e) {
                last = e;
                if (!isTransientNetwork(e) || isRateLimit(e) || attempt == maxAttempts - 1) throw friendlyNetworkException(e);
                sleepBeforeRetry(attempt);
            } finally {
                if (conn != null) conn.disconnect();
                if (!outFile.exists()) deleteFileQuietly(tmp.getAbsolutePath());
            }
        }
        throw friendlyNetworkException(last);
    }

    private IOException httpException(int code, HttpURLConnection conn) {
        if (code == 429) {
            String retry = conn == null ? null : conn.getHeaderField("Retry-After");
            return new IOException("Слишком частые запросы. Повторите позже" + (retry == null ? "" : " (через " + retry + " с)"));
        }
        if (code == 404) return new IOException("Изображение или статья не найдены");
        if (code >= 500) return new IOException("Сервис временно недоступен");
        return new IOException("Ошибка сети: HTTP " + code);
    }

    private boolean isTransientNetwork(IOException e) {
        if (e == null) return false;
        if (e instanceof UnknownHostException || e instanceof SocketTimeoutException || e instanceof ConnectException) return true;
        String msg = e.getMessage() == null ? "" : e.getMessage().toLowerCase(Locale.ROOT);
        return msg.contains("timeout") || msg.contains("timed out") || msg.contains("unable to resolve host")
                || msg.contains("no address associated") || msg.contains("connection reset")
                || msg.contains("connection refused") || msg.contains("сервис временно недоступен");
    }

    private IOException friendlyNetworkException(IOException e) {
        if (e == null) return new IOException("Не удалось выполнить сетевой запрос");
        if (isRateLimit(e)) return e;
        if (e instanceof UnknownHostException) return new IOException("Нет подключения к интернету или DNS временно недоступен");
        if (e instanceof SocketTimeoutException) return new IOException("Сервер не ответил вовремя. Повторите позже");
        String msg = e.getMessage() == null ? "" : e.getMessage();
        String lower = msg.toLowerCase(Locale.ROOT);
        if (lower.contains("unable to resolve host") || lower.contains("no address associated")) {
            return new IOException("Нет подключения к интернету или DNS временно недоступен");
        }
        if (lower.contains("timeout") || lower.contains("timed out")) {
            return new IOException("Сервер не ответил вовремя. Повторите позже");
        }
        return e;
    }

    private void sleepBeforeRetry(int attempt) throws IOException {
        long delay = attempt == 0 ? 1500L : 4500L;
        try {
            Thread.sleep(delay);
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            throw new IOException("Операция отменена");
        }
    }

    private byte[] readAll(InputStream input) throws IOException {
        try (BufferedInputStream in = new BufferedInputStream(input);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            return out.toByteArray();
        }
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network network = cm.getActiveNetwork();
                if (network == null) return false;
                NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
                return capabilities != null && capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
            }
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private boolean isWifiConnected() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network network = cm.getActiveNetwork();
                if (network == null) return false;
                NetworkCapabilities capabilities = cm.getNetworkCapabilities(network);
                return capabilities != null && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
            }
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected() && info.getType() == ConnectivityManager.TYPE_WIFI;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean isRateLimit(Exception e) {
        return e != null && e.getMessage() != null && e.getMessage().contains("Слишком частые запросы");
    }

    private String friendlyMessage(Exception e) {
        String msg = e == null ? "Неизвестная ошибка" : e.getMessage();
        if (msg == null || msg.trim().isEmpty()) return "Не удалось загрузить изображение";
        if (msg.length() > 220) return msg.substring(0, 220).trim() + "…";
        return msg;
    }

    private boolean fileExists(String path) {
        if (path == null || path.trim().isEmpty()) return false;
        File f = new File(path);
        return f.exists() && f.length() > 0;
    }

    private void deleteFileQuietly(String path) {
        try {
            if (path != null && !path.trim().isEmpty()) new File(path).delete();
        } catch (Exception ignored) { }
    }

    private void clearDirectory(File dir) {
        try {
            File[] files = dir.listFiles();
            if (files != null) for (File f : files) f.delete();
        } catch (Exception ignored) { }
    }

    private String normalizedImageUrl(String value) {
        String s = safe(value);
        if (s.startsWith("http://")) s = "https://" + s.substring(7);
        if (s.contains("/wiki/Special:FilePath/") && !s.contains("?")) s += "?width=1600";
        return s;
    }

    private String safeFileName(String value) {
        String s = safe(value).replaceAll("[^A-Za-z0-9._-]", "_");
        return s.isEmpty() ? "art" : s;
    }

    private String urlEncode(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8");
    }

    private String encodePath(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
    }

    private String safe(String value) {
        return value == null ? "" : value.replace('\n', ' ').replace('\r', ' ').trim();
    }


    private void updateStatsLocked(List<ArtEntry> history) {
        Set<String> paths = new HashSet<>();
        for (ArtEntry entry : history) {
            if (fileExists(entry.localPath)) paths.add(entry.localPath);
        }
        try {
            for (String key : new String[]{KEY_CACHE_INDEX, KEY_FAVORITES}) {
                for (ArtEntry entry : readEntries(key)) {
                    if (fileExists(entry.localPath)) paths.add(entry.localPath);
                }
            }
            ArtEntry current = getCurrent();
            if (current != null && fileExists(current.localPath)) paths.add(current.localPath);
        } catch (Exception ignored) { }
        prefs.edit().putInt(KEY_HISTORY_COUNT, history.size())
                .putInt(KEY_CACHE_COUNT, paths.size()).apply();
    }

    private void refreshCurrentFromHistoryLocked(List<ArtEntry> history) {
        try {
            int index = prefs.getInt(KEY_INDEX, -1);
            if (index >= 0 && index < history.size()) {
                prefs.edit().putString(KEY_CURRENT, history.get(index).toJson().toString()).apply();
            } else {
                prefs.edit().remove(KEY_CURRENT).apply();
            }
        } catch (Exception ignored) { }
    }

    private static class LinkedUniqueMap {
        private final Map<String, ArtEntry> map = new java.util.LinkedHashMap<>();
        void putIfAbsent(String key, ArtEntry value) { if (!map.containsKey(key)) map.put(key, value); }
        List<ArtEntry> values() { return new ArrayList<>(map.values()); }
    }
}
