package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import org.json.JSONObject;

public final class ArtworkTranslationManager {
    private static final String PREFS = "artwork_translation_cache_v12_4_4";

    public interface Callback {
        void onResult(String title, String artist, String description, boolean translated);
    }

    private ArtworkTranslationManager() { }

    public static void localize(Context context, ArtEntry entry, Callback callback) {
        if (entry == null) {
            callback.onResult("", "", "", false);
            return;
        }
        String target = LanguageManager.getLanguage(context);
        String directTitle = entry.localizedTitle(target);
        String directArtist = entry.localizedArtist(target);
        String directDescription = entry.localizedDescription(target);
        if (entry.hasLocalizedText(target) || target.equals(entry.sourceLanguage)) {
            callback.onResult(directTitle, directArtist, directDescription, false);
            return;
        }

        SharedPreferences cache = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String cacheKey = entry.qid + "_" + target;
        String cached = cache.getString(cacheKey, "");
        if (!cached.isEmpty()) {
            try {
                JSONObject object = new JSONObject(cached);
                callback.onResult(
                        object.optString("title", directTitle),
                        object.optString("artist", directArtist),
                        object.optString("description", directDescription),
                        true);
                return;
            } catch (Exception ignored) { }
        }

        String source = LanguageManager.EN.equals(entry.sourceLanguage)
                ? TranslateLanguage.ENGLISH : TranslateLanguage.RUSSIAN;
        String targetCode = LanguageManager.EN.equals(target)
                ? TranslateLanguage.ENGLISH : TranslateLanguage.RUSSIAN;
        if (source.equals(targetCode)) {
            callback.onResult(directTitle, directArtist, directDescription, false);
            return;
        }

        String sourceTitle = LanguageManager.EN.equals(entry.sourceLanguage)
                ? nonEmpty(entry.titleEn, entry.title) : nonEmpty(entry.titleRu, entry.title);
        String sourceArtist = LanguageManager.EN.equals(entry.sourceLanguage)
                ? nonEmpty(entry.artistEn, entry.artist) : nonEmpty(entry.artistRu, entry.artist);
        String sourceDescription = LanguageManager.EN.equals(entry.sourceLanguage)
                ? nonEmpty(entry.descriptionEn, entry.description) : nonEmpty(entry.descriptionRu, entry.description);

        TranslatorOptions options = new TranslatorOptions.Builder()
                .setSourceLanguage(source)
                .setTargetLanguage(targetCode)
                .build();
        Translator translator = Translation.getClient(options);
        DownloadConditions conditions = new DownloadConditions.Builder().build();
        translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(v -> translator.translate(sourceTitle)
                        .addOnSuccessListener(translatedTitle -> translator.translate(sourceArtist)
                                .addOnSuccessListener(translatedArtist -> {
                                    if (sourceDescription.trim().isEmpty()) {
                                        saveAndReturn(cache, cacheKey, translatedTitle, translatedArtist,
                                                directDescription, translator, callback);
                                    } else {
                                        translator.translate(sourceDescription)
                                                .addOnSuccessListener(translatedDescription ->
                                                        saveAndReturn(cache, cacheKey, translatedTitle,
                                                                translatedArtist, translatedDescription,
                                                                translator, callback))
                                                .addOnFailureListener(e -> {
                                                    translator.close();
                                                    callback.onResult(directTitle, directArtist,
                                                            directDescription, false);
                                                });
                                    }
                                })
                                .addOnFailureListener(e -> {
                                    translator.close();
                                    callback.onResult(directTitle, directArtist, directDescription, false);
                                }))
                        .addOnFailureListener(e -> {
                            translator.close();
                            callback.onResult(directTitle, directArtist, directDescription, false);
                        }))
                .addOnFailureListener(e -> {
                    translator.close();
                    callback.onResult(directTitle, directArtist, directDescription, false);
                });
    }

    private static void saveAndReturn(SharedPreferences cache, String key,
                                      String title, String artist, String description,
                                      Translator translator, Callback callback) {
        try {
            JSONObject object = new JSONObject();
            object.put("title", title);
            object.put("artist", artist);
            object.put("description", description);
            cache.edit().putString(key, object.toString()).apply();
        } catch (Exception ignored) { }
        translator.close();
        callback.onResult(title, artist, description, true);
    }

    private static String nonEmpty(String preferred, String fallback) {
        return preferred == null || preferred.trim().isEmpty()
                ? (fallback == null ? "" : fallback) : preferred;
    }
}
