package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ArtworkActivity extends LocalizedActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService displayExecutor = Executors.newSingleThreadExecutor();
    private Future<?> displayFuture;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private Runnable pendingRefresh;
    private volatile int displayRequestId = 0;
    private boolean displayLoading = false;
    private boolean actionBusy = false;
    private ArtEntry entry;
    private String qid;
    private ArrayList<String> galleryQids = new ArrayList<>();
    private int galleryPosition = -1;
    private ScrollView scrollView;
    private ImageView imageView;
    private TextView captionView;
    private TextView positionView;
    private Bitmap shownBitmap;
    private TextView descriptionView;
    private Button favoriteButton;
    private Button dislikeButton;
    private Button installButton;
    private Button deleteButton;
    private Button previousButton;
    private Button nextButton;
    private LinearLayout navigationRow;
    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        qid = getIntent().getStringExtra("qid");
        ArrayList<String> suppliedQids = getIntent().getStringArrayListExtra("gallery_qids");
        if (suppliedQids != null) galleryQids = suppliedQids;
        galleryPosition = getIntent().getIntExtra("gallery_position", -1);
        if (galleryPosition < 0 || galleryPosition >= galleryQids.size()
                || qid == null || !qid.equals(galleryQids.get(galleryPosition))) {
            galleryPosition = qid == null ? -1 : galleryQids.indexOf(qid);
        }
        setupColors();
        setContentView(createLayout());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onDestroy() {
        displayRequestId++;
        if (pendingRefresh != null) mainHandler.removeCallbacks(pendingRefresh);
        if (displayFuture != null) displayFuture.cancel(true);
        displayExecutor.shutdownNow();
        executor.shutdownNow();
        recycleShownBitmap();
        super.onDestroy();
    }

    private View createLayout() {
        scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(bgColor);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.setFitsSystemWindows(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(16), top + dp(16), dp(16), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }
        scrollView.addView(root, new ScrollView.LayoutParams(-1, -2));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        Button back = button("←", false);
        back.setTextSize(25);
        back.setContentDescription(tr("Назад", "Back"));
        back.setOnClickListener(v -> finish());
        topRow.addView(back, new LinearLayout.LayoutParams(dp(58), dp(46)));
        positionView = new TextView(this);
        positionView.setTextColor(subTextColor);
        positionView.setTextSize(13);
        positionView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        positionView.setPadding(dp(8), 0, dp(4), 0);
        topRow.addView(positionView, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams topParams = new LinearLayout.LayoutParams(-1, dp(46));
        topParams.setMargins(0, 0, 0, dp(8));
        root.addView(topRow, topParams);

        imageView = new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        imageView.setBackgroundColor(Color.TRANSPARENT);
        imageView.setOnClickListener(v -> openFullscreen());
        root.addView(imageView, new LinearLayout.LayoutParams(-1, dp(390)));

        navigationRow = new LinearLayout(this);
        navigationRow.setOrientation(LinearLayout.HORIZONTAL);
        navigationRow.setGravity(Gravity.CENTER);

        previousButton = button("←", false);
        previousButton.setTextSize(24);
        previousButton.setContentDescription(tr("Предыдущая картина", "Previous artwork"));
        previousButton.setOnClickListener(v -> showRelativeEntry(-1));
        navigationRow.addView(previousButton, new LinearLayout.LayoutParams(0, dp(48), 1f));

        nextButton = button("→", false);
        nextButton.setTextSize(24);
        nextButton.setContentDescription(tr("Следующая картина", "Next artwork"));
        nextButton.setOnClickListener(v -> showRelativeEntry(1));
        LinearLayout.LayoutParams nextButtonParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        nextButtonParams.setMargins(dp(8), 0, 0, 0);
        navigationRow.addView(nextButton, nextButtonParams);

        LinearLayout.LayoutParams navigationParams = new LinearLayout.LayoutParams(-1, dp(48));
        navigationParams.setMargins(0, dp(8), 0, 0);
        root.addView(navigationRow, navigationParams);

        captionView = new TextView(this);
        captionView.setTextColor(linkColor);
        captionView.setTextSize(20);
        captionView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        captionView.setGravity(Gravity.CENTER_HORIZONTAL);
        captionView.setPadding(0, dp(8), 0, dp(8));
        captionView.setCompoundDrawablePadding(dp(6));
        captionView.setOnClickListener(v -> openArticle());
        root.addView(captionView, new LinearLayout.LayoutParams(-1, -2));

        TextView about = new TextView(this);
        about.setText(tr("О картине", "About the artwork"));
        about.setTextSize(18);
        about.setTextColor(textColor);
        about.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        about.setPadding(0, dp(8), 0, dp(8));
        root.addView(about, new LinearLayout.LayoutParams(-1, -2));

        descriptionView = new TextView(this);
        descriptionView.setTextColor(textColor);
        descriptionView.setTextSize(15);
        descriptionView.setLineSpacing(0, 1.16f);
        descriptionView.setPadding(0, 0, 0, dp(16));
        root.addView(descriptionView, new LinearLayout.LayoutParams(-1, -2));

        installButton = button(tr("Установить на виджет", "Set on widget"), true);
        installButton.setOnClickListener(v -> install());
        root.addView(installButton, buttonParams());

        deleteButton = button(tr("Удалить из кэша", "Delete from cache"), false);
        deleteButton.setTextColor(0xFFFF3B30);
        deleteButton.setOnClickListener(v -> confirmDeleteFromCache());
        root.addView(deleteButton, buttonParams());

        LinearLayout reactions = new LinearLayout(this);
        reactions.setOrientation(LinearLayout.HORIZONTAL);
        dislikeButton = button(tr("Не нравится", "Dislike"), false);
        favoriteButton = button(tr("♡ Избранное", "♡ Favorite"), false);
        reactions.addView(dislikeButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams favoriteParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        favoriteParams.setMargins(dp(8), 0, 0, 0);
        reactions.addView(favoriteButton, favoriteParams);
        root.addView(reactions, new LinearLayout.LayoutParams(-1, -2));
        dislikeButton.setOnClickListener(v -> toggleDislike());
        favoriteButton.setOnClickListener(v -> toggleFavorite());
        return scrollView;
    }

    private void refresh() {
        final String requestedQid = qid;
        if (requestedQid == null || requestedQid.isEmpty()) {
            applyLoadedEntry(null, null, false, false);
            return;
        }

        final int requestId = ++displayRequestId;
        displayLoading = true;
        updatePositionView();
        updateActionButtons();
        imageView.setAlpha(0.72f);

        if (displayFuture != null) displayFuture.cancel(true);
        displayFuture = displayExecutor.submit(() -> {
            ArtEntry loadedEntry = null;
            Bitmap loadedBitmap = null;
            boolean favorite = false;
            boolean disliked = false;
            try {
                ArtRepository repo = new ArtRepository(getApplicationContext());
                loadedEntry = repo.findEntry(requestedQid);
                if (Thread.currentThread().isInterrupted()) return;
                if (loadedEntry != null) {
                    favorite = repo.isFavorite(loadedEntry);
                    disliked = repo.isDisliked(loadedEntry);
                    loadedBitmap = decodePreview(loadedEntry);
                }
            } catch (Exception ignored) {
            }

            final ArtEntry resultEntry = loadedEntry;
            final Bitmap resultBitmap = loadedBitmap;
            final boolean resultFavorite = favorite;
            final boolean resultDisliked = disliked;
            runOnUiThread(() -> {
                if (isFinishing()
                        || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())
                        || requestId != displayRequestId
                        || !requestedQid.equals(qid)) {
                    recycleBitmap(resultBitmap);
                    return;
                }
                applyLoadedEntry(resultEntry, resultBitmap, resultFavorite, resultDisliked);
            });
        });
    }

    private Bitmap decodePreview(ArtEntry value) {
        if (value == null || value.localPath == null || value.localPath.isEmpty()) return null;
        File file = new File(value.localPath);
        if (!file.exists() || Thread.currentThread().isInterrupted()) return null;

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int sample = 1;
        int maxSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (maxSide / sample > 1280) sample *= 2;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(1, sample);
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        if (Thread.currentThread().isInterrupted()) {
            recycleBitmap(bitmap);
            return null;
        }
        return bitmap;
    }

    private void applyLoadedEntry(ArtEntry loadedEntry, Bitmap loadedBitmap,
                                  boolean favorite, boolean disliked) {
        displayLoading = false;
        entry = loadedEntry;
        imageView.setAlpha(1f);

        if (loadedEntry == null) {
            captionView.setText(tr("Произведение не найдено", "Artwork not found"));
            captionView.setCompoundDrawables(null, null, null, null);
            descriptionView.setText(tr("Сведения о произведении недоступны.", "Artwork information is unavailable."));
            replaceShownBitmap(null);
        } else {
            String language = LanguageManager.getLanguage(this);
            captionView.setText(loadedEntry.caption(language));
            applyExternalLinkIcon();
            String localizedDescription = loadedEntry.localizedDescription(language);
            descriptionView.setText(localizedDescription.isEmpty()
                    ? (LanguageManager.EN.equals(language) ? "No description available" : "Краткое описание отсутствует")
                    : localizedDescription);
            favoriteButton.setText(favorite ? tr("♥ В избранном", "♥ Favorited") : tr("♡ Избранное", "♡ Favorite"));
            dislikeButton.setText(disliked ? tr("Убрать дизлайк", "Remove dislike") : tr("Не нравится", "Dislike"));
            replaceShownBitmap(loadedBitmap);
        }
        updatePositionView();
        updateActionButtons();
    }

    private void replaceShownBitmap(Bitmap bitmap) {
        Bitmap old = shownBitmap;
        shownBitmap = bitmap;
        if (bitmap == null) imageView.setImageDrawable(null);
        else imageView.setImageBitmap(bitmap);
        if (old != null && old != bitmap && !old.isRecycled()) old.recycle();
    }

    private void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
    }

    private boolean showRelativeEntry(int delta) {
        if (galleryQids == null || galleryQids.isEmpty() || galleryPosition < 0) return false;
        int next = galleryPosition + delta;
        if (next < 0 || next >= galleryQids.size()) return false;
        String nextQid = galleryQids.get(next);
        if (nextQid == null || nextQid.isEmpty()) return false;
        galleryPosition = next;
        qid = nextQid;
        entry = null;
        if (scrollView != null) scrollView.scrollTo(0, 0);
        updatePositionView();
        scheduleCoalescedRefresh();
        return true;
    }

    private void scheduleCoalescedRefresh() {
        if (pendingRefresh != null) mainHandler.removeCallbacks(pendingRefresh);
        pendingRefresh = () -> {
            pendingRefresh = null;
            refresh();
        };
        mainHandler.postDelayed(pendingRefresh, 120L);
    }


    private void applyExternalLinkIcon() {
        Drawable icon = getResources().getDrawable(R.drawable.ic_external_open);
        if (icon != null) {
            icon.setBounds(0, 0, dp(21), dp(21));
            icon.setTint(linkColor);
        }
        captionView.setCompoundDrawables(null, null, icon, null);
    }

    private void updatePositionView() {
        boolean inGallery = galleryPosition >= 0 && galleryPosition < galleryQids.size();
        if (positionView != null) {
            positionView.setText(inGallery
                    ? (galleryPosition + 1) + tr(" из ", " of ") + galleryQids.size()
                    : "");
        }
        if (navigationRow != null) {
            navigationRow.setVisibility(inGallery && galleryQids.size() > 1 ? View.VISIBLE : View.GONE);
        }
        if (previousButton != null) {
            boolean enabled = inGallery && galleryPosition > 0;
            previousButton.setEnabled(enabled);
            previousButton.setAlpha(enabled ? 1f : 0.35f);
        }
        if (nextButton != null) {
            boolean enabled = inGallery && galleryPosition < galleryQids.size() - 1;
            nextButton.setEnabled(enabled);
            nextButton.setAlpha(enabled ? 1f : 0.35f);
        }
    }

    private void recycleShownBitmap() {
        if (shownBitmap != null && !shownBitmap.isRecycled()) shownBitmap.recycle();
        shownBitmap = null;
    }

    private void install() {
        if (entry == null || !UpdateCoordinator.tryBegin()) {
            Toast.makeText(this, tr("Обновление уже выполняется", "An update is already in progress"), Toast.LENGTH_SHORT).show();
            return;
        }
        final String installQid = entry.qid;
        actionBusy = true;
        updateActionButtons();
        executor.execute(() -> {
            try {
                new ArtRepository(getApplicationContext()).installOnWidget(installQid);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    Toast.makeText(this, tr("Картина установлена на виджет", "Artwork set on widget"), Toast.LENGTH_SHORT).show();
                    refresh();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                UpdateCoordinator.finish();
                runOnUiThread(() -> {
                    actionBusy = false;
                    updateActionButtons();
                });
            }
        });
    }

    private void confirmDeleteFromCache() {
        if (entry == null) return;
        AppDialogs.confirm(this,
                tr("Удалить картину из кэша?", "Delete artwork from cache?"),
                tr("Картина будет удалена из галереи и памяти телефона. Если она сейчас установлена на виджете, приложение сразу поставит новую картину.",
                        "The artwork will be removed from the gallery and phone storage. If it is currently on the widget, the app will immediately set a new artwork."),
                tr("Нет", "No"),
                tr("Да", "Yes"),
                true,
                this::deleteFromCache);
    }

    private void deleteFromCache() {
        if (entry == null || actionBusy) return;
        if (!UpdateCoordinator.tryBegin()) {
            Toast.makeText(this, tr("Обновление уже выполняется", "An update is already in progress"), Toast.LENGTH_SHORT).show();
            return;
        }
        final String deleteQid = entry.qid;
        actionBusy = true;
        updateActionButtons();
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(getApplicationContext());
                ArtEntry current = repo.getCurrent();
                boolean isCurrent = current != null && (deleteQid.equals(current.qid)
                        || (entry != null && entry.sameArtwork(current)));
                if (isCurrent) {
                    repo.fetchNextArtworkForManualRequest();
                    ArtWidgetProvider.updateAllWidgets(getApplicationContext());
                }
                repo.deleteLocalFile(deleteQid);
                runOnUiThread(() -> {
                    Toast.makeText(this, tr("Картина удалена из кэша", "Artwork removed from cache"), Toast.LENGTH_SHORT).show();
                    removeDeletedFromGallery(deleteQid);
                    if (galleryQids == null || galleryQids.isEmpty()) {
                        finish();
                    } else {
                        if (galleryPosition >= galleryQids.size()) galleryPosition = galleryQids.size() - 1;
                        qid = galleryQids.get(galleryPosition);
                        refresh();
                    }
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                UpdateCoordinator.finish();
                runOnUiThread(() -> {
                    actionBusy = false;
                    updateActionButtons();
                });
            }
        });
    }

    private void removeDeletedFromGallery(String deletedQid) {
        if (galleryQids == null || deletedQid == null) return;
        int oldPosition = galleryPosition;
        for (int i = galleryQids.size() - 1; i >= 0; i--) {
            if (deletedQid.equals(galleryQids.get(i))) galleryQids.remove(i);
        }
        galleryPosition = Math.min(Math.max(0, oldPosition), galleryQids.size() - 1);
    }

    private void toggleFavorite() {
        if (entry == null) return;
        boolean value = new ArtRepository(this).toggleFavorite(entry);
        Toast.makeText(this, value ? tr("Добавлено в избранное", "Added to favorites") : tr("Удалено из избранного", "Removed from favorites"), Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void toggleDislike() {
        if (entry == null) return;
        ArtRepository repo = new ArtRepository(this);
        boolean newValue = !repo.isDisliked(entry);
        repo.setDisliked(entry, newValue);
        Toast.makeText(this, newValue ? tr("Картина добавлена в чёрный список", "Artwork added to the blacklist") : tr("Дизлайк снят", "Dislike removed"), Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void openArticle() {
        if (entry == null || entry.sourceUrl.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(entry.sourceUrl))); }
        catch (Exception e) { Toast.makeText(this, tr("Не удалось открыть статью", "Could not open the article"), Toast.LENGTH_SHORT).show(); }
    }

    private void openFullscreen() {
        if (entry == null) return;
        Intent intent = new Intent(this, FullscreenActivity.class);
        intent.putExtra("qid", entry.qid);
        startActivity(intent);
    }

    private void updateActionButtons() {
        boolean enabled = !displayLoading && !actionBusy && entry != null;
        installButton.setEnabled(enabled);
        if (deleteButton != null) deleteButton.setEnabled(enabled);
        favoriteButton.setEnabled(enabled);
        dislikeButton.setEnabled(enabled);
        imageView.setEnabled(enabled);
        captionView.setEnabled(enabled);
        installButton.setAlpha(enabled ? 1f : 0.55f);
        if (deleteButton != null) deleteButton.setAlpha(enabled ? 1f : 0.55f);
        favoriteButton.setAlpha(enabled ? 1f : 0.55f);
        dislikeButton.setAlpha(enabled ? 1f : 0.55f);
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15, primary ? 0xFF007AFF : borderColor));
        b.setMinHeight(0);
        return b;
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, 0, 0, dp(8));
        return p;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFEDEDEF;
        borderColor = dark ? 0xFF38383A : 0xFFD1D1D6;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
