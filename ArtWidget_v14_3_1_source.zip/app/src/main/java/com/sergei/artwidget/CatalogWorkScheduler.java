package com.sergei.artwidget;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Проверяет встроенные каталоги и обновляет метаданные категории «Обнажённая натура» без фоновой загрузки изображений. */
public final class CatalogWorkScheduler {
    public static final int PREFETCH_BATCH_SIZE = 8;
    public static final int PREFETCH_DELAY_SECONDS = 12;

    private static final String WORK_BOOTSTRAP = "art_catalog_bootstrap_v14_1_3";
    private static final String WORK_PREFETCH = "art_cache_prefetch_v14_1_3";
    private static final String WORK_MANUAL_PREFETCH = "art_manual_cache_prefetch_v14_1_3";
    private static final String WORK_PREFETCH_PERIODIC = "art_cache_prefetch_periodic_v14_1_3";
    private static final String WORK_NSFW_DISCOVERY = "art_nsfw_discovery_v14_1_3";
    private static final String WORK_NSFW_PERIODIC = "art_nsfw_discovery_periodic_v14_1_3";
    private static final String WORK_BILINGUAL_REINDEX = "art_bilingual_reindex_v14_3_1";

    private CatalogWorkScheduler() { }

    public static void ensureInitialized(Context context) {
        Context app = context.getApplicationContext();
        cancelImagePrefetchWork(app);
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(app)
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.KEEP, request);
        scheduleNsfwDiscovery(app, false);
        schedulePeriodicNsfwDiscovery(app);
    }

    public static void requestManualRefresh(Context context) {
        Context app = context.getApplicationContext();
        cancelImagePrefetchWork(app);
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .build();
        WorkManager.getInstance(app)
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.REPLACE, request);
        scheduleNsfwDiscovery(app, true);
    }

    /** Кэш изображений пополняется только при выборе новой картины или автообновлении виджета. */
    public static void schedulePrefetch(Context context) {
        cancelImagePrefetchWork(context.getApplicationContext());
    }

    public static void schedulePrefetchContinuation(Context context, int emptyRetries) {
        cancelImagePrefetchWork(context.getApplicationContext());
    }

    public static void requestManualPrefetch(Context context, int count) {
        cancelImagePrefetchWork(context.getApplicationContext());
    }

    public static void scheduleNsfwDiscovery(Context context, boolean forceRescan) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(NsfwCatalogDiscoveryWorker.class)
                .setConstraints(networkConstraints(context))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .setInputData(new Data.Builder()
                        .putBoolean(NsfwCatalogDiscoveryWorker.KEY_FORCE_RESCAN, forceRescan)
                        .build())
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_NSFW_DISCOVERY,
                        forceRescan ? ExistingWorkPolicy.REPLACE : ExistingWorkPolicy.KEEP,
                        request);
    }

    public static void scheduleNsfwDiscoveryContinuation(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(NsfwCatalogDiscoveryWorker.class)
                .setConstraints(networkConstraints(context))
                .setInitialDelay(20, TimeUnit.SECONDS)
                .setInputData(new Data.Builder()
                        .putBoolean(NsfwCatalogDiscoveryWorker.KEY_FORCE_RESCAN, false)
                        .build())
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_NSFW_DISCOVERY, ExistingWorkPolicy.APPEND_OR_REPLACE, request);
    }

    private static void schedulePeriodicNsfwDiscovery(Context context) {
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                NsfwCatalogDiscoveryWorker.class, 24, TimeUnit.HOURS)
                .setConstraints(networkConstraints(context))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniquePeriodicWork(WORK_NSFW_PERIODIC,
                        ExistingPeriodicWorkPolicy.UPDATE, request);
    }

    public static void scheduleBilingualReindex(Context context, boolean restart) {
        Context app = context.getApplicationContext();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(BilingualMetadataWorker.class)
                .setConstraints(networkConstraints(app))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(app).enqueueUniqueWork(WORK_BILINGUAL_REINDEX,
                restart ? ExistingWorkPolicy.REPLACE : ExistingWorkPolicy.KEEP, request);
    }

    public static void scheduleBilingualReindexContinuation(Context context) {
        Context app = context.getApplicationContext();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(BilingualMetadataWorker.class)
                .setConstraints(networkConstraints(app))
                .setInitialDelay(20, TimeUnit.SECONDS)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(app).enqueueUniqueWork(WORK_BILINGUAL_REINDEX,
                ExistingWorkPolicy.APPEND_OR_REPLACE, request);
    }

    private static void cancelImagePrefetchWork(Context context) {
        WorkManager manager = WorkManager.getInstance(context.getApplicationContext());
        manager.cancelUniqueWork(WORK_PREFETCH);
        manager.cancelUniqueWork(WORK_MANUAL_PREFETCH);
        manager.cancelUniqueWork(WORK_PREFETCH_PERIODIC);
    }

    private static Constraints networkConstraints(Context context) {
        boolean wifiOnly = new ArtRepository(context.getApplicationContext()).isWifiOnly();
        return new Constraints.Builder()
                .setRequiredNetworkType(wifiOnly ? NetworkType.UNMETERED : NetworkType.CONNECTED)
                .build();
    }

    public static void scheduleRefill(Context context, int mode) {
        if (mode == ArtRepository.CONTENT_ADULT_ONLY) scheduleNsfwDiscovery(context, false);
    }

    public static void scheduleBothIfNeeded(Context context) {
        ensureInitialized(context);
    }
}
