package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Постепенно расширяет локальный NSFW-каталог по тематическим категориям
 * русской и английской Wikipedia. Категория используется только как источник
 * кандидатов; в рабочий каталог попадают страницы конкретных произведений с
 * растровым изображением и явными признаками живописи.
 */
public final class WikipediaNsfwCatalogUpdater {
    private static final String USER_AGENT =
            "ArtWidget/14.3.1 Android; Wikipedia category catalog; contact enricherusa@gmail.com";
    private static final long RESCAN_INTERVAL_MS = 24L * 60L * 60L * 1000L;
    private static final int CONNECT_TIMEOUT_MS = 12_000;
    private static final int READ_TIMEOUT_MS = 20_000;

    private static final String KEY_STATUS = "dynamic_nsfw_status_v14_1_3";
    private static final String KEY_LAST_UPDATE = "dynamic_nsfw_last_update_v14_1_3";
    private static final String KEY_CURRENT_CATEGORY_PREFIX = "dynamic_nsfw_current_category_v14_2_10_";
    private static final String KEY_PENDING_CATEGORIES_PREFIX = "dynamic_nsfw_pending_categories_v14_2_10_";
    private static final String KEY_SEEN_CATEGORIES_PREFIX = "dynamic_nsfw_seen_categories_v14_2_10_";

    private static final Source[] SOURCES = new Source[]{
            new Source("ru", "Категория:Картины с обнажёнными женщинами", "nude-women"),
            new Source("ru", "Категория:Картины с обнажёнными мужчинами", "nude-men"),
            new Source("ru", "Категория:Афродита в живописи", "aphrodite"),
            new Source("en", "Category:Nude paintings", "nude-root"),
            new Source("en", "Category:Nude paintings of women", "nude-women"),
            new Source("en", "Category:Nude paintings of men", "nude-men"),
            new Source("en", "Category:Paintings of Adam and Eve", "adam-eve"),
            new Source("en", "Category:Paintings of Venus", "venus"),
            new Source("en", "Category:Venus Anadyomene", "venus-anadyomene"),
            new Source("en", "Category:Reclining Venus", "reclining-venus"),
            new Source("en", "Category:Sleeping Venus", "sleeping-venus"),
            new Source("en", "Category:Paintings of Danaë", "danae"),
            new Source("en", "Category:Leda and the Swan in art", "leda-swan"),
            new Source("en", "Category:Paintings of Leda and the Swan", "paintings-leda-swan"),
            new Source("en", "Category:Susanna and the Elders in art", "susanna"),
            new Source("en", "Category:Paintings of Susanna and the Elders", "paintings-susanna"),
            new Source("en", "Category:Bathsheba in art", "bathsheba"),
            new Source("en", "Category:Paintings of Bathsheba", "paintings-bathsheba"),
            new Source("en", "Category:Odalisques in art", "odalisques"),
            new Source("en", "Category:Paintings of odalisques", "paintings-odalisques")
    };

    private static final String[] POSITIVE_RU = new String[]{
            " картина", "картина ", " картины", " живопис", " полотно", " холст",
            " масло", " фреск", " роспись", " триптих", " диптих"
    };
    private static final String[] POSITIVE_EN = new String[]{
            " painting", "painted by", " oil on ", " canvas", " fresco",
            " triptych", " diptych", " panel painting"
    };
    private static final String[] REJECT_RU = new String[]{
            "скульптур", "стату", "фотограф", "гравюр", "офорт", "рисунок",
            "литограф", "ксилограф", "плакат", "кинофильм", "фильм ", "мультфильм",
            "здание", "архитектур", "музейная экспозиция",
            "биография", "родился", "умер", "обнаженный ребенок",
            "обнажённый ребёнок", "обнаженные дети", "обнажённые дети",
            "холст — материал", "холст это", "техника живописи", "подрамник", "грунт для живописи"
    };
    private static final String[] REJECT_EN = new String[]{
            "sculpture", "statue", "photograph", "engraving", "etching", "drawing",
            "lithograph", "woodcut", "poster", " film", "building", "architecture",
            "museum exhibition", "biography",
            "born", "died", "known for", "nude child", "nude children",
            "canvas fabric", "canvas is", "durable fabric", "art material", "painting support", "painting technique",
            "stretcher", "gesso", "acrylic paint"
    };

    private static final String[] CHILD_REJECT_RU = new String[]{
            "мадонна с младенцем", "богоматерь с младенцем", "дева с младенцем",
            "святое семейство", "младенец иисус", "младенцем иисусом",
            "обнаженный ребенок", "обнажённый ребёнок", "обнаженные дети", "обнажённые дети",
            "ребенок", "ребёнок", "дети", "младенец", "младенцем",
            "мальчик", "девочка", "юноша", "отрок", "подросток", "несовершеннолет"
    };
    private static final String[] CHILD_REJECT_EN = new String[]{
            "madonna and child", "virgin and child", "holy family",
            "infant jesus", "baby jesus", "child jesus", "christ child",
            "nude child", "nude children", "naked child", "naked children",
            " child", "children", "infant", " baby", " boy", " girl",
            "youth", "adolescent", "minor"
    };
    private static final String[] CUPID_CONTEXT = new String[]{
            "cupid", "amor", "putti", "putto", "cherub", "амур", "купидон", "путти"
    };
    private static final String[] ADULT_NUDE_CONTEXT = new String[]{
            "venus", "aphrodite", "венера", "афродита", "danae", "danaë", "даная",
            "leda", "леда", "susanna", "сусанна", "bathsheba", "вирсавия",
            "odalisque", "одалиска", "reclining nude", "female nude", "male nude",
            "nude woman", "nude man", "обнаженная женщина", "обнажённая женщина",
            "обнаженный мужчина", "обнажённый мужчина", "eve", "adam", "ева", "адам"
    };

    private static final Pattern INFOBOX_ARTIST_BLOCK = Pattern.compile(
            "(?ims)^\\s*\\|\\s*(?:художник|автор|artist|painter)\\s*=\\s*(.*?)"
                    + "(?=^\\s*\\|\\s*[\\p{L}\\p{N}_ -]{1,50}\\s*=|^\\s*\\}\\})");
    private static final Pattern INFOBOX_ARTIST_LINE = Pattern.compile(
            "(?im)^\\s*\\|\\s*(?:художник|автор|artist|painter)\\s*=\\s*(.+?)\\s*$");
    private static final Pattern WIKI_LINK = Pattern.compile(
            "\\[\\[([^\\]|#]+)(?:#[^\\]|]+)?(?:\\|([^\\]]+))?\\]\\]");

    private final Context context;
    private final SharedPreferences prefs;
    private final CatalogStore store;
    private final ArtRepository repository;

    public WikipediaNsfwCatalogUpdater(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(ArtRepository.PREFS, Context.MODE_PRIVATE);
        this.store = new CatalogStore(this.context);
        this.repository = new ArtRepository(this.context);
    }

    public UpdateResult updateBatch(int perSourceLimit, boolean forceRescan) {
        int safeLimit = Math.max(5, Math.min(40, perSourceLimit));
        int scanned = 0;
        int accepted = 0;
        int alreadyKnown = 0;
        int addedBefore = store.countExplicit();
        boolean moreRemaining = false;
        String lastError = "";

        for (Source source : SOURCES) {
            try {
                SourceResult result = updateSource(source, safeLimit, forceRescan);
                scanned += result.scanned;
                accepted += result.accepted;
                alreadyKnown += result.alreadyKnown;
                moreRemaining |= result.moreRemaining;
            } catch (Exception e) {
                lastError = friendly(e);
                AppLogger.log(context, "dynamic-nsfw", "source-error",
                        source.lang + " | " + source.category + " | " + lastError);
            }
        }

        int total = store.countExplicit();
        int added = Math.max(0, total - addedBefore);
        int rejected = Math.max(0, scanned - accepted);
        String status;
        if (added > 0) {
            status = "Локальный каталог «Обнажённая натура»: проверено " + scanned
                    + ", добавлено " + added
                    + ", уже было " + alreadyKnown
                    + ", отклонено " + rejected
                    + ". Всего: " + total;
        } else if (!lastError.isEmpty() && scanned == 0) {
            status = "Локальный каталог «Обнажённая натура»: временная ошибка — " + lastError
                    + ". Всего: " + total;
        } else {
            if (scanned == 0 && lastError.isEmpty()) {
                status = "Локальный каталог «Обнажённая натура»: текущая партия не содержала новых страниц для проверки"
                        + ". Всего: " + total;
                if (moreRemaining) status += ". Есть продолжение обхода подкатегорий";
            } else {
                status = "Локальный каталог «Обнажённая натура»: проверено " + scanned
                        + ", новых подходящих картин не найдено"
                        + ", уже было " + alreadyKnown
                        + ", отклонено " + rejected
                        + ". Всего: " + total;
                if (moreRemaining) status += ". Есть продолжение обхода";
                if (!lastError.isEmpty()) status += ". Часть источников недоступна: " + lastError;
            }
        }
        prefs.edit().putString(KEY_STATUS, status)
                .putLong(KEY_LAST_UPDATE, System.currentTimeMillis()).apply();
        return new UpdateResult(added, scanned, accepted, alreadyKnown, rejected, total, moreRemaining, lastError, status);
    }

    public String getStatus() {
        return prefs.getString(KEY_STATUS, "Автоматическое обновление каталога «Обнажённая натура» ещё не запускалось");
    }

    private SourceResult updateSource(Source source, int limit, boolean forceRescan) throws Exception {
        String base = source.key();
        String cursorKey = "dynamic_nsfw_cursor_v14_1_3_" + base;
        String doneKey = "dynamic_nsfw_done_v14_1_3_" + base;
        String currentCategoryKey = KEY_CURRENT_CATEGORY_PREFIX + base;
        String pendingKey = KEY_PENDING_CATEGORIES_PREFIX + base;
        String seenKey = KEY_SEEN_CATEGORIES_PREFIX + base;
        long now = System.currentTimeMillis();
        long doneAt = prefs.getLong(doneKey, 0L);
        String cursor = prefs.getString(cursorKey, "");
        String currentCategory = prefs.getString(currentCategoryKey, "");
        if (currentCategory == null || currentCategory.trim().isEmpty()) currentCategory = source.category;

        if (cursor.isEmpty() && doneAt > 0L && !forceRescan && now - doneAt < RESCAN_INTERVAL_MS) {
            return new SourceResult(0, 0, 0, false);
        }
        if (cursor.isEmpty() && doneAt > 0L && (forceRescan || now - doneAt >= RESCAN_INTERVAL_MS)) {
            // После завершённого полного прохода начинаем действительно новый обход,
            // включая ранее просмотренные подкатегории. Иначе новые страницы внутри
            // старой подкатегории никогда не будут замечены.
            prefs.edit()
                    .putLong(doneKey, 0L)
                    .putString(currentCategoryKey, source.category)
                    .putString(pendingKey, "[]")
                    .putString(seenKey, "[]")
                    .putString(cursorKey, "")
                    .apply();
            currentCategory = source.category;
            cursor = "";
        }

        CategoryPage categoryPage = fetchCategoryPage(source, currentCategory, cursor, limit);
        Set<String> seen = loadCategorySet(seenKey);
        Set<String> pending = loadCategorySet(pendingKey);
        seen.add(source.category);
        seen.add(currentCategory);
        for (String subcategory : categoryPage.subcategories) {
            if (subcategory == null || subcategory.trim().isEmpty()) continue;
            if (!seen.contains(subcategory)) pending.add(subcategory);
        }

        if (categoryPage.members.isEmpty() && categoryPage.nextCursor.isEmpty()) {
            String nextCategory = popNextCategory(pending, seen);
            SharedPreferences.Editor emptyEditor = prefs.edit()
                    .putString(cursorKey, "")
                    .putString(pendingKey, encodeStringSet(pending))
                    .putString(seenKey, encodeStringSet(seen));
            if (nextCategory.isEmpty()) {
                emptyEditor.putString(currentCategoryKey, source.category).putLong(doneKey, now);
                emptyEditor.apply();
                return new SourceResult(0, 0, 0, false);
            }
            emptyEditor.putString(currentCategoryKey, nextCategory).putLong(doneKey, 0L).apply();
            return new SourceResult(0, 0, 0, true);
        }

        List<ArtEntry> candidates = fetchMetadata(source, categoryPage.members);
        List<ArtEntry> merge = new ArrayList<>();
        int alreadyKnown = 0;
        for (ArtEntry candidate : candidates) {
            ArtEntry existing = store.getByQid(candidate.qid);
            if (existing != null) {
                alreadyKnown++;
                candidate = mergeLocalizedEntry(existing, candidate);
            }
            merge.add(candidate);
        }
        if (!merge.isEmpty()) store.mergeAll(merge);

        SharedPreferences.Editor editor = prefs.edit()
                .putString(pendingKey, encodeStringSet(pending))
                .putString(seenKey, encodeStringSet(seen));
        if (categoryPage.nextCursor.isEmpty()) {
            String nextCategory = popNextCategory(pending, seen);
            editor.putString(cursorKey, "")
                    .putString(pendingKey, encodeStringSet(pending))
                    .putString(seenKey, encodeStringSet(seen));
            if (nextCategory.isEmpty()) {
                editor.putString(currentCategoryKey, source.category).putLong(doneKey, now);
            } else {
                editor.putString(currentCategoryKey, nextCategory).putLong(doneKey, 0L);
            }
        } else {
            editor.putString(currentCategoryKey, currentCategory)
                    .putString(cursorKey, categoryPage.nextCursor)
                    .putLong(doneKey, 0L);
        }
        editor.apply();
        boolean more = !categoryPage.nextCursor.isEmpty() || !pending.isEmpty();
        return new SourceResult(categoryPage.members.size(), candidates.size(), alreadyKnown, more);
    }

    private CategoryPage fetchCategoryPage(Source source, String category, String cursor, int limit) throws Exception {
        String activeCategory = (category == null || category.trim().isEmpty()) ? source.category : category.trim();
        StringBuilder url = new StringBuilder("https://")
                .append(source.lang).append(".wikipedia.org/w/api.php")
                .append("?action=query&format=json&formatversion=2")
                .append("&list=categorymembers&cmnamespace=0%7C14&cmtype=page%7Csubcat")
                .append("&cmlimit=").append(limit)
                .append("&cmtitle=").append(enc(activeCategory));
        if (cursor != null && !cursor.isEmpty()) {
            url.append("&cmcontinue=").append(enc(cursor));
        }
        JSONObject root = requestJson(url.toString());
        JSONObject query = root.optJSONObject("query");
        JSONArray array = query == null ? null : query.optJSONArray("categorymembers");
        List<PageRef> members = new ArrayList<>();
        List<String> subcategories = new ArrayList<>();
        if (array != null) {
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.optJSONObject(i);
                if (item == null) continue;
                int namespace = item.optInt("ns", -1);
                int pageId = item.optInt("pageid", 0);
                String title = item.optString("title", "").trim();
                if (pageId <= 0 || title.isEmpty()) continue;
                if (namespace == 0) {
                    members.add(new PageRef(pageId, title));
                } else if (namespace == 14) {
                    subcategories.add(title);
                }
            }
        }
        JSONObject continuation = root.optJSONObject("continue");
        String next = continuation == null ? "" : continuation.optString("cmcontinue", "");
        return new CategoryPage(members, subcategories, next);
    }

    private Set<String> loadCategorySet(String key) {
        Set<String> result = new HashSet<>();
        try {
            JSONArray array = new JSONArray(prefs.getString(key, "[]"));
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty()) result.add(value);
            }
        } catch (Exception ignored) { }
        return result;
    }

    private String encodeStringSet(Set<String> values) {
        JSONArray array = new JSONArray();
        if (values == null) return array.toString();
        List<String> sorted = new ArrayList<>(values);
        java.util.Collections.sort(sorted);
        for (String value : sorted) {
            if (value != null && !value.trim().isEmpty()) array.put(value.trim());
        }
        return array.toString();
    }

    private String popNextCategory(Set<String> pending, Set<String> seen) {
        if (pending == null || pending.isEmpty()) return "";
        List<String> sorted = new ArrayList<>(pending);
        java.util.Collections.sort(sorted);
        for (String candidate : sorted) {
            if (candidate == null || candidate.trim().isEmpty()) continue;
            pending.remove(candidate);
            if (seen != null && seen.contains(candidate)) continue;
            if (seen != null) seen.add(candidate);
            return candidate;
        }
        return "";
    }

    private List<ArtEntry> fetchMetadata(Source source, List<PageRef> refs) throws Exception {
        if (refs.isEmpty()) return new ArrayList<>();
        StringBuilder titles = new StringBuilder();
        for (PageRef ref : refs) {
            if (titles.length() > 0) titles.append('|');
            titles.append(ref.title);
        }
        String url = "https://" + source.lang + ".wikipedia.org/w/api.php"
                + "?action=query&format=json&formatversion=2&redirects=1"
                + "&prop=pageprops%7Cpageimages%7Cextracts%7Cinfo%7Crevisions"
                + "&piprop=original%7Cthumbnail&pithumbsize=1600"
                + "&exintro=1&explaintext=1&inprop=url"
                + "&rvprop=content&rvslots=main&rvsection=0"
                + "&titles=" + enc(titles.toString());
        JSONObject root = requestJson(url);
        JSONObject query = root.optJSONObject("query");
        JSONArray pages = query == null ? null : query.optJSONArray("pages");
        List<ArtEntry> result = new ArrayList<>();
        if (pages == null) return result;

        Set<String> artworkQids = new HashSet<>();
        for (int i = 0; i < pages.length(); i++) {
            JSONObject page = pages.optJSONObject(i);
            JSONObject props = page == null ? null : page.optJSONObject("pageprops");
            String qid = props == null ? "" : props.optString("wikibase_item", "").trim();
            if (qid.matches("Q\\d+")) artworkQids.add(qid);
        }
        Map<String, ArtistNames> wikidataArtists = fetchWikidataArtists(artworkQids);
        Map<String, ArtworkNames> wikidataArtworkNames = fetchWikidataArtworkNames(artworkQids);

        long now = System.currentTimeMillis();
        for (int i = 0; i < pages.length(); i++) {
            JSONObject page = pages.optJSONObject(i);
            if (page == null || page.optBoolean("missing", false) || page.optInt("ns", -1) != 0) continue;
            String articleTitle = page.optString("title", "").trim();
            String title = ArtEntry.titleForWidget(articleTitle);
            String extract = normalize(page.optString("extract", ""));
            if (!isPainting(source.lang, articleTitle, extract)) continue;

            JSONObject original = page.optJSONObject("original");
            JSONObject thumbnail = page.optJSONObject("thumbnail");
            String originalUrl = original == null ? "" : original.optString("source", "").trim();
            String imageUrl = thumbnail == null ? "" : thumbnail.optString("source", "").trim();
            if (imageUrl.isEmpty()) imageUrl = originalUrl;
            if (originalUrl.isEmpty()) originalUrl = imageUrl;
            if (!isRaster(imageUrl) || !isRaster(originalUrl)) continue;

            JSONObject props = page.optJSONObject("pageprops");
            String qid = props == null ? "" : props.optString("wikibase_item", "").trim();
            if (qid.isEmpty()) {
                qid = "wikicat:" + source.lang + ":" + page.optInt("pageid", 0);
            }
            String sourceUrl = page.optString("fullurl", "").trim();
            if (sourceUrl.isEmpty()) {
                sourceUrl = "https://" + source.lang + ".wikipedia.org/wiki/"
                        + encPath(articleTitle.replace(' ', '_'));
            }
            String description = shorten(extract);
            ArtistNames names = wikidataArtists.get(qid);
            ArtworkNames artworkNames = wikidataArtworkNames.get(qid);
            String infoboxArtist = extractArtistFromInfobox(source.lang, page);
            String artistRu = names == null ? "" : names.ru;
            String artistEn = names == null ? "" : names.en;
            String artist = chooseArtist(source.lang, artistRu, artistEn, infoboxArtist);
            if ("ru".equals(source.lang) && artistRu.isEmpty() && !ArtEntry.isUnknownArtist(artist)) artistRu = artist;
            if ("en".equals(source.lang) && artistEn.isEmpty() && !ArtEntry.isUnknownArtist(artist)) artistEn = artist;
            String genre = "dynamic-nsfw, verified-painting, category-" + source.tag
                    + ", source-" + source.lang;
            boolean ru = "ru".equals(source.lang);
            String titleRu = artworkNames == null ? "" : artworkNames.ru;
            String titleEn = artworkNames == null ? "" : artworkNames.en;
            if (ru && titleRu.isEmpty()) titleRu = title;
            if (!ru && titleEn.isEmpty()) titleEn = title;
            result.add(new ArtEntry(
                    qid,
                    title,
                    artist,
                    description,
                    titleRu,
                    titleEn,
                    artistRu,
                    artistEn,
                    ru ? description : "",
                    ru ? "" : description,
                    source.lang,
                    imageUrl,
                    originalUrl,
                    "",
                    sourceUrl,
                    "painting",
                    "",
                    genre,
                    now,
                    0L,
                    0,
                    true
            ));
        }
        return result;
    }

    private boolean isPainting(String lang, String title, String extract) {
        String text = (title + " " + extract).toLowerCase(Locale.ROOT).replace('ё', 'е');
        String intro = text.length() > 600 ? text.substring(0, 600) : text;
        String[] rejected = "ru".equals(lang) ? REJECT_RU : REJECT_EN;
        for (String value : rejected) if (text.contains(value)) return false;
        if (containsDisallowedChildSubject(text)) return false;

        if ("ru".equals(lang)) {
            return intro.contains(" — картина") || intro.contains(" - картина")
                    || intro.contains("является картиной") || intro.contains("живописное полотно")
                    || intro.matches(".*\\bкартина\\b.{0,100}\\bхудожник.*")
                    || intro.contains("масло на холсте") || intro.contains("холст, масло");
        }
        return intro.matches(".*\\bis (?:an? |the )?[^.]{0,100}\\bpainting\\b.*")
                || intro.contains("painting by ") || intro.contains("oil-on-canvas painting")
                || intro.contains("oil on canvas painting") || intro.contains("panel painting")
                || intro.contains("fresco painting");
    }

    private boolean containsDisallowedChildSubject(String text) {
        if (text == null || text.isEmpty()) return false;
        String normalized = text.toLowerCase(Locale.ROOT).replace('ё', 'е');

        boolean hasCupid = containsAny(normalized, CUPID_CONTEXT);
        boolean hasAdultNude = containsAny(normalized, ADULT_NUDE_CONTEXT);

        // Мифологические сцены вроде Venus and Cupid допустимы, если основная
        // обнажённая фигура взрослая. Но религиозные и бытовые сюжеты с детьми
        // в категорию «Обнажённая натура» не пропускаются.
        if (hasCupid && hasAdultNude
                && !containsAny(normalized, new String[]{
                "madonna and child", "virgin and child", "holy family",
                "infant jesus", "baby jesus", "child jesus", "christ child",
                "мадонна с младенцем", "богоматерь с младенцем", "святое семейство",
                "младенец иисус"})) {
            return false;
        }

        return containsAny(normalized, CHILD_REJECT_RU) || containsAny(normalized, CHILD_REJECT_EN);
    }

    private boolean containsAny(String text, String[] needles) {
        if (text == null || needles == null) return false;
        for (String needle : needles) {
            if (needle != null && !needle.isEmpty() && text.contains(needle)) return true;
        }
        return false;
    }

    private String extractArtistFromInfobox(String lang, JSONObject page) {
        JSONArray revisions = page == null ? null : page.optJSONArray("revisions");
        JSONObject revision = revisions == null ? null : revisions.optJSONObject(0);
        JSONObject slots = revision == null ? null : revision.optJSONObject("slots");
        JSONObject main = slots == null ? null : slots.optJSONObject("main");
        String wikitext = main == null ? "" : main.optString("content", main.optString("*", ""));
        if (wikitext.isEmpty() && revision != null) wikitext = revision.optString("*", "");
        Matcher matcher = INFOBOX_ARTIST_BLOCK.matcher(wikitext);
        String raw = matcher.find() ? matcher.group(1) : "";
        if (raw.isEmpty()) {
            matcher = INFOBOX_ARTIST_LINE.matcher(wikitext);
            if (matcher.find()) raw = matcher.group(1);
        }
        if (raw.isEmpty()) return unknownArtist(lang);
        String value = cleanArtistField(raw);
        return value.isEmpty() ? unknownArtist(lang) : value;
    }

    private String chooseArtist(String lang, String artistRu, String artistEn,
                                String infoboxArtist) {
        if (!ArtEntry.isUnknownArtist(infoboxArtist)) return infoboxArtist;
        if ("ru".equals(lang)) {
            if (!artistRu.isEmpty()) return artistRu;
            if (!artistEn.isEmpty()) return artistEn;
        } else {
            if (!artistEn.isEmpty()) return artistEn;
            if (!artistRu.isEmpty()) return artistRu;
        }
        return unknownArtist(lang);
    }

    private ArtEntry mergeLocalizedEntry(ArtEntry existing, ArtEntry candidate) {
        boolean existingRussian = existing.sourceUrl.contains("ru.wikipedia.org/wiki/");
        boolean candidateRussian = candidate.sourceUrl.contains("ru.wikipedia.org/wiki/");
        ArtEntry preferred = candidateRussian && !existingRussian ? candidate : existing;
        ArtEntry other = preferred == existing ? candidate : existing;
        return new ArtEntry(
                preferred.qid,
                preferred.title,
                ArtEntry.isUnknownArtist(preferred.artist) ? other.artist : preferred.artist,
                preferred.description.length() >= other.description.length() ? preferred.description : other.description,
                firstNonEmpty(existing.titleRu, candidate.titleRu),
                firstNonEmpty(existing.titleEn, candidate.titleEn),
                firstNonEmpty(existing.artistRu, candidate.artistRu),
                firstNonEmpty(existing.artistEn, candidate.artistEn),
                firstNonEmpty(existing.descriptionRu, candidate.descriptionRu),
                firstNonEmpty(existing.descriptionEn, candidate.descriptionEn),
                preferred.sourceLanguage,
                firstNonEmpty(preferred.imageUrl, other.imageUrl),
                firstNonEmpty(preferred.originalImageUrl, other.originalImageUrl),
                firstNonEmpty(preferred.localPath, other.localPath),
                firstNonEmpty(preferred.sourceUrl, other.sourceUrl),
                firstNonEmpty(preferred.instanceLabel, other.instanceLabel),
                firstNonEmpty(preferred.materialLabel, other.materialLabel),
                firstNonEmpty(preferred.genreLabel, other.genreLabel),
                Math.min(existing.addedAt, candidate.addedAt),
                Math.max(existing.lastShownAt, candidate.lastShownAt),
                Math.max(existing.showCount, candidate.showCount),
                existing.explicitContent || candidate.explicitContent
        );
    }

    private static String firstNonEmpty(String first, String second) {
        if (first != null && !first.trim().isEmpty()) return first.trim();
        return second == null ? "" : second.trim();
    }

    private Map<String, ArtworkNames> fetchWikidataArtworkNames(Set<String> artworkQids) {
        Map<String, ArtworkNames> result = new HashMap<>();
        if (artworkQids == null || artworkQids.isEmpty()) return result;
        try {
            JSONObject root = requestJson("https://www.wikidata.org/w/api.php"
                    + "?action=wbgetentities&format=json&formatversion=2&props=labels"
                    + "&languages=ru%7Cen&ids=" + enc(joinIds(artworkQids)));
            JSONObject entities = root.optJSONObject("entities");
            if (entities == null) return result;
            for (String qid : artworkQids) {
                JSONObject entity = entities.optJSONObject(qid);
                JSONObject labels = entity == null ? null : entity.optJSONObject("labels");
                String ru = labelValue(labels, "ru");
                String en = labelValue(labels, "en");
                if (!ru.isEmpty() || !en.isEmpty()) result.put(qid, new ArtworkNames(ru, en));
            }
        } catch (Exception e) {
            AppLogger.log(context, "dynamic-nsfw", "title-enrichment-error", friendly(e));
        }
        return result;
    }

    private Map<String, ArtistNames> fetchWikidataArtists(Set<String> artworkQids) {
        Map<String, ArtistNames> result = new HashMap<>();
        if (artworkQids == null || artworkQids.isEmpty()) return result;
        try {
            String ids = joinIds(artworkQids);
            JSONObject claimsRoot = requestJson("https://www.wikidata.org/w/api.php"
                    + "?action=wbgetentities&format=json&formatversion=2&props=claims&ids=" + enc(ids));
            JSONObject entities = claimsRoot.optJSONObject("entities");
            Map<String, List<String>> artworkToArtists = new HashMap<>();
            Set<String> artistQids = new HashSet<>();
            if (entities != null) {
                for (String artworkQid : artworkQids) {
                    JSONObject entity = entities.optJSONObject(artworkQid);
                    JSONObject claims = entity == null ? null : entity.optJSONObject("claims");
                    JSONArray p170 = claims == null ? null : claims.optJSONArray("P170");
                    if (p170 == null) continue;
                    List<String> idsForArtwork = new ArrayList<>();
                    for (int i = 0; i < p170.length(); i++) {
                        JSONObject claim = p170.optJSONObject(i);
                        JSONObject mainsnak = claim == null ? null : claim.optJSONObject("mainsnak");
                        JSONObject datavalue = mainsnak == null ? null : mainsnak.optJSONObject("datavalue");
                        JSONObject value = datavalue == null ? null : datavalue.optJSONObject("value");
                        String artistQid = value == null ? "" : value.optString("id", "").trim();
                        if (!artistQid.matches("Q\\d+")) continue;
                        if (!idsForArtwork.contains(artistQid)) idsForArtwork.add(artistQid);
                        artistQids.add(artistQid);
                    }
                    if (!idsForArtwork.isEmpty()) artworkToArtists.put(artworkQid, idsForArtwork);
                }
            }
            if (artistQids.isEmpty()) return result;
            JSONObject labelsRoot = requestJson("https://www.wikidata.org/w/api.php"
                    + "?action=wbgetentities&format=json&formatversion=2&props=labels"
                    + "&languages=ru%7Cen&ids=" + enc(joinIds(artistQids)));
            JSONObject labelEntities = labelsRoot.optJSONObject("entities");
            Map<String, ArtistNames> byArtistQid = new HashMap<>();
            if (labelEntities != null) {
                for (String artistQid : artistQids) {
                    JSONObject entity = labelEntities.optJSONObject(artistQid);
                    JSONObject labels = entity == null ? null : entity.optJSONObject("labels");
                    String ru = labelValue(labels, "ru");
                    String en = labelValue(labels, "en");
                    byArtistQid.put(artistQid, new ArtistNames(ru, en));
                }
            }
            for (Map.Entry<String, List<String>> entry : artworkToArtists.entrySet()) {
                List<String> ruNames = new ArrayList<>();
                List<String> enNames = new ArrayList<>();
                for (String artistQid : entry.getValue()) {
                    ArtistNames names = byArtistQid.get(artistQid);
                    if (names == null) continue;
                    addDistinctName(ruNames, names.ru);
                    addDistinctName(enNames, names.en);
                }
                String ru = joinNames(ruNames);
                String en = joinNames(enNames);
                if (!ru.isEmpty() || !en.isEmpty()) result.put(entry.getKey(), new ArtistNames(ru, en));
            }
        } catch (Exception e) {
            AppLogger.log(context, "dynamic-nsfw", "artist-enrichment-error", friendly(e));
        }
        return result;
    }

    private static String labelValue(JSONObject labels, String lang) {
        JSONObject label = labels == null ? null : labels.optJSONObject(lang);
        if (label == null) return "";
        String actualLanguage = label.optString("language", "").trim();
        if (!actualLanguage.isEmpty() && !lang.equalsIgnoreCase(actualLanguage)) return "";
        return cleanArtistMarkup(label.optString("value", ""));
    }

    private static String joinIds(Set<String> ids) {
        StringBuilder out = new StringBuilder();
        for (String id : ids) {
            if (out.length() > 0) out.append('|');
            out.append(id);
        }
        return out.toString();
    }

    private static String cleanArtistMarkup(String value) {
        String text = normalize(value);
        if (text.isEmpty()) return "";
        text = text.replaceAll("(?is)<ref[^>]*>.*?</ref>", " ")
                .replaceAll("(?is)<ref[^>]*/>", " ")
                .replaceAll("(?is)<[^>]+>", " ");
        Matcher links = Pattern.compile("\\[\\[(?:[^\\]|]+\\|)?([^\\]]+)\\]\\]").matcher(text);
        StringBuffer linked = new StringBuffer();
        while (links.find()) links.appendReplacement(linked, Matcher.quoteReplacement(links.group(1)));
        links.appendTail(linked);
        text = linked.toString();
        text = text.replaceAll("\\{\\{[^{}]*\\}\\}", " ")
                .replaceAll("'{2,}", "")
                .replaceAll("\\s+", " ")
                .trim();
        int separator = text.indexOf('|');
        if (separator >= 0) text = text.substring(separator + 1).trim();
        if (text.length() > 90) text = text.substring(0, 90).trim();
        return ArtEntry.isUnknownArtist(text) ? "" : text;
    }

    /**
     * Читает только структурированное поле карточки. Сначала используются подписи
     * внутренних ссылок, потому что они уже находятся в именительном падеже и не
     * содержат слов вроде «французский художник» или продолжения предложения.
     */
    private static String cleanArtistField(String value) {
        String raw = value == null ? "" : value;
        raw = raw.replaceAll("(?is)<!--.*?-->", " ")
                .replaceAll("(?is)<ref[^>]*>.*?</ref>", " ")
                .replaceAll("(?is)<ref[^>]*/>", " ");

        List<String> linkedNames = new ArrayList<>();
        Matcher links = WIKI_LINK.matcher(raw);
        while (links.find()) {
            String target = normalize(links.group(1));
            String label = normalize(links.group(2));
            String name = label.isEmpty() ? target : label;
            String lowerTarget = target.toLowerCase(Locale.ROOT);
            if (lowerTarget.startsWith("file:") || lowerTarget.startsWith("image:")
                    || lowerTarget.startsWith("файл:") || lowerTarget.startsWith("category:")
                    || lowerTarget.startsWith("категория:")) continue;
            name = cleanArtistMarkup(name);
            addDistinctName(linkedNames, name);
        }
        if (!linkedNames.isEmpty()) return joinNames(linkedNames);

        String text = raw.replaceAll("(?i)<br\\s*/?>", "; ")
                .replaceAll("(?s)\\{\\{\\s*(?:plainlist|ubl|unbulleted list|nowrap|small)\\s*\\|", "")
                .replaceAll("(?s)\\{\\{\\s*(?:ill|interlanguage link)\\s*\\|\\s*([^|}]+).*?\\}\\}", "$1")
                .replace("{{", " ")
                .replace("}}", " ")
                .replaceAll("(?m)^\\s*[|*•]+\\s*", "")
                .replace('|', ';');
        List<String> plainNames = new ArrayList<>();
        for (String part : text.split("[;\\n]+")) {
            String cleaned = cleanArtistMarkup(part);
            addDistinctName(plainNames, cleaned);
        }
        return joinNames(plainNames);
    }

    private static void addDistinctName(List<String> names, String value) {
        String cleaned = cleanArtistMarkup(value);
        if (cleaned.isEmpty()) return;
        for (String existing : names) {
            if (existing.equalsIgnoreCase(cleaned)) return;
        }
        names.add(cleaned);
    }

    private static String joinNames(List<String> names) {
        StringBuilder out = new StringBuilder();
        for (String name : names) {
            if (name == null || name.trim().isEmpty()) continue;
            if (out.length() > 0) out.append(", ");
            out.append(name.trim());
        }
        return out.toString();
    }

    private static String unknownArtist(String lang) {
        return "ru".equals(lang) ? "Автор неизвестен" : "Unknown artist";
    }

    private JSONObject requestJson(String urlValue) throws Exception {
        if (!repository.isDownloadNetworkAllowed()) {
            throw new IOException("Загрузка запрещена настройками сети");
        }
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(urlValue).openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Accept", "application/json");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) {
                throw new IOException("Wikipedia HTTP " + code);
            }
            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
                return new JSONObject(output.toString(StandardCharsets.UTF_8.name()));
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static boolean isRaster(String url) {
        if (url == null || url.trim().isEmpty()) return false;
        String lower = url.toLowerCase(Locale.ROOT);
        int query = lower.indexOf('?');
        if (query >= 0) lower = lower.substring(0, query);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                || lower.endsWith(".png") || lower.endsWith(".webp");
    }

    private static String shorten(String value) {
        String text = normalize(value);
        if (text.length() <= 760) return text;
        int cut = text.lastIndexOf(' ', 760);
        if (cut < 500) cut = 760;
        return text.substring(0, cut).trim() + "…";
    }

    private static String normalize(String value) {
        return value == null ? "" : value.replaceAll("\\s+", " ").trim();
    }

    private static String enc(String value) {
        try {
            return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name());
        } catch (Exception e) {
            return "";
        }
    }

    private static String encPath(String value) {
        String[] parts = (value == null ? "" : value).split("/", -1);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) out.append('/');
            out.append(enc(parts[i]).replace("+", "%20"));
        }
        return out.toString();
    }

    private static String friendly(Exception e) {
        String value = e == null ? "" : e.getMessage();
        return value == null || value.trim().isEmpty() ? e.getClass().getSimpleName() : value.trim();
    }

    public static final class UpdateResult {
        public final int added;
        public final int scanned;
        public final int accepted;
        public final int alreadyKnown;
        public final int rejected;
        public final int total;
        public final boolean moreRemaining;
        public final String error;
        public final String status;

        UpdateResult(int added, int scanned, int accepted, int alreadyKnown, int rejected,
                     int total, boolean moreRemaining, String error, String status) {
            this.added = added;
            this.scanned = scanned;
            this.accepted = accepted;
            this.alreadyKnown = alreadyKnown;
            this.rejected = rejected;
            this.total = total;
            this.moreRemaining = moreRemaining;
            this.error = error == null ? "" : error;
            this.status = status == null ? "" : status;
        }
    }

    private static final class ArtworkNames {
        final String ru;
        final String en;

        ArtworkNames(String ru, String en) {
            this.ru = ru == null ? "" : ru.trim();
            this.en = en == null ? "" : en.trim();
        }
    }

    private static final class ArtistNames {
        final String ru;
        final String en;

        ArtistNames(String ru, String en) {
            this.ru = ru == null ? "" : ru.trim();
            this.en = en == null ? "" : en.trim();
        }
    }

    private static final class Source {
        final String lang;
        final String category;
        final String tag;

        Source(String lang, String category, String tag) {
            this.lang = lang;
            this.category = category;
            this.tag = tag;
        }

        String key() {
            return lang + "_" + tag.replace('-', '_');
        }
    }

    private static final class PageRef {
        final int pageId;
        final String title;

        PageRef(int pageId, String title) {
            this.pageId = pageId;
            this.title = title;
        }
    }

    private static final class CategoryPage {
        final List<PageRef> members;
        final List<String> subcategories;
        final String nextCursor;

        CategoryPage(List<PageRef> members, List<String> subcategories, String nextCursor) {
            this.members = members == null ? new ArrayList<>() : members;
            this.subcategories = subcategories == null ? new ArrayList<>() : subcategories;
            this.nextCursor = nextCursor == null ? "" : nextCursor;
        }
    }

    private static final class SourceResult {
        final int scanned;
        final int accepted;
        final int alreadyKnown;
        final boolean moreRemaining;

        SourceResult(int scanned, int accepted, int alreadyKnown, boolean moreRemaining) {
            this.scanned = scanned;
            this.accepted = accepted;
            this.alreadyKnown = alreadyKnown;
            this.moreRemaining = moreRemaining;
        }
    }
}
