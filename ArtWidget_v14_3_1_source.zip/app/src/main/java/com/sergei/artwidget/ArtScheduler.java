package com.sergei.artwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import androidx.work.BackoffPolicy;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public final class ArtScheduler {
    public static final String PREFS = "art_widget_prefs";
    public static final String KEY_INTERVAL_SECONDS = "interval_seconds";
    public static final String KEY_NEXT_AT_MILLIS = "next_update_at_millis";
    public static final String KEY_ENABLED = "automatic_updates_enabled_v14_2";
    public static final String KEY_START_HOUR = "auto_update_start_hour_v14_3";
    public static final String KEY_START_MINUTE = "auto_update_start_minute_v14_3";
    public static final String KEY_ANCHOR_AT_MILLIS = "auto_update_anchor_at_millis_v14_3";
    private static final String KEY_SCHEDULE_MODEL_VERSION = "auto_update_schedule_model_v14_3";

    public static final String KEY_LAST_ATTEMPT_AT = "auto_update_last_attempt_at_v14_3_1";
    public static final String KEY_LAST_SUCCESS_AT = "auto_update_last_success_at_v14_3_1";
    public static final String KEY_LAST_RESULT = "auto_update_last_result_v14_3_1";
    public static final String KEY_LAST_ERROR = "auto_update_last_error_v14_3_1";
    public static final String KEY_LAST_REASON = "auto_update_last_reason_v14_3_1";

    public static final int DEFAULT_INTERVAL_SECONDS = 12 * 60 * 60;
    public static final int DEFAULT_START_HOUR = 0;
    public static final int DEFAULT_START_MINUTE = 0;
    public static final int MIN_INTERVAL_SECONDS = 10;
    public static final int MAX_INTERVAL_SECONDS = 60 * 60 * 24 * 30;

    private static final int SCHEDULE_MODEL_VERSION = 2;
    private static final String WORK_AUTO_UPDATE = "art_widget_auto_update_v14_3_1";
    private static final String WORK_WATCHDOG = "art_widget_auto_update_watchdog_v14_3_1";
    private static final long RETRY_BACKOFF_MINUTES = 15L;

    private ArtScheduler() { }

    public static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(KEY_ENABLED, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        Context app = context.getApplicationContext();
        prefs(app).edit().putBoolean(KEY_ENABLED, enabled).apply();
        if (enabled) resetScheduleFromSettings(app, "enabled");
        else cancel(app);
    }

    public static int getIntervalSeconds(Context context) {
        SharedPreferences prefs = prefs(context);
        int seconds = prefs.getInt(KEY_INTERVAL_SECONDS, DEFAULT_INTERVAL_SECONDS);
        if (!prefs.contains(KEY_INTERVAL_SECONDS) && prefs.contains("interval_hours")) {
            seconds = Math.max(1, prefs.getInt("interval_hours", 12)) * 3600;
            prefs.edit().putInt(KEY_INTERVAL_SECONDS, seconds).apply();
        }
        if (seconds < MIN_INTERVAL_SECONDS || seconds > MAX_INTERVAL_SECONDS) {
            return DEFAULT_INTERVAL_SECONDS;
        }
        return seconds;
    }

    public static int getStartHour(Context context) {
        migrateStartTimeIfNeeded(context);
        return clampHour(prefs(context).getInt(KEY_START_HOUR, DEFAULT_START_HOUR));
    }

    public static int getStartMinute(Context context) {
        migrateStartTimeIfNeeded(context);
        return clampMinute(prefs(context).getInt(KEY_START_MINUTE, DEFAULT_START_MINUTE));
    }

    /** Сохраняет выбранную пользователем отправную точку и интервал одним действием. */
    public static void setSchedule(Context context, int startHour, int startMinute, int seconds) {
        Context app = context.getApplicationContext();
        int hour = clampHour(startHour);
        int minute = clampMinute(startMinute);
        int interval = Math.max(MIN_INTERVAL_SECONDS, Math.min(MAX_INTERVAL_SECONDS, seconds));
        long anchor = localAnchorForToday(hour, minute);
        prefs(app).edit()
                .putInt(KEY_START_HOUR, hour)
                .putInt(KEY_START_MINUTE, minute)
                .putInt(KEY_INTERVAL_SECONDS, interval)
                .putLong(KEY_ANCHOR_AT_MILLIS, anchor)
                .putInt(KEY_SCHEDULE_MODEL_VERSION, SCHEDULE_MODEL_VERSION)
                .apply();
        WorkManager.getInstance(app).cancelUniqueWork(WORK_AUTO_UPDATE);
        if (isEnabled(app)) scheduleNextSlot(app, "schedule-changed");
    }

    public static void setIntervalSeconds(Context context, int seconds) {
        setSchedule(context, getStartHour(context), getStartMinute(context), seconds);
    }

    /**
     * Сохранён для совместимости со старым кодом. Теперь отсчёт идёт не от текущего
     * момента, а от выбранной пользователем отправной точки.
     */
    public static void scheduleFromNow(Context context) {
        resetScheduleFromSettings(context, "legacy-from-now");
    }

    public static void scheduleFromNow(Context context, String reason) {
        resetScheduleFromSettings(context, reason);
    }

    /**
     * Восстанавливает уже назначенный срок и не переносит его от обычного открытия
     * приложения, ручной смены картины или системного onUpdate виджета.
     */
    public static void ensureScheduled(Context context) {
        Context app = context.getApplicationContext();
        if (!isEnabled(app)) {
            cancel(app);
            return;
        }
        ensureWatchdog(app);
        SharedPreferences prefs = prefs(app);
        if (prefs.getInt(KEY_SCHEDULE_MODEL_VERSION, 0) != SCHEDULE_MODEL_VERSION) {
            resetScheduleFromSettings(app, "schedule-model-migration");
            return;
        }
        long next = getNextAtMillis(app);
        long now = System.currentTimeMillis();
        if (next <= 0L) {
            scheduleNextSlot(app, "missing-schedule");
        } else if (next <= now) {
            enqueueAutomaticUpdate(app, "overdue");
        } else {
            scheduleAlarmAt(app, next);
        }
    }

    public static void restoreAfterSystemEvent(Context context, String reason) {
        Context app = context.getApplicationContext();
        AppLogger.log(app, "auto-scheduler", "restore", reason);
        if (Intent.ACTION_TIME_CHANGED.equals(reason)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(reason)) {
            resetScheduleFromSettings(app, "clock-changed");
        } else {
            ensureScheduled(app);
        }
    }

    /** Вызывается AlarmManager: тяжёлая работа переносится в WorkManager. */
    public static void onAlarmFired(Context context) {
        Context app = context.getApplicationContext();
        AppLogger.log(app, "auto-alarm", "fired", "at=" + System.currentTimeMillis());
        enqueueAutomaticUpdate(app, "alarm");
    }

    public static void enqueueAutomaticUpdate(Context context, String reason) {
        Context app = context.getApplicationContext();
        if (!isEnabled(app)) return;
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(ScheduledArtworkUpdateWorker.class)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL,
                        RETRY_BACKOFF_MINUTES, TimeUnit.MINUTES)
                .setInputData(new Data.Builder()
                        .putString(ScheduledArtworkUpdateWorker.KEY_REASON, reason == null ? "" : reason)
                        .build())
                .build();
        WorkManager.getInstance(app).enqueueUniqueWork(
                WORK_AUTO_UPDATE, ExistingWorkPolicy.KEEP, request);
        AppLogger.log(app, "auto-work", "enqueued", reason);
    }

    public static void recordAutomaticAttempt(Context context, String reason) {
        long now = System.currentTimeMillis();
        prefs(context).edit()
                .putLong(KEY_LAST_ATTEMPT_AT, now)
                .putString(KEY_LAST_RESULT, "running")
                .putString(KEY_LAST_REASON, reason == null ? "" : reason)
                .remove(KEY_LAST_ERROR)
                .apply();
    }

    public static void recordAutomaticSuccess(Context context, String details) {
        long now = System.currentTimeMillis();
        prefs(context).edit()
                .putLong(KEY_LAST_SUCCESS_AT, now)
                .putString(KEY_LAST_RESULT, details == null || details.trim().isEmpty() ? "success" : details)
                .remove(KEY_LAST_ERROR)
                .apply();
        scheduleNextSlot(context, "automatic-success");
    }

    public static void recordAutomaticError(Context context, String error) {
        prefs(context).edit()
                .putString(KEY_LAST_RESULT, "error")
                .putString(KEY_LAST_ERROR, error == null ? "" : error)
                .apply();
        ensureWatchdog(context.getApplicationContext());
    }

    public static void cancel(Context context) {
        Context app = context.getApplicationContext();
        AlarmManager manager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (manager != null) manager.cancel(pendingIntent(app));
        prefs(app).edit().remove(KEY_NEXT_AT_MILLIS).apply();
        WorkManager workManager = WorkManager.getInstance(app);
        workManager.cancelUniqueWork(WORK_AUTO_UPDATE);
        workManager.cancelUniqueWork(WORK_WATCHDOG);
    }

    public static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager manager = (AlarmManager) context.getApplicationContext()
                .getSystemService(Context.ALARM_SERVICE);
        return manager != null && manager.canScheduleExactAlarms();
    }

    public static long getNextAtMillis(Context context) {
        return prefs(context).getLong(KEY_NEXT_AT_MILLIS, 0L);
    }

    public static String startTimeDisplay(Context context) {
        return String.format(Locale.getDefault(), "%02d:%02d",
                getStartHour(context), getStartMinute(context));
    }

    public static String nextUpdateDisplay(Context context) {
        boolean english = LanguageManager.isEnglish(context);
        if (!isEnabled(context)) return I18n.t(context,
                "Автообновление выключено",
                "Automatic updates are off");
        long next = getNextAtMillis(context);
        if (next <= 0L) return I18n.t(context,
                "Следующее обновление не запланировано",
                "The next update is not scheduled");
        Calendar now = Calendar.getInstance();
        Calendar target = Calendar.getInstance();
        target.setTimeInMillis(next);
        boolean sameDay = now.get(Calendar.ERA) == target.get(Calendar.ERA)
                && now.get(Calendar.YEAR) == target.get(Calendar.YEAR)
                && now.get(Calendar.DAY_OF_YEAR) == target.get(Calendar.DAY_OF_YEAR);
        Locale locale = english ? Locale.ENGLISH : Locale.getDefault();
        if (sameDay) {
            return I18n.t(context, "Следующее обновление: сегодня в ", "Next update: today at ")
                    + new SimpleDateFormat("HH:mm", locale).format(new Date(next));
        }
        String pattern = english ? "MMMM d 'at' HH:mm" : "d MMMM 'в' HH:mm";
        return I18n.t(context, "Следующее обновление: ", "Next update: ")
                + new SimpleDateFormat(pattern, locale).format(new Date(next));
    }

    public static String technicalSummary(Context context) {
        SharedPreferences prefs = prefs(context);
        boolean english = LanguageManager.isEnglish(context);
        String never = I18n.t(context, "нет данных", "no data");
        long attempt = prefs.getLong(KEY_LAST_ATTEMPT_AT, 0L);
        long success = prefs.getLong(KEY_LAST_SUCCESS_AT, 0L);
        long next = prefs.getLong(KEY_NEXT_AT_MILLIS, 0L);
        String result = prefs.getString(KEY_LAST_RESULT, never);
        String error = prefs.getString(KEY_LAST_ERROR, "");
        String reason = prefs.getString(KEY_LAST_REASON, "");
        Locale locale = english ? Locale.ENGLISH : Locale.getDefault();
        SimpleDateFormat format = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", locale);
        StringBuilder out = new StringBuilder();
        out.append(I18n.t(context, "Автообновление: ", "Automatic updates: "))
                .append(isEnabled(context) ? I18n.t(context, "включено", "on") : I18n.t(context, "выключено", "off"));
        out.append('\n').append(I18n.t(context, "Отправная точка: ", "Start time: "))
                .append(startTimeDisplay(context));
        out.append('\n').append(I18n.t(context, "Интервал: ", "Interval: "))
                .append(intervalText(getIntervalSeconds(context)));
        out.append('\n').append(I18n.t(context, "Следующий запуск: ", "Next run: "))
                .append(next > 0 ? format.format(new Date(next)) : never);
        out.append('\n').append(I18n.t(context, "Последняя попытка: ", "Last attempt: "))
                .append(attempt > 0 ? format.format(new Date(attempt)) : never);
        out.append('\n').append(I18n.t(context, "Последний успешный запуск: ", "Last successful run: "))
                .append(success > 0 ? format.format(new Date(success)) : never);
        out.append('\n').append(I18n.t(context, "Результат: ", "Result: ")).append(result == null ? never : result);
        if (reason != null && !reason.isEmpty()) {
            out.append('\n').append(I18n.t(context, "Источник запуска: ", "Trigger: ")).append(reason);
        }
        if (error != null && !error.isEmpty()) {
            out.append('\n').append(I18n.t(context, "Последняя ошибка: ", "Last error: ")).append(error);
        }
        return out.toString();
    }

    public static String intervalText(int seconds) {
        if (seconds < 60) return seconds + " сек.";
        if (seconds % 3600 == 0) return seconds / 3600 + " ч.";
        if (seconds % 60 == 0) return seconds / 60 + " мин.";
        return seconds + " сек.";
    }

    private static void resetScheduleFromSettings(Context context, String reason) {
        Context app = context.getApplicationContext();
        if (!isEnabled(app)) {
            cancel(app);
            return;
        }
        migrateStartTimeIfNeeded(app);
        int hour = getStartHour(app);
        int minute = getStartMinute(app);
        long anchor = localAnchorForToday(hour, minute);
        prefs(app).edit()
                .putLong(KEY_ANCHOR_AT_MILLIS, anchor)
                .putInt(KEY_SCHEDULE_MODEL_VERSION, SCHEDULE_MODEL_VERSION)
                .apply();
        WorkManager.getInstance(app).cancelUniqueWork(WORK_AUTO_UPDATE);
        scheduleNextSlot(app, reason);
    }

    private static void scheduleNextSlot(Context context, String reason) {
        Context app = context.getApplicationContext();
        if (!isEnabled(app)) {
            cancel(app);
            return;
        }
        migrateStartTimeIfNeeded(app);
        long anchor = prefs(app).getLong(KEY_ANCHOR_AT_MILLIS, 0L);
        if (anchor <= 0L) {
            anchor = localAnchorForToday(getStartHour(app), getStartMinute(app));
            prefs(app).edit().putLong(KEY_ANCHOR_AT_MILLIS, anchor).apply();
        }
        long intervalMillis = getIntervalSeconds(app) * 1000L;
        long triggerAt = nextSlotAfter(anchor, intervalMillis, System.currentTimeMillis());
        prefs(app).edit()
                .putLong(KEY_NEXT_AT_MILLIS, triggerAt)
                .putInt(KEY_SCHEDULE_MODEL_VERSION, SCHEDULE_MODEL_VERSION)
                .apply();
        scheduleAlarmAt(app, triggerAt);
        ensureWatchdog(app);
        AppLogger.log(app, "auto-scheduler", "scheduled",
                reason + " | anchor=" + anchor + " | at=" + triggerAt);
    }

    private static long nextSlotAfter(long anchor, long intervalMillis, long now) {
        if (intervalMillis <= 0L) intervalMillis = DEFAULT_INTERVAL_SECONDS * 1000L;
        if (now < anchor) return anchor;
        long delta = now - anchor;
        long steps = delta / intervalMillis + 1L;
        if (steps > (Long.MAX_VALUE - anchor) / intervalMillis) {
            return now + intervalMillis;
        }
        return anchor + steps * intervalMillis;
    }

    private static long localAnchorForToday(int hour, int minute) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, clampHour(hour));
        calendar.set(Calendar.MINUTE, clampMinute(minute));
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTimeInMillis();
    }

    private static void migrateStartTimeIfNeeded(Context context) {
        SharedPreferences prefs = prefs(context);
        if (prefs.contains(KEY_START_HOUR) && prefs.contains(KEY_START_MINUTE)) return;
        int hour = DEFAULT_START_HOUR;
        int minute = DEFAULT_START_MINUTE;
        long oldNext = prefs.getLong(KEY_NEXT_AT_MILLIS, 0L);
        if (oldNext > 0L) {
            Calendar calendar = Calendar.getInstance();
            calendar.setTimeInMillis(oldNext);
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minute = calendar.get(Calendar.MINUTE);
        }
        prefs.edit()
                .putInt(KEY_START_HOUR, hour)
                .putInt(KEY_START_MINUTE, minute)
                .apply();
    }

    private static int clampHour(int hour) {
        return Math.max(0, Math.min(23, hour));
    }

    private static int clampMinute(int minute) {
        return Math.max(0, Math.min(59, minute));
    }

    private static void ensureWatchdog(Context context) {
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                ScheduledUpdateWatchdogWorker.class, 15, TimeUnit.MINUTES)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniquePeriodicWork(WORK_WATCHDOG,
                        ExistingPeriodicWorkPolicy.KEEP, request);
    }

    private static void scheduleAlarmAt(Context context, long triggerAt) {
        Context app = context.getApplicationContext();
        AlarmManager manager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) {
            AppLogger.log(app, "auto-scheduler", "error", "AlarmManager unavailable");
            return;
        }
        PendingIntent pi = pendingIntent(app);
        manager.cancel(pi);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (manager.canScheduleExactAlarms()) {
                    manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                } else {
                    manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
                }
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                manager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } catch (SecurityException e) {
            manager.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            AppLogger.log(app, "auto-scheduler", "fallback", e.getMessage());
        }
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, ScheduledUpdateReceiver.class);
        intent.setAction(ArtWidgetProvider.ACTION_SCHEDULED_UPDATE);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, 12001, intent, flags);
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }
}
