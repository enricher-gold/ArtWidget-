package com.sergei.artwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class CatalogUpdateScheduler {
    public static final String ACTION_UPDATE_GENERAL = "com.sergei.artwidget.CATALOG_UPDATE_GENERAL";
    public static final String ACTION_UPDATE_ADULT = "com.sergei.artwidget.CATALOG_UPDATE_ADULT";
    public static final String EXTRA_RETRY = "retry";
    private static final long[] RETRY_DELAYS = new long[]{60_000L, 300_000L, 1_200_000L};

    private CatalogUpdateScheduler() { }

    public static void requestImmediate(Context context) {
        Context app = context.getApplicationContext();
        ArtRepository repo = new ArtRepository(app);
        repo.setCatalogPartStatus(false, "запланировано");
        repo.setCatalogPartStatus(true, "запланировано");
        schedule(app, false, 0L, 0);
        schedule(app, true, 15_000L, 0);
    }

    public static void scheduleRetry(Context context, boolean adult, int retry) {
        if (retry >= RETRY_DELAYS.length) return;
        schedule(context.getApplicationContext(), adult, RETRY_DELAYS[retry], retry + 1);
    }

    public static void resumeAfterBoot(Context context) {
        ArtRepository repo = new ArtRepository(context);
        String status = repo.getCatalogUpdateStatus();
        if (status.contains("ожида") || status.contains("повтор") || status.contains("запущено")) {
            requestImmediate(context);
        }
    }

    private static void schedule(Context context, boolean adult, long delayMs, int retry) {
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (manager == null) return;
        long at = System.currentTimeMillis() + Math.max(0L, delayMs);
        PendingIntent pendingIntent = pendingIntent(context, adult, retry);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pendingIntent);
        } else {
            manager.set(AlarmManager.RTC_WAKEUP, at, pendingIntent);
        }
    }

    private static PendingIntent pendingIntent(Context context, boolean adult, int retry) {
        Intent intent = new Intent(context, CatalogUpdateReceiver.class);
        intent.setAction(adult ? ACTION_UPDATE_ADULT : ACTION_UPDATE_GENERAL);
        intent.putExtra(EXTRA_RETRY, retry);
        int requestCode = adult ? 23002 : 23001;
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }
}
