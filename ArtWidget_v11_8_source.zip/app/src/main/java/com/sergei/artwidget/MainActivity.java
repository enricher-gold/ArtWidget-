package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int SPACE = 8;
    private static final int OUTER = 16;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private ImageView previewImage;
    private TextView captionView;
    private TextView descriptionView;
    private TextView statusView;
    private Button nextButton;
    private Button previousButton;
    private Button forwardButton;
    private ImageButton likeButton;
    private ImageButton dislikeButton;
    private ArtEntry currentEntry;
    private boolean busy;

    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;
    private int dangerColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        setContentView(createLayout());
        updateUi();
        ArtWidgetProvider.updateAllWidgets(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUi();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(OUTER), dp(OUTER), dp(OUTER), dp(24));
        root.setBackgroundColor(bgColor);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(OUTER), top + dp(OUTER), dp(OUTER), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout appBar = horizontalRow();
        TextView title = textView(22, true, textColor);
        title.setText("Art Widget");
        title.setGravity(Gravity.CENTER_VERTICAL);
        appBar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));

        ImageButton settingsButton = new ImageButton(this);
        settingsButton.setImageResource(R.drawable.ic_settings);
        settingsButton.setImageTintList(ColorStateList.valueOf(textColor));
        settingsButton.setScaleType(ImageView.ScaleType.CENTER);
        settingsButton.setPadding(dp(12), dp(12), dp(12), dp(12));
        settingsButton.setBackgroundColor(Color.TRANSPARENT);
        settingsButton.setContentDescription("Настройки");
        settingsButton.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        appBar.addView(settingsButton, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout.LayoutParams appBarParams = matchWrap();
        appBarParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(appBar, appBarParams);

        previewImage = new ImageView(this);
        previewImage.setAdjustViewBounds(true);
        previewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewImage.setBackgroundColor(Color.TRANSPARENT);
        previewImage.setContentDescription("Текущая картина");
        previewImage.setOnClickListener(v -> openFullscreen());
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(320));
        imageParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(previewImage, imageParams);

        LinearLayout reactionRow = horizontalRow();
        reactionRow.setGravity(Gravity.CENTER_VERTICAL);
        dislikeButton = makeIconButton(R.drawable.ic_heart_off, "Не нравится");
        likeButton = makeIconButton(R.drawable.ic_heart_outline, "Добавить в избранное");
        reactionRow.addView(dislikeButton, new LinearLayout.LayoutParams(dp(52), dp(48)));
        reactionRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        reactionRow.addView(likeButton, new LinearLayout.LayoutParams(dp(52), dp(48)));
        LinearLayout.LayoutParams reactionParams = matchWrap();
        reactionParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(reactionRow, reactionParams);
        dislikeButton.setOnClickListener(v -> runOperation(Operation.DISLIKE));
        likeButton.setOnClickListener(v -> toggleFavorite());

        captionView = textView(20, true, linkColor);
        captionView.setGravity(Gravity.CENTER_HORIZONTAL);
        captionView.setPadding(dp(4), 0, dp(4), dp(4));
        captionView.setOnClickListener(v -> openArticle());
        root.addView(captionView, matchWrap());

        TextView sourceView = textView(13, false, subTextColor);
        sourceView.setGravity(Gravity.CENTER_HORIZONTAL);
        sourceView.setText("Источник: русская Википедия / Wikimedia Commons");
        LinearLayout.LayoutParams sourceParams = matchWrap();
        sourceParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(sourceView, sourceParams);

        // Навигация закреплена до описания, поэтому её положение не зависит
        // от длины текста статьи.
        LinearLayout navigationCard = sectionCard();
        navigationCard.addView(sectionTitle("Навигация"), matchWrap());
        LinearLayout navRow = horizontalRow();
        previousButton = makeButton("Назад", false);
        nextButton = makeButton("Новая", true);
        forwardButton = makeButton("Вперёд", false);
        navRow.addView(previousButton, weightedButtonParams());
        navRow.addView(nextButton, weightedButtonParamsWithMargins());
        navRow.addView(forwardButton, weightedButtonParams());
        LinearLayout.LayoutParams navParams = matchWrap();
        navParams.setMargins(0, dp(SPACE), 0, 0);
        navigationCard.addView(navRow, navParams);
        root.addView(navigationCard, sectionParams());
        previousButton.setOnClickListener(v -> runOperation(Operation.PREVIOUS));
        nextButton.setOnClickListener(v -> runOperation(Operation.NEXT));
        forwardButton.setOnClickListener(v -> runOperation(Operation.FORWARD));

        statusView = textView(14, false, subTextColor);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackground(rounded(fieldColor, 13, borderColor, 1));
        statusView.setVisibility(View.GONE);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.setMargins(0, 0, 0, dp(12));
        root.addView(statusView, statusParams);

        LinearLayout aboutCard = sectionCard();
        aboutCard.addView(sectionTitle("О картине"), matchWrap());
        descriptionView = textView(15, false, textColor);
        descriptionView.setLineSpacing(0f, 1.18f);
        LinearLayout.LayoutParams descParams = matchWrap();
        descParams.setMargins(0, dp(SPACE), 0, 0);
        aboutCard.addView(descriptionView, descParams);
        root.addView(aboutCard, sectionParams());

        return scroll;
    }

    private void runOperation(Operation operation) {
        if (!UpdateCoordinator.tryBegin()) {
            showStatus("Обновление уже выполняется");
            return;
        }
        setBusy(true);
        if (operation == Operation.NEXT) {
            int mode = new ArtRepository(this).getContentMode();
            showStatus(mode == ArtRepository.CONTENT_ADULT_ONLY
                    ? "Ищу новое произведение NSFW…"
                    : "Загружаю новую картину…");
        }
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(this);
                if (operation == Operation.NEXT) repo.fetchNextArtwork();
                else if (operation == Operation.PREVIOUS) repo.goPrevious();
                else if (operation == Operation.FORWARD) repo.goForward();
                else if (operation == Operation.DISLIKE) repo.dislikeCurrentAndFetchNext();
                ArtScheduler.scheduleNext(this);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    hideStatus();
                    setBusy(false);
                    updateUi();
                });
            } catch (Exception e) {
                if (operation != Operation.NEXT) AppLogger.log(this, operation.name(), "error", e.getMessage());
                runOnUiThread(() -> {
                    showStatus(friendlyError(e));
                    setBusy(false);
                    updateUi();
                });
            } finally {
                UpdateCoordinator.finish();
            }
        });
    }

    private void toggleFavorite() {
        if (currentEntry == null) return;
        ArtRepository repo = new ArtRepository(this);
        boolean value = repo.toggleFavorite(currentEntry);
        Toast.makeText(this, value ? "Добавлено в избранное" : "Удалено из избранного", Toast.LENGTH_SHORT).show();
        updateUi();
    }

    private void updateUi() {
        ArtRepository repo = new ArtRepository(this);
        currentEntry = repo.getCurrent();
        updatePreview(currentEntry);
        if (currentEntry == null) {
            captionView.setText("Картина пока не загружена");
            descriptionView.setText("После загрузки здесь появится краткое описание произведения.");
            dislikeButton.setEnabled(false);
            likeButton.setEnabled(false);
            setReactionState(false, false);
        } else {
            captionView.setText(currentEntry.caption());
            String description = currentEntry.description == null || currentEntry.description.trim().isEmpty()
                    ? "Краткое описание отсутствует" : currentEntry.description;
            descriptionView.setText(description);
            dislikeButton.setEnabled(true);
            likeButton.setEnabled(true);
            setReactionState(repo.isFavorite(currentEntry.qid), repo.isDisliked(currentEntry.qid));
        }
        updateNavigationAvailability(repo);
    }

    private void updateNavigationAvailability(ArtRepository repo) {
        if (repo == null) repo = new ArtRepository(this);
        boolean canBack = !busy && repo.canGoPrevious();
        boolean canForward = !busy && repo.canGoForward();
        previousButton.setEnabled(canBack);
        previousButton.setAlpha(canBack ? 1f : 0.42f);
        forwardButton.setEnabled(canForward);
        forwardButton.setAlpha(canForward ? 1f : 0.42f);
        nextButton.setEnabled(!busy);
        nextButton.setAlpha(busy ? 0.55f : 1f);
    }

    private void setReactionState(boolean favorite, boolean disliked) {
        likeButton.setImageResource(favorite ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        likeButton.setColorFilter(favorite ? dangerColor : textColor);
        likeButton.setBackground(rounded(favorite ? withAlpha(dangerColor, 28) : fieldColor, 15,
                favorite ? dangerColor : borderColor, 1));
        likeButton.setContentDescription(favorite ? "Удалить из избранного" : "Добавить в избранное");

        dislikeButton.setImageResource(R.drawable.ic_heart_off);
        dislikeButton.setColorFilter(disliked ? dangerColor : textColor);
        dislikeButton.setBackground(rounded(disliked ? withAlpha(dangerColor, 28) : fieldColor, 15,
                disliked ? dangerColor : borderColor, 1));
        dislikeButton.setContentDescription(disliked ? "Дизлайк установлен" : "Не нравится");
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private void updatePreview(ArtEntry entry) {
        previewImage.setImageDrawable(null);
        if (entry == null || entry.localPath == null || entry.localPath.isEmpty()) {
            previewImage.setVisibility(View.GONE);
            return;
        }
        File file = new File(entry.localPath);
        if (!file.exists() || file.length() == 0) {
            previewImage.setVisibility(View.GONE);
            return;
        }
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        BitmapFactory.Options opts = new BitmapFactory.Options();
        int max = Math.max(bounds.outWidth, bounds.outHeight);
        opts.inSampleSize = max > 2000 ? 2 : 1;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        if (bitmap == null) {
            previewImage.setVisibility(View.GONE);
            return;
        }
        previewImage.setVisibility(View.VISIBLE);
        previewImage.setImageBitmap(bitmap);
    }

    private void openArticle() {
        if (currentEntry == null || currentEntry.sourceUrl.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentEntry.sourceUrl))); }
        catch (Exception e) { showStatus("Не удалось открыть статью"); }
    }

    private void openFullscreen() {
        if (currentEntry == null) return;
        Intent intent = new Intent(this, FullscreenActivity.class);
        intent.putExtra("qid", currentEntry.qid);
        startActivity(intent);
    }

    private void setBusy(boolean busy) {
        this.busy = busy;
        for (View v : new View[]{dislikeButton, likeButton}) {
            if (v != null) {
                v.setEnabled(!busy);
                v.setAlpha(busy ? 0.55f : 1f);
            }
        }
        updateNavigationAvailability(new ArtRepository(this));
    }

    private void showStatus(String text) {
        statusView.setText(text == null ? "" : text);
        statusView.setVisibility(View.VISIBLE);
    }

    private void hideStatus() {
        statusView.setVisibility(View.GONE);
    }

    private String friendlyError(Exception e) {
        String msg = e == null ? null : e.getMessage();
        if (msg == null || msg.trim().isEmpty()) return "Не удалось выполнить операцию";
        if (msg.contains("HTTP 429") || msg.contains("Слишком частые")) return "Слишком частые запросы. Повторите позже";
        if (msg.contains("Unable to resolve host") || msg.contains("No address associated") || msg.contains("Не удалось определить адрес")) {
            return "Нет подключения к интернету или DNS временно недоступен";
        }
        if (msg.toLowerCase().contains("timeout") || msg.contains("не ответил вовремя")) return "Сервер не ответил вовремя. Повторите позже";
        return msg.length() > 220 ? msg.substring(0, 220) + "…" : msg;
    }

    private Button makeButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15, primary ? 0xFF007AFF : borderColor, 1));
        return b;
    }

    private ImageButton makeIconButton(int iconRes, String description) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(iconRes);
        b.setColorFilter(textColor);
        b.setContentDescription(description);
        b.setPadding(dp(11), dp(9), dp(11), dp(9));
        b.setBackground(rounded(fieldColor, 15, borderColor, 1));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setImageTintList(ColorStateList.valueOf(textColor));
            b.setImageTintList(null);
        }
        return b;
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(rounded(fieldColor, 18, borderColor, 1));
        return card;
    }

    private TextView sectionTitle(String title) {
        TextView tv = textView(17, true, textColor);
        tv.setText(title);
        return tv;
    }

    private LinearLayout.LayoutParams sectionParams() {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private TextView textView(int size, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setTextSize(size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        return new LinearLayout.LayoutParams(0, dp(48), 1f);
    }

    private LinearLayout.LayoutParams weightedButtonParamsWithMargins() {
        LinearLayout.LayoutParams p = weightedButtonParams();
        p.setMargins(dp(SPACE), 0, dp(SPACE), 0);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        borderColor = dark ? 0xFF38383A : 0xFFD9D9DE;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;
        dangerColor = 0xFFFF3B30;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private enum Operation { NEXT, PREVIOUS, FORWARD, DISLIKE }
}
