package com.sergei.artwidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class CatalogUpdateReceiver extends BroadcastReceiver {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean BUSY = new AtomicBoolean(false);

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || intent.getAction() == null) return;
        boolean adult = CatalogUpdateScheduler.ACTION_UPDATE_ADULT.equals(intent.getAction());
        int retry = intent.getIntExtra(CatalogUpdateScheduler.EXTRA_RETRY, 0);
        PendingResult pendingResult = goAsync();
        Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            if (!BUSY.compareAndSet(false, true)) {
                CatalogUpdateScheduler.scheduleRetry(app, adult, retry);
                pendingResult.finish();
                return;
            }
            try {
                ArtRepository repo = new ArtRepository(app);
                if (!repo.isDownloadNetworkAllowed()) {
                    String status = repo.isWifiOnly()
                            ? "Ожидание Wi-Fi для обновления каталога"
                            : "Ожидание подключения к интернету";
                    repo.setCatalogPartStatus(adult, status);
                    AppLogger.log(app, adult ? "adult-catalog" : "catalog", "waiting-network", status);
                    CatalogUpdateScheduler.scheduleRetry(app, adult, retry);
                    return;
                }
                String result = repo.updateCatalogPart(adult);
                repo.setCatalogPartStatus(adult, result.replace("Общий каталог: ", "").replace("NSFW-каталог: ", ""));
            } catch (Exception e) {
                ArtRepository repo = new ArtRepository(app);
                String message = "ошибка, повтор запланирован";
                repo.setCatalogPartStatus(adult, message);
                AppLogger.log(app, adult ? "adult-catalog" : "catalog", "background-error", e.getMessage());
                CatalogUpdateScheduler.scheduleRetry(app, adult, retry);
            } finally {
                BUSY.set(false);
                pendingResult.finish();
            }
        });
    }
}
