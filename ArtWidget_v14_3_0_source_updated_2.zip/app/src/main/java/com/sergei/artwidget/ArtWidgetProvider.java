package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.SizeF;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";
    private static final ScheduledExecutorService RENDER_EXECUTOR =
            Executors.newSingleThreadScheduledExecutor();
    private static final long[] FINAL_SIZE_RECHECK_DELAYS_MS = {350L, 1200L, 2600L};

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidgets(app, manager, ids));
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidget(app, manager, appWidgetId));
        // Лаунчеры часто присылают промежуточные размеры во время resize, а
        // окончательные options публикуют уже после нажатия «Применить».
        for (long delay : FINAL_SIZE_RECHECK_DELAYS_MS) {
            RENDER_EXECUTOR.schedule(
                    () -> updateWidget(app, AppWidgetManager.getInstance(app), appWidgetId),
                    delay,
                    TimeUnit.MILLISECONDS);
        }
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    public static void performScheduledUpdate(Context context) {
        ArtScheduler.enqueueAutomaticUpdate(context, "provider");
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> renderAllWidgetsNow(app));
    }

    static void renderAllWidgetsNow(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bundle options = manager.getAppWidgetOptions(id);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ArrayList<SizeF> sizes = responsiveSizes(options);
            if (sizes.size() == 1) {
                SizeF size = sizes.get(0);
                int width = Math.max(120, Math.round(size.getWidth()));
                int height = Math.max(120, Math.round(size.getHeight()));
                manager.updateAppWidget(id, createViews(context, entry, width, height, id));
                AppLogger.log(context, "widget-size", "exact-render",
                        "id=" + id + ", " + width + "x" + height + " dp");
                return;
            }
            if (sizes.size() >= 2) {
                try {
                    Map<SizeF, RemoteViews> variants = new LinkedHashMap<>();
                    for (SizeF size : sizes) {
                        int width = Math.max(120, Math.round(size.getWidth()));
                        int height = Math.max(120, Math.round(size.getHeight()));
                        variants.put(size, createViews(context, entry, width, height, id));
                    }
                    manager.updateAppWidget(id, new RemoteViews(variants));
                    AppLogger.log(context, "widget-size", "responsive-render",
                            "id=" + id + ", variants=" + sizeList(sizes));
                    return;
                } catch (Throwable error) {
                    AppLogger.log(context, "widget-size", "responsive-fallback",
                            error.getMessage());
                }
            }
        }

        int[] size = resolveWidgetSize(context, options);
        manager.updateAppWidget(id, createViews(context, entry, size[0], size[1], id));
        AppLogger.log(context, "widget-size", "render",
                "id=" + id + ", " + size[0] + "x" + size[1] + " dp");
    }

    private static RemoteViews createViews(Context context, ArtEntry entry,
                                           int widthDp, int heightDp, int id) {
        Bitmap bitmap = ArtRenderer.render(context, entry, widthDp, heightDp);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);
        PendingIntent openApp = openAppIntent(context, 16001 + id);
        views.setOnClickPendingIntent(R.id.widget_open_tap_zone, openApp);
        return views;
    }

    /**
     * Android 12+ сам выбирает из карты вариант, соответствующий фактическому
     * размеру виджета. Это предотвращает уменьшение после завершения resize и
     * корректно переживает смену ориентации планшета.
     */
    private static ArrayList<SizeF> responsiveSizes(Bundle options) {
        ArrayList<SizeF> result = new ArrayList<>();
        if (options == null || Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return result;
        ArrayList<SizeF> source = options.getParcelableArrayList(AppWidgetManager.OPTION_APPWIDGET_SIZES);
        if (source == null) return result;
        Set<String> unique = new LinkedHashSet<>();
        for (SizeF candidate : source) {
            if (candidate == null || candidate.getWidth() <= 0f || candidate.getHeight() <= 0f) continue;
            int w = Math.max(120, Math.round(candidate.getWidth()));
            int h = Math.max(120, Math.round(candidate.getHeight()));
            String key = w + "x" + h;
            if (!unique.add(key)) continue;
            result.add(new SizeF(w, h));
            if (result.size() >= 6) break;
        }
        return result;
    }

    private static int[] resolveWidgetSize(Context context, Bundle options) {
        if (options == null) options = Bundle.EMPTY;
        int minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        int maxW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, minW);
        int minH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 250);
        int maxH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, minH);
        boolean landscape = context.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;

        // До Android 12 min/max описывают размеры виджета в двух ориентациях.
        int targetW = landscape ? Math.max(minW, maxW) : Math.min(minW, maxW);
        int targetH = landscape ? Math.min(minH, maxH) : Math.max(minH, maxH);
        return new int[]{Math.max(120, targetW), Math.max(120, targetH)};
    }

    private static String sizeList(ArrayList<SizeF> sizes) {
        StringBuilder out = new StringBuilder();
        for (SizeF size : sizes) {
            if (out.length() > 0) out.append(',');
            out.append(Math.round(size.getWidth())).append('x').append(Math.round(size.getHeight()));
        }
        return out.toString();
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
