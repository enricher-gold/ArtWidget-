package com.sergei.artwidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;

import java.io.File;

/** Формирует bitmap только с картиной. Подпись выводится отдельным TextView. */
public final class ArtRenderer {
    private static final int MAX_RENDER_LONG_SIDE_PX = 1800;
    private static final int MIN_PLACEHOLDER_SIDE_PX = 160;

    private ArtRenderer() { }

    /**
     * Резервный вызов для экранов, где размер виджета неизвестен.
     */
    public static Bitmap render(Context context, ArtEntry entry) {
        return render(context, entry, 420, 420);
    }

    /**
     * Создаёт bitmap ровно по границам картины, вписанной в доступную область.
     * Внешний прозрачный холст не добавляется. При wrap_content ImageView
     * использует эти размеры как фактические размеры картины, а подпись в
     * соседнем TextView остаётся приклеенной к её нижней границе.
     */
    public static Bitmap render(Context context, ArtEntry entry,
                                int maxWidthDp, int maxHeightDp) {
        int safeWidthDp = Math.max(1, maxWidthDp);
        int safeHeightDp = Math.max(1, maxHeightDp);
        int densityDpi = context.getResources().getDisplayMetrics().densityDpi;
        float density = context.getResources().getDisplayMetrics().density;
        int maxWidthPx = Math.max(1, Math.round(safeWidthDp * density));
        int maxHeightPx = Math.max(1, Math.round(safeHeightDp * density));

        float cap = Math.min(1f, MAX_RENDER_LONG_SIDE_PX
                / (float) Math.max(maxWidthPx, maxHeightPx));
        maxWidthPx = Math.max(1, Math.round(maxWidthPx * cap));
        maxHeightPx = Math.max(1, Math.round(maxHeightPx * cap));

        if (entry == null || !fileExists(entry.localPath)) {
            Bitmap placeholder = renderStatus(I18n.t(context,
                    "Откройте приложение\nи загрузите картину",
                    "Open the app\nand load an artwork"), maxWidthPx, maxHeightPx);
            placeholder.setDensity(densityDpi);
            return placeholder;
        }

        Bitmap original = decodeSampled(entry.localPath,
                Math.max(maxWidthPx, maxHeightPx));
        if (original == null || original.getWidth() <= 0 || original.getHeight() <= 0) {
            Bitmap placeholder = renderStatus(I18n.t(context,
                    "Изображение недоступно",
                    "Image unavailable"), maxWidthPx, maxHeightPx);
            placeholder.setDensity(densityDpi);
            return placeholder;
        }

        int sourceW = original.getWidth();
        int sourceH = original.getHeight();
        float imageScale = Math.min(maxWidthPx / (float) sourceW,
                maxHeightPx / (float) sourceH);
        int artworkW = Math.max(1, Math.round(sourceW * imageScale));
        int artworkH = Math.max(1, Math.round(sourceH * imageScale));

        if (artworkW == sourceW && artworkH == sourceH) {
            original.setDensity(densityDpi);
            return original;
        }

        Bitmap result = Bitmap.createBitmap(artworkW, artworkH, Bitmap.Config.ARGB_8888);
        result.setDensity(densityDpi);
        Canvas canvas = new Canvas(result);
        Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG
                | Paint.FILTER_BITMAP_FLAG
                | Paint.DITHER_FLAG);
        canvas.drawBitmap(original,
                new Rect(0, 0, sourceW, sourceH),
                new RectF(0f, 0f, artworkW, artworkH),
                imagePaint);
        original.recycle();
        return result;
    }

    public static Bitmap renderStatus(String text) {
        return renderStatus(text, 560, 520);
    }

    private static Bitmap renderStatus(String text, int maxWidthPx, int maxHeightPx) {
        int width = Math.max(MIN_PLACEHOLDER_SIDE_PX, maxWidthPx);
        int height = Math.max(MIN_PLACEHOLDER_SIDE_PX, maxHeightPx);
        Bitmap result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);
        drawPlaceholder(canvas, width, height, text);
        return result;
    }

    private static Bitmap decodeSampled(String path, int targetLongSide) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;

        int sample = 1;
        int longSide = Math.max(bounds.outWidth, bounds.outHeight);
        while (longSide / (sample * 2) >= targetLongSide) {
            sample *= 2;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        options.inSampleSize = Math.max(1, sample);
        return BitmapFactory.decodeFile(path, options);
    }

    private static TextPaint textPaint(float size, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setColor(Color.WHITE);
        p.setTextSize(size);
        p.setFakeBoldText(bold);
        p.setShadowLayer(Math.max(2f, size / 5f), 1f, 1f, Color.BLACK);
        return p;
    }

    private static void drawPlaceholder(Canvas canvas, int w, int h, String text) {
        float textSize = clamp(Math.min(w, h) / 22f, 22f, 34f);
        TextPaint p = textPaint(textSize, true);
        String[] lines = text == null ? new String[]{"Art Widget"} : text.split("\n");
        Paint.FontMetrics fm = p.getFontMetrics();
        float lineHeight = (fm.descent - fm.ascent) * 1.22f;
        float total = lineHeight * lines.length;
        float baseline = (h - total) / 2f - fm.ascent;
        for (String line : lines) {
            drawCentered(canvas, w, ellipsize(line, p, w - 16f), baseline, p);
            baseline += lineHeight;
        }
    }

    private static void drawCentered(Canvas canvas, int w, String text,
                                     float baseline, Paint paint) {
        float x = (w - paint.measureText(text)) / 2f;
        canvas.drawText(text, x, baseline, paint);
    }

    private static String ellipsize(String text, Paint paint, float maxWidth) {
        String value = text == null ? "" : text.replace('\n', ' ').replace('\r', ' ').trim();
        if (value.isEmpty()) return " ";
        if (paint.measureText(value) <= maxWidth) return value;
        String suffix = "…";
        int low = 0;
        int high = value.length();
        while (low < high) {
            int mid = (low + high + 1) / 2;
            if (paint.measureText(value.substring(0, mid) + suffix) <= maxWidth) low = mid;
            else high = mid - 1;
        }
        return low <= 0 ? suffix : value.substring(0, low).trim() + suffix;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static boolean fileExists(String path) {
        if (path == null || path.trim().isEmpty()) return false;
        File f = new File(path);
        return f.exists() && f.length() > 0;
    }
}
