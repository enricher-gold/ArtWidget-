package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";
    private static final int DEFAULT_WIDGET_WIDTH_DP = 250;
    private static final int DEFAULT_WIDGET_HEIGHT_DP = 250;
    private static final int CAPTION_BLOCK_HEIGHT_DP = 24;
    private static final ExecutorService RENDER_EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidgets(app, manager, ids));
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidget(app, manager, appWidgetId));
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    public static void performScheduledUpdate(Context context) {
        ArtScheduler.enqueueAutomaticUpdate(context, "provider");
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> renderAllWidgetsNow(app));
    }

    static void renderAllWidgetsNow(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();

        String caption = entry == null
                ? ""
                : entry.widgetCaption(LanguageManager.getLanguage(context));
        caption = caption == null
                ? ""
                : caption.replace('\n', ' ').replace('\r', ' ').trim();

        int[] widgetSize = resolveWidgetSizeDp(context, manager, id);
        int imageHeightDp = Math.max(1, widgetSize[1]
                - (caption.isEmpty() ? 0 : CAPTION_BLOCK_HEIGHT_DP));
        Bitmap bitmap = ArtRenderer.render(context, entry, widgetSize[0], imageHeightDp);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);

        if (caption.isEmpty()) {
            views.setViewVisibility(R.id.widget_caption, View.GONE);
            views.setTextViewText(R.id.widget_caption, "");
        } else {
            views.setViewVisibility(R.id.widget_caption, View.VISIBLE);
            views.setTextViewText(R.id.widget_caption, caption);
            // SP учитывает системный fontScale, но не зависит от размера bitmap,
            // виджета или ориентации планшета.
            views.setTextViewTextSize(R.id.widget_caption,
                    TypedValue.COMPLEX_UNIT_SP, 14f);
        }

        views.setOnClickPendingIntent(R.id.widget_open_tap_zone,
                openAppIntent(context, 16001 + id));
        manager.updateAppWidget(id, views);
        AppLogger.log(context, "widget-render", "compact-caption-attached",
                "id=" + id + ", " + widgetSize[0] + "x" + widgetSize[1] + " dp");
    }

    /**
     * До Android 12 launcher сообщает диапазон размеров для двух ориентаций.
     * В портретной ориентации берём узкую ширину и большую высоту, в альбомной
     * большую ширину и меньшую высоту. Это даёт размер текущего экземпляра без
     * создания прозрачного холста и сохраняет одинаковое поведение после resize.
     */
    private static int[] resolveWidgetSizeDp(Context context,
                                             AppWidgetManager manager,
                                             int appWidgetId) {
        Bundle options = manager.getAppWidgetOptions(appWidgetId);
        int minWidth = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH),
                DEFAULT_WIDGET_WIDTH_DP);
        int minHeight = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT),
                DEFAULT_WIDGET_HEIGHT_DP);
        int maxWidth = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH),
                minWidth);
        int maxHeight = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT),
                minHeight);

        boolean landscape = context.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        int width = landscape ? Math.max(minWidth, maxWidth) : Math.min(minWidth, maxWidth);
        int height = landscape ? Math.min(minHeight, maxHeight) : Math.max(minHeight, maxHeight);

        width = Math.max(1, width);
        height = Math.max(1, height);
        return new int[]{width, height};
    }

    private static int positive(int value, int fallback) {
        return value > 0 ? value : fallback;
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
