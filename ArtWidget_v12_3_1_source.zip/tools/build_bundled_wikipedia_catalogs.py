#!/usr/bin/env python3
"""Builds two production catalogs from exact Wikidata painting items.

The script does not search Wikimedia Commons by a similar title. Every image comes
from P18 of the same Wikidata painting item, and every description comes from the
exact Russian Wikipedia article when available, otherwise the English article.

Intended use: run in CI before Gradle packages the Android assets.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import json
import os
import re
import sys
import time
import urllib.parse
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import requests

VERSION = "2026.06.18-v12.3.1"
SPARQL_ENDPOINT = "https://query.wikidata.org/sparql"
WIKI_API = {
    "ru": "https://ru.wikipedia.org/w/api.php",
    "en": "https://en.wikipedia.org/w/api.php",
}
USER_AGENT = "ArtWidgetCatalogBuilder/12.3.1 (contact: enricherusa@gmail.com)"

PAINTING_QID = "Q3305213"
SAFE_GENRES = ("Q191163", "Q170571", "Q12303833")  # landscape, still life, floral painting

NSFW_MARKERS = (
    "nude", "nudity", "naked", "reclining nude", "standing nude", "seated nude",
    "female nude", "male nude", "bather", "bathers", "bathing", "odalisque",
    "erotic", "venus", "aphrodite", "danae", "danaë", "leda", "bathsheba",
    "susanna and the elders", "three graces", "nymph", "nymphs", "bacchante",
    "maenad", "toilette", "eve", "adam and eve",
    "обнаж", "нагота", "ню", "купальщ", "купающ", "одалиск", "эрот",
    "венера", "афродит", "даная", "леда", "вирсав", "сусанна", "три грации",
    "нимф", "вакхан", "ева", "адам и ева",
)
STRONG_EXPLICIT_MARKERS = (
    "nude", "nudity", "naked", "female nude", "male nude", "reclining nude",
    "standing nude", "seated nude", "odalisque", "erotic",
    "обнаж", "нагота", "ню", "одалиск", "эрот",
)
MINOR_MARKERS = (
    "child", "children", "girl", "boy", "baby", "infant", "adolescent", "teen",
    "teenager", "youth", "young girl", "young boy", "daughter", "son", "putti",
    "putto", "cherub", "cherubs", "minor",
    "ребен", "ребён", "дети", "девоч", "мальчик", "младен", "подрост", "юнош",
    "дочь", "сын", "путти", "херувим",
)
NON_PAINTING_MARKERS = (
    "sculpture", "statue", "drawing", "sketch", "engraving", "etching", "print",
    "photograph", "photo ", "fresco", "mural", "mosaic", "watercolor", "watercolour",
    "pastel", "illustration", "poster", "relief",
    "скульптур", "стату", "рисунок", "эскиз", "гравюр", "офорт", "литограф",
    "фотограф", "фреск", "мозаик", "акварел", "пастел", "иллюстрац", "плакат",
)
SAFE_BLOCK_MARKERS = NSFW_MARKERS + MINOR_MARKERS

RASTER_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")


@dataclass
class Candidate:
    qid: str
    image_url: str
    article_ru: str = ""
    article_en: str = ""
    label_ru: str = ""
    label_en: str = ""
    creators_ru: set[str] = field(default_factory=set)
    creators_en: set[str] = field(default_factory=set)
    evidence: set[str] = field(default_factory=set)

    def merge_row(self, row: dict[str, str], reason: str) -> None:
        self.article_ru = self.article_ru or row.get("articleRu", "")
        self.article_en = self.article_en or row.get("articleEn", "")
        self.label_ru = self.label_ru or row.get("labelRu", "")
        self.label_en = self.label_en or row.get("labelEn", "")
        if row.get("creatorRu"):
            self.creators_ru.add(row["creatorRu"].strip())
        if row.get("creatorEn"):
            self.creators_en.add(row["creatorEn"].strip())
        self.evidence.add(reason)


class Client:
    def __init__(self, cache_dir: Path):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": USER_AGENT})
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def _request_json(self, method: str, url: str, *, cache_key: str | None = None,
                      params: dict[str, Any] | None = None,
                      data: dict[str, Any] | None = None,
                      attempts: int = 6) -> dict[str, Any]:
        cache_path = self.cache_dir / f"{cache_key}.json" if cache_key else None
        if cache_path and cache_path.exists():
            return json.loads(cache_path.read_text(encoding="utf-8"))
        last: Exception | None = None
        for attempt in range(attempts):
            try:
                response = self.session.request(method, url, params=params, data=data, timeout=(30, 180))
                if response.status_code in (429, 502, 503, 504):
                    raise RuntimeError(f"HTTP {response.status_code}")
                response.raise_for_status()
                payload = response.json()
                if cache_path:
                    cache_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
                return payload
            except Exception as exc:  # retries are intentional for Wikimedia public endpoints
                last = exc
                if attempt + 1 == attempts:
                    break
                time.sleep(min(60, 3 * (2 ** attempt)))
        raise RuntimeError(f"Request failed: {url}: {last}")

    def sparql(self, query: str, cache_key: str) -> list[dict[str, str]]:
        payload = self._request_json(
            "POST", SPARQL_ENDPOINT, cache_key=cache_key,
            data={"query": query, "format": "json"},
        )
        rows: list[dict[str, str]] = []
        for binding in payload.get("results", {}).get("bindings", []):
            row = {key: value.get("value", "") for key, value in binding.items()}
            rows.append(row)
        return rows

    def extracts(self, language: str, titles: list[str], cache_key: str) -> dict[str, dict[str, str]]:
        if not titles:
            return {}
        payload = self._request_json(
            "GET", WIKI_API[language], cache_key=cache_key,
            params={
                "action": "query",
                "format": "json",
                "formatversion": "2",
                "prop": "extracts",
                "exintro": "1",
                "explaintext": "1",
                "redirects": "1",
                "titles": "|".join(titles),
            },
        )
        result: dict[str, dict[str, str]] = {}
        query = payload.get("query", {})
        normalized: dict[str, str] = {}
        for item in query.get("normalized", []) or []:
            normalized[item.get("from", "")] = item.get("to", "")
        redirects: dict[str, str] = {}
        for item in query.get("redirects", []) or []:
            redirects[item.get("from", "")] = item.get("to", "")
        page_by_title = {p.get("title", ""): p for p in query.get("pages", []) or []}
        for requested in titles:
            canonical = normalized.get(requested, requested)
            canonical = redirects.get(canonical, canonical)
            page = page_by_title.get(canonical, {})
            extract = clean_text(page.get("extract", ""))
            result[requested] = {"title": page.get("title", canonical), "extract": extract}
        return result


def clean_text(value: Any) -> str:
    text = html.unescape(str(value or ""))
    text = re.sub(r"\s+", " ", text).strip()
    return text


def binding_fields() -> str:
    return """
      OPTIONAL { ?articleRu schema:about ?item; schema:isPartOf <https://ru.wikipedia.org/>. }
      OPTIONAL { ?articleEn schema:about ?item; schema:isPartOf <https://en.wikipedia.org/>. }
      FILTER(BOUND(?articleRu) || BOUND(?articleEn))
      OPTIONAL { ?item rdfs:label ?labelRu. FILTER(LANG(?labelRu) = "ru") }
      OPTIONAL { ?item rdfs:label ?labelEn. FILTER(LANG(?labelEn) = "en") }
      OPTIONAL {
        ?item wdt:P170 ?creator.
        OPTIONAL { ?creator rdfs:label ?creatorRu. FILTER(LANG(?creatorRu) = "ru") }
        OPTIONAL { ?creator rdfs:label ?creatorEn. FILTER(LANG(?creatorEn) = "en") }
      }
    """


def safe_query(limit: int) -> str:
    genres = " ".join(f"wd:{qid}" for qid in SAFE_GENRES)
    return f"""
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX schema: <http://schema.org/>
SELECT ?item ?image ?articleRu ?articleEn ?labelRu ?labelEn ?creatorRu ?creatorEn WHERE {{
  ?item wdt:P31 wd:{PAINTING_QID}; wdt:P18 ?image; wdt:P136 ?genre.
  VALUES ?genre {{ {genres} }}
  {binding_fields()}
}}
LIMIT {limit}
"""


def nsfw_label_query(limit: int) -> str:
    # Deliberately broad discovery; strict Python validation below rejects weak/minor matches.
    regex = "nude|nudity|naked|bather|bathing|odalisque|erotic|venus|aphrodite|danae|danaë|leda|bathsheba|susanna|three graces|nymph|bacchante|maenad|toilette|adam and eve|обнаж|нагота|ню|купаль|одалиск|эрот|венер|афродит|даная|леда|вирсав|сусанн|граци|нимф|вакхан|адам и ева"
    return f"""
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX schema: <http://schema.org/>
SELECT ?item ?image ?articleRu ?articleEn ?labelRu ?labelEn ?creatorRu ?creatorEn WHERE {{
  ?item wdt:P31 wd:{PAINTING_QID}; wdt:P18 ?image.
  OPTIONAL {{ ?item rdfs:label ?labelRu. FILTER(LANG(?labelRu) = "ru") }}
  OPTIONAL {{ ?item rdfs:label ?labelEn. FILTER(LANG(?labelEn) = "en") }}
  FILTER(REGEX(LCASE(CONCAT(COALESCE(STR(?labelRu), ""), " ", COALESCE(STR(?labelEn), ""))), "{regex}"))
  OPTIONAL {{ ?articleRu schema:about ?item; schema:isPartOf <https://ru.wikipedia.org/>. }}
  OPTIONAL {{ ?articleEn schema:about ?item; schema:isPartOf <https://en.wikipedia.org/>. }}
  FILTER(BOUND(?articleRu) || BOUND(?articleEn))
  OPTIONAL {{
    ?item wdt:P170 ?creator.
    OPTIONAL {{ ?creator rdfs:label ?creatorRu. FILTER(LANG(?creatorRu) = "ru") }}
    OPTIONAL {{ ?creator rdfs:label ?creatorEn. FILTER(LANG(?creatorEn) = "en") }}
  }}
}}
LIMIT {limit}
"""


def nsfw_depicts_query(limit: int) -> str:
    regex = "nude|nudity|naked|female body|male body|bather|odalisque|venus|aphrodite|nymph|maenad|обнаж|нагота|ню|купаль|одалиск|венер|афродит|нимф|вакхан"
    return f"""
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX schema: <http://schema.org/>
SELECT ?item ?image ?articleRu ?articleEn ?labelRu ?labelEn ?creatorRu ?creatorEn ?depictedLabel WHERE {{
  ?item wdt:P31 wd:{PAINTING_QID}; wdt:P18 ?image; wdt:P180 ?depicted.
  ?depicted rdfs:label ?depictedLabel.
  FILTER(LANG(?depictedLabel) IN ("en", "ru"))
  FILTER(REGEX(LCASE(STR(?depictedLabel)), "{regex}"))
  {binding_fields()}
}}
LIMIT {limit}
"""



def nsfw_genre_query(limit: int) -> str:
    regex = "nude|nudity|erotic|odalisque|bather|обнаж|нагота|ню|эрот|одалиск|купаль"
    return f"""
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX schema: <http://schema.org/>
SELECT ?item ?image ?articleRu ?articleEn ?labelRu ?labelEn ?creatorRu ?creatorEn ?genreLabel WHERE {{
  ?item wdt:P31 wd:{PAINTING_QID}; wdt:P18 ?image; wdt:P136 ?genre.
  ?genre rdfs:label ?genreLabel.
  FILTER(LANG(?genreLabel) IN ("en", "ru"))
  FILTER(REGEX(LCASE(STR(?genreLabel)), "{regex}"))
  {binding_fields()}
}}
LIMIT {limit}
"""


def nsfw_mythology_query(limit: int) -> str:
    # Additional recall pool. Python only accepts rows whose exact article text
    # also contains a strong adult-body signal.
    return f"""
PREFIX wd: <http://www.wikidata.org/entity/>
PREFIX wdt: <http://www.wikidata.org/prop/direct/>
PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
PREFIX schema: <http://schema.org/>
SELECT ?item ?image ?articleRu ?articleEn ?labelRu ?labelEn ?creatorRu ?creatorEn WHERE {{
  ?item wdt:P31 wd:{PAINTING_QID}; wdt:P18 ?image; wdt:P136 wd:Q3374376.
  {binding_fields()}
}}
LIMIT {limit}
"""

def qid_from_uri(uri: str) -> str:
    value = uri.rstrip("/").rsplit("/", 1)[-1]
    return value if re.fullmatch(r"Q\d+", value) else ""


def normalize_image_url(url: str) -> str:
    value = clean_text(url).replace("http://", "https://", 1)
    return value


def is_raster(url: str) -> bool:
    path = urllib.parse.unquote(urllib.parse.urlsplit(url).path).lower()
    return path.endswith(RASTER_EXTENSIONS)


def article_title(url: str) -> str:
    if not url:
        return ""
    path = urllib.parse.urlsplit(url).path
    marker = "/wiki/"
    if marker not in path:
        return ""
    return urllib.parse.unquote(path.split(marker, 1)[1]).replace("_", " ")


def contains_any(text: str, markers: Iterable[str]) -> bool:
    low = text.casefold()
    return any(marker.casefold() in low for marker in markers)


def nsfw_is_strict(text: str) -> tuple[bool, str]:
    low = text.casefold()
    if contains_any(low, MINOR_MARKERS) or contains_any(low, NON_PAINTING_MARKERS):
        return False, ""
    for marker in STRONG_EXPLICIT_MARKERS:
        if marker.casefold() in low:
            return True, f"явный маркер: {marker}"
    # Mythological/bathing terms are accepted only with a second adult-body signal.
    myth = ("venus", "aphrodite", "danae", "danaë", "leda", "bathsheba", "susanna",
            "three graces", "nymph", "bacchante", "maenad", "eve", "венер", "афродит",
            "даная", "леда", "вирсав", "сусанн", "граци", "нимф", "вакхан", "ева")
    body = ("body", "breast", "bare", "undressed", "bath", "bather", "toilette",
            "тело", "груд", "обнаж", "наг", "купаль", "купающ", "туалет")
    if contains_any(low, myth) and contains_any(low, body):
        return True, "мифологический/купальный сюжет с явным телесным маркером"
    return False, ""


def safe_is_strict(text: str) -> bool:
    low = text.casefold()
    if contains_any(low, SAFE_BLOCK_MARKERS) or contains_any(low, NON_PAINTING_MARKERS):
        return False
    positive = (
        "landscape", "still life", "flower", "floral", "forest", "river", "sea", "lake",
        "mountain", "garden", "trees", "nature", "cityscape", "abstract",
        "пейзаж", "натюрморт", "цвет", "лес", "река", "море", "озеро", "гор", "сад",
        "дерев", "природ", "городской вид", "абстракт",
    )
    return contains_any(low, positive)


def aggregate(rows_with_reason: list[tuple[dict[str, str], str]]) -> dict[str, Candidate]:
    candidates: dict[str, Candidate] = {}
    for row, reason in rows_with_reason:
        qid = qid_from_uri(row.get("item", ""))
        image = normalize_image_url(row.get("image", ""))
        if not qid or not image or not is_raster(image):
            continue
        candidate = candidates.setdefault(qid, Candidate(qid=qid, image_url=image))
        candidate.merge_row(row, reason)
        if row.get("depictedLabel"):
            candidate.evidence.add(clean_text(row["depictedLabel"]))
    return candidates


def fetch_descriptions(client: Client, candidates: list[Candidate]) -> dict[tuple[str, str], dict[str, str]]:
    output: dict[tuple[str, str], dict[str, str]] = {}
    for language in ("ru", "en"):
        title_to_qids: dict[str, list[str]] = {}
        for c in candidates:
            url = c.article_ru if language == "ru" else c.article_en
            title = article_title(url)
            if title:
                title_to_qids.setdefault(title, []).append(c.qid)
        titles = sorted(title_to_qids)
        for batch_index in range(0, len(titles), 40):
            batch = titles[batch_index:batch_index + 40]
            digest = hashlib.sha256((language + "|" + "|".join(batch)).encode()).hexdigest()[:20]
            values = client.extracts(language, batch, f"extracts_{language}_{digest}")
            for requested, info in values.items():
                for qid in title_to_qids.get(requested, []):
                    output[(qid, language)] = info
    return output


def candidate_text(candidate: Candidate, extracts: dict[tuple[str, str], dict[str, str]]) -> str:
    parts = [candidate.label_ru, candidate.label_en, *candidate.evidence]
    for language in ("ru", "en"):
        info = extracts.get((candidate.qid, language), {})
        parts.extend((info.get("title", ""), info.get("extract", "")))
    return clean_text(" ".join(parts))


def creator(candidate: Candidate, language: str) -> str:
    preferred = candidate.creators_ru if language == "ru" else candidate.creators_en
    fallback = candidate.creators_en if language == "ru" else candidate.creators_ru
    names = sorted(name for name in preferred if name) or sorted(name for name in fallback if name)
    return ", ".join(names[:3]) if names else "Автор неизвестен"


def stable_id(qid: str, image_url: str) -> str:
    digest = hashlib.sha256(f"{qid}|{image_url}".encode()).hexdigest()[:16]
    return f"wikidata:{qid}:{digest}"


def build_item(candidate: Candidate, mode: str,
               extracts: dict[tuple[str, str], dict[str, str]], reason: str) -> dict[str, Any] | None:
    selected_language = ""
    info: dict[str, str] = {}
    source_url = ""
    for language, url in (("ru", candidate.article_ru), ("en", candidate.article_en)):
        current = extracts.get((candidate.qid, language), {})
        if url and clean_text(current.get("extract", "")):
            selected_language = language
            info = current
            source_url = url
            break
    if not selected_language:
        return None
    description = clean_text(info.get("extract", ""))
    title = clean_text(info.get("title", "")) or (
        candidate.label_ru if selected_language == "ru" else candidate.label_en
    ) or candidate.label_en or candidate.label_ru or "Без названия"
    return {
        "stable_id": stable_id(candidate.qid, candidate.image_url),
        "qid": candidate.qid,
        "dedupe_key": candidate.qid,
        "artist": creator(candidate, selected_language),
        "title": title,
        "year": None,
        "style": "",
        "tags": [],
        "description": description,
        "description_ru": description,
        "content_mode": mode,
        "content_confidence": "high",
        "content_reason": reason,
        "source_provider": "Wikipedia.org",
        "source_language": selected_language,
        "source_page_url": source_url,
        "image_url": candidate.image_url,
        "original_image_url": candidate.image_url,
        "image_resolver": {
            "type": "wikidata_p18_exact",
            "qid": candidate.qid,
        },
        "requires_image_resolution": False,
        "verification_status": "exact_qid_article_p18_machine_validated",
    }


def select_items(candidates: dict[str, Candidate], mode: str, target: int,
                 extracts: dict[tuple[str, str], dict[str, str]], excluded_images: set[str]) -> list[dict[str, Any]]:
    scored: list[tuple[int, str, Candidate, str]] = []
    for candidate in candidates.values():
        if candidate.image_url in excluded_images:
            continue
        text = candidate_text(candidate, extracts)
        if mode == "NSFW":
            accepted, reason = nsfw_is_strict(text)
            if not accepted:
                continue
            score = sum(3 for m in STRONG_EXPLICIT_MARKERS if m.casefold() in text.casefold())
            score += sum(1 for m in NSFW_MARKERS if m.casefold() in text.casefold())
        else:
            if not safe_is_strict(text):
                continue
            reason = "пейзаж, натюрморт, цветочная или абстрактная живопись без NSFW-маркеров"
            score = 2 if candidate.article_ru else 1
        scored.append((-score, candidate.qid, candidate, reason))
    scored.sort(key=lambda value: (value[0], int(value[1][1:])))
    items: list[dict[str, Any]] = []
    used_images: set[str] = set()
    for _, _, candidate, reason in scored:
        if candidate.image_url in used_images:
            continue
        item = build_item(candidate, mode, extracts, reason)
        if item is None:
            continue
        item["catalog_index"] = len(items) + 1
        items.append(item)
        used_images.add(candidate.image_url)
        if len(items) == target:
            break
    if len(items) != target:
        raise RuntimeError(
            f"Not enough strict {mode} items: {len(items)} of {target}. "
            "The APK build is intentionally stopped rather than packaging an unverified catalog."
        )
    return items


def catalog_document(name: str, mode: str, items: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": 6,
        "catalog_name": name,
        "catalog_mode": mode,
        "catalog_version": VERSION,
        "item_count": len(items),
        "source": {
            "dataset": "Wikidata exact painting items + Wikipedia article extracts",
            "selection_rule": "Russian Wikipedia first; English Wikipedia fallback; image from the exact item P18",
            "commons_title_search_used": False,
            "wikiart_used": False,
        },
        "production_status": "bundled_exact_wikipedia_article_and_wikidata_p18",
        "items": items,
    }


def validate(filter_doc: dict[str, Any], nsfw_doc: dict[str, Any], target: int) -> dict[str, Any]:
    errors: list[str] = []
    summaries: dict[str, Any] = {}
    all_ids: set[str] = set()
    all_images: set[str] = set()
    for name, doc, expected_mode in (
        ("filter", filter_doc, "FILTER"), ("nsfw", nsfw_doc, "NSFW")
    ):
        items = doc.get("items", [])
        ids: set[str] = set()
        images: set[str] = set()
        qids: set[str] = set()
        ru_count = 0
        for index, item in enumerate(items, start=1):
            prefix = f"{name}[{index}]"
            sid = str(item.get("stable_id", ""))
            qid = str(item.get("qid", ""))
            image = str(item.get("image_url", ""))
            source = str(item.get("source_page_url", ""))
            description = clean_text(item.get("description", ""))
            if not sid or sid in ids: errors.append(f"{prefix}: duplicate/empty stable_id")
            if not re.fullmatch(r"Q\d+", qid) or qid in qids: errors.append(f"{prefix}: invalid/duplicate qid")
            if not image or image in images or not is_raster(image): errors.append(f"{prefix}: invalid/duplicate raster image")
            if not re.match(r"^https://(ru|en)\.wikipedia\.org/wiki/", source): errors.append(f"{prefix}: invalid source article")
            if not description: errors.append(f"{prefix}: empty Wikipedia description")
            if item.get("content_mode") != expected_mode: errors.append(f"{prefix}: wrong mode")
            if item.get("requires_image_resolution") is not False: errors.append(f"{prefix}: unresolved image")
            if expected_mode == "NSFW":
                accepted, _ = nsfw_is_strict(" ".join((str(item.get("title", "")), description, str(item.get("content_reason", "")))))
                if not accepted: errors.append(f"{prefix}: NSFW rule not satisfied")
            else:
                if contains_any(" ".join((str(item.get("title", "")), description)), SAFE_BLOCK_MARKERS):
                    errors.append(f"{prefix}: explicit/minor marker in filter catalog")
            if item.get("source_language") == "ru": ru_count += 1
            ids.add(sid); qids.add(qid); images.add(image)
        if len(items) != target: errors.append(f"{name}: {len(items)} items, expected {target}")
        overlap_ids = all_ids.intersection(ids)
        overlap_images = all_images.intersection(images)
        if overlap_ids: errors.append(f"{name}: cross-catalog stable-id overlap")
        if overlap_images: errors.append(f"{name}: cross-catalog image overlap")
        all_ids.update(ids); all_images.update(images)
        summaries[name] = {
            "records": len(items), "unique_ids": len(ids), "unique_qids": len(qids),
            "unique_images": len(images), "russian_articles": ru_count,
        }
    return {
        "version": VERSION,
        "valid": not errors,
        "errors": errors,
        "catalogs": summaries,
        "cross_catalog_overlap": 0 if not errors else None,
        "rules": {
            "wikipedia_priority": "ru -> en",
            "image_resolution": "exact Wikidata QID P18",
            "commons_fuzzy_search": False,
            "wikiart": False,
            "descriptions": "Wikipedia article introduction",
        },
    }


def load_fixture(path: Path) -> tuple[list[tuple[dict[str, str], str]], list[tuple[dict[str, str], str]], dict[tuple[str, str], dict[str, str]]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    safe_rows = [(row, "fixture-safe") for row in data.get("safe_rows", [])]
    nsfw_rows = [(row, "fixture-nsfw") for row in data.get("nsfw_rows", [])]
    extracts: dict[tuple[str, str], dict[str, str]] = {}
    for key, value in data.get("extracts", {}).items():
        qid, language = key.split("|", 1)
        extracts[(qid, language)] = value
    return safe_rows, nsfw_rows, extracts


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("app/src/main/assets"))
    parser.add_argument("--report", type=Path, default=Path("CATALOG_VALIDATION_V12_3_1.json"))
    parser.add_argument("--cache-dir", type=Path, default=Path(".catalog-cache"))
    parser.add_argument("--target", type=int, default=1000)
    parser.add_argument("--query-limit", type=int, default=12000)
    parser.add_argument("--fixture", type=Path)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.fixture:
        safe_rows, nsfw_rows, fixed_extracts = load_fixture(args.fixture)
        safe_candidates = aggregate(safe_rows)
        nsfw_candidates = aggregate(nsfw_rows)
        extracts = fixed_extracts
    else:
        client = Client(args.cache_dir)
        safe_rows = [(row, "Wikidata genre: landscape/still life/floral painting")
                     for row in client.sparql(safe_query(args.query_limit), "sparql_safe_v3")]
        nsfw_rows: list[tuple[dict[str, str], str]] = []
        nsfw_rows += [(row, "Wikidata painting label")
                      for row in client.sparql(nsfw_label_query(args.query_limit), "sparql_nsfw_labels_v3")]
        nsfw_rows += [(row, "Wikidata depicts statement")
                      for row in client.sparql(nsfw_depicts_query(args.query_limit), "sparql_nsfw_depicts_v3")]
        nsfw_rows += [(row, "Wikidata adult-art genre")
                      for row in client.sparql(nsfw_genre_query(args.query_limit), "sparql_nsfw_genre_v3")]
        nsfw_rows += [(row, "Wikidata mythological painting recall pool")
                      for row in client.sparql(nsfw_mythology_query(args.query_limit), "sparql_nsfw_mythology_v3")]
        safe_candidates = aggregate(safe_rows)
        nsfw_candidates = aggregate(nsfw_rows)
        combined = list(safe_candidates.values()) + list(nsfw_candidates.values())
        extracts = fetch_descriptions(client, combined)

    filter_items = select_items(safe_candidates, "FILTER", args.target, extracts, set())
    filter_images = {item["image_url"] for item in filter_items}
    nsfw_items = select_items(nsfw_candidates, "NSFW", args.target, extracts, filter_images)

    filter_doc = catalog_document("filter_catalog_1000", "FILTER", filter_items)
    nsfw_doc = catalog_document("nsfw_catalog_1000", "NSFW", nsfw_items)
    report = validate(filter_doc, nsfw_doc, args.target)
    if not report["valid"]:
        raise RuntimeError("Catalog validation failed:\n" + "\n".join(report["errors"][:50]))

    (args.output_dir / "filter_catalog.json").write_text(
        json.dumps(filter_doc, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output_dir / "nsfw_catalog.json").write_text(
        json.dumps(nsfw_doc, ensure_ascii=False, indent=2), encoding="utf-8")
    manifest = {
        "schema_version": 6,
        "catalog_version": VERSION,
        "filter_asset": "filter_catalog.json",
        "filter_count": args.target,
        "nsfw_asset": "nsfw_catalog.json",
        "nsfw_count": args.target,
        "source_label": "Wikipedia.org",
        "descriptions": "Wikipedia article introduction",
        "image_rule": "exact Wikidata QID P18",
        "production_status": "ready_for_apk_embedding",
    }
    (args.output_dir / "catalog_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
