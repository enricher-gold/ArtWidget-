import hashlib
import json
import re
import zipfile
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PIPELINE_ZIP = Path('/mnt/data/ArtWidget_commons_resolution_pipeline_v1.zip')
ASSETS = ROOT / 'app/src/main/assets'
ASSETS.mkdir(parents=True, exist_ok=True)

MINOR_RE = re.compile(r'\b(child|children|girl|girls|boy|boys|baby|babies|infant|infants|minor|minors|putti|cherub|cherubs|adolescent|adolescents|teen|teens|teenage|youth|young|youngster|daughter|daughters|son|sons|schoolgirl|schoolboy)\b', re.I)
NONPAINT_RE = re.compile(r'\b(sketch|drawing|study|etching|engraving|print|watercolor|watercolour|pastel|illustration|sculpture|statue|bronze|lithograph|woodcut|fresco|mural|mosaic|ceramic|photograph|photography|poster|icon|altarpiece|triptych|polyptych)\b', re.I)
GENERIC_TITLE_RE = re.compile(r'^(untitled|nude|female nude|male nude|naked woman|naked man|figure|study|bather|woman|man|landscape|portrait|composition|still life|abstract painting)(\s*\d+)?$', re.I)
EXPLICIT_TAGS = {'female-nude', 'male-nude'}

STYLE_RU = {
    'impressionism': 'импрессионизму', 'post_impressionism': 'постимпрессионизму',
    'romanticism': 'романтизму', 'realism': 'реализму', 'baroque': 'барокко',
    'rococo': 'рококо', 'renaissance': 'Возрождению',
    'northern_renaissance': 'Северному Возрождению',
    'early_renaissance': 'Раннему Возрождению', 'high_renaissance': 'Высокому Возрождению',
    'mannerism_late_renaissance': 'маньеризму', 'neoclassicism': 'неоклассицизму',
    'symbolism': 'символизму', 'expressionism': 'экспрессионизму',
    'art_nouveau_modern': 'модерну', 'academic_art': 'академической живописи',
    'surrealism': 'сюрреализму', 'cubism': 'кубизму', 'fauvism': 'фовизму',
    'naive_art_primitivism': 'наивному искусству', 'ukiyo_e': 'укиё-э',
    'abstract_expressionism': 'абстрактному экспрессионизму',
    'color_field_painting': 'живописи цветового поля'
}
TAG_RU = {
    'female-nude': 'обнажённая женская фигура', 'male-nude': 'обнажённая мужская фигура',
    'mythology': 'мифологический сюжет', 'greek-and-roman-mythology': 'античная мифология',
    'bathing-and-swimming': 'купание', 'couples': 'парный сюжет',
    'leisure-and-sleep': 'отдых или сон', 'artists-and-models': 'художник и модель',
    'nymphs-and-satyrs': 'нимфы и сатиры', 'allegories-and-symbols': 'аллегорический сюжет',
    'famous-people': 'известные личности', 'portrait': 'портрет',
    'natural landscape': 'пейзаж', 'landscape': 'пейзаж', 'nature': 'природа',
    'still life': 'натюрморт', 'houses-and-buildings': 'архитектурный пейзаж',
    'architecture': 'архитектура', 'boats-and-ships': 'корабли', 'seas-and-oceans': 'море',
    'forests-and-trees': 'лес', 'animals': 'животные', 'streets-and-squares': 'городской вид',
    'flower': 'цветы', 'tree': 'деревья', 'mountains': 'горы', 'rivers-and-waterfalls': 'реки'
}

def load_pool(member):
    with zipfile.ZipFile(PIPELINE_ZIP) as zf:
        return json.loads(zf.read(member))['items']

def norm(value):
    return re.sub(r'\s+', ' ', str(value or '').strip())

def title_score(item):
    title = norm(item.get('title'))
    artist = norm(item.get('artist'))
    tokens = re.findall(r"[A-Za-zÀ-žА-Яа-яЁё0-9']+", title)
    score = min(len(title), 60) + min(len(tokens), 8) * 8
    if item.get('year'): score += 12
    if len(artist.split()) >= 2: score += 8
    if GENERIC_TITLE_RE.match(title): score -= 120
    if len(title) < 5: score -= 50
    if '(' in title or ')' in title: score += 4
    return score

def select_diverse(items, target, explicit):
    accepted = []
    seen_ids = set()
    for item in items:
        sid = stable_id(item)
        if sid in seen_ids:
            continue
        seen_ids.add(sid)
        tags = {str(t).strip().lower() for t in item.get('tags', [])}
        text = ' '.join([norm(item.get('title')), norm(item.get('source_record_image_name')), ' '.join(tags)])
        if MINOR_RE.search(text) or NONPAINT_RE.search(text):
            continue
        if explicit and not (tags & EXPLICIT_TAGS):
            continue
        if not explicit and tags & EXPLICIT_TAGS:
            continue
        row = dict(item)
        row['_score'] = title_score(row)
        accepted.append(row)
    accepted.sort(key=lambda x: (-x['_score'], norm(x.get('artist')).lower(), norm(x.get('title')).lower()))

    by_artist = defaultdict(list)
    for row in accepted:
        by_artist[norm(row.get('artist'))].append(row)
    selected = []
    # First passes maximize variety; later passes fill remaining places.
    for round_no in range(20):
        for artist in sorted(by_artist, key=str.lower):
            rows = by_artist[artist]
            if round_no < len(rows):
                selected.append(rows[round_no])
                if len(selected) >= target:
                    return selected
    used = {x.get('stable_id') for x in selected}
    for row in accepted:
        if row.get('stable_id') in used:
            continue
        selected.append(row)
        if len(selected) >= target:
            break
    if len(selected) < target:
        raise RuntimeError(f'Only {len(selected)} eligible records for target {target}')
    return selected[:target]

def description_ru(item, explicit):
    # Описание загружается приложением только из статьи Wikipedia.org.
    return ''

def stable_id(item):
    key = f"{norm(item.get('artist')).lower()}|{norm(item.get('title')).lower()}"
    return 'wpseed:' + hashlib.sha1(key.encode('utf-8')).hexdigest()[:20]

def build_record(item, mode, index):
    artist = norm(item.get('artist')) or 'Автор неизвестен'
    title = norm(item.get('title')) or 'Без названия'
    query = f'{title} {artist}'.strip()
    return {
        'catalog_index': index,
        'stable_id': stable_id(item),
        'dedupe_key': norm(item.get('dedupe_key')) or f'{artist.lower()}|{title.lower()}',
        'artist': artist,
        'title': title,
        'year': item.get('year'),
        'style': item.get('style'),
        'tags': item.get('tags', []),
        'description_ru': description_ru(item, mode == 'NSFW'),
        'content_mode': mode,
        'content_confidence': 'strict-metadata-seed',
        'content_reason': ('explicit nude source tags; Wikipedia article must pass NSFW validation'
                           if mode == 'NSFW'
                           else 'explicit/minor/non-painting markers excluded; Wikipedia article must pass filter validation'),
        'source_provider': 'Wikipedia',
        'source_page_url': '',
        'image_url': None,
        'wikipedia_query_ru': query,
        'wikipedia_query_en': query,
        'resolver_order': ['ruwiki_exact_article', 'enwiki_exact_article'],
        'image_resolver': {
            'type': 'wikipedia_article_pageimage',
            'allow_wikiart': False,
            'allow_commons_title_search': False,
            'allow_exact_qid_p18': True
        },
        'requires_image_resolution': True
    }

def write_catalog(filename, mode, items):
    payload = {
        'schema_version': 5,
        'catalog_name': filename,
        'catalog_mode': mode,
        'catalog_version': '2026.06.18-wikipedia-description-v5',
        'generated_at_utc': datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        'item_count': len(items),
        'production_status': 'wikipedia_priority_seed_catalog_runtime_article_description',
        'source_priority': ['ru.wikipedia.org', 'en.wikipedia.org'],
        'items': [build_record(x, mode, i + 1) for i, x in enumerate(items)]
    }
    (ASSETS / filename).write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
    return payload

filter_pool = load_pool('input/filter_candidate_pool_5000.json')
nsfw_pool = load_pool('input/nsfw_candidate_pool_1120.json')
nsfw_selected = select_diverse(nsfw_pool, 1000, True)
nsfw_keys = {stable_id(x) for x in nsfw_selected}
filter_candidates = [x for x in filter_pool if stable_id(x) not in nsfw_keys]
filter_selected = select_diverse(filter_candidates, 1000, False)
filter_payload = write_catalog('filter_catalog.json', 'FILTER', filter_selected)
nsfw_payload = write_catalog('nsfw_catalog.json', 'NSFW', nsfw_selected)

manifest = {
    'schema_version': 5,
    'catalog_version': '2026.06.18-wikipedia-description-v5',
    'catalogs': [
        {'asset': 'filter_catalog.json', 'mode': 'FILTER', 'items': 1000},
        {'asset': 'nsfw_catalog.json', 'mode': 'NSFW', 'items': 1000}
    ],
    'source_priority': ['ru.wikipedia.org', 'en.wikipedia.org'],
    'wikiart_allowed': False,
    'commons_title_search_allowed': False,
    'exact_article_or_qid_image_only': True,
    'description_policy': 'Wikipedia article extract only; catalog descriptions are empty'
}
(ASSETS / 'catalog_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')

all_items = filter_payload['items'] + nsfw_payload['items']
report = {
    'filter_count': len(filter_payload['items']),
    'nsfw_count': len(nsfw_payload['items']),
    'unique_stable_ids': len({x['stable_id'] for x in all_items}),
    'wikiart_urls': sum('wikiart.org' in json.dumps(x).lower() for x in all_items),
    'commons_fuzzy_search_enabled': sum(bool(x['image_resolver']['allow_commons_title_search']) for x in all_items),
    'ru_first_entries': sum(x['resolver_order'][0] == 'ruwiki_exact_article' for x in all_items),
    'nsfw_without_explicit_tag': sum(not ({str(t).lower() for t in x['tags']} & EXPLICIT_TAGS) for x in nsfw_payload['items']),
    'minor_marker_hits': sum(bool(MINOR_RE.search(' '.join([x['title'], ' '.join(x['tags'])]))) for x in nsfw_payload['items']),
    'nonpainting_marker_hits': sum(bool(NONPAINT_RE.search(' '.join([x['title'], ' '.join(x['tags'])]))) for x in all_items)
}
(ROOT / 'CATALOG_VALIDATION_V12_2.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
