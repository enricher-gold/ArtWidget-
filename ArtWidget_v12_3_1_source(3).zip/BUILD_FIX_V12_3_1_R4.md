# Art Widget 12.3.1 catalog build fix r4

The previous generator had a structural ceiling: after strict checks it could resolve only about 542 NSFW works from individual Wikidata/Wikipedia artwork records, so increasing category depth alone could not reach 1000.

Changes:
- Added a second, exact source for the NSFW shortfall: raster files that are direct members of Wikimedia Commons painting categories.
- No fuzzy Commons title search is used. Category membership and file metadata are checked directly.
- Existing exact Wikidata QID + Wikipedia artwork records remain the first-priority source.
- For Commons fallback records, descriptive text still comes from Wikipedia.org: the exact creator article when available, otherwise a relevant art-topic article.
- Minor-related branches and metadata are rejected, including child, youth, young, putti and cherub markers.
- Drawings, prints, photographs, sculpture, watercolor, pastel, fresco, mural, mosaic and other non-painting media are rejected.
- The independent validator and Gradle checks accept both exact Wikidata identities (`Q...`) and exact Commons file identities (`commons:...`).
- The build still fails before APK packaging unless both embedded catalogs contain exactly 1000 complete records.

App version stays 12.3.1 (versionCode 25).
