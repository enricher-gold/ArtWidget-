#!/usr/bin/env python3
"""Build two deterministic 1000-item catalogs without Wikidata SPARQL.

Discovery uses fixed local candidate QIDs plus curated Wikipedia categories. Every
accepted record must resolve to the same Wikidata QID, an exact ru/en Wikipedia
article, and that item's P18 image. Descriptions are the article introductions.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import gzip
import hashlib
import html
import json
import re
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

VERSION = "2026.06.18-v12.3.1-r4"
USER_AGENT = "ArtWidgetCatalogBuilder/12.3.1 (contact: enricherusa@gmail.com)"
WIKIDATA_API = "https://www.wikidata.org/w/api.php"
COMMONS_API = "https://commons.wikimedia.org/w/api.php"
WIKI_API = {
    "ru": "https://ru.wikipedia.org/w/api.php",
    "en": "https://en.wikipedia.org/w/api.php",
}
RASTER_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")

NSFW_CATEGORIES = [
    # Strong roots. Their descendants are still revalidated as exact painting items
    # with P18 and a dedicated ru/en Wikipedia article before acceptance.
    ("Nude paintings", 3),
    ("Nude paintings of women", 3),
    ("Nude paintings of men", 3),
    ("Paintings of nude women", 3),
    ("Paintings of nude men", 3),
    ("Nude paintings by artist", 3),
    ("Nude paintings by country", 3),
    ("Nude paintings by century", 3),
    ("Nude paintings by period", 3),
    ("Nude paintings by art movement", 3),
    ("Academic nude paintings", 3),
    ("Reclining nudes", 3),
    ("Standing nudes", 3),
    ("Seated nudes", 3),
    ("Female nude in art", 3),
    ("Male nude in art", 3),
    ("Nudity in art", 3),
    ("Nude art", 3),
    ("Toplessness in art", 3),
    ("Erotic art", 3),
    ("Erotic paintings", 3),
    ("Erotic paintings by artist", 3),
    ("Erotic paintings by country", 3),
    ("Obscenity controversies in painting", 3),
    ("Prostitution in paintings", 3),
    ("Paintings of prostitutes", 3),
    ("Paintings of bathers", 3),
    ("Bathers in art", 3),
    ("Bathing in art", 2),
    ("Bathing in paintings", 2),
    ("Odalisques in art", 3),
    ("Odalisque paintings", 3),
    ("Harem paintings", 2),
    ("Paintings of harems", 2),
    ("Paintings of Venus", 2),
    ("Paintings of Aphrodite", 2),
    ("Paintings of Adam and Eve", 2),
    ("Paintings of Eve", 2),
    ("Paintings of Bathsheba", 2),
    ("Paintings of Susanna and the Elders", 2),
    ("Paintings of Danaë", 2),
    ("Paintings of Leda", 2),
    ("Paintings of nymphs", 2),
    ("Paintings of the Three Graces", 2),
    ("Paintings of Diana", 1),
    ("Paintings of Diana and Actaeon", 1),
    ("Paintings of Actaeon", 1),
    ("Paintings of Saint Sebastian", 1),
    ("Paintings of Lucretia", 1),
    ("Paintings of Andromeda", 1),
    ("Paintings of Galatea", 1),
    ("Paintings of Psyche", 1),
    ("Paintings of Io", 1),
    ("Paintings of Europa", 1),
    ("Paintings of the Judgement of Paris", 1),
    ("Paintings of Lot and his daughters", 1),
    ("Paintings of Joseph and Potiphar's Wife", 1),
]
COMMONS_NSFW_CATEGORIES = [
    ("Nude paintings", 3),
    ("Paintings of nude females", 3),
    ("Paintings of nude males", 3),
    ("Paintings of nude women", 3),
    ("Paintings of nude men", 3),
    ("Nude paintings of women", 3),
    ("Nude paintings of men", 3),
    ("Nude paintings by artist", 3),
    ("Nude paintings by century", 3),
    ("Nude paintings by country", 3),
    ("Nude paintings by museum", 3),
    ("Nude paintings by year", 3),
    ("Paintings of nude couples", 3),
    ("Nude group paintings", 3),
    ("Paintings of nude people in nature", 3),
    ("Portrait paintings of nude people", 3),
    ("Paintings of nude recumbent people", 3),
    ("Nude people in religious paintings", 3),
    ("Renaissance paintings of nudes", 3),
    ("Expressionist paintings of nudes", 3),
    ("Reclining nudes", 3),
    ("Standing nudes", 3),
    ("Seated nudes", 3),
    ("Erotic paintings", 3),
    ("Odalisques", 3),
    ("Paintings of bathers", 3),
    ("Paintings of Venus", 3),
    ("Paintings of Aphrodite", 3),
    ("Paintings of Adam and Eve", 3),
    ("Paintings of Bathsheba", 3),
    ("Paintings of Susanna and the Elders", 3),
    ("Paintings of Danaë", 3),
    ("Paintings of Leda and the Swan", 3),
    ("Paintings of nymphs", 3),
    ("Paintings of the Three Graces", 3),
]

SAFE_CATEGORIES = [
    ("Landscape paintings", 3),
    ("Still life paintings", 3),
    ("Flower paintings", 3),
    ("Marine paintings", 3),
    ("Cityscape paintings", 3),
    ("Animal paintings", 2),
    ("Abstract paintings", 2),
]

EXPLICIT_MARKERS = (
    "nude", "nudity", "naked", "female nude", "male nude", "reclining nude",
    "standing nude", "seated nude", "odalisque", "erotic", "topless",
    "bare breast", "breasts", "buttocks", "bather", "bathers", "bathing",
    "обнаж", "нагота", "ню", "одалиск", "эрот", "купальщ", "купающ",
    "обнаженная", "обнажённая", "обнаженный", "обнажённый",
)
MYTH_MARKERS = (
    "venus", "aphrodite", "danae", "danaë", "leda", "bathsheba", "susanna",
    "three graces", "nymph", "bacchante", "maenad", "adam and eve", "eve",
    "венер", "афродит", "даная", "леда", "вирсав", "сусанн", "три грац",
    "нимф", "вакхан", "адам и ева", "ева",
)
BODY_MARKERS = (
    "body", "bare", "undressed", "breast", "chest", "skin", "bath", "bather",
    "тело", "обнаж", "наг", "груд", "купаль", "купающ", "раздет",
)
MINOR_MARKERS = (
    "child", "children", "young", "young girl", "young boy", "baby", "infant",
    "adolescent", "teenager", "putti", "putto", "cherub", "minor",
    "ребен", "ребён", "дети", "девоч", "мальчик", "младен", "подрост",
    "путти", "херувим",
)
NON_PAINTING_MARKERS = (
    "sculpture", "statue", "photograph", "photography", "engraving", "etching",
    "lithograph", "drawing", "sketch", "poster", "mosaic", "relief",
    "watercolor", "watercolour", "pastel", "fresco", "mural", "manuscript",
    "illustration", "woodcut", "print", "study", "installation", "exhibition view",
    "скульптур", "стату", "фотограф", "гравюр", "офорт", "литограф",
    "рисунок", "эскиз", "плакат", "мозаик", "рельеф", "акварел", "пастел",
    "фреск", "мурал", "рукопис", "иллюстрац", "ксилограф", "эстамп", "этюд",
)
SAFE_POSITIVE = (
    "landscape", "still life", "flower", "floral", "forest", "river", "sea",
    "marine", "lake", "mountain", "garden", "trees", "cityscape", "abstract",
    "animal painting", "пейзаж", "натюрморт", "цвет", "лес", "река", "море",
    "озеро", "гор", "сад", "дерев", "городской вид", "абстракт", "анималист",
)


def clean_text(value: Any) -> str:
    return re.sub(r"\s+", " ", html.unescape(str(value or ""))).strip()


def contains_any(text: str, markers: Iterable[str]) -> bool:
    low = text.casefold()
    return any(marker.casefold() in low for marker in markers)


def is_raster(url: str) -> bool:
    path = urllib.parse.unquote(urllib.parse.urlsplit(str(url or "")).path).lower()
    return path.endswith(RASTER_EXTENSIONS)


def nsfw_is_strict(text: str, strength: int = 0) -> tuple[bool, str]:
    value = clean_text(text)
    if contains_any(value, NON_PAINTING_MARKERS):
        return False, ""
    # Каталог 18+ не должен включать сюжеты с несовершеннолетними даже при наличии наготы.
    if contains_any(value, MINOR_MARKERS):
        return False, ""
    explicit = contains_any(value, EXPLICIT_MARKERS)
    if explicit or strength >= 3:
        return True, "явный признак наготы или эротического сюжета"
    if strength >= 2 and contains_any(value, BODY_MARKERS):
        return True, "подтверждённый сюжет категории обнажённой живописи"
    if strength >= 1 and contains_any(value, MYTH_MARKERS) and contains_any(value, BODY_MARKERS):
        return True, "мифологический сюжет с телесным маркером"
    return False, ""


def safe_is_strict(text: str, safe_hint: bool = False) -> bool:
    value = clean_text(text)
    if contains_any(value, EXPLICIT_MARKERS + MINOR_MARKERS + NON_PAINTING_MARKERS):
        return False
    return safe_hint or contains_any(value, SAFE_POSITIVE)


class ApiClient:
    def __init__(self, cache_dir: Path):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)

    def request(self, url: str, params: dict[str, Any], cache_key: str,
                *, post: bool = False, attempts: int = 7) -> dict[str, Any]:
        cache = self.cache_dir / f"{cache_key}.json"
        if cache.exists():
            return json.loads(cache.read_text(encoding="utf-8"))
        encoded = urllib.parse.urlencode({k: v for k, v in params.items() if v is not None}).encode()
        last: Exception | None = None
        for attempt in range(attempts):
            try:
                if post:
                    req = urllib.request.Request(url, data=encoded, method="POST")
                else:
                    req = urllib.request.Request(url + "?" + encoded.decode(), method="GET")
                req.add_header("User-Agent", USER_AGENT)
                req.add_header("Accept", "application/json")
                with urllib.request.urlopen(req, timeout=120) as response:
                    payload = json.loads(response.read().decode("utf-8"))
                if "error" in payload:
                    code = str(payload["error"].get("code", ""))
                    if code in {"maxlag", "ratelimited", "readonly"}:
                        raise RuntimeError(f"Wikimedia API temporary error: {payload['error']}")
                    # Missing categories are not fatal.
                    if code in {"missingtitle", "invalidcategory"}:
                        return {"query": {"categorymembers": []}}
                    raise RuntimeError(f"Wikimedia API error: {payload['error']}")
                cache.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
                return payload
            except Exception as exc:
                last = exc
                if attempt + 1 >= attempts:
                    break
                wait = min(45, 2 * (2 ** attempt))
                print(f"API retry {attempt + 1}/{attempts}: {exc}; sleep {wait}s", file=sys.stderr, flush=True)
                time.sleep(wait)
        raise RuntimeError(f"Request failed for {url}: {last}")

    def entities(self, qids: list[str]) -> dict[str, dict[str, Any]]:
        if not qids:
            return {}
        digest = hashlib.sha256("|".join(qids).encode()).hexdigest()[:20]
        payload = self.request(WIKIDATA_API, {
            "action": "wbgetentities", "format": "json", "formatversion": "2",
            "ids": "|".join(qids), "props": "labels|descriptions|claims|sitelinks",
            "languages": "ru|en", "sitefilter": "ruwiki|enwiki", "maxlag": "5",
        }, f"entities_{digest}", post=True)
        return payload.get("entities", {}) or {}

    def wiki_pages(self, language: str, titles: list[str]) -> dict[str, dict[str, Any]]:
        if not titles:
            return {}
        digest = hashlib.sha256((language + "|" + "|".join(titles)).encode()).hexdigest()[:20]
        payload = self.request(WIKI_API[language], {
            "action": "query", "format": "json", "formatversion": "2",
            "prop": "extracts|pageprops|pageimages", "exintro": "1", "explaintext": "1",
            "piprop": "thumbnail|original", "pithumbsize": "1600",
            "redirects": "1", "titles": "|".join(titles), "maxlag": "5",
        }, f"pages_{language}_{digest}", post=True)
        query = payload.get("query", {}) or {}
        normalized = {x.get("from", ""): x.get("to", "") for x in query.get("normalized", []) or []}
        redirects = {x.get("from", ""): x.get("to", "") for x in query.get("redirects", []) or []}
        pages = {p.get("title", ""): p for p in query.get("pages", []) or []}
        result: dict[str, dict[str, Any]] = {}
        for requested in titles:
            canonical = redirects.get(normalized.get(requested, requested), normalized.get(requested, requested))
            result[requested] = pages.get(canonical, {})
        return result

    def category_members(self, category: str, continuation: str = "") -> dict[str, Any]:
        key = hashlib.sha256((category + "|" + continuation).encode()).hexdigest()[:20]
        params = {
            "action": "query", "format": "json", "formatversion": "2",
            "list": "categorymembers", "cmtitle": "Category:" + category,
            "cmtype": "page|subcat", "cmlimit": "max", "maxlag": "5",
        }
        if continuation:
            params["cmcontinue"] = continuation
        return self.request(WIKI_API["en"], params, f"category_{key}")

    def search_entities(self, query: str) -> list[dict[str, Any]]:
        key = hashlib.sha256(query.encode()).hexdigest()[:20]
        payload = self.request(WIKIDATA_API, {
            "action": "wbsearchentities", "format": "json", "language": "en",
            "uselang": "en", "type": "item", "limit": "7", "search": query,
            "maxlag": "5",
        }, f"search_{key}")
        return payload.get("search", []) or []

    def commons_category_members(self, category: str, continuation: str = "") -> dict[str, Any]:
        key = hashlib.sha256((category + "|" + continuation).encode()).hexdigest()[:20]
        params = {
            "action": "query", "format": "json", "formatversion": "2",
            "list": "categorymembers", "cmtitle": "Category:" + category,
            "cmtype": "file|subcat", "cmlimit": "max", "maxlag": "5",
        }
        if continuation:
            params["cmcontinue"] = continuation
        return self.request(COMMONS_API, params, f"commons_category_{key}")

    def commons_file_info(self, pageids: list[int]) -> dict[int, dict[str, Any]]:
        if not pageids:
            return {}
        digest = hashlib.sha256("|".join(str(x) for x in pageids).encode()).hexdigest()[:20]
        payload = self.request(COMMONS_API, {
            "action": "query", "format": "json", "formatversion": "2",
            "prop": "imageinfo|categories", "pageids": "|".join(str(x) for x in pageids),
            "iiprop": "url|mime|extmetadata", "iiurlwidth": "1600",
            "cllimit": "max", "maxlag": "5",
        }, f"commons_files_{digest}", post=True)
        result: dict[int, dict[str, Any]] = {}
        for page in ((payload.get("query") or {}).get("pages") or []):
            try:
                result[int(page.get("pageid"))] = page
            except Exception:
                continue
        return result


@dataclass
class Candidate:
    qid: str
    title: str = ""
    artist: str = ""
    year: int | None = None
    evidence: str = ""
    safe_hint: bool = False
    nsfw_strength: int = 0
    category_evidence: set[str] = field(default_factory=set)

    def merge(self, other: "Candidate") -> None:
        self.title = self.title or other.title
        self.artist = self.artist or other.artist
        self.year = self.year if self.year is not None else other.year
        self.evidence = clean_text(self.evidence + " " + other.evidence)
        self.safe_hint = self.safe_hint or other.safe_hint
        self.nsfw_strength = max(self.nsfw_strength, other.nsfw_strength)
        self.category_evidence.update(other.category_evidence)


def load_pool(path: Path) -> tuple[dict[str, Candidate], list[dict[str, Any]]]:
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        data = json.load(handle)
    candidates: dict[str, Candidate] = {}
    for row in data.get("candidates", []):
        qid = str(row.get("qid", ""))
        if not re.fullmatch(r"Q\d+", qid):
            continue
        candidates[qid] = Candidate(
            qid=qid, title=clean_text(row.get("title")), artist=clean_text(row.get("artist")),
            year=row.get("year") if isinstance(row.get("year"), int) else None,
            evidence=clean_text(row.get("evidence")), safe_hint=bool(row.get("safe_hint")),
            nsfw_strength=int(row.get("nsfw_strength", 0) or 0),
        )
    seeds = list(data.get("fallback_seeds", []))
    if not seeds:
        # The source pool used in 12.3.1 had an empty fallback_seeds array. Build
        # deterministic exact-title seeds from the same offline candidate records so
        # alternate/merged Wikidata items can still be found when the stored QID lacks
        # a sitelink, P18 or article extract.
        for candidate in candidates.values():
            if candidate.nsfw_strength > 0 and candidate.title:
                seeds.append({
                    "mode": "NSFW", "title": candidate.title,
                    "artist": candidate.artist, "year": candidate.year,
                    "tags": [candidate.evidence],
                })
            if candidate.safe_hint and candidate.title:
                seeds.append({
                    "mode": "FILTER", "title": candidate.title,
                    "artist": candidate.artist, "year": candidate.year,
                    "tags": [candidate.evidence],
                })
    return candidates, seeds


def discover_category_candidates(client: ApiClient, roots: list[tuple[str, int]],
                                 *, max_depth: int, max_pages: int,
                                 traverse_all_subcategories: bool = False) -> dict[str, Candidate]:
    discovered_pages: dict[str, tuple[int, set[str]]] = {}
    seen_categories: set[str] = set()
    queue: list[tuple[str, int, int, str]] = [(name, strength, 0, name) for name, strength in roots]
    while queue and len(discovered_pages) < max_pages:
        category, strength, depth, root = queue.pop(0)
        key = category.casefold()
        if key in seen_categories:
            continue
        seen_categories.add(key)
        continuation = ""
        while True:
            payload = client.category_members(category, continuation)
            members = ((payload.get("query") or {}).get("categorymembers") or [])
            for member in members:
                ns = member.get("ns")
                title = clean_text(member.get("title"))
                if ns == 14 and depth < max_depth:
                    sub = title.split(":", 1)[1] if ":" in title else title
                    low = sub.casefold()
                    # Never descend into branches involving minors or non-painting media.
                    blocked_subcategory_words = (
                        "child", "children", "boy", "boys", "girl", "girls", "baby", "babies",
                        "infant", "adolescent", "teen", "youth", "young", "putti", "putto", "cherub",
                        "schoolchildren", "sculpture", "statue", "photograph", "photography",
                        "drawing", "sketch", "engraving", "etching", "lithograph", "printmaking",
                        "mosaic", "relief", "film", "pornograph",
                    )
                    if any(word in low for word in blocked_subcategory_words):
                        continue
                    # NSFW roots often branch as "by artist" -> an artist's surname. The previous
                    # whitelist stopped at that level and therefore saw only about 700 pages.
                    # Strong NSFW roots are now traversed through all safe subcategories; every page
                    # is still checked later for P31/description = painting, P18 and article extract.
                    if traverse_all_subcategories or any(word in low for word in (
                        "painting", "paintings", "nude", "venus", "bather", "landscape",
                        "still life", "flower", "marine", "cityscape", "abstract", "animal",
                        "artist", "century", "country", "movement", "period",
                    )):
                        queue.append((sub, strength, depth + 1, root))
                elif ns == 0 and title:
                    old_strength, roots_seen = discovered_pages.get(title, (0, set()))
                    roots_seen.add(root)
                    discovered_pages[title] = (max(old_strength, strength), roots_seen)
                    if len(discovered_pages) >= max_pages:
                        break
            continuation = ((payload.get("continue") or {}).get("cmcontinue") or "")
            if not continuation or len(discovered_pages) >= max_pages:
                break
        print(f"Category scan: {category}; pages={len(discovered_pages)}", flush=True)

    output: dict[str, Candidate] = {}
    titles = sorted(discovered_pages)
    for offset in range(0, len(titles), 30):
        batch = titles[offset:offset + 30]
        pages = client.wiki_pages("en", batch)
        for requested in batch:
            page = pages.get(requested, {})
            qid = str((page.get("pageprops") or {}).get("wikibase_item", ""))
            if not re.fullmatch(r"Q\d+", qid):
                continue
            strength, roots_seen = discovered_pages[requested]
            c = Candidate(
                qid=qid, title=clean_text(page.get("title", requested)),
                evidence="; ".join(sorted(roots_seen)),
                safe_hint=any(root in {name for name, _ in SAFE_CATEGORIES} for root in roots_seen),
                nsfw_strength=strength if any(root in {name for name, _ in NSFW_CATEGORIES} for root in roots_seen) else 0,
                category_evidence=set(roots_seen),
            )
            if qid in output:
                output[qid].merge(c)
            else:
                output[qid] = c
        if offset % 300 == 0:
            print(f"Category page resolution: {min(offset + 30, len(titles))}/{len(titles)}", flush=True)
    return output


def entity_value(entity: dict[str, Any], prop: str) -> list[Any]:
    values: list[Any] = []
    for claim in ((entity.get("claims") or {}).get(prop) or []):
        mainsnak = claim.get("mainsnak") or {}
        datavalue = mainsnak.get("datavalue") or {}
        if "value" in datavalue:
            values.append(datavalue["value"])
    return values


def entity_qids(entity: dict[str, Any], prop: str) -> set[str]:
    result: set[str] = set()
    for value in entity_value(entity, prop):
        if isinstance(value, dict):
            qid = str(value.get("id", ""))
            if re.fullmatch(r"Q\d+", qid):
                result.add(qid)
    return result


def entity_is_painting(entity: dict[str, Any]) -> bool:
    if "Q3305213" in entity_qids(entity, "P31"):
        return True
    text = (description(entity, "en") + " " + description(entity, "ru")).casefold()
    blocked = ("painter", "artist", "sculpture", "photograph", "film", "novel", "book", "exhibition",
               "художник", "скульптур", "фотограф", "фильм", "роман", "книга", "выставка")
    if any(word in text for word in blocked):
        return False
    return "painting" in text or "картина" in text or "живопис" in text


def label(entity: dict[str, Any], language: str) -> str:
    return clean_text((((entity.get("labels") or {}).get(language) or {}).get("value")))


def description(entity: dict[str, Any], language: str) -> str:
    return clean_text((((entity.get("descriptions") or {}).get(language) or {}).get("value")))


def sitelink(entity: dict[str, Any], language: str) -> str:
    return clean_text((((entity.get("sitelinks") or {}).get(language + "wiki") or {}).get("title")))


def p18_filename(entity: dict[str, Any]) -> str:
    values = entity_value(entity, "P18")
    return clean_text(values[0]) if values else ""


def creator_qids(entity: dict[str, Any]) -> list[str]:
    result: list[str] = []
    for value in entity_value(entity, "P170"):
        if isinstance(value, dict):
            qid = str(value.get("id", ""))
            if re.fullmatch(r"Q\d+", qid):
                result.append(qid)
    return result[:3]


def contextual_qids(entity: dict[str, Any]) -> list[str]:
    """Wikipedia context priority: creator, collection, movement, genre."""
    result: list[str] = []
    for prop, limit in (("P170", 3), ("P195", 2), ("P135", 2), ("P136", 2)):
        added = 0
        for value in entity_value(entity, prop):
            if not isinstance(value, dict):
                continue
            qid = str(value.get("id", ""))
            if re.fullmatch(r"Q\d+", qid) and qid not in result:
                result.append(qid)
                added += 1
                if added >= limit:
                    break
    return result


def inception_year(entity: dict[str, Any]) -> int | None:
    for value in entity_value(entity, "P571"):
        if isinstance(value, dict):
            match = re.match(r"^[+-](\d{1,4})-", str(value.get("time", "")))
            if match:
                return int(match.group(1))
    return None


def image_url_from_p18(filename: str) -> str:
    normalized = filename.replace(" ", "_")
    return "https://commons.wikimedia.org/wiki/Special:Redirect/file/" + urllib.parse.quote(normalized, safe="()_',-.~") + "?width=1600"




def page_image_url(page: dict[str, Any]) -> str:
    """Return a raster image exposed by the exact Wikipedia article."""
    for key in ("original", "thumbnail"):
        value = str(((page.get(key) or {}).get("source")) or "")
        if value.startswith("http://"):
            value = "https://" + value[len("http://"):]
        if is_raster(value):
            return value
    return ""


def candidate_is_painting(candidate: Candidate, entity: dict[str, Any]) -> bool:
    """Use Wikidata first, then conservative offline material evidence."""
    if entity_is_painting(entity):
        return True
    evidence = clean_text(candidate.title + " " + candidate.evidence)
    if contains_any(evidence, NON_PAINTING_MARKERS):
        return False
    painting_markers = (
        "painting", "oil paint", "oil on canvas", "tempera", "canvas", "panel",
        "картина", "живопис", "масло", "темпера", "холст", "доска",
    )
    return contains_any(evidence, painting_markers)

def article_url(language: str, title: str) -> str:
    return f"https://{language}.wikipedia.org/wiki/" + urllib.parse.quote(title.replace(" ", "_"), safe="()_',-.~")


def stable_id(qid: str, image_url: str) -> str:
    return "wikidata:" + qid + ":" + hashlib.sha256((qid + "|" + image_url).encode()).hexdigest()[:16]


@dataclass
class Resolved:
    candidate: Candidate
    entity: dict[str, Any]
    language: str
    source_page_title: str
    display_title: str
    extract: str
    image_url: str
    creators: list[str]
    reason: str
    source_kind: str


def resolve_candidates(client: ApiClient, candidates: list[Candidate], mode: str, target: int,
                       excluded_qids: set[str], excluded_images: set[str]) -> list[Resolved]:
    """Resolve real artwork images first, then Wikipedia text.

    Priority:
    1. exact artwork article (ru, then en) + exact QID P18 or that article's PageImages image;
    2. exact QID P18 + Wikipedia article about the creator;
    3. exact QID P18 + a relevant Wikipedia art-topic article.

    The second and third paths are needed because Wikipedia has far fewer than 1000
    individual articles for nude paintings, although Wikidata and Commons contain
    enough separately identified paintings with P18 images. No WikiArt or fuzzy
    Commons title search is used.
    """
    accepted: list[Resolved] = []
    used_qids = set(excluded_qids)
    used_images = set(excluded_images)
    total = len(candidates)

    generic_requests = {
        "ru": ["Обнажённая натура", "Эротическое искусство", "Одалиска"],
        "en": ["Nude (art)", "Erotic art", "Odalisque", "Bather"],
    }
    generic_pages: dict[tuple[str, str], dict[str, Any]] = {}
    for language, titles in generic_requests.items():
        pages = client.wiki_pages(language, titles)
        for requested, page in pages.items():
            if clean_text(page.get("extract")):
                generic_pages[(language, requested)] = page

    def page_context(language: str, requested: str, page: dict[str, Any]) -> tuple[str, str, str] | None:
        extract = clean_text(page.get("extract"))
        if not extract:
            return None
        title = clean_text(page.get("title", requested)) or requested
        return language, title, extract

    def generic_context(candidate: Candidate) -> tuple[str, str, str] | None:
        evidence = clean_text(candidate.title + " " + candidate.evidence + " " + " ".join(candidate.category_evidence)).casefold()
        preferred: list[tuple[str, str]]
        if "odalis" in evidence or "одалиск" in evidence:
            preferred = [("ru", "Одалиска"), ("en", "Odalisque")]
        elif any(x in evidence for x in ("erotic", "prostitut", "harem", "эрот", "проститут", "гарем")):
            preferred = [("ru", "Эротическое искусство"), ("en", "Erotic art")]
        elif any(x in evidence for x in ("bather", "bathing", "купаль", "купающ")):
            preferred = [("en", "Bather"), ("ru", "Обнажённая натура"), ("en", "Nude (art)")]
        else:
            preferred = [("ru", "Обнажённая натура"), ("en", "Nude (art)")]
        for key in preferred:
            page = generic_pages.get(key)
            if page:
                result = page_context(key[0], key[1], page)
                if result:
                    return result
        return None

    for offset in range(0, total, 50):
        if len(accepted) >= target:
            break
        batch_candidates = [c for c in candidates[offset:offset + 50] if c.qid not in used_qids]
        if not batch_candidates:
            continue
        entities = client.entities([c.qid for c in batch_candidates])

        eligible: list[Candidate] = []
        ru_titles: list[str] = []
        en_titles: list[str] = []
        creator_ids: set[str] = set()
        artist_titles: set[str] = set()
        for c in batch_candidates:
            e = entities.get(c.qid, {})
            if e.get("missing") is not None or not candidate_is_painting(c, e):
                continue
            ru = sitelink(e, "ru")
            en = sitelink(e, "en")
            if ru:
                ru_titles.append(ru)
            if en:
                en_titles.append(en)
            creator_ids.update(contextual_qids(e))
            if c.artist:
                artist_titles.add(c.artist)
            eligible.append(c)

        ru_pages: dict[str, dict[str, Any]] = {}
        en_pages: dict[str, dict[str, Any]] = {}
        for i in range(0, len(ru_titles), 30):
            ru_pages.update(client.wiki_pages("ru", ru_titles[i:i + 30]))
        for i in range(0, len(en_titles), 30):
            en_pages.update(client.wiki_pages("en", en_titles[i:i + 30]))

        creator_entities: dict[str, dict[str, Any]] = {}
        creator_ru_pages: dict[str, dict[str, Any]] = {}
        creator_en_pages: dict[str, dict[str, Any]] = {}
        creator_ru_titles: list[str] = []
        creator_en_titles: list[str] = []
        ordered_creator_ids = sorted(creator_ids, key=lambda x: int(x[1:]))
        for i in range(0, len(ordered_creator_ids), 50):
            creator_entities.update(client.entities(ordered_creator_ids[i:i + 50]))
        for entity in creator_entities.values():
            ru = sitelink(entity, "ru")
            en = sitelink(entity, "en")
            if ru:
                creator_ru_titles.append(ru)
            if en:
                creator_en_titles.append(en)
        for i in range(0, len(creator_ru_titles), 30):
            creator_ru_pages.update(client.wiki_pages("ru", creator_ru_titles[i:i + 30]))
        for i in range(0, len(creator_en_titles), 30):
            creator_en_pages.update(client.wiki_pages("en", creator_en_titles[i:i + 30]))

        # Many museum items omit P170, while the offline candidate still has an exact
        # artist name. Query that exact title in both Wikipedias without fuzzy matching.
        artist_ru_pages: dict[str, dict[str, Any]] = {}
        artist_en_pages: dict[str, dict[str, Any]] = {}
        ordered_artist_titles = sorted(artist_titles)
        for i in range(0, len(ordered_artist_titles), 30):
            chunk = ordered_artist_titles[i:i + 30]
            artist_ru_pages.update(client.wiki_pages("ru", chunk))
            artist_en_pages.update(client.wiki_pages("en", chunk))

        for c in eligible:
            if len(accepted) >= target:
                break
            e = entities.get(c.qid, {})
            p18 = image_url_from_p18(p18_filename(e)) if p18_filename(e) else ""
            if p18 and not is_raster(p18):
                p18 = ""

            ru_title = sitelink(e, "ru")
            en_title = sitelink(e, "en")
            ru_page = ru_pages.get(ru_title, {}) if ru_title else {}
            en_page = en_pages.get(en_title, {}) if en_title else {}
            ru_exact = page_context("ru", ru_title, ru_page) if ru_title else None
            en_exact = page_context("en", en_title, en_page) if en_title else None
            exact = ru_exact or en_exact

            article_image = p18 or page_image_url(ru_page) or page_image_url(en_page)
            source_kind = ""
            context: tuple[str, str, str] | None = None
            image = ""
            if exact and article_image:
                context = exact
                image = article_image
                source_kind = "artwork_article"
            elif p18:
                # Description fallback 1: creator's exact Wikipedia article.
                for creator_qid in contextual_qids(e):
                    creator = creator_entities.get(creator_qid, {})
                    crt_ru = sitelink(creator, "ru")
                    crt_en = sitelink(creator, "en")
                    if crt_ru:
                        context = page_context("ru", crt_ru, creator_ru_pages.get(crt_ru, {}))
                    if context is None and crt_en:
                        context = page_context("en", crt_en, creator_en_pages.get(crt_en, {}))
                    if context:
                        break
                # Description fallback 2: exact artist-name article.
                if context is None and c.artist:
                    context = page_context("ru", c.artist, artist_ru_pages.get(c.artist, {}))
                    if context is None:
                        context = page_context("en", c.artist, artist_en_pages.get(c.artist, {}))
                # Last textual fallback remains Wikipedia, not generated wording.
                if context is None:
                    context = generic_context(c)
                if context:
                    image = p18
                    source_kind = "wikipedia_context"

            if not context or not image or image in used_images:
                continue
            chosen_language, source_title, chosen_extract = context
            display_title = (
                source_title if source_kind == "artwork_article"
                else label(e, "ru") or label(e, "en") or c.title or "Без названия"
            )
            combined = " ".join((
                c.title, c.artist, c.evidence, label(e, "ru"), label(e, "en"),
                description(e, "ru"), description(e, "en"), display_title,
                " ".join(c.category_evidence),
            ))
            if mode == "NSFW":
                ok, reason = nsfw_is_strict(combined, c.nsfw_strength)
            else:
                ok = safe_is_strict(combined, c.safe_hint)
                reason = "проверенная живопись без признаков NSFW"
            if not ok:
                continue
            accepted.append(Resolved(
                c, e, chosen_language, source_title, display_title, chosen_extract,
                image, creator_qids(e), reason, source_kind,
            ))
            used_qids.add(c.qid)
            used_images.add(image)
        print(f"{mode}: checked {min(offset + 50, total)}/{total}; accepted {len(accepted)}/{target}", flush=True)
    return accepted


def normalize_match(value: str) -> str:
    value = re.sub(r"[^\w\s]", " ", clean_text(value).casefold(), flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def match_score(expected: str, actual: str) -> float:
    a = set(normalize_match(expected).split())
    b = set(normalize_match(actual).split())
    if not a or not b:
        return 0.0
    if normalize_match(expected) == normalize_match(actual):
        return 1.0
    return len(a & b) / len(a | b)


def fallback_search_candidates(client: ApiClient, seeds: list[dict[str, Any]], mode: str,
                               existing_qids: set[str], max_searches: int = 5000) -> list[Candidate]:
    relevant = [s for s in seeds if s.get("mode") == mode]
    relevant = relevant[:max_searches]

    def one(seed: dict[str, Any]) -> Candidate | None:
        title = clean_text(seed.get("title")); artist = clean_text(seed.get("artist"))
        if not title:
            return None
        query = clean_text(title + " " + artist)
        def choose(results: list[dict[str, Any]]) -> tuple[float, dict[str, Any]] | None:
            best_value: tuple[float, dict[str, Any]] | None = None
            for result in results:
                qid = str(result.get("id", ""))
                if qid in existing_qids or not re.fullmatch(r"Q\d+", qid):
                    continue
                score = match_score(title, clean_text(result.get("label")))
                desc = clean_text(result.get("description"))
                if "painting" in desc.casefold() or "картина" in desc.casefold():
                    score += 0.25
                if best_value is None or score > best_value[0]:
                    best_value = (score, result)
            return best_value

        try:
            best = choose(client.search_entities(query))
            if best is None or best[0] < 0.55:
                best = choose(client.search_entities(title))
        except Exception as exc:
            print(f"Search skipped for {query}: {exc}", file=sys.stderr, flush=True)
            return None
        if best is None or best[0] < 0.55:
            return None
        result = best[1]
        tags = " ".join(clean_text(x) for x in seed.get("tags", []))
        return Candidate(
            qid=str(result["id"]), title=title, artist=artist,
            year=seed.get("year") if isinstance(seed.get("year"), int) else None,
            evidence=clean_text(title + " " + artist + " " + tags),
            safe_hint=(mode == "FILTER"), nsfw_strength=3 if mode == "NSFW" else 0,
        )

    found: dict[str, Candidate] = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        for index, candidate in enumerate(executor.map(one, relevant), start=1):
            if candidate is not None:
                found.setdefault(candidate.qid, candidate)
            if index % 100 == 0:
                print(f"Fallback search {mode}: {index}/{len(relevant)}; QIDs={len(found)}", flush=True)
    return list(found.values())


def resolve_creator_names(client: ApiClient, resolved: list[Resolved]) -> dict[str, str]:
    qids = sorted({qid for item in resolved for qid in item.creators}, key=lambda x: int(x[1:]))
    names: dict[str, str] = {}
    for offset in range(0, len(qids), 50):
        entities = client.entities(qids[offset:offset + 50])
        for qid, entity in entities.items():
            names[qid] = label(entity, "ru") or label(entity, "en") or qid
    return names


def build_items(client: ApiClient, resolved: list[Resolved], mode: str) -> list[dict[str, Any]]:
    creator_names = resolve_creator_names(client, resolved)
    items: list[dict[str, Any]] = []
    for index, item in enumerate(resolved, start=1):
        c, e = item.candidate, item.entity
        artists = [creator_names.get(qid, qid) for qid in item.creators]
        artist = ", ".join(artists) or c.artist or "Автор неизвестен"
        year = c.year if c.year is not None else inception_year(e)
        items.append({
            "catalog_index": index,
            "stable_id": stable_id(c.qid, item.image_url),
            "qid": c.qid,
            "dedupe_key": c.qid,
            "artist": artist,
            "title": item.display_title or label(e, item.language) or c.title or "Без названия",
            "year": year,
            "style": "",
            "tags": [],
            "description": item.extract,
            "description_ru": item.extract,
            "content_mode": mode,
            "content_confidence": "high",
            "content_reason": item.reason,
            "source_provider": "Wikipedia.org",
            "source_language": item.language,
            "source_page_url": article_url(item.language, item.source_page_title),
            "image_url": item.image_url,
            "original_image_url": item.image_url,
            "image_resolver": {"type": "wikidata_p18_or_exact_article_pageimage", "qid": c.qid},
            "description_source_kind": item.source_kind,
            "requires_image_resolution": False,
            "verification_status": "wikidata_image_wikipedia_text_machine_validated",
        })
    return items


def strip_html_text(value: Any) -> str:
    text = str(value or "")
    text = re.sub(r"<br\s*/?>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return clean_text(text)


def extmetadata_value(info: dict[str, Any], key: str) -> str:
    value = ((info.get("extmetadata") or {}).get(key) or {}).get("value", "")
    return str(value or "")


def wikipedia_link_from_html(value: str) -> tuple[str, str] | None:
    for language in ("ru", "en"):
        pattern = r"href=[\"'](?:https?:)?//" + language + r"\.wikipedia\.org/wiki/([^\"'#?]+)"
        match = re.search(pattern, str(value or ""), flags=re.I)
        if match:
            title = urllib.parse.unquote(match.group(1)).replace("_", " ")
            return language, clean_text(title)
    return None


def commons_display_title(file_title: str, object_name: str, image_description: str) -> str:
    object_text = strip_html_text(object_name)
    generic = {"painting", "oil painting", "artwork", "work of art", "картина", "живопись"}
    if object_text and object_text.casefold() not in generic and len(object_text) <= 180:
        return object_text
    name = file_title.split(":", 1)[-1]
    name = urllib.parse.unquote(name)
    name = re.sub(r"\.(jpe?g|png|webp)$", "", name, flags=re.I)
    name = name.replace("_", " ")
    name = re.sub(r"\s+", " ", name).strip(" -_")
    if name and len(name) <= 220:
        return name
    description_text = strip_html_text(image_description)
    if description_text:
        return description_text[:220].strip()
    return "Без названия"


def artwork_meta_key(artist: str, title: str) -> str:
    return normalize_match(artist) + "|" + normalize_match(title)


def build_commons_nsfw_items(
    client: ApiClient,
    target: int,
    start_index: int,
    excluded_images: set[str],
    excluded_keys: set[str],
    *,
    max_depth: int = 4,
    max_files: int = 8000,
) -> list[dict[str, Any]]:
    """Fill strict NSFW records from exact Commons category membership.

    This is not a fuzzy title search. Every image is an exact file member of a
    strong nude/erotic painting category. Descriptive text still comes from a
    Russian or English Wikipedia article, preferably the creator's article.
    """
    discovered: dict[int, dict[str, Any]] = {}
    seen_categories: set[str] = set()
    queue: list[tuple[str, int, int, str]] = [
        (name, strength, 0, name) for name, strength in COMMONS_NSFW_CATEGORIES
    ]
    blocked_subcategory_words = (
        "child", "children", "boy", "boys", "girl", "girls", "baby", "babies",
        "infant", "adolescent", "teen", "youth", "young", "putti", "putto", "cherub",
        "schoolchildren", "sculpture", "statue", "photograph", "photography",
        "drawing", "sketch", "engraving", "etching", "lithograph", "printmaking",
        "watercolor", "watercolour", "pastel", "fresco", "mural", "mosaic",
        "relief", "film", "pornograph", "manuscript", "illustration",
    )
    while queue and len(discovered) < max_files:
        category, strength, depth, root = queue.pop(0)
        key = category.casefold()
        if key in seen_categories:
            continue
        seen_categories.add(key)
        continuation = ""
        while True:
            payload = client.commons_category_members(category, continuation)
            members = ((payload.get("query") or {}).get("categorymembers") or [])
            for member in members:
                ns = member.get("ns")
                title = clean_text(member.get("title"))
                if ns == 14 and depth < max_depth:
                    sub = title.split(":", 1)[1] if ":" in title else title
                    low = sub.casefold()
                    if any(word in low for word in blocked_subcategory_words):
                        continue
                    queue.append((sub, strength, depth + 1, root))
                elif ns == 6:
                    try:
                        pageid = int(member.get("pageid"))
                    except Exception:
                        continue
                    row = discovered.setdefault(pageid, {
                        "pageid": pageid, "title": title, "strength": strength, "roots": set(),
                    })
                    row["strength"] = max(int(row.get("strength", 0)), strength)
                    row["roots"].add(root)
                    if len(discovered) >= max_files:
                        break
            continuation = ((payload.get("continue") or {}).get("cmcontinue") or "")
            if not continuation or len(discovered) >= max_files:
                break
        print(f"Commons category scan: {category}; files={len(discovered)}", flush=True)

    raw_records: list[dict[str, Any]] = []
    used_images = set(excluded_images)
    used_keys = set(excluded_keys)
    pageids = sorted(discovered)
    for offset in range(0, len(pageids), 30):
        pages = client.commons_file_info(pageids[offset:offset + 30])
        for pageid in pageids[offset:offset + 30]:
            page = pages.get(pageid, {})
            info_list = page.get("imageinfo") or []
            if not info_list:
                continue
            info = info_list[0] or {}
            mime = str(info.get("mime", "")).casefold()
            if mime not in {"image/jpeg", "image/png", "image/webp"}:
                continue
            original = str(info.get("url", "") or "")
            thumb = str(info.get("thumburl", "") or "")
            image = thumb if is_raster(thumb) else original
            if not is_raster(image) or image in used_images:
                continue

            file_title = clean_text(page.get("title") or discovered[pageid].get("title"))
            roots = sorted(discovered[pageid].get("roots") or [])
            categories = " ".join(clean_text(x.get("title")) for x in (page.get("categories") or []))
            artist_html = extmetadata_value(info, "Artist")
            object_name = extmetadata_value(info, "ObjectName")
            image_description = extmetadata_value(info, "ImageDescription")
            medium = extmetadata_value(info, "Medium")
            date_text = strip_html_text(extmetadata_value(info, "DateTimeOriginal") or extmetadata_value(info, "DateTime"))
            metadata_text = " ".join((
                file_title, " ".join(roots), categories, strip_html_text(object_name),
                strip_html_text(image_description), strip_html_text(medium), strip_html_text(artist_html),
            ))
            if contains_any(metadata_text, MINOR_MARKERS + NON_PAINTING_MARKERS):
                continue
            ok, reason = nsfw_is_strict(metadata_text, int(discovered[pageid].get("strength", 3)))
            if not ok:
                continue
            painting_evidence = " ".join(roots) + " " + categories + " " + strip_html_text(medium)
            if not contains_any(painting_evidence, (
                "painting", "paintings", "oil", "canvas", "tempera", "panel",
                "картина", "живопис", "масло", "холст", "темпера", "доска",
            )):
                continue

            artist = strip_html_text(artist_html)
            artist = re.sub(r"\s*\([^)]*(?:born|died|–|—|\d{4})[^)]*\)\s*$", "", artist, flags=re.I).strip()
            if artist.casefold() in {"", "unknown", "anonymous", "неизвестен", "неизвестный автор"}:
                artist = "Автор неизвестен"
            title = commons_display_title(file_title, object_name, image_description)
            key = artwork_meta_key(artist, title)
            if not normalize_match(title) or key in used_keys:
                continue
            year = None
            match = re.search(r"(?<!\d)(1[0-9]{3}|20[0-2][0-9])(?!\d)", date_text)
            if match:
                year = int(match.group(1))
            raw_records.append({
                "pageid": pageid, "file_title": file_title, "title": title,
                "artist": artist, "artist_html": artist_html, "year": year,
                "roots": roots, "reason": reason, "image": image,
                "original": original if is_raster(original) else image, "key": key,
            })
            used_images.add(image)
            used_keys.add(key)
            if len(raw_records) >= target * 3:
                break
        if len(raw_records) >= target * 3:
            break
        if offset % 300 == 0:
            print(f"Commons file validation: {min(offset + 30, len(pageids))}/{len(pageids)}; candidates={len(raw_records)}", flush=True)

    requested: dict[str, set[str]] = {"ru": set(), "en": set()}
    for row in raw_records:
        linked = wikipedia_link_from_html(row["artist_html"])
        row["artist_wiki_link"] = linked
        if linked:
            requested[linked[0]].add(linked[1])
        if row["artist"] != "Автор неизвестен":
            requested["ru"].add(row["artist"])
            requested["en"].add(row["artist"])
    generic_titles = {
        "ru": ["Обнажённая натура", "Эротическое искусство", "Одалиска"],
        "en": ["Nude (art)", "Erotic art", "Odalisque", "Bather"],
    }
    for language, titles in generic_titles.items():
        requested[language].update(titles)

    wiki_pages: dict[tuple[str, str], dict[str, Any]] = {}
    for language in ("ru", "en"):
        titles = sorted(requested[language])
        for offset in range(0, len(titles), 30):
            chunk = titles[offset:offset + 30]
            pages = client.wiki_pages(language, chunk)
            for requested_title, page in pages.items():
                if clean_text(page.get("extract")):
                    wiki_pages[(language, requested_title)] = page

    def context_from(language: str, requested_title: str) -> tuple[str, str, str] | None:
        page = wiki_pages.get((language, requested_title), {})
        extract = clean_text(page.get("extract"))
        if not extract:
            return None
        page_title = clean_text(page.get("title", requested_title)) or requested_title
        return language, page_title, extract

    def choose_context(row: dict[str, Any]) -> tuple[str, str, str, str] | None:
        linked = row.get("artist_wiki_link")
        if linked:
            context = context_from(linked[0], linked[1])
            if context:
                return (*context, "creator_article")
        if row["artist"] != "Автор неизвестен":
            context = context_from("ru", row["artist"]) or context_from("en", row["artist"])
            if context:
                return (*context, "creator_article")
        roots_text = " ".join(row["roots"]).casefold()
        if "odalis" in roots_text or "одалиск" in roots_text:
            choices = [("ru", "Одалиска"), ("en", "Odalisque")]
        elif "erotic" in roots_text or "эрот" in roots_text:
            choices = [("ru", "Эротическое искусство"), ("en", "Erotic art")]
        elif "bather" in roots_text or "bathing" in roots_text:
            choices = [("en", "Bather"), ("ru", "Обнажённая натура"), ("en", "Nude (art)")]
        else:
            choices = [("ru", "Обнажённая натура"), ("en", "Nude (art)")]
        for language, title in choices:
            context = context_from(language, title)
            if context:
                return (*context, "art_topic_article")
        return None

    items: list[dict[str, Any]] = []
    for row in raw_records:
        context = choose_context(row)
        if not context:
            continue
        language, source_title, extract, source_kind = context
        identity = f"commons:{row['pageid']}"
        stable = identity + ":" + hashlib.sha256((identity + "|" + row["image"]).encode()).hexdigest()[:16]
        file_page = "https://commons.wikimedia.org/wiki/" + urllib.parse.quote(
            row["file_title"].replace(" ", "_"), safe=":()_',-.~"
        )
        items.append({
            "catalog_index": start_index + len(items),
            "stable_id": stable,
            "qid": identity,
            "dedupe_key": row["key"],
            "artist": row["artist"],
            "title": row["title"],
            "year": row["year"],
            "style": "",
            "tags": row["roots"],
            "description": extract,
            "description_ru": extract,
            "content_mode": "NSFW",
            "content_confidence": "high",
            "content_reason": "точное членство файла в категории обнажённой или эротической живописи",
            "source_provider": "Wikipedia.org",
            "source_language": language,
            "source_page_url": article_url(language, source_title),
            "commons_file_page_url": file_page,
            "image_url": row["image"],
            "original_image_url": row["original"],
            "image_resolver": {"type": "commons_category_exact_file", "pageid": row["pageid"]},
            "description_source_kind": source_kind,
            "requires_image_resolution": False,
            "verification_status": "commons_category_image_wikipedia_text_machine_validated",
        })
        if len(items) >= target:
            break
    print(f"Commons NSFW accepted: {len(items)}/{target}", flush=True)
    return items

def catalog_document(name: str, mode: str, items: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "schema_version": 6,
        "catalog_name": name,
        "catalog_mode": mode,
        "catalog_version": VERSION,
        "item_count": len(items),
        "source": {
            "dataset": "Exact Wikidata items discovered from fixed QIDs and Wikipedia painting categories",
            "selection_rule": "Russian Wikipedia first; English Wikipedia fallback; artwork image from exact QID P18 or the exact artwork article PageImages",
            "commons_title_search_used": False,
            "wikiart_used": False,
            "sparql_used": False,
        },
        "production_status": "bundled_verified_wikidata_images_with_wikipedia_descriptions",
        "items": items,
    }


def validate(filter_doc: dict[str, Any], nsfw_doc: dict[str, Any], target: int) -> dict[str, Any]:
    errors: list[str] = []
    summaries: dict[str, Any] = {}
    all_qids: set[str] = set(); all_images: set[str] = set()
    for name, doc, mode in (("filter", filter_doc, "FILTER"), ("nsfw", nsfw_doc, "NSFW")):
        items = doc.get("items") if isinstance(doc.get("items"), list) else []
        qids: set[str] = set(); images: set[str] = set(); ids: set[str] = set(); ru = 0
        for index, item in enumerate(items, start=1):
            prefix = f"{name}[{index}]"
            sid = str(item.get("stable_id", "")); qid = str(item.get("qid", ""))
            image = str(item.get("image_url", "")); source = str(item.get("source_page_url", ""))
            desc = clean_text(item.get("description"))
            if not sid or sid in ids: errors.append(prefix + ": duplicate/empty stable_id")
            if not (re.fullmatch(r"Q\d+", qid) or re.fullmatch(r"commons:\d+", qid)) or qid in qids:
                errors.append(prefix + ": invalid/duplicate artwork identity")
            if not image or image in images or not is_raster(image): errors.append(prefix + ": invalid/duplicate raster image")
            if not re.match(r"^https://(ru|en)\.wikipedia\.org/wiki/.+", source): errors.append(prefix + ": no exact Wikipedia article")
            if not desc: errors.append(prefix + ": empty Wikipedia description")
            if item.get("content_mode") != mode: errors.append(prefix + ": wrong mode")
            if item.get("requires_image_resolution") is not False: errors.append(prefix + ": unresolved image")
            if item.get("verification_status") not in {
                "exact_qid_article_p18_machine_validated",
                "wikidata_image_wikipedia_text_machine_validated",
                "commons_category_image_wikipedia_text_machine_validated",
            }:
                errors.append(prefix + ": unverified record")
            ids.add(sid); qids.add(qid); images.add(image)
            if item.get("source_language") == "ru": ru += 1
        if len(items) != target: errors.append(f"{name}: {len(items)} items, expected {target}")
        if all_qids & qids: errors.append(name + ": cross-catalog QID overlap")
        if all_images & images: errors.append(name + ": cross-catalog image overlap")
        all_qids.update(qids); all_images.update(images)
        summaries[name] = {"records": len(items), "unique_ids": len(ids), "unique_qids": len(qids), "unique_images": len(images), "russian_articles": ru}
    return {
        "version": VERSION, "valid": not errors, "errors": errors, "catalogs": summaries,
        "cross_catalog_overlap": 0 if not errors else None,
        "rules": {"wikipedia_priority": "ru -> en", "image_resolution": "exact Wikidata QID P18, exact artwork article PageImages, or exact Commons painting-category file", "commons_fuzzy_search": False, "commons_category_membership": True, "wikiart": False, "sparql": False, "descriptions": "Wikipedia article introduction; creator/topic article only when the artwork has no own article"},
    }


def run_fixture(path: Path, target: int) -> tuple[dict[str, Any], dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    def make(rows: list[dict[str, Any]], mode: str) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        extracts = data.get("extracts", {})
        for row in rows[:target]:
            qid = str(row.get("item", "")).rstrip("/").rsplit("/", 1)[-1]
            lang = "ru" if row.get("articleRu") else "en"
            source = row.get("articleRu") or row.get("articleEn")
            info = extracts.get(qid + "|" + lang, {})
            image = str(row.get("image", "")).replace("http://", "https://", 1)
            result.append({
                "catalog_index": len(result)+1, "stable_id": stable_id(qid, image), "qid": qid,
                "dedupe_key": qid, "artist": row.get("creatorRu") or row.get("creatorEn") or "Автор неизвестен",
                "title": info.get("title") or row.get("labelRu") or row.get("labelEn"), "year": None,
                "style": "", "tags": [], "description": info.get("extract", ""), "description_ru": info.get("extract", ""),
                "content_mode": mode, "content_confidence": "high", "content_reason": "fixture",
                "source_provider": "Wikipedia.org", "source_language": lang, "source_page_url": source,
                "image_url": image, "original_image_url": image,
                "image_resolver": {"type": "wikidata_p18_exact", "qid": qid},
                "requires_image_resolution": False, "verification_status": "exact_qid_article_p18_machine_validated",
            })
        return result
    return catalog_document("filter_catalog_1000", "FILTER", make(data.get("safe_rows", []), "FILTER")), catalog_document("nsfw_catalog_1000", "NSFW", make(data.get("nsfw_rows", []), "NSFW"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=Path("app/src/main/assets"))
    parser.add_argument("--report", type=Path, default=Path("CATALOG_VALIDATION_V12_3_1.json"))
    parser.add_argument("--cache-dir", type=Path, default=Path(".catalog-cache-v2"))
    parser.add_argument("--candidate-pool", type=Path, default=Path("tools/catalog_candidates.json.gz"))
    parser.add_argument("--target", type=int, default=1000)
    parser.add_argument("--category-depth", type=int, default=4)
    parser.add_argument("--category-page-limit", type=int, default=6000)
    parser.add_argument("--fixture", type=Path)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    if args.fixture:
        filter_doc, nsfw_doc = run_fixture(args.fixture, args.target)
    else:
        client = ApiClient(args.cache_dir)
        fixed, seeds = load_pool(args.candidate_pool)

        nsfw_categories = discover_category_candidates(
            client, NSFW_CATEGORIES, max_depth=args.category_depth,
            max_pages=args.category_page_limit, traverse_all_subcategories=True,
        )
        for qid, candidate in nsfw_categories.items():
            fixed.setdefault(qid, Candidate(qid)).merge(candidate)
        nsfw_candidates = [c for c in fixed.values() if c.nsfw_strength > 0]
        nsfw_candidates.sort(key=lambda c: (-c.nsfw_strength, 0 if c.category_evidence else 1, int(c.qid[1:])))
        print(f"NSFW candidate QIDs: {len(nsfw_candidates)}", flush=True)
        nsfw_resolved = resolve_candidates(client, nsfw_candidates, "NSFW", args.target, set(), set())
        if len(nsfw_resolved) < args.target:
            missing = args.target - len(nsfw_resolved)
            print(f"NSFW fixed/category pool short by {missing}; starting exact-title fallback", flush=True)
            searched = fallback_search_candidates(client, seeds, "NSFW", {x.candidate.qid for x in nsfw_resolved})
            extra = resolve_candidates(client, searched, "NSFW", missing,
                                       {x.candidate.qid for x in nsfw_resolved}, {x.image_url for x in nsfw_resolved})
            nsfw_resolved.extend(extra)
        nsfw_items = build_items(client, nsfw_resolved, "NSFW")
        if len(nsfw_items) < args.target:
            missing = args.target - len(nsfw_items)
            print(f"NSFW Wikidata/Wikipedia pool short by {missing}; starting exact Commons-category fallback", flush=True)
            existing_keys = {artwork_meta_key(str(item.get("artist", "")), str(item.get("title", ""))) for item in nsfw_items}
            commons_items = build_commons_nsfw_items(
                client, missing, len(nsfw_items) + 1,
                {str(item.get("image_url", "")) for item in nsfw_items},
                existing_keys,
                max_depth=args.category_depth,
                max_files=max(args.category_page_limit, 8000),
            )
            nsfw_items.extend(commons_items)
        if len(nsfw_items) != args.target:
            raise RuntimeError(f"Not enough verified NSFW paintings after exact Commons fallback: {len(nsfw_items)} of {args.target}")

        used_qids = {x.candidate.qid for x in nsfw_resolved}
        used_images = {str(item.get("image_url", "")) for item in nsfw_items}
        safe_categories = discover_category_candidates(
            client, SAFE_CATEGORIES, max_depth=min(args.category_depth, 3),
            max_pages=args.category_page_limit, traverse_all_subcategories=False,
        )
        for qid, candidate in safe_categories.items():
            fixed.setdefault(qid, Candidate(qid)).merge(candidate)
        safe_candidates = [c for c in fixed.values() if c.safe_hint and c.qid not in used_qids]
        safe_candidates.sort(key=lambda c: (0 if c.category_evidence else 1, int(c.qid[1:])))
        print(f"FILTER candidate QIDs: {len(safe_candidates)}", flush=True)
        filter_resolved = resolve_candidates(client, safe_candidates, "FILTER", args.target, used_qids, used_images)
        if len(filter_resolved) < args.target:
            missing = args.target - len(filter_resolved)
            print(f"FILTER fixed/category pool short by {missing}; starting exact-title fallback", flush=True)
            searched = fallback_search_candidates(client, seeds, "FILTER", used_qids | {x.candidate.qid for x in filter_resolved})
            extra = resolve_candidates(client, searched, "FILTER", missing,
                                       used_qids | {x.candidate.qid for x in filter_resolved},
                                       used_images | {x.image_url for x in filter_resolved})
            filter_resolved.extend(extra)
        if len(filter_resolved) != args.target:
            raise RuntimeError(f"Not enough verified FILTER paintings: {len(filter_resolved)} of {args.target}")

        filter_items = build_items(client, filter_resolved, "FILTER")
        filter_doc = catalog_document("filter_catalog_1000", "FILTER", filter_items)
        nsfw_doc = catalog_document("nsfw_catalog_1000", "NSFW", nsfw_items)

    report = validate(filter_doc, nsfw_doc, args.target)
    if not report["valid"]:
        raise RuntimeError("Catalog validation failed:\n" + "\n".join(report["errors"][:100]))
    (args.output_dir / "filter_catalog.json").write_text(json.dumps(filter_doc, ensure_ascii=False, indent=2), encoding="utf-8")
    (args.output_dir / "nsfw_catalog.json").write_text(json.dumps(nsfw_doc, ensure_ascii=False, indent=2), encoding="utf-8")
    manifest = {
        "schema_version": 6, "catalog_version": VERSION,
        "filter_asset": "filter_catalog.json", "filter_count": args.target,
        "nsfw_asset": "nsfw_catalog.json", "nsfw_count": args.target,
        "source_label": "Wikipedia.org", "descriptions": "Wikipedia article introduction",
        "image_rule": "exact Wikidata QID P18, exact article PageImages, or exact Commons painting-category file",
        "production_status": "ready_for_apk_embedding",
        "generator": "fixed QIDs + Wikipedia categories + exact Commons category membership; no SPARQL, no fuzzy Commons title search",
    }
    (args.output_dir / "catalog_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print("CATALOG BUILD FAILED: " + str(exc), file=sys.stderr, flush=True)
        raise
