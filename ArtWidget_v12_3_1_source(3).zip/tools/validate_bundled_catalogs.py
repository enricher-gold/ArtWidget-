#!/usr/bin/env python3
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from pathlib import Path


def load_builder(path: Path):
    spec = importlib.util.spec_from_file_location("catalog_builder", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--assets", type=Path, default=Path("app/src/main/assets"))
    parser.add_argument("--target", type=int, default=1000)
    parser.add_argument("--report", type=Path, default=Path("CATALOG_VALIDATION_V12_3_1.json"))
    args = parser.parse_args()

    root = Path(__file__).resolve().parent.parent
    builder = load_builder(root / "tools" / "build_bundled_wikipedia_catalogs.py")
    filter_doc = json.loads((args.assets / "filter_catalog.json").read_text(encoding="utf-8"))
    nsfw_doc = json.loads((args.assets / "nsfw_catalog.json").read_text(encoding="utf-8"))
    report = builder.validate(filter_doc, nsfw_doc, args.target)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    if not report["valid"]:
        raise SystemExit("\n".join(report["errors"][:100]))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
