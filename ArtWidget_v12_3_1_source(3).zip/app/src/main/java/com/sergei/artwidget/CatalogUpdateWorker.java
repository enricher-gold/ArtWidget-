package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Проверяет встроенную часть каталога без сетевого пополнения. */
public class CatalogUpdateWorker extends Worker {
    public static final String KEY_ADULT = "adult";
    public static final String KEY_FORCE = "force";

    public CatalogUpdateWorker(@NonNull Context context,
                               @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        boolean adult = getInputData().getBoolean(KEY_ADULT, false);
        boolean force = getInputData().getBoolean(KEY_FORCE, false);
        int mode = adult ? ArtRepository.CONTENT_ADULT_ONLY : ArtRepository.CONTENT_FILTER;
        long started = System.currentTimeMillis();
        try {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            repo.initializeStorageInBackground();
            int remaining = repo.getRemainingForMode(mode, true);
            if (!force && remaining > CatalogWorkScheduler.REFILL_THRESHOLD) {
                repo.setCatalogPartStatus(adult, "запас " + remaining + ", обновление не требуется");
                return Result.success();
            }
            String result = repo.updateCatalogPart(adult);
            int after = repo.getRemainingForMode(mode, true);
            AppLogger.log(getApplicationContext(), adult ? "nsfw-worker" : "filter-worker", "ok",
                    result + " | remaining=" + after + " | "
                            + (System.currentTimeMillis() - started) + " ms");
            if (after < CatalogWorkScheduler.TARGET_REMAINING && repo.canContinueCatalogUpdate(adult)) {
                return Result.retry();
            }
            return Result.success();
        } catch (Exception e) {
            AppLogger.log(getApplicationContext(), adult ? "nsfw-worker" : "filter-worker", "error",
                    e.getMessage() + " | " + (System.currentTimeMillis() - started) + " ms");
            return Result.retry();
        }
    }
}
