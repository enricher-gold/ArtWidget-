package com.sergei.artwidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ThumbnailLoader {
    private final Context context;
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final LruCache<String, Bitmap> cache;

    public ThumbnailLoader(Context context) {
        this.context = context.getApplicationContext();
        int maxKb = (int) (Runtime.getRuntime().maxMemory() / 1024L);
        cache = new LruCache<String, Bitmap>(Math.max(8 * 1024, maxKb / 10)) {
            @Override protected int sizeOf(String key, Bitmap bitmap) {
                return Math.max(1, bitmap.getByteCount() / 1024);
            }
        };
    }

    public void load(ImageView view, ArtEntry entry, int targetPx, boolean allowTemporaryNetwork) {
        if (view == null || entry == null) return;
        String key = entry.qid + "@" + targetPx;
        view.setTag(key);
        Bitmap cached = cache.get(key);
        if (cached != null && !cached.isRecycled()) {
            view.setImageBitmap(cached);
            return;
        }
        view.setImageDrawable(null);
        executor.execute(() -> {
            Bitmap bitmap = null;
            try {
                File file = entry.localPath == null ? null : new File(entry.localPath);
                if ((file == null || !file.exists() || file.length() == 0) && allowTemporaryNetwork) {
                    file = new ArtRepository(context).downloadTemporaryThumbnail(entry);
                }
                if (file != null && file.exists() && file.length() > 0) {
                    bitmap = decodeSampled(file.getAbsolutePath(), targetPx);
                }
            } catch (Exception e) {
                AppLogger.log(context, "thumbnail", "error", entry.qid + " | " + e.getMessage());
            }
            final Bitmap result = bitmap;
            if (result != null) cache.put(key, result);
            main.post(() -> {
                Object tag = view.getTag();
                if (key.equals(tag) && result != null) view.setImageBitmap(result);
            });
        });
    }

    public void shutdown() {
        executor.shutdownNow();
        cache.evictAll();
    }

    private Bitmap decodeSampled(String path, int targetPx) {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null;
        int sample = 1;
        while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > targetPx * 2) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        opts.inPreferredConfig = Bitmap.Config.RGB_565;
        return BitmapFactory.decodeFile(path, opts);
    }
}
