package com.sergei.artwidget;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class AppLogger {
    private static final Object LOCK = new Object();
    private static final String FILE_NAME = "artwidget.log";
    private static final int MAX_BYTES = 180_000;

    private AppLogger() { }

    public static void log(Context context, String operation, String result, String details) {
        if (context == null) return;
        synchronized (LOCK) {
            try {
                File file = new File(context.getApplicationContext().getFilesDir(), FILE_NAME);
                if (file.exists() && file.length() > MAX_BYTES) trim(file);
                String timestamp = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(new Date());
                String line = timestamp + " | " + clean(operation) + " | " + clean(result) + " | " + clean(details) + "\n";
                try (FileOutputStream out = new FileOutputStream(file, true)) {
                    out.write(line.getBytes("UTF-8"));
                }
            } catch (Exception ignored) {
            }
        }
    }

    public static String read(Context context) {
        if (context == null) return "";
        synchronized (LOCK) {
            File file = new File(context.getApplicationContext().getFilesDir(), FILE_NAME);
            if (!file.exists()) return "Журнал пока пуст.";
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) sb.append(line).append('\n');
            } catch (Exception e) {
                return "Не удалось прочитать журнал.";
            }
            return sb.length() == 0 ? "Журнал пока пуст." : sb.toString();
        }
    }

    public static void clear(Context context) {
        if (context == null) return;
        synchronized (LOCK) {
            try {
                File file = new File(context.getApplicationContext().getFilesDir(), FILE_NAME);
                if (file.exists()) file.delete();
            } catch (Exception ignored) {
            }
        }
    }

    private static void trim(File file) {
        try {
            byte[] all = new byte[(int) file.length()];
            try (FileInputStream in = new FileInputStream(file)) {
                int read = in.read(all);
                if (read <= 0) return;
            }
            int keep = Math.min(all.length, MAX_BYTES / 2);
            try (FileOutputStream out = new FileOutputStream(file, false)) {
                out.write(all, all.length - keep, keep);
            }
        } catch (Exception ignored) {
        }
    }

    private static String clean(String value) {
        if (value == null) return "";
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 600 ? s.substring(0, 600) + "…" : s;
    }
}
