package com.sergei.artwidget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Импортирует готовые каталоги Wikipedia.org из APK. */
public final class PreloadedCatalogImporter {
    public static final String FILTER_ASSET = "filter_catalog.json";
    public static final String NSFW_ASSET = "nsfw_catalog.json";
    public static final int EXPECTED_PER_CATALOG = 1000;

    private PreloadedCatalogImporter() { }

    public static List<ArtEntry> loadAll(Context context) throws Exception {
        List<ArtEntry> out = new ArrayList<>(EXPECTED_PER_CATALOG * 2);
        out.addAll(load(context, FILTER_ASSET, false));
        out.addAll(load(context, NSFW_ASSET, true));
        if (out.size() != EXPECTED_PER_CATALOG * 2) {
            throw new IllegalStateException("В APK отсутствует полный каталог 1000+1000");
        }
        return out;
    }

    public static List<ArtEntry> load(Context context, String assetName, boolean explicit) throws Exception {
        String text = readAsset(context, assetName);
        JSONObject root = new JSONObject(text);
        JSONArray items = root.optJSONArray("items");
        if (items == null || items.length() != EXPECTED_PER_CATALOG) {
            throw new IllegalStateException(assetName + ": ожидается ровно " + EXPECTED_PER_CATALOG + " записей");
        }
        List<ArtEntry> out = new ArrayList<>(items.length());
        long now = System.currentTimeMillis();
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) throw new IllegalStateException(assetName + ": повреждена запись " + (i + 1));
            String qid = item.optString("qid", "").trim();
            String stableId = item.optString("stable_id", "").trim();
            String title = item.optString("title", "Без названия").trim();
            String artist = item.optString("artist", "Автор неизвестен").trim();
            String sourceUrl = item.optString("source_page_url", "").trim();
            String imageUrl = item.optString("image_url", "").trim();
            String originalImageUrl = item.optString("original_image_url", imageUrl).trim();
            String description = item.optString("description_ru",
                    item.optString("description", "")).trim();
            String tags = joinTags(item.optJSONArray("tags"));
            String style = item.optString("style", "").trim();
            String marker = explicit ? "bundled-nsfw" : "bundled-filter";
            String genre = tags.isEmpty() ? marker : marker + ", " + tags;
            if (!style.isEmpty()) genre += ", " + style;

            if (qid.isEmpty()) qid = stableId;
            if (qid.isEmpty()) throw invalid(assetName, i, "нет QID/stable_id");
            if (!isWikipediaArticle(sourceUrl)) throw invalid(assetName, i, "нет точной статьи Wikipedia.org");
            if (!isRasterImage(imageUrl)) throw invalid(assetName, i, "нет готового растрового изображения P18");
            if (description.isEmpty()) throw invalid(assetName, i, "нет описания из Wikipedia.org");

            out.add(new ArtEntry(
                    qid,
                    title.isEmpty() ? "Без названия" : title,
                    artist.isEmpty() ? "Автор неизвестен" : artist,
                    description,
                    imageUrl,
                    originalImageUrl.isEmpty() ? imageUrl : originalImageUrl,
                    "",
                    sourceUrl,
                    "painting",
                    "",
                    genre,
                    now,
                    0,
                    0,
                    explicit
            ));
        }
        return out;
    }

    private static IllegalStateException invalid(String assetName, int index, String message) {
        return new IllegalStateException(assetName + " [" + (index + 1) + "]: " + message);
    }

    private static boolean isWikipediaArticle(String value) {
        String lower = value == null ? "" : value.toLowerCase(Locale.ROOT);
        return lower.startsWith("https://ru.wikipedia.org/wiki/")
                || lower.startsWith("https://en.wikipedia.org/wiki/");
    }

    private static boolean isRasterImage(String value) {
        String lower = value == null ? "" : value.toLowerCase(Locale.ROOT);
        if (lower.isEmpty() || lower.contains(".svg") || lower.contains(".tif")
                || lower.contains(".pdf") || lower.contains(".djvu")) return false;
        return lower.contains(".jpg") || lower.contains(".jpeg")
                || lower.contains(".png") || lower.contains(".webp");
    }

    private static String joinTags(JSONArray tags) {
        if (tags == null || tags.length() == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tags.length(); i++) {
            String value = tags.optString(i, "").trim();
            if (value.isEmpty()) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(value);
        }
        return sb.toString();
    }

    private static String readAsset(Context context, String name) throws Exception {
        StringBuilder sb = new StringBuilder(2_000_000);
        try (InputStream input = context.getAssets().open(name);
             BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) >= 0) sb.append(buffer, 0, read);
        }
        return sb.toString();
    }
}
