# Art Widget 12.3.1 build notes

Current catalog builder revision: r4.

The APK build creates and validates exactly 1000 FILTER and 1000 NSFW records before packaging. Exact Wikidata/Wikipedia artwork records are used first. If the strict NSFW artwork pool is shorter than 1000, the remaining records are taken only from exact Wikimedia Commons painting-category file membership. Descriptions remain sourced from Wikipedia.org.

No SPARQL, WikiArt, fuzzy Commons title matching or synthetic descriptions are used. Minor-related content and non-painting media are rejected.

See `BUILD_FIX_V12_3_1_R4.md` for the detailed fix.
