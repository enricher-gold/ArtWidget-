package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/**
 * Совместимый заглушечный Worker для заданий, сохранённых версией 14.1.3.
 * Начиная с 14.2.0 фоновое пополнение кэша изображений отключено.
 */
public class CatalogUpdateWorker extends Worker {
    public static final String KEY_COUNT = "count";
    public static final String KEY_MANUAL = "manual";
    public static final String KEY_EMPTY_RETRIES = "empty_retries";

    public CatalogUpdateWorker(@NonNull Context context,
                               @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        CatalogWorkScheduler.schedulePrefetch(getApplicationContext());
        AppLogger.log(getApplicationContext(), "cache-prefetch", "disabled",
                "Background image prefetch is disabled in 14.2.1");
        return Result.success();
    }
}
