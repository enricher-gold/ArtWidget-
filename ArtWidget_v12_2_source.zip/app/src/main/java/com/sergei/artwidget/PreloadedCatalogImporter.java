package com.sergei.artwidget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Импортирует встроенные каталоги метаданных из APK. Изображения не входят в APK. */
public final class PreloadedCatalogImporter {
    public static final String FILTER_ASSET = "filter_catalog.json";
    public static final String NSFW_ASSET = "nsfw_catalog.json";

    private PreloadedCatalogImporter() { }

    public static List<ArtEntry> loadAll(Context context) throws Exception {
        List<ArtEntry> out = new ArrayList<>(2000);
        out.addAll(load(context, FILTER_ASSET, false));
        out.addAll(load(context, NSFW_ASSET, true));
        return out;
    }

    public static List<ArtEntry> load(Context context, String assetName, boolean explicit) throws Exception {
        String text = readAsset(context, assetName);
        JSONObject root = new JSONObject(text);
        JSONArray items = root.optJSONArray("items");
        List<ArtEntry> out = new ArrayList<>(items == null ? 0 : items.length());
        if (items == null) return out;
        long now = System.currentTimeMillis();
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;
            String stableId = item.optString("stable_id", "").trim();
            String title = item.optString("title", "Без названия").trim();
            String artist = item.optString("artist", "Автор неизвестен").trim();
            String sourceUrl = item.optString("source_page_url", "").trim();
            String imageUrl = item.isNull("image_url") ? "" : item.optString("image_url", "").trim();
            String description = item.optString("description_ru", "").trim();
            String tags = joinTags(item.optJSONArray("tags"));
            String style = item.optString("style", "").trim();
            String marker = explicit ? "preloaded-nsfw" : "preloaded-filter";
            String genre = tags.isEmpty() ? marker : marker + ", " + tags;
            if (stableId.isEmpty()) stableId = "asset:" + Integer.toHexString((artist + "|" + title).hashCode());
            out.add(new ArtEntry(
                    stableId,
                    title,
                    artist,
                    description,
                    imageUrl,
                    imageUrl,
                    "",
                    sourceUrl,
                    "painting",
                    "",
                    style.isEmpty() ? genre : genre + ", " + style,
                    now,
                    now,
                    0,
                    explicit
            ));
        }
        return out;
    }

    private static String joinTags(JSONArray tags) {
        if (tags == null || tags.length() == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tags.length(); i++) {
            String value = tags.optString(i, "").trim();
            if (value.isEmpty()) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(value);
        }
        return sb.toString();
    }

    private static String readAsset(Context context, String name) throws Exception {
        StringBuilder sb = new StringBuilder(1_500_000);
        try (InputStream input = context.getAssets().open(name);
             BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) >= 0) sb.append(buffer, 0, read);
        }
        return sb.toString();
    }
}
