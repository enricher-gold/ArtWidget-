import json, re, hashlib
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path('/mnt/data')
FILTER_SRC=ROOT/'artwidget_catalogs_v2/filter_catalog_1000.json'
NSFW_POOL=ROOT/'artwidget_commons_resolution_v1/input/nsfw_candidate_pool_1120.json'
OUT=ROOT/'artwidget_catalogs_v3_strict'
OUT.mkdir(exist_ok=True)

MINOR_RE=re.compile(r'\b(child|children|girl|girls|boy|boys|baby|babies|infant|infants|minor|minors|putti|cherub|cherubs|adolescent|adolescents|teen|teens|teenage|youth|young|youngster|daughter|daughters|son|sons|schoolgirl|schoolboy)\b',re.I)
NONPAINT_RE=re.compile(r'\b(sketch|drawing|study|etching|engraving|print|watercolor|watercolour|pastel|illustration|sculpture|statue|bronze|lithograph|woodcut|fresco|mural|mosaic|ceramic|photograph|photography|poster|icon|altarpiece|triptych|polyptych)\b',re.I)
EXPLICIT={'female-nude','male-nude'}
CORROBORATING={'human','human body','flesh','barechested','chest','leg','arm','muscle','bathing-and-swimming','nymphs-and-satyrs','artists-and-models','couples','odalisque','erotic'}

STYLE_RU={
 'impressionism':'импрессионизму','post_impressionism':'постимпрессионизму','romanticism':'романтизму',
 'realism':'реализму','baroque':'барокко','rococo':'рококо','renaissance':'Возрождению',
 'northern_renaissance':'Северному Возрождению','early_renaissance':'Раннему Возрождению',
 'high_renaissance':'Высокому Возрождению','mannerism_late_renaissance':'маньеризму',
 'neoclassicism':'неоклассицизму','symbolism':'символизму','expressionism':'экспрессионизму',
 'art_nouveau_modern':'модерну','academic_art':'академической живописи','surrealism':'сюрреализму',
 'cubism':'кубизму','fauvism':'фовизму','naive_art_primitivism':'наивному искусству',
 'ukiyo_e':'укиё-э','abstract_expressionism':'абстрактному экспрессионизму','color_field_painting':'живописи цветового поля'
}
TAG_RU={
 'female-nude':'обнажённая женская фигура','male-nude':'обнажённая мужская фигура','mythology':'мифологический сюжет',
 'greek-and-roman-mythology':'античная мифология','bathing-and-swimming':'купание','couples':'парный сюжет',
 'leisure-and-sleep':'отдых или сон','artists-and-models':'художник и модель','nymphs-and-satyrs':'нимфы и сатиры',
 'allegories-and-symbols':'аллегорический сюжет','famous-people':'известные личности','portrait':'портрет',
 'natural landscape':'пейзаж','landscape':'пейзаж','nature':'природа','still life':'натюрморт',
 'houses-and-buildings':'архитектурный пейзаж','architecture':'архитектура','boats-and-ships':'корабли',
 'seas-and-oceans':'море','forests-and-trees':'лес','animals':'животные','streets-and-squares':'городской вид',
 'flower':'цветы','tree':'деревья','mountains':'горы','rivers-and-waterfalls':'реки'
}

def load_items(p):
 d=json.load(open(p,encoding='utf-8'))
 return d if isinstance(d,list) else d.get('items',[])

def clean_tag(t): return str(t).strip().lower()

def description(item, explicit):
 title=item.get('title') or 'Без названия'
 artist=item.get('artist') or 'Автор неизвестен'
 year=item.get('year')
 style=item.get('style')
 tags=[clean_tag(x) for x in item.get('tags',[]) if clean_tag(x)]
 parts=[f'«{title}» — произведение художника {artist}']
 if year: parts[0]+=f', созданное в {year} году'
 parts[0]+='.'
 if style:
  human=STYLE_RU.get(style, str(style).replace('_',' '))
  parts.append(f'Произведение относят к {human}.')
 themes=[]
 for t in tags:
  if t in TAG_RU and TAG_RU[t] not in themes: themes.append(TAG_RU[t])
  if len(themes)>=3: break
 if themes:
  parts.append('Основные темы: '+', '.join(themes)+'.')
 if explicit:
  parts.append('В произведении присутствует изображение обнажённого тела.')
 return ' '.join(parts)

def normalized_record(item, mode, idx):
 out={
  'catalog_index':idx,
  'stable_id':item['stable_id'],
  'dedupe_key':item['dedupe_key'],
  'artist':item['artist'],
  'title':item['title'],
  'year':item.get('year'),
  'style':item.get('style'),
  'tags':item.get('tags',[]),
  'description_ru':description(item, mode=='NSFW'),
  'content_mode':mode,
  'content_confidence':'strict',
  'content_reason':('explicit nude tag from source dataset; exact source image only' if mode=='NSFW' else 'conservative non-explicit selection; exact source image only'),
  'source_provider':'WikiArt',
  'source_page_url':item['source_page_url'],
  'source_record_image_name':item.get('source_record_image_name',''),
  'image_url':None,
  'image_resolver':{
    'type':'exact_source_page_primary_image',
    'page_url':item['source_page_url'],
    'allow_commons_title_search':False
  },
  'wikipedia_query':f"{item['artist']} {item['title']}",
  'requires_image_resolution':True,
 }
 return out

# Filter: retain the existing conservative 1000, but strip licensing/search fields and add descriptions.
filter_items=load_items(FILTER_SRC)
filter_out=[normalized_record(x,'FILTER',i+1) for i,x in enumerate(filter_items[:1000])]

# NSFW: rebuild from full 1120 pool with strict explicit evidence and exact image source.
pool=load_items(NSFW_POOL)
accepted=[]; rejected=[]
for item in pool:
 tags={clean_tag(x) for x in item.get('tags',[])}
 text=' '.join([str(item.get('title','')),str(item.get('source_record_image_name','')),' '.join(tags)])
 reasons=[]
 if not (tags & EXPLICIT): reasons.append('no explicit nude tag')
 if MINOR_RE.search(text): reasons.append('minor marker')
 if NONPAINT_RE.search(text): reasons.append('non-painting marker')
 if not item.get('source_page_url','').startswith('https://www.wikiart.org/'): reasons.append('no exact source page')
 if reasons:
  rejected.append({'stable_id':item.get('stable_id'),'artist':item.get('artist'),'title':item.get('title'),'reasons':reasons})
  continue
 corroboration=len(tags & CORROBORATING)
 explicit_count=len(tags & EXPLICIT)
 item['_strict_score']=explicit_count*100+corroboration*10+len(tags)
 accepted.append(item)
# Diverse selection: rank, but cap initial passes per artist.
accepted.sort(key=lambda x:(-x['_strict_score'],x.get('artist',''),x.get('title','')))
by_artist={}
for x in accepted: by_artist.setdefault(x.get('artist',''),[]).append(x)
selected=[]
for round_no in range(12):
 for artist in sorted(by_artist):
  xs=by_artist[artist]
  if round_no<len(xs): selected.append(xs[round_no])
  if len(selected)>=1000: break
 if len(selected)>=1000: break
if len(selected)<1000:
 used={x['stable_id'] for x in selected}
 selected += [x for x in accepted if x['stable_id'] not in used][:1000-len(selected)]
if len(selected)<1000: raise RuntimeError(f'Only {len(selected)} strict NSFW candidates')
selected=selected[:1000]
nsfw_out=[normalized_record(x,'NSFW',i+1) for i,x in enumerate(selected)]

def write(name,mode,items):
 payload={
  'schema_version':3,
  'catalog_name':name,
  'catalog_mode':mode,
  'catalog_version':'2026.06.17-strict-v3',
  'generated_at_utc':datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
  'item_count':len(items),
  'production_status':'strict_metadata_catalog_exact_source_resolver',
  'items':items
 }
 (OUT/name).write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')

write('filter_catalog.json','FILTER',filter_out)
write('nsfw_catalog.json','NSFW',nsfw_out)
manifest={
 'schema_version':3,'catalog_version':'2026.06.17-strict-v3',
 'catalogs':[
  {'asset':'filter_catalog.json','mode':'FILTER','items':len(filter_out)},
  {'asset':'nsfw_catalog.json','mode':'NSFW','items':len(nsfw_out)}
 ],
 'resolver_policy':'exact source page image only; Commons title search disabled',
 'license_filtering':False
}
(OUT/'catalog_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
report={
 'filter_count':len(filter_out),'nsfw_count':len(nsfw_out),'candidate_pool':len(pool),
 'strict_accepted_before_selection':len(accepted),'rejected':len(rejected),
 'nsfw_all_have_explicit_nude_tag':all(bool({clean_tag(t) for t in x['tags']} & EXPLICIT) for x in nsfw_out),
 'nsfw_minor_marker_hits':sum(bool(MINOR_RE.search(' '.join([x['title'],x.get('source_record_image_name',''),' '.join(x['tags'])]))) for x in nsfw_out),
 'nsfw_nonpainting_marker_hits':sum(bool(NONPAINT_RE.search(' '.join([x['title'],x.get('source_record_image_name',''),' '.join(x['tags'])]))) for x in nsfw_out),
 'commons_title_search_enabled':False,
 'license_fields_present':any(any('license' in k.lower() for k in x) for x in filter_out+nsfw_out),
 'rejected_examples':rejected[:20]
}
(OUT/'catalog_validation_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
