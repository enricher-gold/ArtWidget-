package com.sergei.artwidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;
import android.util.DisplayMetrics;

import java.io.File;

/** Формирует единый прозрачный холст виджета: картина и подпись под ней. */
public final class ArtRenderer {
    private static final int DEFAULT_W_DP = 280;
    private static final int DEFAULT_H_DP = 280;
    private static final int MAX_LONG_SIDE_PX = 1400;
    private static final int MIN_SIDE_PX = 160;

    private ArtRenderer() { }

    public static Bitmap render(Context context, ArtEntry entry, int widgetWidthDp, int widgetHeightDp) {
        DisplayMetrics dm = context.getResources().getDisplayMetrics();
        int widthDp = widgetWidthDp > 0 ? widgetWidthDp : DEFAULT_W_DP;
        int heightDp = widgetHeightDp > 0 ? widgetHeightDp : DEFAULT_H_DP;

        float rawW = Math.max(1f, widthDp * dm.density);
        float rawH = Math.max(1f, heightDp * dm.density);
        float cap = Math.min(1f, MAX_LONG_SIDE_PX / Math.max(rawW, rawH));
        int w = Math.max(MIN_SIDE_PX, Math.round(rawW * cap));
        int h = Math.max(MIN_SIDE_PX, Math.round(rawH * cap));

        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);

        if (entry == null || !fileExists(entry.localPath)) {
            drawPlaceholder(canvas, w, h, I18n.t(context, "Откройте приложение\nи загрузите картину", "Open the app\nand load an artwork"));
            return result;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap original = BitmapFactory.decodeFile(entry.localPath, options);
        if (original == null || original.getWidth() <= 0 || original.getHeight() <= 0) {
            drawPlaceholder(canvas, w, h, I18n.t(context, "Изображение недоступно", "Image unavailable"));
            return result;
        }

        float scaleToCanvas = cap;
        float outerPad = Math.max(1f, 2f * dm.density * scaleToCanvas);
        float gap = Math.max(2f, 4f * dm.density * scaleToCanvas);
        float captionTextSize = Math.max(12f, 12f * dm.scaledDensity * scaleToCanvas);
        TextPaint captionPaint = textPaint(captionTextSize, true);
        Paint.FontMetrics fm = captionPaint.getFontMetrics();
        float captionHeight = Math.max(captionTextSize * 1.55f,
                (fm.descent - fm.ascent) + 4f * dm.density * scaleToCanvas);

        float maxW = Math.max(1f, w - outerPad * 2f);
        float maxH = Math.max(1f, h - outerPad * 2f - gap - captionHeight);
        float imageScale = Math.min(maxW / original.getWidth(), maxH / original.getHeight());
        float dstW = Math.max(1f, original.getWidth() * imageScale);
        float dstH = Math.max(1f, original.getHeight() * imageScale);

        // Изображение и подпись образуют единый компактный блок. Он центрируется
        // в виджете, а подпись всегда находится непосредственно под картиной.
        float groupHeight = dstH + gap + captionHeight;
        float top = Math.max(outerPad, (h - groupHeight) / 2f);
        float left = (w - dstW) / 2f;

        RectF artwork = new RectF(left, top, left + dstW, top + dstH);
        Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        canvas.drawBitmap(original,
                new Rect(0, 0, original.getWidth(), original.getHeight()),
                artwork,
                imagePaint);
        original.recycle();

        String caption = entry.widgetCaption(LanguageManager.getLanguage(context));
        caption = ellipsize(caption, captionPaint, w - outerPad * 2f);
        float captionTop = artwork.bottom + gap;
        float baseline = captionTop + (captionHeight - (fm.descent - fm.ascent)) / 2f - fm.ascent;
        drawCentered(canvas, w, caption, baseline, captionPaint);
        return result;
    }

    public static Bitmap renderStatus(String text) {
        Bitmap result = Bitmap.createBitmap(560, 520, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);
        drawPlaceholder(canvas, 560, 520, text);
        return result;
    }

    private static TextPaint textPaint(float size, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setColor(Color.WHITE);
        p.setTextSize(size);
        p.setFakeBoldText(bold);
        p.setShadowLayer(Math.max(2f, size / 5f), 1f, 1f, Color.BLACK);
        return p;
    }

    private static void drawPlaceholder(Canvas canvas, int w, int h, String text) {
        float textSize = clamp(Math.min(w, h) / 22f, 22f, 34f);
        TextPaint p = textPaint(textSize, true);
        String[] lines = text == null ? new String[]{"Art Widget"} : text.split("\\n");
        Paint.FontMetrics fm = p.getFontMetrics();
        float lineHeight = (fm.descent - fm.ascent) * 1.22f;
        float total = lineHeight * lines.length;
        float baseline = (h - total) / 2f - fm.ascent;
        for (String line : lines) {
            drawCentered(canvas, w, ellipsize(line, p, w - 16f), baseline, p);
            baseline += lineHeight;
        }
    }

    private static void drawCentered(Canvas canvas, int w, String text, float baseline, Paint paint) {
        float x = (w - paint.measureText(text)) / 2f;
        canvas.drawText(text, x, baseline, paint);
    }

    private static String ellipsize(String text, Paint paint, float maxWidth) {
        String value = text == null ? "" : text.replace('\n', ' ').replace('\r', ' ').trim();
        if (value.isEmpty()) return " ";
        if (paint.measureText(value) <= maxWidth) return value;
        String suffix = "…";
        int low = 0;
        int high = value.length();
        while (low < high) {
            int mid = (low + high + 1) / 2;
            if (paint.measureText(value.substring(0, mid) + suffix) <= maxWidth) low = mid;
            else high = mid - 1;
        }
        return low <= 0 ? suffix : value.substring(0, low).trim() + suffix;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static boolean fileExists(String path) {
        if (path == null || path.trim().isEmpty()) return false;
        File f = new File(path);
        return f.exists() && f.length() > 0;
    }
}
