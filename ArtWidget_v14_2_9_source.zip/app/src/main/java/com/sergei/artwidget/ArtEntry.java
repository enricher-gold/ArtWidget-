package com.sergei.artwidget;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URLDecoder;
import java.util.Locale;

public class ArtEntry {
    public final String qid;
    public final String title;
    public final String artist;
    public final String description;
    public final String titleRu;
    public final String titleEn;
    public final String artistRu;
    public final String artistEn;
    public final String descriptionRu;
    public final String descriptionEn;
    public final String sourceLanguage;
    public final String imageUrl;
    public final String originalImageUrl;
    public final String localPath;
    public final String sourceUrl;
    public final String instanceLabel;
    public final String materialLabel;
    public final String genreLabel;
    public final long addedAt;
    public final long lastShownAt;
    public final int showCount;
    public final boolean explicitContent;

    public ArtEntry(
            String qid,
            String title,
            String artist,
            String description,
            String imageUrl,
            String originalImageUrl,
            String localPath,
            String sourceUrl,
            String instanceLabel,
            String materialLabel,
            String genreLabel,
            long addedAt,
            long lastShownAt,
            int showCount,
            boolean explicitContent
    ) {
        this(qid, title, artist, description,
                inferLocalized(title, sourceUrl, true), inferLocalized(title, sourceUrl, false),
                inferLocalized(artist, sourceUrl, true), inferLocalized(artist, sourceUrl, false),
                inferLocalized(description, sourceUrl, true), inferLocalized(description, sourceUrl, false),
                inferSourceLanguage(sourceUrl, title + " " + description),
                imageUrl, originalImageUrl, localPath, sourceUrl,
                instanceLabel, materialLabel, genreLabel,
                addedAt, lastShownAt, showCount, explicitContent);
    }

    public ArtEntry(
            String qid,
            String title,
            String artist,
            String description,
            String titleRu,
            String titleEn,
            String artistRu,
            String artistEn,
            String descriptionRu,
            String descriptionEn,
            String sourceLanguage,
            String imageUrl,
            String originalImageUrl,
            String localPath,
            String sourceUrl,
            String instanceLabel,
            String materialLabel,
            String genreLabel,
            long addedAt,
            long lastShownAt,
            int showCount,
            boolean explicitContent
    ) {
        this.qid = safe(qid, stableFallback(title, sourceUrl, imageUrl));
        this.title = safe(title, "Без названия");
        this.artist = sanitizeArtist(artist);
        this.description = safe(description, "");
        this.titleRu = safe(titleRu, "");
        this.titleEn = safe(titleEn, "");
        this.artistRu = sanitizeOptionalArtist(artistRu);
        this.artistEn = sanitizeOptionalArtist(artistEn);
        this.descriptionRu = safe(descriptionRu, "");
        this.descriptionEn = safe(descriptionEn, "");
        this.sourceLanguage = normalizeLanguage(sourceLanguage, sourceUrl, this.title + " " + this.description);
        this.imageUrl = safe(imageUrl, "");
        this.originalImageUrl = safe(originalImageUrl, this.imageUrl);
        this.localPath = safe(localPath, "");
        this.sourceUrl = safe(sourceUrl, "");
        this.instanceLabel = safe(instanceLabel, "");
        this.materialLabel = safe(materialLabel, "");
        this.genreLabel = safe(genreLabel, "");
        this.addedAt = addedAt > 0 ? addedAt : System.currentTimeMillis();
        this.lastShownAt = lastShownAt > 0 ? lastShownAt : this.addedAt;
        this.showCount = Math.max(0, showCount);
        this.explicitContent = explicitContent;
    }

    public static ArtEntry catalog(
            String qid,
            String title,
            String artist,
            String description,
            String imageUrl,
            String sourceUrl,
            String instanceLabel,
            String materialLabel,
            String genreLabel,
            boolean explicitContent
    ) {
        return new ArtEntry(qid, title, artist, description, imageUrl, imageUrl, "", sourceUrl,
                instanceLabel, materialLabel, genreLabel, 0L, 0L, 0, explicitContent);
    }

    public ArtEntry withResolvedWikipedia(String resolvedTitle, String resolvedDescription,
                                          String resolvedLanguage, String standardUrl,
                                          String originalUrl, String resolvedSourceUrl) {
        String lang = LanguageManager.EN.equals(resolvedLanguage) ? LanguageManager.EN : LanguageManager.RU;
        String nextTitleRu = titleRu;
        String nextTitleEn = titleEn;
        String nextDescriptionRu = descriptionRu;
        String nextDescriptionEn = descriptionEn;
        if (LanguageManager.RU.equals(lang)) {
            nextTitleRu = safe(resolvedTitle, nextTitleRu);
            nextDescriptionRu = safe(resolvedDescription, nextDescriptionRu);
        } else {
            nextTitleEn = safe(resolvedTitle, nextTitleEn);
            nextDescriptionEn = safe(resolvedDescription, nextDescriptionEn);
        }
        return new ArtEntry(qid,
                safe(resolvedTitle, title), artist, safe(resolvedDescription, description),
                nextTitleRu, nextTitleEn, artistRu, artistEn,
                nextDescriptionRu, nextDescriptionEn, lang,
                safe(standardUrl, imageUrl), safe(originalUrl, standardUrl), localPath,
                safe(resolvedSourceUrl, sourceUrl), instanceLabel, materialLabel, genreLabel,
                addedAt, lastShownAt, showCount, explicitContent);
    }

    public ArtEntry withDownloadedData(String descriptionValue, String standardUrl, String originalUrl, String path) {
        String nextRu = descriptionRu;
        String nextEn = descriptionEn;
        if (LanguageManager.EN.equals(sourceLanguage)) nextEn = safe(descriptionValue, nextEn);
        else nextRu = safe(descriptionValue, nextRu);
        return new ArtEntry(qid, title, artist,
                safe(descriptionValue, description),
                titleRu, titleEn, artistRu, artistEn, nextRu, nextEn, sourceLanguage,
                safe(standardUrl, imageUrl),
                safe(originalUrl, standardUrl),
                path,
                sourceUrl,
                instanceLabel,
                materialLabel,
                genreLabel,
                addedAt,
                lastShownAt,
                showCount,
                explicitContent);
    }

    public ArtEntry withLocalPath(String path) {
        return new ArtEntry(qid, title, artist, description,
                titleRu, titleEn, artistRu, artistEn, descriptionRu, descriptionEn, sourceLanguage,
                imageUrl, originalImageUrl, path, sourceUrl, instanceLabel, materialLabel, genreLabel,
                addedAt, lastShownAt, showCount, explicitContent);
    }

    public ArtEntry markedShown() {
        return new ArtEntry(qid, title, artist, description,
                titleRu, titleEn, artistRu, artistEn, descriptionRu, descriptionEn, sourceLanguage,
                imageUrl, originalImageUrl, localPath, sourceUrl, instanceLabel, materialLabel, genreLabel,
                addedAt, System.currentTimeMillis(), showCount + 1, explicitContent);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("qid", qid);
        o.put("title", title);
        o.put("artist", artist);
        o.put("description", description);
        o.put("titleRu", titleRu);
        o.put("titleEn", titleEn);
        o.put("artistRu", artistRu);
        o.put("artistEn", artistEn);
        o.put("descriptionRu", descriptionRu);
        o.put("descriptionEn", descriptionEn);
        o.put("sourceLanguage", sourceLanguage);
        o.put("imageUrl", imageUrl);
        o.put("originalImageUrl", originalImageUrl);
        o.put("localPath", localPath);
        o.put("sourceUrl", sourceUrl);
        o.put("instanceLabel", instanceLabel);
        o.put("materialLabel", materialLabel);
        o.put("genreLabel", genreLabel);
        o.put("addedAt", addedAt);
        o.put("lastShownAt", lastShownAt);
        o.put("showCount", showCount);
        o.put("explicitContent", explicitContent);
        return o;
    }

    public static ArtEntry fromJson(JSONObject o) {
        String titleRu = o.optString("titleRu", o.optString("title_ru", ""));
        String titleEn = o.optString("titleEn", o.optString("title_en", ""));
        String title = o.optString("title", !titleRu.isEmpty() ? titleRu
                : (!titleEn.isEmpty() ? titleEn : o.optString("pageTitle", "Без названия")));
        String source = o.optString("sourceUrl", o.optString("source_page_url", ""));
        String image = o.optString("imageUrl", o.optString("image_url", o.optString("directImageUrl", "")));
        String qid = o.optString("qid", "");
        if (qid.isEmpty()) {
            String itemUrl = o.optString("itemUrl", "");
            int slash = itemUrl.lastIndexOf('/');
            String itemId = slash >= 0 ? itemUrl.substring(slash + 1) : itemUrl;
            if (itemId.matches("Q\\d+")) qid = itemId;
        }
        if (qid.isEmpty()) {
            int legacyId = o.optInt("id", 0);
            qid = legacyId != 0 ? "legacy:" + legacyId : stableFallback(title, source, image);
        }
        String artistRu = o.optString("artistRu", o.optString("artist_ru", ""));
        String artistEn = o.optString("artistEn", o.optString("artist_en", ""));
        String artist = o.optString("artist", !artistRu.isEmpty() ? artistRu
                : (!artistEn.isEmpty() ? artistEn : o.optString("originalArtist", "Автор неизвестен")));
        String descriptionRu = o.optString("descriptionRu", o.optString("description_ru", ""));
        String descriptionEn = o.optString("descriptionEn", o.optString("description_en", ""));
        String description = o.optString("description", !descriptionRu.isEmpty() ? descriptionRu : descriptionEn);
        String original = o.optString("originalImageUrl", o.optString("original_image_url", image));
        return new ArtEntry(
                qid, title, artist, description,
                titleRu, titleEn, artistRu, artistEn, descriptionRu, descriptionEn,
                o.optString("sourceLanguage", o.optString("source_language", "")),
                image, original, o.optString("localPath", ""), source,
                o.optString("instanceLabel", ""),
                o.optString("materialLabel", o.optString("mediumDisplay", "")),
                o.optString("genreLabel", ""),
                o.optLong("addedAt", System.currentTimeMillis()),
                o.optLong("lastShownAt", System.currentTimeMillis()),
                o.optInt("showCount", 0),
                o.optBoolean("explicitContent", o.optBoolean("explicit_content", false))
        );
    }

    public String localizedTitle(String language) {
        if (LanguageManager.EN.equals(language)) return safe(titleEn, title);
        return safe(titleRu, title);
    }

    public String localizedArtist(String language) {
        String value = LanguageManager.EN.equals(language) ? safe(artistEn, artist) : safe(artistRu, artist);
        return sanitizeArtist(value);
    }

    public String localizedDescription(String language) {
        return LanguageManager.EN.equals(language) ? safe(descriptionEn, description) : safe(descriptionRu, description);
    }

    public boolean hasLocalizedText(String language) {
        if (LanguageManager.EN.equals(language)) return !titleEn.isEmpty() && !descriptionEn.isEmpty();
        return !titleRu.isEmpty() && !descriptionRu.isEmpty();
    }

    public String canonicalKey() {
        // Идентичность произведения не должна меняться после исправления имени
        // автора или локализованного названия. Поэтому сначала используются
        // стабильный Wikidata QID и точная статья Wikipedia, а текстовые поля
        // остаются только резервным вариантом для старых записей без источника.
        if (qid != null && qid.matches("(?i)Q\\d+")) {
            return "qid:" + qid.toUpperCase(Locale.ROOT);
        }
        String article = canonicalArticleKey(sourceUrl);
        if (!article.isEmpty()) return "wiki:" + article;
        String normalizedArtist = normalizeIdentityText(artist);
        String normalizedTitle = normalizeIdentityText(titleForWidget(title));
        return "meta:" + normalizedArtist + "|" + normalizedTitle;
    }

    public boolean sameArtwork(ArtEntry other) {
        return other != null && canonicalKey().equals(other.canonicalKey());
    }

    private static String canonicalArticleKey(String value) {
        if (value == null) return "";
        String s = value.trim();
        int wiki = s.indexOf("/wiki/");
        if (wiki >= 0) s = s.substring(wiki + 6);
        else if (s.startsWith("http://") || s.startsWith("https://")) return "";
        int hash = s.indexOf('#');
        if (hash >= 0) s = s.substring(0, hash);
        int query = s.indexOf('?');
        if (query >= 0) s = s.substring(0, query);
        try { s = URLDecoder.decode(s, "UTF-8"); } catch (Exception ignored) { }
        s = s.replace('_', ' ');
        return normalizeIdentityText(s);
    }

    private static String normalizeIdentityText(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT)
                .replace('ё', 'е')
                .replaceAll("[\\p{Punct}«»„“”’]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    public String caption() { return caption(LanguageManager.RU); }

    public String caption(String language) {
        String localizedArtist = localizedArtist(language);
        String localizedTitle = localizedTitle(language);
        if (isUnknownArtist(localizedArtist)) return localizedTitle;
        return localizedArtist + " · " + localizedTitle;
    }

    public String widgetCaption() { return widgetCaption(LanguageManager.RU); }

    public String widgetCaption(String language) {
        String localizedArtist = localizedArtist(language);
        String shortTitle = titleForWidget(localizedTitle(language));
        if (isUnknownArtist(localizedArtist)) return shortTitle;
        return localizedArtist + " · " + shortTitle;
    }

    public static String titleForWidget(String value) {
        String result = safe(value, "Без названия");
        for (int i = 0; i < 4; i++) {
            String cleaned = result.replaceFirst("\\s*[\\(（][^\\)）]{1,180}[\\)）]\\s*$", "").trim();
            if (cleaned.equals(result) || cleaned.isEmpty()) break;
            result = cleaned;
        }
        result = result.replaceAll("\\s{2,}", " ").trim();
        return result.isEmpty() ? "Без названия" : result;
    }

    public static String sanitizeArtist(String value) {
        String s = safe(value, "Автор неизвестен");
        String lower = s.toLowerCase(Locale.ROOT);
        if (lower.startsWith("http://") || lower.startsWith("https://")
                || lower.contains("wikidata.org") || lower.contains("/.well-known/genid/")
                || lower.matches("q\\d+")) return "Автор неизвестен";
        if (s.length() > 160) return "Автор неизвестен";
        return s;
    }

    private static String sanitizeOptionalArtist(String value) {
        if (value == null || value.trim().isEmpty()) return "";
        String sanitized = sanitizeArtist(value);
        return isUnknownArtist(sanitized) ? "" : sanitized;
    }

    public static boolean isUnknownArtist(String value) {
        if (value == null) return true;
        String s = value.trim().toLowerCase(Locale.ROOT);
        return s.isEmpty() || s.equals("автор неизвестен") || s.equals("неизвестный художник")
                || s.equals("unknown") || s.equals("unknown artist") || s.equals("anonymous") || s.equals("аноним");
    }

    private static String inferLocalized(String value, String sourceUrl, boolean russian) {
        String source = inferSourceLanguage(sourceUrl, value);
        return russian == LanguageManager.RU.equals(source) ? safe(value, "") : "";
    }

    public static String inferSourceLanguage(String sourceUrl, String text) {
        int cyr = 0;
        int latin = 0;
        String value = safe(text, "");
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if ((c >= 'А' && c <= 'я') || c == 'Ё' || c == 'ё') cyr++;
            else if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) latin++;
        }
        if (cyr >= 4 && cyr > latin * 2) return LanguageManager.RU;
        if (latin >= 4 && latin > cyr * 2) return LanguageManager.EN;
        String source = safe(sourceUrl, "").toLowerCase(Locale.ROOT);
        if (source.contains("ru.wikipedia.org")) return LanguageManager.RU;
        if (source.contains("en.wikipedia.org")) return LanguageManager.EN;
        return cyr >= latin ? LanguageManager.RU : LanguageManager.EN;
    }

    private static String normalizeLanguage(String value, String sourceUrl, String text) {
        if (LanguageManager.RU.equals(value) || LanguageManager.EN.equals(value)) return value;
        return inferSourceLanguage(sourceUrl, text);
    }

    private static String safe(String value, String fallback) {
        if (value == null) return fallback == null ? "" : fallback;
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        return s.isEmpty() ? (fallback == null ? "" : fallback) : s;
    }

    private static String stableFallback(String title, String source, String image) {
        String key = safe(source, "");
        if (key.isEmpty()) key = safe(image, "");
        if (key.isEmpty()) key = safe(title, "Без названия");
        return "local:" + Integer.toHexString(key.hashCode());
    }
}
