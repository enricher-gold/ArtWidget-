package com.sergei.artwidget;

import android.Manifest;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.content.pm.PackageManager;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FullscreenActivity extends LocalizedActivity {
    private static final int REQUEST_WRITE_STORAGE = 4401;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService saveExecutor = Executors.newSingleThreadExecutor();
    private ZoomImageView imageView;
    private ProgressBar progress;
    private TextView error;
    private Bitmap loadedBitmap;
    private ArtEntry entry;
    private TextView downloadButton;
    private boolean saving;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(createLayout());
        String qid = getIntent().getStringExtra("qid");
        entry = new ArtRepository(this).findEntry(qid);
        if (entry == null) {
            showError(tr("Изображение недоступно", "Image unavailable"));
            return;
        }
        load(entry);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        saveExecutor.shutdownNow();
        if (loadedBitmap != null && !loadedBitmap.isRecycled()) loadedBitmap.recycle();
        loadedBitmap = null;
        super.onDestroy();
    }

    private View createLayout() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        imageView = new ZoomImageView(this);
        imageView.setBackgroundColor(Color.BLACK);
        root.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        progress = new ProgressBar(this);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER);
        root.addView(progress, pp);

        error = new TextView(this);
        error.setTextColor(Color.WHITE);
        error.setTextSize(17);
        error.setGravity(Gravity.CENTER);
        error.setPadding(dp(24), dp(24), dp(24), dp(24));
        error.setVisibility(View.GONE);
        root.addView(error, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextColor(Color.WHITE);
        close.setTextSize(36);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(0x66000000);
        close.setOnClickListener(v -> finish());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP | Gravity.END);
        cp.setMargins(0, dp(18), dp(14), 0);
        root.addView(close, cp);

        downloadButton = new TextView(this);
        downloadButton.setText("↓");
        downloadButton.setTextColor(Color.WHITE);
        downloadButton.setTextSize(28);
        downloadButton.setGravity(Gravity.CENTER);
        downloadButton.setContentDescription(tr("Скачать изображение", "Download image"));
        GradientDrawable downloadBackground = new GradientDrawable();
        downloadBackground.setShape(GradientDrawable.OVAL);
        downloadBackground.setColor(0xB3007AFF);
        downloadButton.setBackground(downloadBackground);
        downloadButton.setOnClickListener(v -> requestSave());
        FrameLayout.LayoutParams dp = new FrameLayout.LayoutParams(dp(58), dp(58), Gravity.BOTTOM | Gravity.END);
        dp.setMargins(0, 0, dp(18), dp(24));
        root.addView(downloadButton, dp);
        return root;
    }

    private void load(ArtEntry entry) {
        executor.execute(() -> {
            try {
                Bitmap bitmap = null;
                String url = entry.originalImageUrl.isEmpty() ? entry.imageUrl : entry.originalImageUrl;
                if (!url.isEmpty() && new ArtRepository(this).isDownloadNetworkAllowed()) {
                    try { bitmap = downloadBitmap(url); }
                    catch (Exception networkError) {
                        AppLogger.log(this, "fullscreen", "fallback", networkError.getMessage());
                    }
                }
                if (bitmap == null && entry.localPath != null && !entry.localPath.isEmpty()) {
                    bitmap = BitmapFactory.decodeFile(entry.localPath);
                }
                if (bitmap == null) throw new Exception(tr("Не удалось декодировать изображение", "Could not decode the image"));
                final Bitmap finalBitmap = bitmap;
                loadedBitmap = finalBitmap;
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    imageView.setImageBitmap(finalBitmap);
                });
            } catch (Exception e) {
                AppLogger.log(this, "fullscreen", "error", e.getMessage());
                runOnUiThread(() -> showError(tr("Не удалось загрузить изображение высокого разрешения", "Could not load the high-resolution image")));
            }
        });
    }

    private Bitmap downloadBitmap(String urlString) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(urlString).openConnection();
            conn.setRequestProperty("User-Agent", "ArtWidget/14.0 Android; contact enricherusa@gmail.com");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            byte[] bytes;
            try (InputStream input = new BufferedInputStream(conn.getInputStream());
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[16384];
                int read;
                int total = 0;
                while ((read = input.read(buffer)) != -1) {
                    total += read;
                    if (total > 45 * 1024 * 1024) throw new Exception(tr("Файл слишком большой", "The file is too large"));
                    out.write(buffer, 0, read);
                }
                bytes = out.toByteArray();
            }
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            int sample = 1;
            while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 4096) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void requestSave() {
        if (entry == null || saving) return;
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAGE);
            return;
        }
        saveImage();
    }

    private void saveImage() {
        if (entry == null || saving) return;
        saving = true;
        downloadButton.setEnabled(false);
        downloadButton.setAlpha(0.55f);
        Toast.makeText(this, tr("Сохранение изображения…", "Saving image…"), Toast.LENGTH_SHORT).show();
        saveExecutor.execute(() -> ImageSaver.save(getApplicationContext(), entry, new ImageSaver.Callback() {
            @Override
            public void onSuccess(String displayName) {
                runOnUiThread(() -> {
                    saving = false;
                    downloadButton.setEnabled(true);
                    downloadButton.setAlpha(1f);
                    Toast.makeText(FullscreenActivity.this,
                            tr("Изображение сохранено в Pictures/Art Widget", "Image saved to Pictures/Art Widget"), Toast.LENGTH_LONG).show();
                });
            }

            @Override
            public void onError(Exception saveError) {
                runOnUiThread(() -> {
                    saving = false;
                    downloadButton.setEnabled(true);
                    downloadButton.setAlpha(1f);
                    String message = saveError == null || saveError.getMessage() == null
                            ? tr("Не удалось сохранить изображение", "Could not save the image") : saveError.getMessage();
                    Toast.makeText(FullscreenActivity.this, message, Toast.LENGTH_LONG).show();
                });
            }
        }));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) saveImage();
            else Toast.makeText(this, tr("Нет разрешения на сохранение изображения", "Permission to save the image was not granted"), Toast.LENGTH_LONG).show();
        }
    }

    private void showError(String message) {
        progress.setVisibility(View.GONE);
        error.setText(message);
        error.setVisibility(View.VISIBLE);
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
