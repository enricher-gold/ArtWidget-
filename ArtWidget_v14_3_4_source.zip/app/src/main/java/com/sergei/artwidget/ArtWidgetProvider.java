package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";

    private static final float CAPTION_TEXT_SP = 14f;
    private static final float CAPTION_GAP_DP = 2f;
    private static final float CAPTION_SIDE_PADDING_DP = 4f;
    private static final int DEFAULT_WIDGET_WIDTH_DP = 250;
    private static final int DEFAULT_WIDGET_HEIGHT_DP = 250;
    private static final ExecutorService RENDER_EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidgets(app, manager, ids));
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        Context app = context.getApplicationContext();
        Bundle finalOptions = options == null ? null : new Bundle(options);
        RENDER_EXECUTOR.execute(() -> updateWidget(app, manager, appWidgetId, finalOptions));
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    public static void performScheduledUpdate(Context context) {
        ArtScheduler.enqueueAutomaticUpdate(context, "provider");
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> renderAllWidgetsNow(app));
    }

    static void renderAllWidgetsNow(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id, null);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id,
                                     Bundle suppliedOptions) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bitmap bitmap = ArtRenderer.render(context, entry);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);

        String caption = entry == null
                ? ""
                : entry.widgetCaption(LanguageManager.getLanguage(context));
        caption = caption == null
                ? ""
                : caption.replace('\n', ' ').replace('\r', ' ').trim();

        int[] widgetSizeDp = resolveWidgetSizeDp(context, manager, id, suppliedOptions);
        CaptionGeometry geometry = calculateCaptionGeometry(
                context, widgetSizeDp[0], widgetSizeDp[1], bitmap);

        // Нижний внутренний отступ резервирует строку подписи, но ImageView остаётся
        // размером во всё поле. Поэтому fitCenter по-прежнему максимально увеличивает
        // и вертикальные, и горизонтальные картины.
        views.setViewPadding(R.id.widget_image, 0, 0, 0,
                caption.isEmpty() ? 0 : geometry.reserveBottomPx);

        if (caption.isEmpty()) {
            views.setViewVisibility(R.id.widget_caption, View.GONE);
            views.setTextViewText(R.id.widget_caption, "");
            views.setViewPadding(R.id.widget_caption, 0, 0, 0, 0);
        } else {
            views.setViewVisibility(R.id.widget_caption, View.VISIBLE);
            views.setTextViewText(R.id.widget_caption, caption);
            views.setTextViewTextSize(R.id.widget_caption,
                    TypedValue.COMPLEX_UNIT_SP, CAPTION_TEXT_SP);
            views.setViewPadding(R.id.widget_caption,
                    geometry.sidePaddingPx,
                    geometry.captionTopPx,
                    geometry.sidePaddingPx,
                    0);
        }

        views.setOnClickPendingIntent(R.id.widget_open_tap_zone,
                openAppIntent(context, 16001 + id));
        manager.updateAppWidget(id, views);
        AppLogger.log(context, "widget-render", "full-fit-center-caption-overlay",
                "id=" + id
                        + ", widget=" + widgetSizeDp[0] + "x" + widgetSizeDp[1] + "dp"
                        + ", captionTop=" + geometry.captionTopPx + "px");
    }

    /**
     * Вычисляет положение строки сразу под фактическим прямоугольником fitCenter.
     * Ошибка оценки размера лаунчером может сдвинуть только подпись, но никогда не
     * уменьшает саму картину: bitmap больше не рендерится под расчётный размер.
     */
    private static CaptionGeometry calculateCaptionGeometry(Context context,
                                                             int widgetWidthDp,
                                                             int widgetHeightDp,
                                                             Bitmap bitmap) {
        DisplayMetrics metrics = context.getResources().getDisplayMetrics();
        float density = Math.max(0.1f, metrics.density);
        float scaledDensity = Math.max(0.1f, metrics.scaledDensity);

        int widthPx = Math.max(1, Math.round(widgetWidthDp * density));
        int heightPx = Math.max(1, Math.round(widgetHeightDp * density));
        int gapPx = Math.max(1, Math.round(CAPTION_GAP_DP * density));
        int sidePaddingPx = Math.max(0, Math.round(CAPTION_SIDE_PADDING_DP * density));

        // includeFontPadding=false, поэтому 1.35 от размера шрифта достаточно для
        // одной строки даже при системном fontScale. Добавляется небольшой запас.
        int textHeightPx = Math.max(1,
                (int) Math.ceil(CAPTION_TEXT_SP * scaledDensity * 1.35f));
        int reserveBottomPx = Math.min(heightPx - 1,
                Math.max(1, textHeightPx + gapPx + Math.round(density)));
        int imageAreaHeightPx = Math.max(1, heightPx - reserveBottomPx);

        int bitmapWidth = bitmap == null ? 1 : Math.max(1, bitmap.getWidth());
        int bitmapHeight = bitmap == null ? 1 : Math.max(1, bitmap.getHeight());
        float scale = Math.min(widthPx / (float) bitmapWidth,
                imageAreaHeightPx / (float) bitmapHeight);
        float drawnHeight = bitmapHeight * scale;
        float imageTop = (imageAreaHeightPx - drawnHeight) / 2f;
        int captionTopPx = Math.round(imageTop + drawnHeight + gapPx);

        int maxCaptionTop = Math.max(0, heightPx - textHeightPx);
        captionTopPx = Math.max(0, Math.min(captionTopPx, maxCaptionTop));
        return new CaptionGeometry(captionTopPx, reserveBottomPx, sidePaddingPx);
    }

    /**
     * OPTION_APPWIDGET_* задаёт диапазон размеров для двух ориентаций. Переданный
     * в onAppWidgetOptionsChanged Bundle используется первым, чтобы не читать
     * устаревшие значения сразу после отпускания границы виджета.
     */
    private static int[] resolveWidgetSizeDp(Context context,
                                             AppWidgetManager manager,
                                             int appWidgetId,
                                             Bundle suppliedOptions) {
        Bundle options = suppliedOptions != null
                ? suppliedOptions
                : manager.getAppWidgetOptions(appWidgetId);
        if (options == null) options = Bundle.EMPTY;

        int minWidth = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH),
                DEFAULT_WIDGET_WIDTH_DP);
        int minHeight = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT),
                DEFAULT_WIDGET_HEIGHT_DP);
        int maxWidth = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH),
                minWidth);
        int maxHeight = positive(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT),
                minHeight);

        boolean landscape = context.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        int width = landscape ? Math.max(minWidth, maxWidth) : Math.min(minWidth, maxWidth);
        int height = landscape ? Math.min(minHeight, maxHeight) : Math.max(minHeight, maxHeight);
        return new int[]{Math.max(1, width), Math.max(1, height)};
    }

    private static int positive(int value, int fallback) {
        return value > 0 ? value : fallback;
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }

    private static final class CaptionGeometry {
        final int captionTopPx;
        final int reserveBottomPx;
        final int sidePaddingPx;

        CaptionGeometry(int captionTopPx, int reserveBottomPx, int sidePaddingPx) {
            this.captionTopPx = captionTopPx;
            this.reserveBottomPx = reserveBottomPx;
            this.sidePaddingPx = sidePaddingPx;
        }
    }
}
