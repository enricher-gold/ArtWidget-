# Art Widget

Android-приложение с домашним виджетом 4×4 для показа картин.

## Что умеет

- прозрачный фон виджета;
- картина вписывается целиком, без обрезки;
- для вертикальной картины по бокам остаётся прозрачное поле;
- для горизонтальной картины сверху и снизу остаётся прозрачное поле;
- под картиной выводятся художник и название;
- ручное обновление из приложения;
- автообновление через 1, 6, 12 или 24 часа;
- возврат к предыдущей картине;
- локальный кэш до 20 последних картин;
- после перезагрузки телефона автообновление планируется заново.

## Источник изображений

Приложение использует публичный API Art Institute of Chicago и берёт изображения public domain.

## Сборка через GitHub с телефона

### Вариант для телефона, без компьютера

1. Создайте новый репозиторий GitHub.
2. Загрузите в корень репозитория ZIP-файл с проектом. Название ZIP может быть любым, но лучше `ArtWidget_source.zip`.
3. В репозитории нажмите `Add file` → `Create new file`.
4. В поле имени файла вставьте:

```text
.github/workflows/build-from-zip.yml
```

5. Вставьте в файл этот текст:

```yaml
name: Build APK from uploaded ZIP

on:
  push:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Find source ZIP
        id: zip
        shell: bash
        run: |
          ZIP_FILE=$(find . -maxdepth 1 -type f -name "*.zip" | head -n 1)
          if [ -z "$ZIP_FILE" ]; then
            echo "No ZIP file found in repository root"
            exit 1
          fi
          echo "zip_file=$ZIP_FILE" >> "$GITHUB_OUTPUT"

      - name: Unpack source ZIP
        shell: bash
        run: |
          mkdir source
          unzip -q "${{ steps.zip.outputs.zip_file }}" -d source
          PROJECT_FILE=$(find source -name settings.gradle -o -name settings.gradle.kts | head -n 1)
          if [ -z "$PROJECT_FILE" ]; then
            echo "settings.gradle not found after unpacking ZIP"
            exit 1
          fi
          echo "PROJECT_DIR=$(dirname "$PROJECT_FILE")" >> "$GITHUB_ENV"

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'

      - name: Set up Android SDK
        uses: android-actions/setup-android@v3

      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.11.1'

      - name: Install Android SDK components
        run: |
          yes | sdkmanager "platforms;android-35" "build-tools;35.0.0" || true

      - name: Build debug APK
        working-directory: ${{ env.PROJECT_DIR }}
        run: gradle assembleDebug --no-daemon

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: ArtWidget-debug-apk
          path: ${{ env.PROJECT_DIR }}/app/build/outputs/apk/debug/app-debug.apk
```

6. Нажмите `Commit changes`.
7. Откройте вкладку `Actions`.
8. Дождитесь завершения сборки `Build APK from uploaded ZIP`.
9. Откройте завершённый запуск сборки.
10. Внизу страницы скачайте артефакт `ArtWidget-debug-apk`.
11. Распакуйте скачанный архив на телефоне.
12. Установите `app-debug.apk`.
13. Откройте приложение `Art Widget` и нажмите `Обновить картину сейчас`.
14. Добавьте виджет на рабочий стол: удержание пустого места → `Виджеты` → `Art Widget` → перетащить на экран → растянуть до 4×4.

## Если сборка упала

Откройте упавший запуск во вкладке `Actions`, зайдите в красный шаг и скопируйте текст ошибки. По нему можно быстро понять, проблема в загрузке ZIP, Android SDK, Gradle или коде.
