package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.BroadcastReceiver.PendingResult;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAllWidgets(context);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent == null || intent.getAction() == null) return;

        String action = intent.getAction();
        if (ACTION_SCHEDULED_UPDATE.equals(action) || ACTION_WIDGET_NEXT.equals(action)) {
            updateNextAsync(context, ACTION_SCHEDULED_UPDATE.equals(action));
        } else if (ACTION_WIDGET_PREVIOUS.equals(action)) {
            previousAsync(context);
        }
    }

    private void updateNextAsync(Context context, boolean scheduled) {
        final PendingResult pendingResult = goAsync();
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(context);
                repo.fetchNextArtwork();
                updateAllWidgets(context);
            } catch (Exception e) {
                Bitmap status = ArtRenderer.renderStatus("Не удалось обновить");
                updateAllWidgetsWithBitmap(context, status);
            } finally {
                ArtScheduler.scheduleNext(context);
                pendingResult.finish();
                executor.shutdown();
            }
        });
    }

    private void previousAsync(Context context) {
        final PendingResult pendingResult = goAsync();
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(context);
                repo.goPrevious();
                updateAllWidgets(context);
            } catch (Exception e) {
                Bitmap status = ArtRenderer.renderStatus("Нет предыдущей картины");
                updateAllWidgetsWithBitmap(context, status);
            } finally {
                pendingResult.finish();
                executor.shutdown();
            }
        });
    }

    public static void updateAllWidgets(Context context) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bitmap bitmap = ArtRenderer.render(context, entry);
        updateAllWidgetsWithBitmap(context, bitmap);
    }

    public static void updateAllWidgetsWithBitmap(Context context, Bitmap bitmap) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
        ComponentName componentName = new ComponentName(context.getApplicationContext(), ArtWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(componentName);
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
            views.setImageViewBitmap(R.id.widget_image, bitmap);
            views.setOnClickPendingIntent(R.id.widget_left_tap_zone, broadcastPendingIntent(context, ACTION_WIDGET_PREVIOUS, 14001));
            views.setOnClickPendingIntent(R.id.widget_right_tap_zone, broadcastPendingIntent(context, ACTION_WIDGET_NEXT, 14002));
            manager.updateAppWidget(id, views);
        }
    }

    private static PendingIntent broadcastPendingIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, ArtWidgetProvider.class);
        intent.setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }
}
