package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.text.Html;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Random;

public class ArtRepository {
    private static final String PREFS = "art_widget_prefs";
    private static final String KEY_HISTORY = "history";
    private static final String KEY_INDEX = "history_index";
    private static final int MAX_HISTORY = 20;
    private static final int SEARCH_LIMIT = 25;
    private static final String USER_AGENT = "ArtWidget/2.0 Android";

    private final Context context;
    private final SharedPreferences prefs;
    private final Random random = new Random();

    public ArtRepository(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public synchronized ArtEntry getCurrent() {
        try {
            JSONArray history = getHistoryArray();
            int index = prefs.getInt(KEY_INDEX, -1);
            if (index < 0 || index >= history.length()) return null;
            ArtEntry entry = ArtEntry.fromJson(history.getJSONObject(index));
            if (entry.localPath == null || entry.localPath.isEmpty()) return null;
            File f = new File(entry.localPath);
            if (!f.exists() || f.length() == 0) return null;
            return entry;
        } catch (Exception e) {
            return null;
        }
    }

    public synchronized ArtEntry goPrevious() throws JSONException {
        JSONArray history = getHistoryArray();
        int index = prefs.getInt(KEY_INDEX, -1);
        if (history.length() == 0 || index <= 0) {
            return getCurrent();
        }
        index--;
        prefs.edit().putInt(KEY_INDEX, index).apply();
        return ArtEntry.fromJson(history.getJSONObject(index));
    }

    public synchronized ArtEntry fetchNextArtwork() throws IOException, JSONException {
        if (!hasNetwork()) {
            ArtEntry current = getCurrent();
            if (current != null) return current;
            throw new IOException("Нет интернета и нет сохранённой картины в кэше.");
        }

        IOException lastIo = null;
        JSONException lastJson = null;

        for (int attempt = 0; attempt < 12; attempt++) {
            try {
                JSONObject candidate = getRandomArtworkFromApi();
                ArtEntry entry = downloadCandidate(candidate);
                appendToHistory(entry);
                return entry;
            } catch (IOException e) {
                lastIo = e;
            } catch (JSONException e) {
                lastJson = e;
            }
        }

        ArtEntry current = getCurrent();
        if (current != null) return current;
        if (lastIo != null) throw lastIo;
        if (lastJson != null) throw lastJson;
        throw new IOException("Не удалось загрузить картину.");
    }

    public synchronized int getCacheCount() {
        try {
            return getHistoryArray().length();
        } catch (Exception e) {
            return 0;
        }
    }

    public synchronized void clearCache() {
        try {
            JSONArray history = getHistoryArray();
            for (int i = 0; i < history.length(); i++) {
                JSONObject item = history.optJSONObject(i);
                if (item != null) deleteFileQuietly(item.optString("localPath", ""));
            }
        } catch (Exception ignored) {
        }
        prefs.edit().putString(KEY_HISTORY, "[]").putInt(KEY_INDEX, -1).apply();
        File cacheDir = new File(context.getFilesDir(), "art_cache");
        File[] files = cacheDir.listFiles();
        if (files != null) {
            for (File f : files) {
                try {
                    //noinspection ResultOfMethodCallIgnored
                    f.delete();
                } catch (Exception ignored) {
                }
            }
        }
    }

    private JSONObject getRandomArtworkFromApi() throws IOException, JSONException {
        int firstPage = 1;
        JSONObject first = readJson(searchUrl(firstPage));
        JSONObject pagination = first.optJSONObject("pagination");
        int totalPages = pagination == null ? 1 : Math.max(1, pagination.optInt("total_pages", 1));
        int maxPage = Math.min(totalPages, 500);
        int page = 1 + random.nextInt(maxPage);

        JSONObject response = page == 1 ? first : readJson(searchUrl(page));
        JSONArray data = response.optJSONArray("data");
        if (data == null || data.length() == 0) {
            throw new IOException("API вернул пустой список.");
        }

        for (int i = 0; i < data.length(); i++) {
            JSONObject item = data.getJSONObject(random.nextInt(data.length()));
            String imageId = item.optString("image_id", "");
            String title = item.optString("title", "");
            if (!imageId.isEmpty() && !title.isEmpty()) {
                String iiifBase = "https://www.artic.edu/iiif/2";
                JSONObject config = response.optJSONObject("config");
                if (config != null && !config.optString("iiif_url", "").isEmpty()) {
                    iiifBase = config.optString("iiif_url");
                }
                item.put("iiif_base", iiifBase);
                return item;
            }
        }
        throw new IOException("В выбранной выдаче нет картин с image_id.");
    }

    private String searchUrl(int page) {
        return "https://api.artic.edu/api/v1/artworks/search"
                + "?q=painting"
                + "&query%5Bterm%5D%5Bis_public_domain%5D=true"
                + "&fields=id,title,artist_title,artist_display,image_id,artwork_type_title,date_display,medium_display,thumbnail,short_description,description"
                + "&limit=" + SEARCH_LIMIT
                + "&page=" + page;
    }

    private ArtEntry downloadCandidate(JSONObject item) throws IOException, JSONException {
        int id = item.optInt("id", 0);
        JSONObject detail = item;
        if (id > 0) {
            try {
                JSONObject detailResponse = readJson("https://api.artic.edu/api/v1/artworks/" + id
                        + "?fields=id,title,artist_title,artist_display,image_id,artwork_type_title,date_display,medium_display,thumbnail,short_description,description");
                JSONObject data = detailResponse.optJSONObject("data");
                if (data != null) detail = data;
            } catch (Exception ignored) {
                detail = item;
            }
        }

        String artworkType = clean(detail.optString("artwork_type_title", item.optString("artwork_type_title", "")));
        if (!artworkType.isEmpty() && !artworkType.toLowerCase().contains("painting")) {
            throw new IOException("Пропущен не-живописный объект: " + artworkType);
        }

        String originalTitle = clean(detail.optString("title", item.optString("title", "Без названия")));
        String originalArtist = clean(detail.optString("artist_title", item.optString("artist_title", "")));
        if (originalArtist.isEmpty()) {
            originalArtist = cleanArtistDisplay(detail.optString("artist_display", item.optString("artist_display", "")));
        }
        if (originalArtist.isEmpty()) originalArtist = "Неизвестный художник";

        String titleRu = translateToRussian(originalTitle);
        String artistRu = translateToRussian(originalArtist);
        if (titleRu.isEmpty()) titleRu = originalTitle;
        if (artistRu.isEmpty()) artistRu = originalArtist;

        String rawDescription = cleanDescription(detail);
        String descriptionRu = "";
        if (!rawDescription.isEmpty()) {
            descriptionRu = translateToRussian(limit(rawDescription, 900));
            if (descriptionRu.isEmpty()) descriptionRu = limit(rawDescription, 900);
        }

        String dateDisplay = clean(detail.optString("date_display", ""));
        String mediumDisplay = clean(detail.optString("medium_display", ""));
        String imageId = detail.optString("image_id", item.optString("image_id", ""));
        String iiifBase = item.optString("iiif_base", "https://www.artic.edu/iiif/2");
        String imageUrl = iiifBase + "/" + imageId + "/full/843,/0/default.jpg";
        String sourceUrl = id > 0 ? "https://www.artic.edu/artworks/" + id : "";

        File cacheDir = new File(context.getFilesDir(), "art_cache");
        if (!cacheDir.exists() && !cacheDir.mkdirs()) {
            throw new IOException("Не удалось создать папку кэша.");
        }
        File outFile = new File(cacheDir, "art_" + System.currentTimeMillis() + "_" + Math.abs(random.nextInt()) + ".jpg");
        downloadFile(imageUrl, outFile);

        if (BitmapFactory.decodeFile(outFile.getAbsolutePath()) == null) {
            //noinspection ResultOfMethodCallIgnored
            outFile.delete();
            throw new IOException("Загруженный файл не распознан как изображение.");
        }

        if (descriptionRu.isEmpty()) {
            descriptionRu = buildFallbackDescription(artistRu, titleRu, dateDisplay, mediumDisplay);
        }

        return new ArtEntry(id, titleRu, artistRu, originalTitle, originalArtist, descriptionRu, imageId, imageUrl,
                outFile.getAbsolutePath(), sourceUrl, dateDisplay, mediumDisplay);
    }

    private String cleanDescription(JSONObject detail) {
        String text = clean(detail.optString("short_description", ""));
        if (text.isEmpty()) text = clean(detail.optString("description", ""));
        if (text.isEmpty()) {
            JSONObject thumbnail = detail.optJSONObject("thumbnail");
            if (thumbnail != null) text = clean(thumbnail.optString("alt_text", ""));
        }
        text = htmlToText(text);
        text = text.replaceAll("\\s+", " ").trim();
        return text;
    }

    private String buildFallbackDescription(String artist, String title, String date, String medium) {
        StringBuilder sb = new StringBuilder();
        sb.append("Отдельного музейного описания для этой картины в источнике нет. ");
        sb.append("В карточке указано: ").append(artist).append(", «").append(title).append("»");
        if (date != null && !date.trim().isEmpty()) sb.append(", дата: ").append(date.trim());
        if (medium != null && !medium.trim().isEmpty()) sb.append(", материал/техника: ").append(medium.trim());
        sb.append(".");
        return sb.toString();
    }

    private String htmlToText(String text) {
        if (text == null || text.trim().isEmpty()) return "";
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                return Html.fromHtml(text, Html.FROM_HTML_MODE_LEGACY).toString();
            } else {
                //noinspection deprecation
                return Html.fromHtml(text).toString();
            }
        } catch (Exception e) {
            return text.replaceAll("<[^>]+>", " ");
        }
    }

    private String translateToRussian(String text) {
        text = clean(text);
        if (text.isEmpty()) return "";
        if (looksRussian(text)) return text;
        try {
            String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ru&dt=t&q="
                    + URLEncoder.encode(text, "UTF-8");
            String json = readText(url);
            JSONArray root = new JSONArray(json);
            JSONArray chunks = root.optJSONArray(0);
            if (chunks == null) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < chunks.length(); i++) {
                JSONArray chunk = chunks.optJSONArray(i);
                if (chunk != null) sb.append(chunk.optString(0, ""));
            }
            return clean(sb.toString());
        } catch (Exception e) {
            return "";
        }
    }

    private boolean looksRussian(String text) {
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if ((c >= 'А' && c <= 'я') || c == 'ё' || c == 'Ё') return true;
        }
        return false;
    }

    private String limit(String text, int max) {
        text = clean(text);
        if (text.length() <= max) return text;
        return text.substring(0, max).trim() + "…";
    }

    private String clean(String s) {
        if (s == null) return "";
        return s.replace('\n', ' ').replace('\r', ' ').trim();
    }

    private String cleanArtistDisplay(String s) {
        s = clean(s);
        if (s.contains("\n")) s = s.substring(0, s.indexOf('\n'));
        return s;
    }

    private JSONObject readJson(String urlString) throws IOException, JSONException {
        String text = readText(urlString);
        return new JSONObject(text);
    }

    private String readText(String urlString) throws IOException {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(25000);
            int code = conn.getResponseCode();
            InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            if (input == null) throw new IOException("HTTP " + code);
            byte[] bytes = readAll(input);
            if (code < 200 || code >= 300) {
                throw new IOException("HTTP " + code + ": " + new String(bytes));
            }
            return new String(bytes, "UTF-8");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private byte[] readAll(InputStream input) throws IOException {
        try (BufferedInputStream in = new BufferedInputStream(input);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return out.toByteArray();
        }
    }

    private void downloadFile(String urlString, File outFile) throws IOException {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке изображения");
            try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(outFile))) {
                byte[] buffer = new byte[16384];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
            }
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private JSONArray getHistoryArray() throws JSONException {
        return new JSONArray(prefs.getString(KEY_HISTORY, "[]"));
    }

    private void appendToHistory(ArtEntry entry) throws JSONException {
        JSONArray history = getHistoryArray();
        int index = prefs.getInt(KEY_INDEX, history.length() - 1);

        while (history.length() > index + 1 && history.length() > 0) {
            JSONObject removed = history.getJSONObject(history.length() - 1);
            deleteFileQuietly(removed.optString("localPath", ""));
            history.remove(history.length() - 1);
        }

        history.put(entry.toJson());
        while (history.length() > MAX_HISTORY) {
            JSONObject removed = history.getJSONObject(0);
            deleteFileQuietly(removed.optString("localPath", ""));
            history.remove(0);
        }

        prefs.edit()
                .putString(KEY_HISTORY, history.toString())
                .putInt(KEY_INDEX, history.length() - 1)
                .apply();
    }

    private void deleteFileQuietly(String path) {
        try {
            if (path != null && !path.isEmpty()) {
                //noinspection ResultOfMethodCallIgnored
                new File(path).delete();
            }
        } catch (Exception ignored) {
        }
    }
}
