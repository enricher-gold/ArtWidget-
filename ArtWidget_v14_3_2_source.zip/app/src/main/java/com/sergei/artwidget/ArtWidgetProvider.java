package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";
    private static final ExecutorService RENDER_EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidgets(app, manager, ids));
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        Context app = context.getApplicationContext();
        // Bitmap содержит только картину, а подпись остаётся отдельным TextView.
        // Launcher вписывает изображение через fitCenter без изменения шрифта.
        RENDER_EXECUTOR.execute(() -> updateWidget(app, manager, appWidgetId));
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    public static void performScheduledUpdate(Context context) {
        ArtScheduler.enqueueAutomaticUpdate(context, "provider");
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> renderAllWidgetsNow(app));
    }

    static void renderAllWidgetsNow(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bitmap bitmap = ArtRenderer.render(context, entry);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);

        String caption = entry == null
                ? ""
                : entry.widgetCaption(LanguageManager.getLanguage(context));
        caption = caption == null
                ? ""
                : caption.replace('\n', ' ').replace('\r', ' ').trim();
        if (caption.isEmpty()) {
            views.setViewVisibility(R.id.widget_caption, View.GONE);
            views.setTextViewText(R.id.widget_caption, "");
        } else {
            views.setViewVisibility(R.id.widget_caption, View.VISIBLE);
            views.setTextViewText(R.id.widget_caption, caption);
            // SP учитывает системный fontScale, но не зависит от размера bitmap,
            // виджета или ориентации планшета.
            views.setTextViewTextSize(R.id.widget_caption,
                    TypedValue.COMPLEX_UNIT_SP, 14f);
        }

        views.setOnClickPendingIntent(R.id.widget_open_tap_zone,
                openAppIntent(context, 16001 + id));
        manager.updateAppWidget(id, views);
        AppLogger.log(context, "widget-render", "image-fit-center-caption-14sp", "id=" + id);
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
