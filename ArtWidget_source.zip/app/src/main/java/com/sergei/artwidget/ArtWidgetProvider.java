package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.BroadcastReceiver.PendingResult;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateAllWidgets(context);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent != null && ACTION_SCHEDULED_UPDATE.equals(intent.getAction())) {
            final PendingResult pendingResult = goAsync();
            ExecutorService executor = Executors.newSingleThreadExecutor();
            executor.execute(() -> {
                try {
                    ArtRepository repo = new ArtRepository(context);
                    repo.fetchNextArtwork();
                    updateAllWidgets(context);
                } catch (Exception e) {
                    Bitmap status = ArtRenderer.renderStatus("Не удалось обновить\nбудет повтор позже");
                    updateAllWidgetsWithBitmap(context, status);
                } finally {
                    ArtScheduler.scheduleNext(context);
                    pendingResult.finish();
                    executor.shutdown();
                }
            });
        }
    }

    public static void updateAllWidgets(Context context) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bitmap bitmap = ArtRenderer.render(context, entry);
        updateAllWidgetsWithBitmap(context, bitmap);
    }

    public static void updateAllWidgetsWithBitmap(Context context, Bitmap bitmap) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
        ComponentName componentName = new ComponentName(context.getApplicationContext(), ArtWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(componentName);
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
            views.setImageViewBitmap(R.id.widget_image, bitmap);
            views.setOnClickPendingIntent(R.id.widget_root, openAppPendingIntent(context));
            views.setOnClickPendingIntent(R.id.widget_image, openAppPendingIntent(context));
            manager.updateAppWidget(id, views);
        }
    }

    private static PendingIntent openAppPendingIntent(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, 13001, intent, flags);
    }
}
