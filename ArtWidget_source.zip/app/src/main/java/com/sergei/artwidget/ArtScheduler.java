package com.sergei.artwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public class ArtScheduler {
    public static final String PREFS = "art_widget_prefs";
    public static final String KEY_INTERVAL_HOURS = "interval_hours";
    public static final int DEFAULT_INTERVAL_HOURS = 6;

    public static int getIntervalHours(Context context) {
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int h = prefs.getInt(KEY_INTERVAL_HOURS, DEFAULT_INTERVAL_HOURS);
        if (h != 1 && h != 6 && h != 12 && h != 24) return DEFAULT_INTERVAL_HOURS;
        return h;
    }

    public static void setIntervalHours(Context context, int hours) {
        if (hours != 1 && hours != 6 && hours != 12 && hours != 24) hours = DEFAULT_INTERVAL_HOURS;
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_INTERVAL_HOURS, hours)
                .apply();
        scheduleNext(context);
    }

    public static void scheduleNext(Context context) {
        Context app = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        PendingIntent pi = pendingIntent(app);
        alarmManager.cancel(pi);

        long delay = getIntervalHours(app) * 60L * 60L * 1000L;
        long triggerAt = System.currentTimeMillis() + delay;

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }

    public static void cancel(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) alarmManager.cancel(pendingIntent(context.getApplicationContext()));
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, ArtWidgetProvider.class);
        intent.setAction(ArtWidgetProvider.ACTION_SCHEDULED_UPDATE);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, 12001, intent, flags);
    }
}
