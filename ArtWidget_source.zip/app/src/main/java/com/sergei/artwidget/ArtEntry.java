package com.sergei.artwidget;

import org.json.JSONException;
import org.json.JSONObject;

public class ArtEntry {
    public final int id;
    public final String title;
    public final String artist;
    public final String imageId;
    public final String imageUrl;
    public final String localPath;

    public ArtEntry(int id, String title, String artist, String imageId, String imageUrl, String localPath) {
        this.id = id;
        this.title = title;
        this.artist = artist;
        this.imageId = imageId;
        this.imageUrl = imageUrl;
        this.localPath = localPath;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("artist", artist);
        o.put("imageId", imageId);
        o.put("imageUrl", imageUrl);
        o.put("localPath", localPath);
        return o;
    }

    public static ArtEntry fromJson(JSONObject o) {
        return new ArtEntry(
                o.optInt("id", 0),
                o.optString("title", "Без названия"),
                o.optString("artist", "Неизвестный художник"),
                o.optString("imageId", ""),
                o.optString("imageUrl", ""),
                o.optString("localPath", "")
        );
    }

    public String caption() {
        return artist + "\n" + title;
    }
}
