package com.sergei.artwidget;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private TextView status;
    private Button refreshButton;
    private Button previousButton;
    private Button saveIntervalButton;
    private Spinner intervalSpinner;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private int selectedHours = ArtScheduler.DEFAULT_INTERVAL_HOURS;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        selectedHours = ArtScheduler.getIntervalHours(this);
        setContentView(createLayout());
        updateStatusFromCache();
        ArtWidgetProvider.updateAllWidgets(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Art Widget");
        title.setTextSize(26);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.START);
        root.addView(title, matchWrap());

        TextView hint = new TextView(this);
        hint.setText("Виджет показывает картину целиком на прозрачном фоне. Под картиной выводятся художник и название. Источник: публичные изображения Art Institute of Chicago.");
        hint.setTextSize(15);
        hint.setPadding(0, dp(8), 0, dp(14));
        root.addView(hint, matchWrap());

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 0, 0, dp(16));
        root.addView(status, matchWrap());

        refreshButton = new Button(this);
        refreshButton.setText("Обновить картину сейчас");
        refreshButton.setAllCaps(false);
        refreshButton.setOnClickListener(v -> refreshNow());
        root.addView(refreshButton, matchWrap());

        previousButton = new Button(this);
        previousButton.setText("Вернуться к предыдущей картине");
        previousButton.setAllCaps(false);
        previousButton.setOnClickListener(v -> previous());
        root.addView(previousButton, matchWrap());

        TextView intervalLabel = new TextView(this);
        intervalLabel.setText("Автообновление:");
        intervalLabel.setTextSize(16);
        intervalLabel.setPadding(0, dp(18), 0, dp(6));
        root.addView(intervalLabel, matchWrap());

        intervalSpinner = new Spinner(this);
        String[] labels = new String[]{"1 час", "6 часов", "12 часов", "24 часа"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        intervalSpinner.setAdapter(adapter);
        intervalSpinner.setSelection(hoursToPosition(selectedHours));
        intervalSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedHours = positionToHours(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        root.addView(intervalSpinner, matchWrap());

        saveIntervalButton = new Button(this);
        saveIntervalButton.setText("Сохранить интервал");
        saveIntervalButton.setAllCaps(false);
        saveIntervalButton.setOnClickListener(v -> {
            ArtScheduler.setIntervalHours(this, selectedHours);
            setStatus("Интервал сохранён: " + selectedHoursText(selectedHours) + ". Следующее автообновление будет по этому интервалу.");
        });
        root.addView(saveIntervalButton, matchWrap());

        TextView installHint = new TextView(this);
        installHint.setText("Как добавить виджет: удерживайте пустое место на рабочем столе Android → Виджеты → Art Widget → перетащите на экран. Размер можно растянуть до 4×4.");
        installHint.setTextSize(14);
        installHint.setPadding(0, dp(18), 0, 0);
        root.addView(installHint, matchWrap());

        return scroll;
    }

    private void refreshNow() {
        setBusy(true);
        setStatus("Загружаю новую картину…");
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(this);
                ArtEntry entry = repo.fetchNextArtwork();
                ArtScheduler.scheduleNext(this);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    setStatus("Загружено:\n" + entry.artist + "\n" + entry.title);
                    setBusy(false);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setStatus("Ошибка загрузки: " + e.getMessage());
                    setBusy(false);
                });
            }
        });
    }

    private void previous() {
        try {
            ArtRepository repo = new ArtRepository(this);
            ArtEntry entry = repo.goPrevious();
            ArtWidgetProvider.updateAllWidgets(this);
            if (entry == null) {
                setStatus("Предыдущей картины пока нет. Сначала нажмите «Обновить картину сейчас» несколько раз.");
            } else {
                setStatus("Показана предыдущая картина:\n" + entry.artist + "\n" + entry.title);
            }
        } catch (Exception e) {
            setStatus("Ошибка: " + e.getMessage());
        }
    }

    private void updateStatusFromCache() {
        ArtRepository repo = new ArtRepository(this);
        ArtEntry current = repo.getCurrent();
        if (current == null) {
            setStatus("Картин в кэше пока нет. Нажмите «Обновить картину сейчас». Текущий интервал автообновления: " + selectedHoursText(selectedHours) + ".");
        } else {
            setStatus("Сейчас в виджете:\n" + current.artist + "\n" + current.title + "\n\nИнтервал автообновления: " + selectedHoursText(selectedHours) + ".");
        }
    }

    private void setBusy(boolean busy) {
        refreshButton.setEnabled(!busy);
        previousButton.setEnabled(!busy);
        saveIntervalButton.setEnabled(!busy);
        intervalSpinner.setEnabled(!busy);
    }

    private void setStatus(String text) {
        status.setText(text == null ? "" : text);
    }

    private int positionToHours(int position) {
        switch (position) {
            case 0: return 1;
            case 1: return 6;
            case 2: return 12;
            case 3: return 24;
            default: return ArtScheduler.DEFAULT_INTERVAL_HOURS;
        }
    }

    private int hoursToPosition(int hours) {
        switch (hours) {
            case 1: return 0;
            case 6: return 1;
            case 12: return 2;
            case 24: return 3;
            default: return 1;
        }
    }

    private String selectedHoursText(int hours) {
        if (hours == 1) return "1 час";
        if (hours == 24) return "24 часа";
        return hours + " часов";
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0, 0, 0, dp(8));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
