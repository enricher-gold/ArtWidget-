package com.sergei.artwidget;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FullscreenActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private ZoomImageView imageView;
    private ProgressBar progress;
    private TextView error;
    private Bitmap loadedBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setContentView(createLayout());
        String qid = getIntent().getStringExtra("qid");
        ArtEntry entry = new ArtRepository(this).findEntry(qid);
        if (entry == null) {
            showError("Изображение недоступно");
            return;
        }
        load(entry);
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (loadedBitmap != null && !loadedBitmap.isRecycled()) loadedBitmap.recycle();
        loadedBitmap = null;
        super.onDestroy();
    }

    private View createLayout() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        imageView = new ZoomImageView(this);
        imageView.setBackgroundColor(Color.BLACK);
        root.addView(imageView, new FrameLayout.LayoutParams(-1, -1));

        progress = new ProgressBar(this);
        FrameLayout.LayoutParams pp = new FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER);
        root.addView(progress, pp);

        error = new TextView(this);
        error.setTextColor(Color.WHITE);
        error.setTextSize(17);
        error.setGravity(Gravity.CENTER);
        error.setPadding(dp(24), dp(24), dp(24), dp(24));
        error.setVisibility(View.GONE);
        root.addView(error, new FrameLayout.LayoutParams(-1, -2, Gravity.CENTER));

        TextView close = new TextView(this);
        close.setText("×");
        close.setTextColor(Color.WHITE);
        close.setTextSize(36);
        close.setGravity(Gravity.CENTER);
        close.setBackgroundColor(0x66000000);
        close.setOnClickListener(v -> finish());
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(52), dp(52), Gravity.TOP | Gravity.END);
        cp.setMargins(0, dp(18), dp(14), 0);
        root.addView(close, cp);
        return root;
    }

    private void load(ArtEntry entry) {
        executor.execute(() -> {
            try {
                Bitmap bitmap = null;
                String url = entry.originalImageUrl.isEmpty() ? entry.imageUrl : entry.originalImageUrl;
                if (!url.isEmpty()) {
                    try { bitmap = downloadBitmap(url); }
                    catch (Exception networkError) {
                        AppLogger.log(this, "fullscreen", "fallback", networkError.getMessage());
                    }
                }
                if (bitmap == null && entry.localPath != null && !entry.localPath.isEmpty()) {
                    bitmap = BitmapFactory.decodeFile(entry.localPath);
                }
                if (bitmap == null) throw new Exception("Не удалось декодировать изображение");
                final Bitmap finalBitmap = bitmap;
                loadedBitmap = finalBitmap;
                runOnUiThread(() -> {
                    progress.setVisibility(View.GONE);
                    imageView.setImageBitmap(finalBitmap);
                });
            } catch (Exception e) {
                AppLogger.log(this, "fullscreen", "error", e.getMessage());
                runOnUiThread(() -> showError("Не удалось загрузить изображение высокого разрешения"));
            }
        });
    }

    private Bitmap downloadBitmap(String urlString) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(urlString).openConnection();
            conn.setRequestProperty("User-Agent", "ArtWidget/11.2 Android; contact enricherusa@gmail.com");
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            byte[] bytes;
            try (InputStream input = new BufferedInputStream(conn.getInputStream());
                 ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[16384];
                int read;
                int total = 0;
                while ((read = input.read(buffer)) != -1) {
                    total += read;
                    if (total > 45 * 1024 * 1024) throw new Exception("Файл слишком большой");
                    out.write(buffer, 0, read);
                }
                bytes = out.toByteArray();
            }
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(bytes, 0, bytes.length, bounds);
            int sample = 1;
            while (Math.max(bounds.outWidth / sample, bounds.outHeight / sample) > 4096) sample *= 2;
            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            return BitmapFactory.decodeByteArray(bytes, 0, bytes.length, opts);
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private void showError(String message) {
        progress.setVisibility(View.GONE);
        error.setText(message);
        error.setVisibility(View.VISIBLE);
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
