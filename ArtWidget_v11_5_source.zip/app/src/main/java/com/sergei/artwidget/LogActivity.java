package com.sergei.artwidget;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class LogActivity extends Activity {
    private TextView logView;
    private TextView statsView;
    private int bgColor;
    private int textColor;
    private int fieldColor;
    private int borderColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        setContentView(createLayout());
        refresh();
    }

    private View createLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(18));
        root.setBackgroundColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(16), top + dp(16), dp(16), bottom + dp(18));
                return insets;
            });
            root.requestApplyInsets();
        }

        TextView title = new TextView(this);
        title.setText("Технический журнал");
        title.setTextColor(textColor);
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(0, 0, 0, dp(10));
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        statsView = new TextView(this);
        statsView.setTextColor(textColor);
        statsView.setTextSize(14);
        statsView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statsView.setBackground(rounded(fieldColor, 13, borderColor));
        LinearLayout.LayoutParams statsParams = new LinearLayout.LayoutParams(-1, -2);
        statsParams.setMargins(0, 0, 0, dp(12));
        root.addView(statsView, statsParams);

        ScrollView scroll = new ScrollView(this);
        logView = new TextView(this);
        logView.setTextColor(textColor);
        logView.setTextSize(13);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(12), dp(12), dp(12), dp(12));
        logView.setBackground(rounded(fieldColor, 13, borderColor));
        scroll.addView(logView, new ScrollView.LayoutParams(-1, -2));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1f));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button copy = button("Копировать");
        Button clear = button("Очистить");
        Button close = button("Закрыть");
        row.addView(copy, weighted());
        row.addView(clear, weightedMargin());
        row.addView(close, weightedMargin());
        LinearLayout.LayoutParams rowParams = new LinearLayout.LayoutParams(-1, -2);
        rowParams.setMargins(0, dp(12), 0, 0);
        root.addView(row, rowParams);
        copy.setOnClickListener(v -> copyLog());
        clear.setOnClickListener(v -> { AppLogger.clear(this); refresh(); });
        close.setOnClickListener(v -> finish());
        return root;
    }

    private void refresh() {
        ArtRepository repo = new ArtRepository(this);
        statsView.setText(repo.getTechnicalCatalogStats());
        logView.setText(AppLogger.read(this));
    }

    private void copyLog() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("Art Widget log", logView.getText()));
            Toast.makeText(this, "Журнал скопирован", Toast.LENGTH_SHORT).show();
        }
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextColor(textColor);
        b.setTextSize(13);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackground(rounded(fieldColor, 13, borderColor));
        return b;
    }

    private LinearLayout.LayoutParams weighted() { return new LinearLayout.LayoutParams(0, dp(48), 1f); }
    private LinearLayout.LayoutParams weightedMargin() {
        LinearLayout.LayoutParams p = weighted();
        p.setMargins(dp(8), 0, 0, 0);
        return p;
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFEDEDEF;
        borderColor = dark ? 0xFF38383A : 0xFFD1D1D6;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
