package com.sergei.artwidget;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class AppLogger {
    private static final Object LOCK = new Object();
    private static final String FILE_NAME = "artwidget.log";
    private static final int MAX_BYTES = 180_000;

    private AppLogger() { }

    public static void log(Context context, String operation, String result, String details) {
        if (context == null) return;
        synchronized (LOCK) {
            try {
                File file = new File(context.getApplicationContext().getFilesDir(), FILE_NAME);
                if (file.exists() && file.length() > MAX_BYTES) trim(file);
                String timestamp = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(new Date());
                String line = timestamp + " | " + clean(operation) + " | " + clean(result) + " | " + clean(details) + "\n";
                try (FileOutputStream out = new FileOutputStream(file, true)) {
                    out.write(line.getBytes("UTF-8"));
                }
            } catch (Exception ignored) {
            }
        }
    }

    /** Совместимость со старым вызовом. Новые записи возвращаются первыми. */
    public static String read(Context context) {
        return readNewestFirst(context, false);
    }

    /**
     * Читает журнал в обратном хронологическом порядке. При errorsOnly оставляет
     * только ошибки, исключения и повторные попытки фоновых операций.
     */
    public static String readNewestFirst(Context context, boolean errorsOnly) {
        if (context == null) return "";
        synchronized (LOCK) {
            File file = new File(context.getApplicationContext().getFilesDir(), FILE_NAME);
            if (!file.exists()) return "";
            List<String> lines = new ArrayList<>();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String value = line.trim();
                    if (value.isEmpty()) continue;
                    if (!errorsOnly || isErrorLine(value)) lines.add(value);
                }
            } catch (Exception e) {
                return "";
            }
            Collections.reverse(lines);
            StringBuilder out = new StringBuilder();
            for (String line : lines) out.append(line).append('\n');
            return out.toString();
        }
    }

    public static void clear(Context context) {
        if (context == null) return;
        synchronized (LOCK) {
            try {
                File file = new File(context.getApplicationContext().getFilesDir(), FILE_NAME);
                if (file.exists()) file.delete();
            } catch (Exception ignored) {
            }
        }
    }

    private static boolean isErrorLine(String line) {
        String lower = line.toLowerCase(Locale.ROOT);
        return lower.contains(" | error |")
                || lower.contains(" | failed |")
                || lower.contains(" | failure |")
                || lower.contains(" | exception |")
                || lower.contains(" | retry |")
                || lower.contains("ошибка")
                || lower.contains("не удалось");
    }

    private static void trim(File file) {
        try {
            byte[] all = new byte[(int) file.length()];
            try (FileInputStream in = new FileInputStream(file)) {
                int read = in.read(all);
                if (read <= 0) return;
            }
            int keep = Math.min(all.length, MAX_BYTES / 2);
            try (FileOutputStream out = new FileOutputStream(file, false)) {
                out.write(all, all.length - keep, keep);
            }
        } catch (Exception ignored) {
        }
    }

    private static String clean(String value) {
        if (value == null) return "";
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 600 ? s.substring(0, 600) + "…" : s;
    }
}
