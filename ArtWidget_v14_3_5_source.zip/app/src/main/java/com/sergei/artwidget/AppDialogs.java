package com.sergei.artwidget;

import android.app.Activity;
import android.app.Dialog;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class AppDialogs {
    private AppDialogs() { }

    public static void confirm(Activity activity, String title, String message,
                               String noText, String yesText, boolean destructive,
                               final Runnable onYes) {
        if (activity == null || activity.isFinishing()) return;
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        boolean dark = (activity.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        int bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        int cardColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        int textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        int subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        int borderColor = dark ? 0xFF38383A : 0xFFD9D9DE;
        int accent = destructive ? 0xFFFF3B30 : 0xFF007AFF;

        LinearLayout card = new LinearLayout(activity);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(activity, 18), dp(activity, 16), dp(activity, 18), dp(activity, 16));
        card.setBackground(rounded(activity, cardColor, 18, borderColor, 1));

        TextView titleView = new TextView(activity);
        titleView.setText(title == null ? "" : title);
        titleView.setTextColor(textColor);
        titleView.setTextSize(18);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(titleView, new LinearLayout.LayoutParams(-1, -2));

        TextView messageView = new TextView(activity);
        messageView.setText(message == null ? "" : message);
        messageView.setTextColor(subTextColor);
        messageView.setTextSize(14);
        messageView.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams msgParams = new LinearLayout.LayoutParams(-1, -2);
        msgParams.setMargins(0, dp(activity, 8), 0, dp(activity, 14));
        card.addView(messageView, msgParams);

        LinearLayout row = new LinearLayout(activity);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);

        Button no = button(activity, noText == null ? "Нет" : noText, false, textColor, cardColor, borderColor, 0xFF007AFF);
        Button yes = button(activity, yesText == null ? "Да" : yesText, true, Color.WHITE, cardColor, borderColor, accent);
        row.addView(no, new LinearLayout.LayoutParams(0, dp(activity, 46), 1f));
        LinearLayout.LayoutParams yesParams = new LinearLayout.LayoutParams(0, dp(activity, 46), 1f);
        yesParams.setMargins(dp(activity, 8), 0, 0, 0);
        row.addView(yes, yesParams);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        no.setOnClickListener(v -> dialog.dismiss());
        yes.setOnClickListener(v -> {
            dialog.dismiss();
            if (onYes != null) onYes.run();
        });

        LinearLayout wrap = new LinearLayout(activity);
        wrap.setPadding(dp(activity, 20), 0, dp(activity, 20), 0);
        wrap.setGravity(Gravity.CENTER);
        wrap.setBackgroundColor(Color.TRANSPARENT);
        wrap.addView(card, new LinearLayout.LayoutParams(-1, -2));

        dialog.setContentView(wrap);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
            lp.copyFrom(window.getAttributes());
            lp.width = WindowManager.LayoutParams.MATCH_PARENT;
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
            lp.dimAmount = 0.54f;
            window.setAttributes(lp);
        }
        dialog.show();
    }

    public static void message(Activity activity, String title, String message, String buttonText) {
        confirm(activity, title, message, "", buttonText == null ? "Понятно" : buttonText, false, null);
    }

    private static Button button(Activity activity, String text, boolean filled, int textColor,
                                 int cardColor, int borderColor, int accent) {
        Button b = new Button(activity);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(filled ? Color.WHITE : textColor);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setPadding(dp(activity, 10), 0, dp(activity, 10), 0);
        b.setBackground(rounded(activity, filled ? accent : cardColor, 14, filled ? accent : borderColor, 1));
        if (text == null || text.isEmpty()) {
            b.setVisibility(View.GONE);
        }
        return b;
    }

    private static GradientDrawable rounded(Activity activity, int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(activity, radiusDp));
        if (strokeDp > 0) d.setStroke(dp(activity, strokeDp), strokeColor);
        return d;
    }

    private static int dp(Activity activity, int value) {
        return (int) (value * activity.getResources().getDisplayMetrics().density + 0.5f);
    }
}
