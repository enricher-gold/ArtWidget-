package com.sergei.artwidget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.widget.Button;

public final class WidgetPinHelper {
    private static long lastRequestAt;

    private WidgetPinHelper() { }

    public static boolean hasActiveWidgets(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
            int[] ids = manager.getAppWidgetIds(new ComponentName(context.getApplicationContext(), ArtWidgetProvider.class));
            return ids != null && ids.length > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static int activeWidgetCount(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
            int[] ids = manager.getAppWidgetIds(new ComponentName(context.getApplicationContext(), ArtWidgetProvider.class));
            return ids == null ? 0 : ids.length;
        } catch (Exception ignored) {
            return 0;
        }
    }

    public static boolean canRequestPin(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false;
        try {
            return AppWidgetManager.getInstance(context.getApplicationContext()).isRequestPinAppWidgetSupported();
        } catch (Exception ignored) {
            return false;
        }
    }

    public static void requestPinWidgetConfirmed(Activity activity, Button sourceButton) {
        if (activity == null || activity.isFinishing()) return;
        int count = activeWidgetCount(activity);
        String title = count > 0
                ? I18n.t(activity, "Добавить ещё один виджет?", "Add another widget?")
                : I18n.t(activity, "Добавить виджет на экран?", "Add widget to home screen?");
        String message = count > 0
                ? I18n.t(activity,
                    "На главном экране уже есть виджет Art Widget. Будет добавлен ещё один экземпляр. Продолжить?",
                    "An Art Widget already exists on the home screen. Another instance will be added. Continue?")
                : I18n.t(activity,
                    "Будет добавлен виджет Art Widget на главный экран. Продолжить?",
                    "Art Widget will be added to the home screen. Continue?");
        AppDialogs.confirm(activity, title, message,
                I18n.t(activity, "Нет", "No"),
                I18n.t(activity, "Да", "Yes"),
                false,
                () -> requestPinWidget(activity, sourceButton));
    }

    private static void requestPinWidget(Activity activity, Button sourceButton) {
        if (activity == null || activity.isFinishing()) return;
        long now = System.currentTimeMillis();
        if (now - lastRequestAt < 2500L) return;
        lastRequestAt = now;
        if (sourceButton != null) {
            sourceButton.setEnabled(false);
            sourceButton.setAlpha(0.55f);
            sourceButton.postDelayed(() -> {
                sourceButton.setEnabled(true);
                sourceButton.setAlpha(1f);
            }, 3500L);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && canRequestPin(activity)) {
            try {
                AppWidgetManager manager = AppWidgetManager.getInstance(activity.getApplicationContext());
                ComponentName provider = new ComponentName(activity.getApplicationContext(), ArtWidgetProvider.class);
                manager.requestPinAppWidget(provider, null, null);
                return;
            } catch (Exception e) {
                AppLogger.log(activity, "pin-widget", "error", e.getMessage());
            }
        }
        showManualInstruction(activity);
    }

    private static void showManualInstruction(Activity activity) {
        AppDialogs.message(activity,
                I18n.t(activity, "Добавление виджета", "Adding a widget"),
                I18n.t(activity,
                        "Этот экран телефона не поддерживает автоматическое добавление виджета. Добавьте его вручную: удерживайте пустое место на главном экране, выберите «Виджеты» и найдите Art Widget.",
                        "This home screen does not support automatic widget pinning. Add it manually: long-press an empty area on the home screen, choose Widgets, and find Art Widget."),
                I18n.t(activity, "Понятно", "OK"));
    }
}
