package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Резервно восстанавливает пропущенный AlarmManager-запуск. */
public final class ScheduledUpdateWatchdogWorker extends Worker {
    public ScheduledUpdateWatchdogWorker(@NonNull Context context,
                                         @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        ArtScheduler.ensureScheduled(getApplicationContext());
        return Result.success();
    }
}
