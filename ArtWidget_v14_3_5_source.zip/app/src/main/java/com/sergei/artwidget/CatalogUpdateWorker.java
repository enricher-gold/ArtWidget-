package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Фоново добавляет в кэш одно или несколько произведений, не меняя текущую картину. */
public class CatalogUpdateWorker extends Worker {
    public static final String KEY_COUNT = "count";
    public static final String KEY_MANUAL = "manual";
    public static final String KEY_EMPTY_RETRIES = "empty_retries";
    private static final int MAX_EMPTY_BATCH_RETRIES = 4;

    public CatalogUpdateWorker(@NonNull Context context,
                               @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        ArtRepository repo = new ArtRepository(getApplicationContext());
        int requested = Math.max(1, Math.min(50, getInputData().getInt(KEY_COUNT, 1)));
        boolean manual = getInputData().getBoolean(KEY_MANUAL, false);
        int emptyRetries = Math.max(0, getInputData().getInt(KEY_EMPTY_RETRIES, 0));
        int added = 0;
        try {
            repo.initializeStorageInBackground();
            if (manual && !repo.isDownloadNetworkAllowed()) {
                repo.setManualPrefetchStatus(repo.isWifiOnly()
                        ? "Ожидание подключения к Wi-Fi"
                        : "Ожидание подключения к интернету");
                return Result.retry();
            }
            if (manual) repo.setManualPrefetchStatus("Выполняется: добавлено 0 из " + requested);
            int previousCount = repo.getCachedCountFast();
            for (int i = 0; i < requested && !isStopped(); i++) {
                boolean loaded = repo.prefetchOneArtwork();
                int currentCount = repo.getCachedCountFast();
                if (currentCount > previousCount) added += currentCount - previousCount;
                previousCount = currentCount;
                if (manual) repo.setManualPrefetchStatus("Выполняется: добавлено " + added + " из " + requested);
                if (!loaded || currentCount >= ArtRepository.MAX_CACHE_FILES) break;
            }
            if (manual) {
                String result = added > 0
                        ? "Последнее пополнение: добавлено " + added + " картин"
                        : "Последнее пополнение не добавило новых картин";
                repo.setManualPrefetchStatus(result);
            }
            AppLogger.log(getApplicationContext(), "cache-prefetch", "ok",
                    "requested=" + requested + ", added=" + added + ", manual=" + manual);
            if (!manual && !isStopped()
                    && repo.getCachedCountFast() < ArtRepository.MAX_CACHE_FILES
                    && repo.getUncachedCatalogCountForCurrentMode() > 0) {
                if (added > 0) {
                    CatalogWorkScheduler.schedulePrefetchContinuation(getApplicationContext(), 0);
                } else if (emptyRetries < MAX_EMPTY_BATCH_RETRIES) {
                    // A temporary Wikipedia/Commons failure must not permanently stop
                    // background growth at one arbitrary cache size (for example 51 files).
                    CatalogWorkScheduler.schedulePrefetchContinuation(getApplicationContext(), emptyRetries + 1);
                }
            }
            return Result.success();
        } catch (Exception e) {
            if (manual) repo.setManualPrefetchStatus(added > 0
                    ? "Загрузка остановлена после " + added + " картин"
                    : "Не удалось пополнить кэш");
            // Ошибка фоновой загрузки не должна запускать бесконечные повторы
            // и никак не влияет на показ уже загруженных изображений.
            AppLogger.log(getApplicationContext(), "cache-prefetch", "error", e.getMessage());
            return Result.success();
        }
    }
}
