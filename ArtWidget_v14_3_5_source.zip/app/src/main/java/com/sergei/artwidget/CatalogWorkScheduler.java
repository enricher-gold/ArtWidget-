package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Проверяет встроенные каталоги и обновляет метаданные категории «Обнажённая натура» без фоновой загрузки изображений. */
public final class CatalogWorkScheduler {
    public static final int PREFETCH_BATCH_SIZE = 8;
    public static final int PREFETCH_DELAY_SECONDS = 12;

    private static final String STATE_PREFS = "catalog_work_scheduler_state_v14_3_2";
    private static final String KEY_LAST_BOOTSTRAP_REQUEST_AT = "last_bootstrap_request_at";
    private static final String KEY_QUEUE_MODEL_VERSION = "queue_model_version";
    private static final int QUEUE_MODEL_VERSION = 2;
    private static final long BOOTSTRAP_COOLDOWN_MS = TimeUnit.HOURS.toMillis(6);
    private static final long CONTINUATION_DELAY_MINUTES = 15L;

    private static final String WORK_BOOTSTRAP = "art_catalog_bootstrap_v14_1_3";
    private static final String WORK_PREFETCH = "art_cache_prefetch_v14_1_3";
    private static final String WORK_MANUAL_PREFETCH = "art_manual_cache_prefetch_v14_1_3";
    private static final String WORK_PREFETCH_PERIODIC = "art_cache_prefetch_periodic_v14_1_3";
    private static final String WORK_NSFW_DISCOVERY = "art_nsfw_discovery_v14_1_3";
    private static final String WORK_NSFW_PERIODIC = "art_nsfw_discovery_periodic_v14_1_3";
    private static final String WORK_BILINGUAL_REINDEX = "art_bilingual_reindex_v14_3_1";

    private CatalogWorkScheduler() { }

    public static void ensureInitialized(Context context) {
        Context app = context.getApplicationContext();
        cancelImagePrefetchWork(app);
        schedulePeriodicNsfwDiscovery(app);

        // Этот метод вызывается при открытии экранов, перерисовке виджета и
        // системных событиях. Без ограничения каждый вызов после завершения
        // предыдущей unique work снова запускал bootstrap и новый обход Wikipedia.
        SharedPreferences state = app.getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE);
        if (state.getInt(KEY_QUEUE_MODEL_VERSION, 0) != QUEUE_MODEL_VERSION) {
            // Удаляем хвосты старых 20-секундных цепочек после обновления приложения.
            WorkManager manager = WorkManager.getInstance(app);
            manager.cancelUniqueWork(WORK_BOOTSTRAP);
            manager.cancelUniqueWork(WORK_NSFW_DISCOVERY);
            manager.cancelUniqueWork(WORK_BILINGUAL_REINDEX);
            state.edit().putInt(KEY_QUEUE_MODEL_VERSION, QUEUE_MODEL_VERSION).apply();
            if (!new ArtRepository(app).isBilingualReindexComplete()) {
                scheduleBilingualReindexContinuation(app);
            }
        }
        long now = System.currentTimeMillis();
        long last = state.getLong(KEY_LAST_BOOTSTRAP_REQUEST_AT, 0L);
        if (last > 0L && now - last >= 0L && now - last < BOOTSTRAP_COOLDOWN_MS) return;
        state.edit().putLong(KEY_LAST_BOOTSTRAP_REQUEST_AT, now).apply();

        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(app)
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.KEEP, request);
    }

    public static void requestManualRefresh(Context context) {
        Context app = context.getApplicationContext();
        cancelImagePrefetchWork(app);
        app.getSharedPreferences(STATE_PREFS, Context.MODE_PRIVATE)
                .edit().putLong(KEY_LAST_BOOTSTRAP_REQUEST_AT, System.currentTimeMillis()).apply();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .build();
        WorkManager.getInstance(app)
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.REPLACE, request);
        scheduleNsfwDiscovery(app, true);
    }

    /** Кэш изображений пополняется только при выборе новой картины или автообновлении виджета. */
    public static void schedulePrefetch(Context context) {
        cancelImagePrefetchWork(context.getApplicationContext());
    }

    public static void schedulePrefetchContinuation(Context context, int emptyRetries) {
        cancelImagePrefetchWork(context.getApplicationContext());
    }

    public static void requestManualPrefetch(Context context, int count) {
        cancelImagePrefetchWork(context.getApplicationContext());
    }

    public static void scheduleNsfwDiscovery(Context context, boolean forceRescan) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(NsfwCatalogDiscoveryWorker.class)
                .setConstraints(networkConstraints(context))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .setInputData(new Data.Builder()
                        .putBoolean(NsfwCatalogDiscoveryWorker.KEY_FORCE_RESCAN, forceRescan)
                        .build())
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_NSFW_DISCOVERY,
                        forceRescan ? ExistingWorkPolicy.REPLACE : ExistingWorkPolicy.KEEP,
                        request);
    }

    public static void scheduleNsfwDiscoveryContinuation(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(NsfwCatalogDiscoveryWorker.class)
                .setConstraints(networkConstraints(context))
                .setInitialDelay(CONTINUATION_DELAY_MINUTES, TimeUnit.MINUTES)
                .setInputData(new Data.Builder()
                        .putBoolean(NsfwCatalogDiscoveryWorker.KEY_FORCE_RESCAN, false)
                        .build())
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_NSFW_DISCOVERY, ExistingWorkPolicy.APPEND_OR_REPLACE, request);
    }

    private static void schedulePeriodicNsfwDiscovery(Context context) {
        PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(
                NsfwCatalogDiscoveryWorker.class, 24, TimeUnit.HOURS)
                .setConstraints(networkConstraints(context))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniquePeriodicWork(WORK_NSFW_PERIODIC,
                        ExistingPeriodicWorkPolicy.UPDATE, request);
    }

    public static void scheduleBilingualReindex(Context context, boolean restart) {
        Context app = context.getApplicationContext();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(BilingualMetadataWorker.class)
                .setConstraints(networkConstraints(app))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(app).enqueueUniqueWork(WORK_BILINGUAL_REINDEX,
                restart ? ExistingWorkPolicy.REPLACE : ExistingWorkPolicy.KEEP, request);
    }

    public static void scheduleBilingualReindexContinuation(Context context) {
        Context app = context.getApplicationContext();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(BilingualMetadataWorker.class)
                .setConstraints(networkConstraints(app))
                .setInitialDelay(CONTINUATION_DELAY_MINUTES, TimeUnit.MINUTES)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(app).enqueueUniqueWork(WORK_BILINGUAL_REINDEX,
                ExistingWorkPolicy.APPEND_OR_REPLACE, request);
    }

    private static void cancelImagePrefetchWork(Context context) {
        WorkManager manager = WorkManager.getInstance(context.getApplicationContext());
        manager.cancelUniqueWork(WORK_PREFETCH);
        manager.cancelUniqueWork(WORK_MANUAL_PREFETCH);
        manager.cancelUniqueWork(WORK_PREFETCH_PERIODIC);
    }

    private static Constraints networkConstraints(Context context) {
        boolean wifiOnly = new ArtRepository(context.getApplicationContext()).isWifiOnly();
        return new Constraints.Builder()
                .setRequiredNetworkType(wifiOnly ? NetworkType.UNMETERED : NetworkType.CONNECTED)
                .build();
    }

    public static void scheduleRefill(Context context, int mode) {
        if (mode == ArtRepository.CONTENT_ADULT_ONLY) scheduleNsfwDiscovery(context, false);
    }

    public static void scheduleBothIfNeeded(Context context) {
        ensureInitialized(context);
    }
}
