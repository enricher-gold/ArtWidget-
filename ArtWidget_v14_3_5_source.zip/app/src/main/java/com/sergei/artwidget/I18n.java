package com.sergei.artwidget;

import android.content.Context;

public final class I18n {
    private I18n() { }

    public static boolean isEnglish(Context context) {
        return LanguageManager.isEnglish(context);
    }

    public static String t(Context context, String russian, String english) {
        return isEnglish(context) ? english : russian;
    }

    public static String t(String language, String russian, String english) {
        return LanguageManager.EN.equals(language) ? english : russian;
    }
}
