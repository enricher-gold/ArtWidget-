package com.sergei.artwidget;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.MimeTypeMap;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class ImageSaver {
    private static final String USER_AGENT = "ArtWidget/14.0 Android; contact enricherusa@gmail.com";
    private static final long MAX_BYTES = 90L * 1024L * 1024L;

    public interface Callback {
        void onSuccess(String displayName);
        void onError(Exception error);
    }

    private ImageSaver() { }

    public static void save(Context context, ArtEntry entry, Callback callback) {
        HttpURLConnection connection = null;
        InputStream input = null;
        try {
            String mime = "image/jpeg";
            String sourceUrl = entry.originalImageUrl == null || entry.originalImageUrl.isEmpty()
                    ? entry.imageUrl : entry.originalImageUrl;
            ArtRepository repository = new ArtRepository(context);
            IOException networkError = null;
            if (sourceUrl != null && !sourceUrl.isEmpty() && repository.isDownloadNetworkAllowed()) {
                for (int attempt = 0; attempt < 3; attempt++) {
                    try {
                        connection = (HttpURLConnection) new URL(sourceUrl).openConnection();
                        connection.setInstanceFollowRedirects(true);
                        connection.setRequestProperty("User-Agent", USER_AGENT);
                        connection.setConnectTimeout(12000);
                        connection.setReadTimeout(45000);
                        int code = connection.getResponseCode();
                        if (code < 200 || code >= 300) throw new IOException(I18n.t(context, "Ошибка загрузки: HTTP ", "Download error: HTTP ") + code);
                        String type = connection.getContentType();
                        if (type != null && type.toLowerCase(Locale.ROOT).startsWith("image/")) {
                            mime = type.split(";", 2)[0].trim();
                        }
                        input = new BufferedInputStream(connection.getInputStream());
                        break;
                    } catch (IOException e) {
                        networkError = e;
                        if (connection != null) connection.disconnect();
                        connection = null;
                        if (attempt < 2) {
                            try { Thread.sleep(attempt == 0 ? 1000L : 2500L); }
                            catch (InterruptedException interrupted) {
                                Thread.currentThread().interrupt();
                                throw new IOException(I18n.t(context, "Сохранение отменено", "Saving was cancelled"), interrupted);
                            }
                        }
                    }
                }
            }
            if (input == null && entry.localPath != null && !entry.localPath.isEmpty()
                    && new File(entry.localPath).isFile()) {
                File local = new File(entry.localPath);
                mime = guessMime(local.getName(), mime);
                input = new BufferedInputStream(new FileInputStream(local));
            }
            if (input == null) {
                if (networkError != null) throw networkError;
                throw new IOException(I18n.t(context, "Оригинал недоступен: подключите интернет", "The original is unavailable. Connect to the internet"));
            }

            String language = LanguageManager.getLanguage(context);
            String artist = entry.localizedArtist(language);
            String base = ArtEntry.isUnknownArtist(artist)
                    ? sanitize(entry.localizedTitle(language))
                    : sanitize(artist + " - " + entry.localizedTitle(language));
            if (base.isEmpty()) base = "Art Widget";
            String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
            String extension = extensionForMime(mime);
            String displayName = base + "_" + stamp + "." + extension;
            saveStream(context, input, displayName, mime);
            callback.onSuccess(displayName);
        } catch (Exception e) {
            callback.onError(e);
        } finally {
            try { if (input != null) input.close(); } catch (Exception ignored) { }
            if (connection != null) connection.disconnect();
        }
    }

    private static void saveStream(Context context, InputStream input, String displayName, String mime)
            throws IOException {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, displayName);
            values.put(MediaStore.Images.Media.MIME_TYPE, mime);
            values.put(MediaStore.Images.Media.RELATIVE_PATH,
                    Environment.DIRECTORY_PICTURES + File.separator + "Art Widget");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException(I18n.t(context, "Не удалось создать файл в галерее", "Could not create a file in the gallery"));
            boolean completed = false;
            OutputStream rawOutput = resolver.openOutputStream(uri);
            if (rawOutput == null) {
                resolver.delete(uri, null, null);
                throw new IOException(I18n.t(context, "Не удалось открыть файл для записи", "Could not open the file for writing"));
            }
            try (OutputStream output = new BufferedOutputStream(rawOutput)) {
                copyLimited(context, input, output);
                completed = true;
            } finally {
                if (!completed) resolver.delete(uri, null, null);
            }
            ContentValues ready = new ContentValues();
            ready.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, ready, null, null);
        } else {
            File pictures = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
            File directory = new File(pictures, "Art Widget");
            if (!directory.exists() && !directory.mkdirs()) {
                throw new IOException(I18n.t(context, "Не удалось создать папку Art Widget", "Could not create the Art Widget folder"));
            }
            File outputFile = uniqueLegacyFile(directory, displayName);
            try (OutputStream output = new BufferedOutputStream(new FileOutputStream(outputFile))) {
                copyLimited(context, input, output);
            }
            MediaScannerConnection.scanFile(context,
                    new String[]{outputFile.getAbsolutePath()}, new String[]{mime}, null);
        }
    }

    private static void copyLimited(Context context, InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[32 * 1024];
        long total = 0;
        int read;
        while ((read = input.read(buffer)) != -1) {
            total += read;
            if (total > MAX_BYTES) throw new IOException(I18n.t(context, "Изображение слишком большое", "The image is too large"));
            output.write(buffer, 0, read);
        }
        output.flush();
    }

    private static File uniqueLegacyFile(File directory, String displayName) {
        File file = new File(directory, displayName);
        if (!file.exists()) return file;
        int dot = displayName.lastIndexOf('.');
        String stem = dot > 0 ? displayName.substring(0, dot) : displayName;
        String ext = dot > 0 ? displayName.substring(dot) : "";
        int index = 2;
        while (file.exists()) file = new File(directory, stem + "_" + index++ + ext);
        return file;
    }

    private static String sanitize(String value) {
        if (value == null) return "";
        String result = value.replaceAll("[\\\\/:*?\"<>|]", " ")
                .replaceAll("\\s+", " ").trim();
        if (result.length() > 120) result = result.substring(0, 120).trim();
        return result;
    }

    private static String extensionForMime(String mime) {
        String extension = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime);
        if (extension == null || extension.isEmpty()) {
            if ("image/png".equalsIgnoreCase(mime)) return "png";
            if ("image/webp".equalsIgnoreCase(mime)) return "webp";
            return "jpg";
        }
        return extension;
    }

    private static String guessMime(String fileName, String fallback) {
        int dot = fileName == null ? -1 : fileName.lastIndexOf('.');
        if (dot >= 0) {
            String value = MimeTypeMap.getSingleton().getMimeTypeFromExtension(
                    fileName.substring(dot + 1).toLowerCase(Locale.ROOT));
            if (value != null) return value;
        }
        return fallback;
    }
}
