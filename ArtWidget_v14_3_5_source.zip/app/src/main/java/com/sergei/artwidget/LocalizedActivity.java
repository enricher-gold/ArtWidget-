package com.sergei.artwidget;

import android.app.Activity;
import android.os.Bundle;

public abstract class LocalizedActivity extends Activity {
    private String languageAtCreation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        languageAtCreation = LanguageManager.getLanguage(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        String current = LanguageManager.getLanguage(this);
        if (languageAtCreation != null && !languageAtCreation.equals(current)) {
            recreate();
        }
    }

    protected final String tr(String russian, String english) {
        return I18n.t(this, russian, english);
    }
}
