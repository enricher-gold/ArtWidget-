package com.sergei.artwidget;

import java.util.concurrent.atomic.AtomicBoolean;

public final class UpdateCoordinator {
    private static final AtomicBoolean BUSY = new AtomicBoolean(false);

    private UpdateCoordinator() { }

    public static boolean tryBegin() {
        return BUSY.compareAndSet(false, true);
    }

    public static void finish() {
        BUSY.set(false);
    }

    public static boolean isBusy() {
        return BUSY.get();
    }
}
