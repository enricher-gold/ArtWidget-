package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Фоново переиндексирует русские и английские подписи/aliases кэша. */
public final class BilingualMetadataWorker extends Worker {
    public BilingualMetadataWorker(@NonNull Context context,
                                   @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        ArtRepository repository = new ArtRepository(getApplicationContext());
        try {
            repository.initializeStorageInBackground();
            repository.refreshBilingualSearchMetadata(50);
            if (!repository.isBilingualReindexComplete() && !isStopped()) {
                CatalogWorkScheduler.scheduleBilingualReindexContinuation(getApplicationContext());
            }
            return Result.success();
        } catch (Exception e) {
            AppLogger.log(getApplicationContext(), "bilingual-index-worker", "error",
                    e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
            return Result.retry();
        }
    }
}
