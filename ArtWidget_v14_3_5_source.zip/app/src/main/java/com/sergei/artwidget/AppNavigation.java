package com.sergei.artwidget;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

/** Единый визуальный стиль кнопки «Назад» для всех вложенных экранов. */
public final class AppNavigation {
    private AppNavigation() { }

    public static Button backButton(Context context, int textColor, View.OnClickListener listener) {
        Button back = new Button(context);
        apply(back, textColor, listener);
        return back;
    }

    public static TextView backOverlay(Context context, int textColor, int backgroundColor,
                                       View.OnClickListener listener) {
        TextView back = new TextView(context);
        apply(back, textColor, listener);
        back.setBackgroundColor(backgroundColor);
        return back;
    }

    private static void apply(TextView back, int textColor, View.OnClickListener listener) {
        back.setText("‹");
        back.setTextSize(32);
        back.setTextColor(textColor);
        back.setGravity(Gravity.CENTER);
        back.setMinWidth(0);
        back.setMinHeight(0);
        back.setPadding(0, 0, 0, 0);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setContentDescription("Назад / Back");
        back.setOnClickListener(listener);
    }
}
