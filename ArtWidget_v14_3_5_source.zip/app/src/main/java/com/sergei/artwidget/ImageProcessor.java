package com.sergei.artwidget;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public final class ImageProcessor {
    public static final float MAX_ASPECT_RATIO = 4.5f;
    private static final int MAX_STANDARD_SIDE = 1800;

    private ImageProcessor() { }

    public static File processToStandard(File downloaded, File outputStem) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(downloaded.getAbsolutePath(), bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw new IOException("Загруженный файл не распознан как изображение");
        }
        float ratio = bounds.outWidth / (float) bounds.outHeight;
        if (ratio > MAX_ASPECT_RATIO || ratio < 1f / MAX_ASPECT_RATIO) {
            throw new IOException("Изображение имеет неподходящие пропорции");
        }

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
        opts.inSampleSize = sampleSize(bounds.outWidth, bounds.outHeight, MAX_STANDARD_SIDE);
        Bitmap bitmap = BitmapFactory.decodeFile(downloaded.getAbsolutePath(), opts);
        if (bitmap == null) throw new IOException("Не удалось обработать изображение");

        Bitmap processed = makeEdgeBackgroundTransparent(bitmap);
        if (processed != bitmap) bitmap.recycle();

        boolean hasAlpha = processed.hasAlpha() && containsTransparentPixel(processed);
        File target = new File(outputStem.getAbsolutePath() + (hasAlpha ? ".png" : ".jpg"));
        try (FileOutputStream out = new FileOutputStream(target)) {
            boolean ok = processed.compress(hasAlpha ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG,
                    hasAlpha ? 100 : 91, out);
            if (!ok) throw new IOException("Не удалось сохранить обработанное изображение");
        } finally {
            processed.recycle();
        }
        if (!target.exists() || target.length() == 0) throw new IOException("Не удалось сохранить изображение");
        return target;
    }

    public static int[] readBounds(String path) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(path, options);
        return new int[]{options.outWidth, options.outHeight};
    }

    private static int sampleSize(int width, int height, int maxSide) {
        int sample = 1;
        while (Math.max(width / sample, height / sample) > maxSide * 2) sample *= 2;
        return sample;
    }

    private static Bitmap makeEdgeBackgroundTransparent(Bitmap source) {
        int w = source.getWidth();
        int h = source.getHeight();
        if (w < 120 || h < 120 || (long) w * h > 4_000_000L) return source;

        int c1 = source.getPixel(0, 0);
        int c2 = source.getPixel(w - 1, 0);
        int c3 = source.getPixel(0, h - 1);
        int c4 = source.getPixel(w - 1, h - 1);
        if (!isNearWhite(c1) || !isNearWhite(c2) || !isNearWhite(c3) || !isNearWhite(c4)) return source;

        int[] pixels = new int[w * h];
        source.getPixels(pixels, 0, w, 0, 0, w, h);
        boolean[] visited = new boolean[pixels.length];
        int[] queue = new int[pixels.length];
        int head = 0;
        int tail = 0;

        for (int x = 0; x < w; x++) {
            tail = enqueueIfBackground(x, pixels, visited, queue, tail);
            tail = enqueueIfBackground((h - 1) * w + x, pixels, visited, queue, tail);
        }
        for (int y = 0; y < h; y++) {
            tail = enqueueIfBackground(y * w, pixels, visited, queue, tail);
            tail = enqueueIfBackground(y * w + w - 1, pixels, visited, queue, tail);
        }

        int removed = 0;
        while (head < tail) {
            int idx = queue[head++];
            removed++;
            int x = idx % w;
            int y = idx / w;
            if (x > 0) tail = enqueueIfBackground(idx - 1, pixels, visited, queue, tail);
            if (x + 1 < w) tail = enqueueIfBackground(idx + 1, pixels, visited, queue, tail);
            if (y > 0) tail = enqueueIfBackground(idx - w, pixels, visited, queue, tail);
            if (y + 1 < h) tail = enqueueIfBackground(idx + w, pixels, visited, queue, tail);
        }

        float removedRatio = removed / (float) pixels.length;
        if (removedRatio < 0.035f || removedRatio > 0.68f) return source;

        int minX = w, minY = h, maxX = -1, maxY = -1;
        for (int i = 0; i < pixels.length; i++) {
            if (!visited[i]) {
                int x = i % w;
                int y = i / w;
                if (x < minX) minX = x;
                if (x > maxX) maxX = x;
                if (y < minY) minY = y;
                if (y > maxY) maxY = y;
            }
        }
        if (maxX <= minX || maxY <= minY) return source;
        int marginX = Math.min(minX, w - 1 - maxX);
        int marginY = Math.min(minY, h - 1 - maxY);
        if (marginX < w * 0.015f && marginY < h * 0.015f) return source;

        for (int i = 0; i < pixels.length; i++) {
            if (visited[i]) pixels[i] = pixels[i] & 0x00FFFFFF;
        }
        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        result.setPixels(pixels, 0, w, 0, 0, w, h);
        result.setHasAlpha(true);
        return result;
    }

    private static int enqueueIfBackground(int idx, int[] pixels, boolean[] visited, int[] queue, int tail) {
        if (idx < 0 || idx >= pixels.length || visited[idx]) return tail;
        if (!isNearWhite(pixels[idx])) return tail;
        visited[idx] = true;
        queue[tail] = idx;
        return tail + 1;
    }

    private static boolean isNearWhite(int color) {
        int a = Color.alpha(color);
        if (a < 30) return true;
        int r = Color.red(color);
        int g = Color.green(color);
        int b = Color.blue(color);
        int max = Math.max(r, Math.max(g, b));
        int min = Math.min(r, Math.min(g, b));
        return min >= 238 && max - min <= 14;
    }

    private static boolean containsTransparentPixel(Bitmap bitmap) {
        int w = bitmap.getWidth();
        int h = bitmap.getHeight();
        int stepX = Math.max(1, w / 60);
        int stepY = Math.max(1, h / 60);
        for (int y = 0; y < h; y += stepY) {
            for (int x = 0; x < w; x += stepX) {
                if (Color.alpha(bitmap.getPixel(x, y)) < 250) return true;
            }
        }
        return false;
    }
}
