package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Фоново продолжает обход тематических категорий Wikipedia. */
public class NsfwCatalogDiscoveryWorker extends Worker {
    public static final String KEY_FORCE_RESCAN = "force_rescan";

    public NsfwCatalogDiscoveryWorker(@NonNull Context context,
                                      @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context context = getApplicationContext();
        ArtRepository repo = new ArtRepository(context);
        if (!repo.isDownloadNetworkAllowed()) return Result.retry();
        try {
            boolean force = getInputData().getBoolean(KEY_FORCE_RESCAN, false);
            WikipediaNsfwCatalogUpdater.UpdateResult result =
                    new WikipediaNsfwCatalogUpdater(context).updateBatch(20, force);
            repo.onDynamicNsfwCatalogUpdated(result.added, result.status);
            if (result.moreRemaining && !isStopped()) {
                CatalogWorkScheduler.scheduleNsfwDiscoveryContinuation(context);
            }
            AppLogger.log(context, "dynamic-nsfw", "ok",
                    "added=" + result.added + ", scanned=" + result.scanned
                            + ", more=" + result.moreRemaining);
            return Result.success();
        } catch (Exception e) {
            AppLogger.log(context, "dynamic-nsfw", "error", e.getMessage());
            return Result.retry();
        }
    }
}
