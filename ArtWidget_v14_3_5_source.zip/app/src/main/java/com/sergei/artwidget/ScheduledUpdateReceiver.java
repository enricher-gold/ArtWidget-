package com.sergei.artwidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Внутренний receiver только передаёт запуск в WorkManager. */
public final class ScheduledUpdateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !ArtWidgetProvider.ACTION_SCHEDULED_UPDATE.equals(intent.getAction())) return;
        ArtScheduler.onAlarmFired(context);
    }
}
