package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Надёжно выполняет плановую смену картины вне BroadcastReceiver. */
public final class ScheduledArtworkUpdateWorker extends Worker {
    public static final String KEY_REASON = "reason";

    public ScheduledArtworkUpdateWorker(@NonNull Context context,
                                         @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context app = getApplicationContext();
        if (!ArtScheduler.isEnabled(app)) return Result.success();
        String reason = getInputData().getString(KEY_REASON);
        if (!UpdateCoordinator.tryBegin()) {
            AppLogger.log(app, "auto-update", "retry", "another update is running");
            return Result.retry();
        }
        ArtScheduler.recordAutomaticAttempt(app, reason);
        try {
            ArtRepository repository = new ArtRepository(app);
            ArtEntry before = repository.getCurrent();
            ArtEntry after = null;
            Exception primaryError = null;
            boolean usedCacheFallback = false;

            try {
                after = repository.fetchNextArtwork();
            } catch (Exception e) {
                primaryError = e;
                AppLogger.log(app, "auto-update", "network-or-catalog-error", messageOf(e));
            }

            // Любая сетевая ошибка, отсутствие новых записей или возврат той же
            // картины должны завершаться попыткой взять другую запись из кэша.
            if (after == null || (before != null && before.sameArtwork(after))) {
                try {
                    ArtEntry cached = repository.activateCachedFallbackForAutomaticUpdate();
                    if (cached != null) {
                        after = cached;
                        usedCacheFallback = true;
                    }
                } catch (Exception cacheError) {
                    if (primaryError == null) primaryError = cacheError;
                    AppLogger.log(app, "auto-update-cache", "error", messageOf(cacheError));
                }
            }

            if (after == null || (before != null && before.sameArtwork(after))) {
                if (primaryError != null) throw new IllegalStateException(messageOf(primaryError), primaryError);
                throw new IllegalStateException(I18n.t(app,
                        "В кэше нет другой подходящей картины",
                        "There is no other suitable artwork in the cache"));
            }

            ArtWidgetProvider.renderAllWidgetsNow(app);
            String details = (usedCacheFallback ? "cache-fallback | " : "success | ")
                    + after.canonicalKey();
            ArtScheduler.recordAutomaticSuccess(app, details);
            if (primaryError != null && usedCacheFallback) {
                AppLogger.log(app, "auto-update", "recovered-from-cache",
                        messageOf(primaryError) + " | " + after.canonicalKey());
            } else {
                AppLogger.log(app, "auto-update", "success", details);
            }
            return Result.success();
        } catch (Exception e) {
            String message = messageOf(e);
            ArtScheduler.recordAutomaticError(app, message);
            AppLogger.log(app, "auto-update", "error",
                    "attempt=" + getRunAttemptCount() + " | " + message);
            return Result.retry();
        } finally {
            UpdateCoordinator.finish();
        }
    }

    private static String messageOf(Exception e) {
        if (e == null) return "unknown error";
        String value = e.getMessage();
        return value == null || value.trim().isEmpty()
                ? e.getClass().getSimpleName()
                : value.trim();
    }
}
