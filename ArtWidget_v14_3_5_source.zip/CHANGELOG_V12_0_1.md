# Art Widget 12.0.1

- Включена поддержка AndroidX через `android.useAndroidX=true`.
- Добавлен `android.enableJetifier=true` для совместимости транзитивных зависимостей.
- Исправлена ошибка GitHub Actions `:app:checkDebugAarMetadata`, возникавшая из-за WorkManager/AndroidX.
- versionName: 12.0.1
- versionCode: 21
