# Code audit 14.3.2

## Confirmed defects in 14.3.1

1. `ArtScheduler.nextSlotAfter()` returned today's anchor whenever current time was earlier than it. For short intervals this skipped valid slots between the previous day and the selected time.
2. The next alarm was scheduled only after a successful Worker result. A delayed or failed Worker therefore broke the alarm chain.
3. `ExistingWorkPolicy.KEEP` allowed an old retry task to block a newer scheduled slot.
4. The caption was painted into the artwork bitmap and therefore scaled together with the image and orientation.
5. `ConnectivityManager.getActiveNetwork()` could identify the VPN or temporarily return no active network after wake-up, causing a false “no internet” result before any HTTP request.
6. `CatalogWorkScheduler.ensureInitialized()` could start bootstrap again after every completed unique task. The NSFW and bilingual continuation chains also ran every 20 seconds. The journal showed repeated catalog work and multi-hour waits, which could starve the scheduled artwork Worker.

## Corrections

- Periodic grid now uses the nearest strictly future `anchor + k × interval` slot, including negative `k`.
- Alarm chain advances before the artwork Worker starts.
- Overdue state is advanced once before a catch-up update is enqueued.
- New scheduled work replaces stale retry work.
- Caption is a separate 14 sp `TextView` in `RemoteViews`.
- Ordinary network mode performs the real HTTP request; only Wi-Fi policy is prechecked.
- Wi-Fi detection checks all networks so an active VPN does not hide Wi-Fi.
- Bootstrap is throttled, old rapid WorkManager chains are cancelled on migration, and continuation delay is 15 minutes.

## Offline validation

- Java bracket/string/comment structural scan passed.
- All XML files parsed successfully.
- All JSON files parsed successfully.
- Catalog asset validator passed: 89 general and 42 adult exact entries.
- Schedule grid test passed for six boundary cases.
- Full Android Gradle build was not run because the environment has no Android SDK, Gradle executable, or Gradle wrapper.
