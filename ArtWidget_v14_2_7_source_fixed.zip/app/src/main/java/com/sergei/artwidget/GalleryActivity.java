package com.sergei.artwidget;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GalleryActivity extends LocalizedActivity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService statsExecutor = Executors.newSingleThreadExecutor();
    private ThumbnailLoader loader;
    private GridView grid;
    private ListView groupedList;
    private GalleryAdapter adapter;
    private GroupedAdapter groupedAdapter;
    private TextView titleView;
    private EditText searchInput;
    private Button allTab;
    private Button favoritesTab;
    private Button dislikesTab;
    private int tab = 0;
    private int columns = 5;
    private int sort = 0;
    private boolean groupByAuthor = false;
    private List<ArtEntry> entries = new ArrayList<>();
    private List<ArtEntry> sourceEntries = new ArrayList<>();
    private String searchQuery = "";
    private ScaleGestureDetector scaleDetector;
    private int loadRequestId;
    private boolean firstResume = true;

    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        loader = new ThumbnailLoader(this);
        columns = getPreferences(MODE_PRIVATE).getInt("columns", 5);
        sort = getPreferences(MODE_PRIVATE).getInt("sort", 0);
        groupByAuthor = getPreferences(MODE_PRIVATE).getBoolean("group", false);
        setContentView(createLayout());
        loadData();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (firstResume) firstResume = false;
        else loadData();
    }

    @Override
    protected void onDestroy() {
        loadRequestId++;
        executor.shutdownNow();
        statsExecutor.shutdownNow();
        if (loader != null) loader.shutdown();
        // Удаление временных миниатюр не выполняется в главном потоке.
        // Файлы переиспользуются и очищаются вместе с системным cacheDir.
        super.onDestroy();
    }

    private View createLayout() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        root.setPadding(0, dp(8), 0, dp(16));
        root.setFitsSystemWindows(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(0, top + dp(8), 0, bottom + dp(16));
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), 0, dp(8), dp(6));
        titleView = new TextView(this);
        titleView.setText(tr("Галерея кэша", "Cache gallery"));
        titleView.setTextColor(textColor);
        titleView.setTextSize(22);
        titleView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.addView(titleView, new LinearLayout.LayoutParams(0, dp(52), 1f));
        Button search = new Button(this);
        search.setText("⌕");
        search.setTextSize(25);
        search.setTextColor(textColor);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setContentDescription(tr("Поиск", "Search"));
        search.setOnClickListener(v -> toggleSearch());
        bar.addView(search, new LinearLayout.LayoutParams(dp(52), dp(52)));
        Button menu = new Button(this);
        menu.setText("⋮");
        menu.setTextSize(25);
        menu.setTextColor(textColor);
        menu.setBackgroundColor(Color.TRANSPARENT);
        menu.setOnClickListener(this::showMenu);
        bar.addView(menu, new LinearLayout.LayoutParams(dp(52), dp(52)));
        root.addView(bar, new LinearLayout.LayoutParams(-1, dp(58)));

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setHint(tr("Название или автор", "Title or artist"));
        searchInput.setTextColor(textColor);
        searchInput.setHintTextColor(subTextColor);
        searchInput.setTextSize(15);
        searchInput.setPadding(dp(14), 0, dp(14), 0);
        searchInput.setBackground(rounded(fieldColor, 13, borderColor, 1));
        searchInput.setVisibility(View.GONE);
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence value, int start, int before, int count) {
                searchQuery = value == null ? "" : value.toString();
                renderCurrentEntries();
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(48));
        searchParams.setMargins(dp(14), 0, dp(14), dp(8));
        root.addView(searchInput, searchParams);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        tabs.setPadding(dp(14), 0, dp(14), dp(8));
        allTab = tabButton(tr("Все", "All"));
        favoritesTab = tabButton(tr("Избранное", "Favorites"));
        dislikesTab = tabButton(tr("Дизлайки", "Dislikes"));
        tabs.addView(allTab, new LinearLayout.LayoutParams(0, dp(43), 1f));
        tabs.addView(favoritesTab, new LinearLayout.LayoutParams(0, dp(43), 1f));
        tabs.addView(dislikesTab, new LinearLayout.LayoutParams(0, dp(43), 1f));
        root.addView(tabs, new LinearLayout.LayoutParams(-1, dp(51)));
        allTab.setOnClickListener(v -> switchTab(0));
        favoritesTab.setOnClickListener(v -> switchTab(1));
        dislikesTab.setOnClickListener(v -> switchTab(2));

        FrameLayout content = new FrameLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(columns);
        grid.setVerticalSpacing(dp(2));
        grid.setHorizontalSpacing(dp(2));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setClipToPadding(false);
        grid.setPadding(dp(2), dp(2), dp(2), dp(18));
        grid.setBackgroundColor(bgColor);
        adapter = new GalleryAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener((parent, view, position, id) -> openEntry(adapter.getItem(position)));
        grid.setOnItemLongClickListener((parent, view, position, id) -> {
            showEntryActions(adapter.getItem(position));
            return true;
        });

        groupedList = new ListView(this);
        groupedList.setDivider(null);
        groupedList.setDividerHeight(0);
        groupedList.setBackgroundColor(bgColor);
        groupedList.setClipToPadding(false);
        groupedList.setPadding(0, 0, 0, dp(18));
        groupedAdapter = new GroupedAdapter();
        groupedList.setAdapter(groupedAdapter);

        content.addView(grid, new FrameLayout.LayoutParams(-1, -1));
        content.addView(groupedList, new FrameLayout.LayoutParams(-1, -1));
        root.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));

        scaleDetector = new ScaleGestureDetector(this, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            private float accumulated = 1f;
            @Override public boolean onScale(ScaleGestureDetector detector) {
                accumulated *= detector.getScaleFactor();
                if (accumulated > 1.18f) {
                    setColumns(Math.max(2, columns - 1));
                    accumulated = 1f;
                } else if (accumulated < 0.84f) {
                    setColumns(Math.min(7, columns + 1));
                    accumulated = 1f;
                }
                return true;
            }
        });
        View.OnTouchListener touch = (v, event) -> {
            scaleDetector.onTouchEvent(event);
            return false;
        };
        grid.setOnTouchListener(touch);
        groupedList.setOnTouchListener(touch);
        updateTabs();
        updateModeViews();
        return root;
    }

    private void loadData() {
        if (executor.isShutdown()) return;
        final int requestId = ++loadRequestId;
        final int requestedTab = tab;
        titleView.setText(tr("Галерея кэша · загрузка…", "Cache gallery · loading…"));
        executor.execute(() -> {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            List<ArtEntry> loaded;
            if (requestedTab == 1) loaded = repo.getFavoriteEntries();
            else if (requestedTab == 2) loaded = repo.getDislikedEntries();
            else loaded = repo.getCachedEntries();
            runOnUiThread(() -> {
                if (requestId != loadRequestId || requestedTab != tab || isFinishing()
                        || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) return;
                sourceEntries = loaded;
                renderCurrentEntries();
            });
        });
    }

    private void toggleSearch() {
        boolean show = searchInput.getVisibility() != View.VISIBLE;
        searchInput.setVisibility(show ? View.VISIBLE : View.GONE);
        if (show) {
            searchInput.requestFocus();
            searchInput.postDelayed(() -> {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) imm.showSoftInput(searchInput, InputMethodManager.SHOW_IMPLICIT);
            }, 120L);
        } else {
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
            searchInput.setText("");
            searchQuery = "";
            renderCurrentEntries();
        }
    }

    private void renderCurrentEntries() {
        if (adapter == null || groupedAdapter == null) return;
        String query = normalizeSearch(searchQuery);
        List<ArtEntry> filtered = new ArrayList<>();
        for (ArtEntry entry : sourceEntries) {
            if (query.isEmpty()) {
                filtered.add(entry);
                continue;
            }
            String haystack = normalizeSearch(titleFor(entry) + " " + artistFor(entry)
                    + " " + entry.title + " " + entry.artist + " " + entry.titleRu
                    + " " + entry.titleEn + " " + entry.artistRu + " " + entry.artistEn);
            if (haystack.contains(query)) filtered.add(entry);
        }
        sortEntries(filtered, sort);
        entries = filtered;
        titleView.setText(tab == 0 ? tr("Галерея кэша · ", "Cache gallery · ") + entries.size()
                : tab == 1 ? tr("Избранное · ", "Favorites · ") + entries.size()
                : tr("Дизлайки · ", "Dislikes · ") + entries.size());
        adapter.notifyDataSetChanged();
        groupedAdapter.setRows(groupByAuthor ? buildGroupRows(entries, columns) : new ArrayList<>());
        updateModeViews();
    }

    private String normalizeSearch(String value) {
        return value == null ? "" : value.toLowerCase(Locale.ROOT)
                .replace('ё', 'е').replaceAll("\\s+", " ").trim();
    }

    private void switchTab(int value) {
        tab = value;
        updateTabs();
        loadData();
    }

    private void updateTabs() {
        styleTab(allTab, tab == 0, true, false);
        styleTab(favoritesTab, tab == 1, false, false);
        styleTab(dislikesTab, tab == 2, false, true);
    }

    private void setColumns(int value) {
        columns = Math.max(2, Math.min(7, value));
        getPreferences(MODE_PRIVATE).edit().putInt("columns", columns).apply();
        grid.setNumColumns(columns);
        renderCurrentEntries();
    }

    private void updateModeViews() {
        grid.setVisibility(groupByAuthor ? View.GONE : View.VISIBLE);
        groupedList.setVisibility(groupByAuthor ? View.VISIBLE : View.GONE);
    }

    private void showMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add(tr("Мелкая сетка", "Small grid")).setOnMenuItemClickListener(item -> { setColumns(6); return true; });
        popup.getMenu().add(tr("Средняя сетка", "Medium grid")).setOnMenuItemClickListener(item -> { setColumns(4); return true; });
        popup.getMenu().add(tr("Крупная сетка", "Large grid")).setOnMenuItemClickListener(item -> { setColumns(2); return true; });
        popup.getMenu().add(groupByAuthor ? tr("Убрать группировку", "Remove grouping") : tr("Группировать по автору", "Group by artist")).setOnMenuItemClickListener(item -> {
            groupByAuthor = !groupByAuthor;
            getPreferences(MODE_PRIVATE).edit().putBoolean("group", groupByAuthor).apply();
            renderCurrentEntries();
            return true;
        });
        popup.getMenu().add(tr("Сначала новые", "Newest first")).setOnMenuItemClickListener(item -> { setSort(0); return true; });
        popup.getMenu().add(tr("Сначала старые", "Oldest first")).setOnMenuItemClickListener(item -> { setSort(1); return true; });
        popup.getMenu().add(tr("По автору", "By artist")).setOnMenuItemClickListener(item -> { setSort(2); return true; });
        popup.getMenu().add(tr("По названию", "By title")).setOnMenuItemClickListener(item -> { setSort(3); return true; });
        popup.getMenu().add(tr("Сведения о кэше", "Cache information")).setOnMenuItemClickListener(item -> { showCacheInfo(); return true; });
        popup.getMenu().add(tr("Очистить кэш", "Clear cache")).setOnMenuItemClickListener(item -> { confirmClearCache(); return true; });
        popup.getMenu().add(tr("Очистить историю", "Clear history")).setOnMenuItemClickListener(item -> { confirmClearHistory(); return true; });
        popup.show();
    }

    private void setSort(int value) {
        sort = value;
        getPreferences(MODE_PRIVATE).edit().putInt("sort", sort).apply();
        renderCurrentEntries();
    }

    private void sortEntries(List<ArtEntry> list, int sortMode) {
        Comparator<ArtEntry> comparator;
        if (sortMode == 1) comparator = Comparator.comparingLong(e -> e.addedAt);
        else if (sortMode == 2) comparator = Comparator.comparing(e -> artistFor(e).toLowerCase(Locale.ROOT));
        else if (sortMode == 3) comparator = Comparator.comparing(e -> titleFor(e).toLowerCase(Locale.ROOT));
        else comparator = (a, b) -> Long.compare(b.addedAt, a.addedAt);
        Collections.sort(list, comparator);
    }

    private List<GroupRow> buildGroupRows(List<ArtEntry> source, int columnCount) {
        List<GroupRow> rows = new ArrayList<>();
        Map<String, List<ArtEntry>> groups = new LinkedHashMap<>();
        List<ArtEntry> sorted = new ArrayList<>(source);
        sorted.sort(Comparator.comparing(e -> artistFor(e).toLowerCase(Locale.ROOT)));
        for (ArtEntry e : sorted) groups.computeIfAbsent(artistFor(e), k -> new ArrayList<>()).add(e);
        for (Map.Entry<String, List<ArtEntry>> group : groups.entrySet()) {
            rows.add(GroupRow.header(group.getKey()));
            List<ArtEntry> values = group.getValue();
            for (int i = 0; i < values.size(); i += columnCount) {
                rows.add(GroupRow.items(new ArrayList<>(values.subList(i,
                        Math.min(values.size(), i + columnCount)))));
            }
        }
        return rows;
    }

    private void showCacheInfo() {
        if (statsExecutor.isShutdown()) return;
        AlertDialog progressDialog = new AlertDialog.Builder(this)
                .setTitle(tr("Кэш", "Cache"))
                .setMessage(tr("Подсчитываю файлы и размер…", "Calculating files and size…"))
                .setNegativeButton(tr("Отмена", "Cancel"), null)
                .create();
        progressDialog.show();
        statsExecutor.execute(() -> {
            ArtRepository.CacheStats stats = new ArtRepository(getApplicationContext()).collectCacheStats();
            runOnUiThread(() -> {
                if (isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) return;
                if (progressDialog.isShowing()) progressDialog.dismiss();
                ArtRepository repo = new ArtRepository(getApplicationContext());
                String message = tr("Файлов: ", "Files: ") + stats.files
                        + tr("\nРазмер: ", "\nSize: ") + formatBytes(stats.bytes)
                        + tr("\nЛимит: ", "\nLimit: ") + repo.galleryCacheLimitLabel()
                        + tr("\nИстория: ", "\nHistory: ") + stats.history;
                new AlertDialog.Builder(this)
                        .setTitle(tr("Кэш", "Cache"))
                        .setMessage(message)
                        .setPositiveButton(tr("Закрыть", "Close"), null)
                        .show();
            });
        });
    }

    private void confirmClearCache() {
        if (executor.isShutdown()) return;
        AlertDialog progressDialog = new AlertDialog.Builder(this)
                .setTitle(tr("Очистить кэш?", "Clear cache?"))
                .setMessage(tr("Подсчитываю локальные файлы…", "Calculating local files…"))
                .setNegativeButton(tr("Отмена", "Cancel"), null)
                .create();
        progressDialog.show();
        statsExecutor.execute(() -> {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            ArtRepository.CacheStats stats = repo.collectCacheStats();
            runOnUiThread(() -> {
                if (isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) return;
                if (progressDialog.isShowing()) progressDialog.dismiss();
                new AlertDialog.Builder(this)
                        .setTitle(tr("Очистить кэш?", "Clear cache?"))
                        .setMessage(tr("Будут удалены обычные локальные файлы (", "Ordinary local files will be removed (")
                                + stats.files + ", " + formatBytes(stats.bytes)
                                + tr("). Текущая картина и избранное сохранятся.", "). The current artwork and favorites will be preserved."))
                        .setNegativeButton(tr("Отмена", "Cancel"), null)
                        .setPositiveButton(tr("Очистить", "Clear"), (d, w) -> executor.execute(() -> {
                            repo.clearOrdinaryCache();
                            runOnUiThread(() -> {
                                ArtWidgetProvider.updateAllWidgets(this);
                                loadData();
                            });
                        }))
                        .show();
            });
        });
    }

    private void confirmClearHistory() {
        new AlertDialog.Builder(this)
                .setTitle(tr("Очистить историю?", "Clear history?"))
                .setMessage(tr("Навигация назад и вперёд будет сброшена. Избранное и дизлайки сохранятся.", "Back and forward navigation will be reset. Favorites and dislikes will be preserved."))
                .setNegativeButton(tr("Отмена", "Cancel"), null)
                .setPositiveButton(tr("Очистить", "Clear"), (d, w) -> executor.execute(() -> {
                    new ArtRepository(getApplicationContext()).clearHistory();
                    runOnUiThread(() -> {
                        ArtWidgetProvider.updateAllWidgets(this);
                        loadData();
                    });
                })).show();
    }

    private void openEntry(ArtEntry entry) {
        if (entry == null) return;
        List<ArtEntry> navigationEntries = new ArrayList<>(entries);
        if (groupByAuthor) {
            navigationEntries.sort(Comparator.comparing(e -> artistFor(e).toLowerCase(Locale.ROOT)));
        }
        ArrayList<String> qids = new ArrayList<>();
        int position = -1;
        for (ArtEntry value : navigationEntries) {
            if (value == null || value.qid == null || value.qid.isEmpty()) continue;
            if (position < 0 && value.qid.equals(entry.qid)) position = qids.size();
            qids.add(value.qid);
        }
        Intent intent = new Intent(this, ArtworkActivity.class);
        intent.putExtra("qid", entry.qid);
        intent.putStringArrayListExtra("gallery_qids", qids);
        intent.putExtra("gallery_position", position);
        startActivity(intent);
    }

    private void showEntryActions(ArtEntry entry) {
        if (entry == null || executor.isShutdown()) return;
        executor.execute(() -> {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            boolean favorite = repo.isFavorite(entry);
            boolean disliked = repo.isDisliked(entry);
            runOnUiThread(() -> {
                if (isFinishing() || (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1 && isDestroyed())) return;
                List<String> actions = new ArrayList<>();
                actions.add(tr("Установить на виджет", "Set on widget"));
                actions.add(favorite ? tr("Удалить из избранного", "Remove from favorites") : tr("Добавить в избранное", "Add to favorites"));
                actions.add(disliked ? tr("Убрать дизлайк", "Remove dislike") : tr("Поставить дизлайк", "Dislike"));
                actions.add(tr("Удалить локальный файл", "Delete local file"));
                actions.add(tr("Открыть статью Википедии", "Open Wikipedia article"));
                String[] items = actions.toArray(new String[0]);
                new AlertDialog.Builder(this)
                        .setTitle(captionFor(entry))
                        .setItems(items, (dialog, which) -> {
                            if (which == 0) installEntry(entry);
                            else if (which == 1) executor.execute(() -> { repo.toggleFavorite(entry); runOnUiThread(this::loadData); });
                            else if (which == 2) executor.execute(() -> { repo.setDisliked(entry, !disliked); runOnUiThread(this::loadData); });
                            else if (which == 3) executor.execute(() -> { repo.deleteLocalFile(entry.qid); runOnUiThread(this::loadData); });
                            else if (which == 4) openArticle(entry);
                        }).show();
            });
        });
    }

    private void installEntry(ArtEntry entry) {
        if (!UpdateCoordinator.tryBegin()) {
            Toast.makeText(this, tr("Обновление уже выполняется", "An update is already in progress"), Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, tr("Устанавливаю картину…", "Setting artwork…"), Toast.LENGTH_SHORT).show();
        executor.execute(() -> {
            try {
                new ArtRepository(this).installOnWidget(entry.qid);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    Toast.makeText(this, tr("Картина установлена на виджет", "Artwork set on widget"), Toast.LENGTH_SHORT).show();
                    loadData();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                UpdateCoordinator.finish();
            }
        });
    }

    private void openArticle(ArtEntry entry) {
        if (entry == null || entry.sourceUrl.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(entry.sourceUrl))); }
        catch (Exception e) { Toast.makeText(this, tr("Не удалось открыть статью", "Could not open the article"), Toast.LENGTH_SHORT).show(); }
    }

    private View createCell(ArtEntry entry, View convertView, int cellWidth) {
        LinearLayout cell;
        ImageView image;
        TextView label;
        if (!(convertView instanceof LinearLayout) || convertView.getTag() == null) {
            cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setBackgroundColor(bgColor);
            image = new ImageView(this);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(fieldColor);
            label = new TextView(this);
            label.setTextColor(textColor);
            label.setTextSize(12);
            label.setMaxLines(columns <= 2 ? 2 : 1);
            label.setPadding(dp(4), dp(4), dp(4), dp(5));
            cell.addView(image, new LinearLayout.LayoutParams(-1, cellWidth));
            cell.addView(label, new LinearLayout.LayoutParams(-1, -2));
            cell.setTag(new CellHolder(image, label));
        } else {
            cell = (LinearLayout) convertView;
            CellHolder holder = (CellHolder) cell.getTag();
            image = holder.image;
            label = holder.label;
            ViewGroup.LayoutParams p = image.getLayoutParams();
            p.height = cellWidth;
            image.setLayoutParams(p);
        }
        if (columns >= 5) {
            label.setVisibility(View.GONE);
        } else {
            label.setVisibility(View.VISIBLE);
            label.setText(columns <= 2 ? captionFor(entry) : titleFor(entry));
        }
        boolean allowNetwork = tab == 1 || tab == 2;
        loader.load(image, entry, Math.max(180, cellWidth), allowNetwork);
        return cell;
    }

    private class GalleryAdapter extends BaseAdapter {
        @Override public int getCount() { return entries.size(); }
        @Override public ArtEntry getItem(int position) { return position >= 0 && position < entries.size() ? entries.get(position) : null; }
        @Override public long getItemId(int position) { return position; }
        @Override public View getView(int position, View convertView, ViewGroup parent) {
            int width = Math.max(dp(90), (parent.getWidth() - dp(2) * (columns + 1)) / Math.max(1, columns));
            return createCell(getItem(position), convertView, width);
        }
    }

    private class GroupedAdapter extends BaseAdapter {
        private final List<GroupRow> rows = new ArrayList<>();

        void setRows(List<GroupRow> prepared) {
            rows.clear();
            if (prepared != null) rows.addAll(prepared);
            notifyDataSetChanged();
        }

        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int position) { return rows.get(position); }
        @Override public long getItemId(int position) { return position; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int position) { return rows.get(position).header != null ? 0 : 1; }

        @Override public View getView(int position, View convertView, ViewGroup parent) {
            GroupRow row = rows.get(position);
            if (row.header != null) {
                TextView header = convertView instanceof TextView ? (TextView) convertView : new TextView(GalleryActivity.this);
                header.setText(row.header);
                header.setTextColor(textColor);
                header.setTextSize(17);
                header.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
                header.setPadding(dp(14), dp(16), dp(12), dp(8));
                header.setBackgroundColor(bgColor);
                return header;
            }
            LinearLayout line = convertView instanceof LinearLayout ? (LinearLayout) convertView : new LinearLayout(GalleryActivity.this);
            line.removeAllViews();
            line.setOrientation(LinearLayout.HORIZONTAL);
            line.setBackgroundColor(bgColor);
            int width = Math.max(dp(90), (parent.getWidth() - dp(2) * (columns + 1)) / Math.max(1, columns));
            for (ArtEntry e : row.items) {
                View cell = createCell(e, null, width);
                cell.setOnClickListener(v -> openEntry(e));
                cell.setOnLongClickListener(v -> { showEntryActions(e); return true; });
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, -2, 1f);
                p.setMargins(dp(1), dp(1), dp(1), dp(1));
                line.addView(cell, p);
            }
            for (int i = row.items.size(); i < columns; i++) line.addView(new View(GalleryActivity.this), new LinearLayout.LayoutParams(0, 1, 1f));
            return line;
        }
    }

    private static class GroupRow {
        final String header;
        final List<ArtEntry> items;
        private GroupRow(String header, List<ArtEntry> items) { this.header = header; this.items = items; }
        static GroupRow header(String text) { return new GroupRow(text, null); }
        static GroupRow items(List<ArtEntry> list) { return new GroupRow(null, list); }
    }

    private static class CellHolder {
        final ImageView image;
        final TextView label;
        CellHolder(ImageView image, TextView label) { this.image = image; this.label = label; }
    }

    private Button tabButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setMinHeight(0);
        b.setPadding(dp(4), 0, dp(4), 0);
        return b;
    }

    private void styleTab(Button button, boolean active, boolean first, boolean last) {
        button.setTextColor(active ? Color.WHITE : textColor);
        GradientDrawable d = new GradientDrawable();
        d.setColor(active ? 0xFF007AFF : fieldColor);
        d.setStroke(dp(1), active ? 0xFF007AFF : borderColor);
        float r = dp(13);
        d.setCornerRadii(new float[]{first ? r : 0, first ? r : 0, last ? r : 0, last ? r : 0,
                last ? r : 0, last ? r : 0, first ? r : 0, first ? r : 0});
        button.setBackground(d);
    }

    private String titleFor(ArtEntry entry) {
        return entry == null ? "" : entry.localizedTitle(LanguageManager.getLanguage(this));
    }

    private String artistFor(ArtEntry entry) {
        return entry == null ? "" : entry.localizedArtist(LanguageManager.getLanguage(this));
    }

    private String captionFor(ArtEntry entry) {
        return entry == null ? "" : entry.caption(LanguageManager.getLanguage(this));
    }

    private String formatBytes(long value) {
        if (value < 1024) return value + tr(" Б", " B");
        if (value < 1024L * 1024L) return String.format(Locale.getDefault(), tr("%.1f КБ", "%.1f KB"), value / 1024f);
        return String.format(Locale.getDefault(), tr("%.1f МБ", "%.1f MB"), value / (1024f * 1024f));
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFEDEDEF;
        borderColor = dark ? 0xFF38383A : 0xFFD1D1D6;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
