package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SettingsActivity extends Activity {
    private static final int SPACE = 8;
    private static final int OUTER = 16;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private Button filterButton;
    private Button allButton;
    private Button nsfwButton;
    private Button updateCatalogButton;
    private Button saveIntervalButton;
    private Button exactAlarmButton;
    private Button galleryButton;
    private Button logButton;
    private EditText intervalValue;
    private Spinner unitSpinner;
    private TextView nextUpdateView;
    private TextView catalogStatsView;
    private TextView statusView;
    private Switch wifiOnlySwitch;
    private boolean busy;
    private boolean updatingUi;

    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        setContentView(createLayout());
        updateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUi();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(OUTER), dp(OUTER), dp(OUTER), dp(24));
        root.setBackgroundColor(bgColor);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(OUTER), top + dp(OUTER), dp(OUTER), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout appBar = horizontalRow();
        Button back = new Button(this);
        back.setText("‹");
        back.setTextSize(32);
        back.setTextColor(textColor);
        back.setGravity(Gravity.CENTER);
        back.setMinWidth(0);
        back.setMinHeight(0);
        back.setPadding(0, 0, 0, 0);
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setContentDescription("Назад");
        back.setOnClickListener(v -> finish());
        appBar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        TextView title = textView(22, true, textColor);
        title.setText("Настройки");
        title.setGravity(Gravity.CENTER_VERTICAL);
        appBar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams appBarParams = matchWrap();
        appBarParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(appBar, appBarParams);

        statusView = textView(14, false, subTextColor);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackground(rounded(fieldColor, 13, borderColor, 1));
        statusView.setVisibility(View.GONE);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.setMargins(0, 0, 0, dp(12));
        root.addView(statusView, statusParams);

        LinearLayout contentCard = sectionCard();
        contentCard.addView(sectionTitle("Контент"), matchWrap());
        LinearLayout segment = horizontalRow();
        filterButton = makeSegment("Фильтр");
        allButton = makeSegment("Все");
        nsfwButton = makeSegment("NSFW");
        segment.addView(filterButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        segment.addView(allButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        segment.addView(nsfwButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams segmentParams = matchWrap();
        segmentParams.setMargins(0, dp(SPACE), 0, 0);
        contentCard.addView(segment, segmentParams);
        TextView contentHint = textView(13, false, subTextColor);
        contentHint.setText("Фильтр автоматически скрывает часть откровенных произведений, но не является детским режимом и не гарантирует абсолютную точность.");
        contentHint.setLineSpacing(0f, 1.12f);
        LinearLayout.LayoutParams hintParams = matchWrap();
        hintParams.setMargins(0, dp(SPACE), 0, 0);
        contentCard.addView(contentHint, hintParams);
        root.addView(contentCard, sectionParams());
        filterButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_FILTER));
        allButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_ALL));
        nsfwButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_ADULT_ONLY));

        LinearLayout catalogCard = sectionCard();
        catalogCard.addView(sectionTitle("Каталог"), matchWrap());
        catalogStatsView = textView(14, false, subTextColor);
        catalogStatsView.setLineSpacing(0f, 1.15f);
        LinearLayout.LayoutParams statsParams = matchWrap();
        statsParams.setMargins(0, dp(SPACE), 0, dp(SPACE));
        catalogCard.addView(catalogStatsView, statsParams);
        updateCatalogButton = makeButton("Обновить каталог", true);
        catalogCard.addView(updateCatalogButton, new LinearLayout.LayoutParams(-1, dp(50)));
        updateCatalogButton.setOnClickListener(v -> updateCatalog());
        root.addView(catalogCard, sectionParams());

        LinearLayout networkCard = sectionCard();
        networkCard.addView(sectionTitle("Сеть"), matchWrap());
        wifiOnlySwitch = new Switch(this);
        wifiOnlySwitch.setText("Загружать только по Wi-Fi");
        wifiOnlySwitch.setTextColor(textColor);
        wifiOnlySwitch.setTextSize(15);
        wifiOnlySwitch.setGravity(Gravity.CENTER_VERTICAL);
        wifiOnlySwitch.setPadding(0, dp(SPACE), 0, 0);
        networkCard.addView(wifiOnlySwitch, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView networkHint = textView(13, false, subTextColor);
        networkHint.setText("Если включено, загрузка картин и обновление каталога через мобильную сеть не выполняются. При нажатии «Новая» приложение использует другую картину из кэша.");
        networkHint.setLineSpacing(0f, 1.12f);
        networkCard.addView(networkHint, matchWrap());
        wifiOnlySwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (updatingUi) return;
            new ArtRepository(this).setWifiOnly(isChecked);
            Toast.makeText(this, isChecked ? "Загрузка только по Wi-Fi" : "Разрешена мобильная сеть", Toast.LENGTH_SHORT).show();
        });
        root.addView(networkCard, sectionParams());

        LinearLayout intervalCard = sectionCard();
        intervalCard.addView(sectionTitle("Автообновление"), matchWrap());
        LinearLayout intervalRow = horizontalRow();
        intervalValue = new EditText(this);
        intervalValue.setInputType(InputType.TYPE_CLASS_NUMBER);
        intervalValue.setSingleLine(true);
        intervalValue.setTextColor(textColor);
        intervalValue.setTextSize(16);
        intervalValue.setPadding(dp(14), 0, dp(14), 0);
        intervalValue.setBackground(rounded(fieldColor, 13, borderColor, 1));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        inputParams.setMargins(0, 0, dp(SPACE), 0);
        intervalRow.addView(intervalValue, inputParams);

        unitSpinner = new Spinner(this);
        String[] units = new String[]{"секунд", "минут", "часов"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, units) {
            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                if (view instanceof TextView) {
                    ((TextView) view).setTextColor(textColor);
                    ((TextView) view).setTextSize(16);
                }
                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                if (view instanceof TextView) ((TextView) view).setTextColor(textColor);
                view.setBackgroundColor(bgColor);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitSpinner.setAdapter(adapter);
        unitSpinner.setBackground(rounded(fieldColor, 13, borderColor, 1));
        intervalRow.addView(unitSpinner, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams intervalRowParams = matchWrap();
        intervalRowParams.setMargins(0, dp(SPACE), 0, dp(SPACE));
        intervalCard.addView(intervalRow, intervalRowParams);

        saveIntervalButton = makeButton("Сохранить интервал", true);
        intervalCard.addView(saveIntervalButton, new LinearLayout.LayoutParams(-1, dp(50)));
        saveIntervalButton.setOnClickListener(v -> saveInterval());

        nextUpdateView = textView(14, false, subTextColor);
        LinearLayout.LayoutParams nextParams = matchWrap();
        nextParams.setMargins(dp(4), dp(SPACE), dp(4), 0);
        intervalCard.addView(nextUpdateView, nextParams);

        exactAlarmButton = makeButton("Разрешить точное автообновление", false);
        LinearLayout.LayoutParams exactParams = new LinearLayout.LayoutParams(-1, dp(50));
        exactParams.setMargins(0, dp(SPACE), 0, 0);
        intervalCard.addView(exactAlarmButton, exactParams);
        exactAlarmButton.setOnClickListener(v -> openExactAlarmSettings());
        root.addView(intervalCard, sectionParams());

        LinearLayout serviceCard = sectionCard();
        serviceCard.addView(sectionTitle("Разделы приложения"), matchWrap());
        galleryButton = makeButton("Галерея кэша", false);
        LinearLayout.LayoutParams galleryParams = new LinearLayout.LayoutParams(-1, dp(50));
        galleryParams.setMargins(0, dp(SPACE), 0, 0);
        serviceCard.addView(galleryButton, galleryParams);
        galleryButton.setOnClickListener(v -> startActivity(new Intent(this, GalleryActivity.class)));

        logButton = makeButton("Технический журнал", false);
        LinearLayout.LayoutParams logParams = new LinearLayout.LayoutParams(-1, dp(50));
        logParams.setMargins(0, dp(SPACE), 0, 0);
        serviceCard.addView(logButton, logParams);
        logButton.setOnClickListener(v -> startActivity(new Intent(this, LogActivity.class)));
        root.addView(serviceCard, sectionParams());

        applyIntervalToControls(ArtScheduler.getIntervalSeconds(this));
        return scroll;
    }

    private void setContentMode(int mode) {
        new ArtRepository(this).setContentMode(mode);
        updateSegments(mode);
        String text = mode == ArtRepository.CONTENT_FILTER ? "Выбран режим «Фильтр»"
                : mode == ArtRepository.CONTENT_ALL ? "Выбран режим «Все»"
                : "Выбран режим «NSFW»";
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        updateUi();
    }

    private void updateCatalog() {
        CatalogWorkScheduler.requestManualRefresh(this);
        showStatus("Обновление каталога запущено в фоне");
        updateUi();
    }

    private void saveInterval() {
        int value;
        try {
            value = Integer.parseInt(intervalValue.getText().toString().trim());
        } catch (Exception e) {
            showStatus("Введите число для интервала автообновления");
            return;
        }
        if (value <= 0) {
            showStatus("Интервал должен быть больше нуля");
            return;
        }
        long seconds = value;
        int unit = unitSpinner.getSelectedItemPosition();
        if (unit == 1) seconds *= 60L;
        if (unit == 2) seconds *= 3600L;
        seconds = Math.max(ArtScheduler.MIN_INTERVAL_SECONDS, Math.min(ArtScheduler.MAX_INTERVAL_SECONDS, seconds));
        ArtScheduler.setIntervalSeconds(this, (int) seconds);
        applyIntervalToControls((int) seconds);
        nextUpdateView.setText(ArtScheduler.nextUpdateDisplay(this));
        hideStatus();
        Toast.makeText(this, "Интервал сохранён", Toast.LENGTH_SHORT).show();
    }

    private void updateUi() {
        ArtRepository repo = new ArtRepository(this);
        updatingUi = true;
        updateSegments(repo.getContentMode());
        catalogStatsView.setText(repo.getTechnicalCatalogStats()
                + "\nСтатус обновления:\n" + repo.getCatalogUpdateStatus());
        wifiOnlySwitch.setChecked(repo.isWifiOnly());
        updatingUi = false;
        nextUpdateView.setText(ArtScheduler.nextUpdateDisplay(this));
        exactAlarmButton.setVisibility(ArtScheduler.canScheduleExact(this) ? View.GONE : View.VISIBLE);
    }

    private void updateSegments(int mode) {
        styleSegment(filterButton, mode == ArtRepository.CONTENT_FILTER, true, false);
        styleSegment(allButton, mode == ArtRepository.CONTENT_ALL, false, false);
        styleSegment(nsfwButton, mode == ArtRepository.CONTENT_ADULT_ONLY, false, true);
    }

    private void styleSegment(Button button, boolean active, boolean first, boolean last) {
        int color = active ? 0xFF007AFF : fieldColor;
        int stroke = active ? 0xFF007AFF : borderColor;
        button.setTextColor(active ? Color.WHITE : textColor);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setStroke(dp(1), stroke);
        float r = dp(13);
        float[] radii = new float[]{first ? r : 0, first ? r : 0, last ? r : 0, last ? r : 0,
                last ? r : 0, last ? r : 0, first ? r : 0, first ? r : 0};
        shape.setCornerRadii(radii);
        button.setBackground(shape);
    }

    private Button makeSegment(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setMinHeight(0);
        b.setMinWidth(0);
        return b;
    }

    private void setBusy(boolean value) {
        busy = value;
        for (View v : new View[]{filterButton, allButton, nsfwButton, updateCatalogButton,
                saveIntervalButton, exactAlarmButton, galleryButton, logButton, intervalValue, unitSpinner, wifiOnlySwitch}) {
            if (v != null) {
                v.setEnabled(!busy);
                v.setAlpha(busy ? 0.55f : 1f);
            }
        }
    }

    private void showStatus(String text) {
        statusView.setText(text == null ? "" : text);
        statusView.setVisibility(View.VISIBLE);
    }

    private void hideStatus() {
        statusView.setVisibility(View.GONE);
    }

    private String friendlyError(Exception e) {
        String msg = e == null ? null : e.getMessage();
        if (msg == null || msg.trim().isEmpty()) return "Не удалось выполнить операцию";
        if (msg.contains("HTTP 429") || msg.contains("Слишком частые")) return "Слишком частые запросы. Повторите позже";
        if (msg.contains("Unable to resolve host") || msg.contains("No address associated") || msg.contains("Не удалось определить адрес")) {
            return "Нет подключения к интернету или DNS временно недоступен";
        }
        if (msg.toLowerCase().contains("timeout") || msg.contains("не ответил вовремя")) return "Сервер не ответил вовремя. Повторите позже";
        return msg.length() > 220 ? msg.substring(0, 220) + "…" : msg;
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void applyIntervalToControls(int seconds) {
        if (seconds < 60) {
            intervalValue.setText(String.valueOf(seconds));
            unitSpinner.setSelection(0);
        } else if (seconds % 3600 == 0) {
            intervalValue.setText(String.valueOf(seconds / 3600));
            unitSpinner.setSelection(2);
        } else {
            intervalValue.setText(String.valueOf(Math.max(1, seconds / 60)));
            unitSpinner.setSelection(1);
        }
    }

    private Button makeButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15, primary ? 0xFF007AFF : borderColor, 1));
        return b;
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(rounded(fieldColor, 18, borderColor, 1));
        return card;
    }

    private TextView sectionTitle(String title) {
        TextView tv = textView(17, true, textColor);
        tv.setText(title);
        return tv;
    }

    private LinearLayout.LayoutParams sectionParams() {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private TextView textView(int size, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setTextSize(size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        borderColor = dark ? 0xFF38383A : 0xFFD9D9DE;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
