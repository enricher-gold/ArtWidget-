package com.sergei.artwidget;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Планирование импорта и автономного пополнения каталогов через WorkManager. */
public final class CatalogWorkScheduler {
    public static final int REFILL_THRESHOLD = 500;
    public static final int TARGET_REMAINING = 1000;

    private static final String WORK_BOOTSTRAP = "art_catalog_bootstrap_v12";
    private static final String WORK_FILTER = "art_catalog_filter_refill_v12";
    private static final String WORK_NSFW = "art_catalog_nsfw_refill_v12";
    private static final String PERIODIC_FILTER = "art_catalog_filter_periodic_v12";
    private static final String PERIODIC_NSFW = "art_catalog_nsfw_periodic_v12";

    private CatalogWorkScheduler() { }

    public static void ensureInitialized(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.KEEP, request);
        schedulePeriodicMaintenance(context);
    }

    public static void requestManualRefresh(Context context) {
        enqueueUpdate(context, false, true, ExistingWorkPolicy.REPLACE);
        enqueueUpdate(context, true, true, ExistingWorkPolicy.REPLACE);
    }

    public static void scheduleRefill(Context context, int mode) {
        if (mode == ArtRepository.CONTENT_ALL) {
            enqueueUpdate(context, false, false, ExistingWorkPolicy.KEEP);
            enqueueUpdate(context, true, false, ExistingWorkPolicy.KEEP);
            return;
        }
        boolean adult = mode == ArtRepository.CONTENT_ADULT_ONLY;
        enqueueUpdate(context, adult, false, ExistingWorkPolicy.KEEP);
    }

    public static void scheduleBothIfNeeded(Context context) {
        enqueueUpdate(context, false, false, ExistingWorkPolicy.KEEP);
        enqueueUpdate(context, true, false, ExistingWorkPolicy.KEEP);
    }

    private static void enqueueUpdate(Context context, boolean adult, boolean force,
                                      ExistingWorkPolicy policy) {
        Data input = new Data.Builder()
                .putBoolean(CatalogUpdateWorker.KEY_ADULT, adult)
                .putBoolean(CatalogUpdateWorker.KEY_FORCE, force)
                .build();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogUpdateWorker.class)
                .setInputData(input)
                .setConstraints(networkConstraints(context))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build();
        WorkManager.getInstance(context.getApplicationContext()).enqueueUniqueWork(
                adult ? WORK_NSFW : WORK_FILTER, policy, request);
    }

    private static void schedulePeriodicMaintenance(Context context) {
        Constraints constraints = networkConstraints(context);
        PeriodicWorkRequest filter = new PeriodicWorkRequest.Builder(
                CatalogUpdateWorker.class, 12, TimeUnit.HOURS)
                .setInputData(new Data.Builder()
                        .putBoolean(CatalogUpdateWorker.KEY_ADULT, false)
                        .putBoolean(CatalogUpdateWorker.KEY_FORCE, false)
                        .build())
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build();
        PeriodicWorkRequest nsfw = new PeriodicWorkRequest.Builder(
                CatalogUpdateWorker.class, 12, TimeUnit.HOURS)
                .setInputData(new Data.Builder()
                        .putBoolean(CatalogUpdateWorker.KEY_ADULT, true)
                        .putBoolean(CatalogUpdateWorker.KEY_FORCE, false)
                        .build())
                .setConstraints(constraints)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 1, TimeUnit.MINUTES)
                .build();
        WorkManager manager = WorkManager.getInstance(context.getApplicationContext());
        manager.enqueueUniquePeriodicWork(PERIODIC_FILTER,
                ExistingPeriodicWorkPolicy.UPDATE, filter);
        manager.enqueueUniquePeriodicWork(PERIODIC_NSFW,
                ExistingPeriodicWorkPolicy.UPDATE, nsfw);
    }

    private static Constraints networkConstraints(Context context) {
        boolean wifiOnly = context.getSharedPreferences(ArtRepository.PREFS, Context.MODE_PRIVATE)
                .getBoolean("wifi_only_v11_8", false);
        return new Constraints.Builder()
                .setRequiredNetworkType(wifiOnly ? NetworkType.UNMETERED : NetworkType.CONNECTED)
                .build();
    }
}
