package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Импортирует встроенные 1000+1000 записей и выполняет миграции вне UI-потока. */
public class CatalogBootstrapWorker extends Worker {
    public CatalogBootstrapWorker(@NonNull Context context,
                                  @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        long started = System.currentTimeMillis();
        try {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            repo.initializeStorageInBackground();
            CatalogWorkScheduler.scheduleBothIfNeeded(getApplicationContext());
            AppLogger.log(getApplicationContext(), "catalog-bootstrap", "ok",
                    (System.currentTimeMillis() - started) + " ms");
            return Result.success();
        } catch (Exception e) {
            AppLogger.log(getApplicationContext(), "catalog-bootstrap", "error", e.getMessage());
            return Result.retry();
        }
    }
}
