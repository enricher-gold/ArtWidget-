# Art Widget 12.3.1 catalog build fix r3

The previous NSFW discovery stopped at category branches such as “by artist” because artist-name subcategories did not match the recursion whitelist. It therefore found only about 720 Wikipedia pages and verified 522 paintings.

Changes:
- NSFW category traversal now continues through safe descendant categories to depth 4.
- Added explicit roots for nude paintings by artist/country/century/movement, reclining/standing/seated nudes, bathers, odalisques and related adult subjects.
- Child/minor branches and non-painting media are excluded before traversal.
- Final acceptance remains strict: exact Wikidata QID, painting classification/description, exact P18 raster image, dedicated Russian or English Wikipedia article, and non-empty article introduction.
- Safe catalog traversal remains conservative.
- Catalog page ceiling increased to 30000.

App version stays 12.3.1 (versionCode 25).
