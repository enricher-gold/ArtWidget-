package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtworkActivity extends Activity {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private ArtEntry entry;
    private String qid;
    private ArrayList<String> galleryQids = new ArrayList<>();
    private int galleryPosition = -1;
    private ScrollView scrollView;
    private ImageView imageView;
    private TextView captionView;
    private TextView positionView;
    private Bitmap shownBitmap;
    private TextView descriptionView;
    private Button favoriteButton;
    private Button dislikeButton;
    private Button installButton;
    private Button previousButton;
    private Button nextButton;
    private LinearLayout navigationRow;
    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        qid = getIntent().getStringExtra("qid");
        ArrayList<String> suppliedQids = getIntent().getStringArrayListExtra("gallery_qids");
        if (suppliedQids != null) galleryQids = suppliedQids;
        galleryPosition = getIntent().getIntExtra("gallery_position", -1);
        if (galleryPosition < 0 || galleryPosition >= galleryQids.size()
                || qid == null || !qid.equals(galleryQids.get(galleryPosition))) {
            galleryPosition = qid == null ? -1 : galleryQids.indexOf(qid);
        }
        setupColors();
        setContentView(createLayout());
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        recycleShownBitmap();
        super.onDestroy();
    }

    private View createLayout() {
        scrollView = new ScrollView(this);
        scrollView.setBackgroundColor(bgColor);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.setFitsSystemWindows(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(16), top + dp(16), dp(16), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }
        scrollView.addView(root, new ScrollView.LayoutParams(-1, -2));

        LinearLayout topRow = new LinearLayout(this);
        topRow.setOrientation(LinearLayout.HORIZONTAL);
        topRow.setGravity(Gravity.CENTER_VERTICAL);
        Button back = button("Назад", false);
        back.setOnClickListener(v -> finish());
        topRow.addView(back, new LinearLayout.LayoutParams(dp(110), dp(46)));
        positionView = new TextView(this);
        positionView.setTextColor(subTextColor);
        positionView.setTextSize(13);
        positionView.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        positionView.setPadding(dp(8), 0, dp(4), 0);
        topRow.addView(positionView, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams topParams = new LinearLayout.LayoutParams(-1, dp(46));
        topParams.setMargins(0, 0, 0, dp(8));
        root.addView(topRow, topParams);

        imageView = new ImageView(this);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setAdjustViewBounds(true);
        imageView.setBackgroundColor(Color.TRANSPARENT);
        imageView.setOnClickListener(v -> openFullscreen());
        root.addView(imageView, new LinearLayout.LayoutParams(-1, dp(390)));

        navigationRow = new LinearLayout(this);
        navigationRow.setOrientation(LinearLayout.HORIZONTAL);
        navigationRow.setGravity(Gravity.CENTER);

        previousButton = button("←", false);
        previousButton.setTextSize(24);
        previousButton.setContentDescription("Предыдущая картина");
        previousButton.setOnClickListener(v -> showRelativeEntry(-1));
        navigationRow.addView(previousButton, new LinearLayout.LayoutParams(0, dp(48), 1f));

        nextButton = button("→", false);
        nextButton.setTextSize(24);
        nextButton.setContentDescription("Следующая картина");
        nextButton.setOnClickListener(v -> showRelativeEntry(1));
        LinearLayout.LayoutParams nextButtonParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        nextButtonParams.setMargins(dp(8), 0, 0, 0);
        navigationRow.addView(nextButton, nextButtonParams);

        LinearLayout.LayoutParams navigationParams = new LinearLayout.LayoutParams(-1, dp(48));
        navigationParams.setMargins(0, dp(8), 0, 0);
        root.addView(navigationRow, navigationParams);

        captionView = new TextView(this);
        captionView.setTextColor(linkColor);
        captionView.setTextSize(20);
        captionView.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        captionView.setGravity(Gravity.CENTER_HORIZONTAL);
        captionView.setPadding(0, dp(8), 0, dp(8));
        captionView.setOnClickListener(v -> openArticle());
        root.addView(captionView, new LinearLayout.LayoutParams(-1, -2));

        TextView about = new TextView(this);
        about.setText("О картине");
        about.setTextSize(18);
        about.setTextColor(textColor);
        about.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        about.setPadding(0, dp(8), 0, dp(8));
        root.addView(about, new LinearLayout.LayoutParams(-1, -2));

        descriptionView = new TextView(this);
        descriptionView.setTextColor(textColor);
        descriptionView.setTextSize(15);
        descriptionView.setLineSpacing(0, 1.16f);
        descriptionView.setPadding(0, 0, 0, dp(16));
        root.addView(descriptionView, new LinearLayout.LayoutParams(-1, -2));

        installButton = button("Установить на виджет", true);
        installButton.setOnClickListener(v -> install());
        root.addView(installButton, buttonParams());

        LinearLayout reactions = new LinearLayout(this);
        reactions.setOrientation(LinearLayout.HORIZONTAL);
        dislikeButton = button("Не нравится", false);
        favoriteButton = button("♡ Избранное", false);
        reactions.addView(dislikeButton, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams favoriteParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        favoriteParams.setMargins(dp(8), 0, 0, 0);
        reactions.addView(favoriteButton, favoriteParams);
        root.addView(reactions, new LinearLayout.LayoutParams(-1, -2));
        dislikeButton.setOnClickListener(v -> toggleDislike());
        favoriteButton.setOnClickListener(v -> toggleFavorite());
        return scrollView;
    }

    private void refresh() {
        entry = new ArtRepository(this).findEntry(qid);
        if (entry == null) {
            captionView.setText("Произведение не найдено");
            descriptionView.setText("Сведения о произведении недоступны.");
            imageView.setImageDrawable(null);
            recycleShownBitmap();
            updatePositionView();
            return;
        }
        captionView.setText(entry.caption());
        descriptionView.setText(entry.description.isEmpty() ? "Краткое описание отсутствует" : entry.description);
        updatePositionView();
        ArtRepository repo = new ArtRepository(this);
        favoriteButton.setText(repo.isFavorite(entry) ? "♥ В избранном" : "♡ Избранное");
        dislikeButton.setText(repo.isDisliked(entry) ? "Убрать дизлайк" : "Не нравится");
        showImage(entry);
    }

    private void showImage(ArtEntry e) {
        imageView.setImageDrawable(null);
        recycleShownBitmap();
        if (e.localPath == null || e.localPath.isEmpty()) return;
        File file = new File(e.localPath);
        if (!file.exists()) return;
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = Math.max(bounds.outWidth, bounds.outHeight) > 2200 ? 2 : 1;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        if (bitmap != null) {
            shownBitmap = bitmap;
            imageView.setImageBitmap(bitmap);
        }
    }

    private boolean showRelativeEntry(int delta) {
        if (galleryQids == null || galleryQids.isEmpty() || galleryPosition < 0) return false;
        int next = galleryPosition + delta;
        if (next < 0 || next >= galleryQids.size()) return false;
        String nextQid = galleryQids.get(next);
        if (nextQid == null || nextQid.isEmpty()) return false;
        galleryPosition = next;
        qid = nextQid;
        if (scrollView != null) scrollView.scrollTo(0, 0);
        refresh();
        return true;
    }

    private void updatePositionView() {
        boolean inGallery = galleryPosition >= 0 && galleryPosition < galleryQids.size();
        if (positionView != null) {
            positionView.setText(inGallery
                    ? (galleryPosition + 1) + " из " + galleryQids.size()
                    : "");
        }
        if (navigationRow != null) {
            navigationRow.setVisibility(inGallery && galleryQids.size() > 1 ? View.VISIBLE : View.GONE);
        }
        if (previousButton != null) {
            boolean enabled = inGallery && galleryPosition > 0;
            previousButton.setEnabled(enabled);
            previousButton.setAlpha(enabled ? 1f : 0.35f);
        }
        if (nextButton != null) {
            boolean enabled = inGallery && galleryPosition < galleryQids.size() - 1;
            nextButton.setEnabled(enabled);
            nextButton.setAlpha(enabled ? 1f : 0.35f);
        }
    }

    private void recycleShownBitmap() {
        if (shownBitmap != null && !shownBitmap.isRecycled()) shownBitmap.recycle();
        shownBitmap = null;
    }

    private void install() {
        if (entry == null || !UpdateCoordinator.tryBegin()) {
            Toast.makeText(this, "Обновление уже выполняется", Toast.LENGTH_SHORT).show();
            return;
        }
        setButtonsEnabled(false);
        executor.execute(() -> {
            try {
                new ArtRepository(this).installOnWidget(entry.qid);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    Toast.makeText(this, "Картина установлена на виджет", Toast.LENGTH_SHORT).show();
                    refresh();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show());
            } finally {
                UpdateCoordinator.finish();
                runOnUiThread(() -> setButtonsEnabled(true));
            }
        });
    }

    private void toggleFavorite() {
        if (entry == null) return;
        boolean value = new ArtRepository(this).toggleFavorite(entry);
        Toast.makeText(this, value ? "Добавлено в избранное" : "Удалено из избранного", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void toggleDislike() {
        if (entry == null) return;
        ArtRepository repo = new ArtRepository(this);
        boolean newValue = !repo.isDisliked(entry);
        repo.setDisliked(entry, newValue);
        Toast.makeText(this, newValue ? "Картина добавлена в чёрный список" : "Дизлайк снят", Toast.LENGTH_SHORT).show();
        refresh();
    }

    private void openArticle() {
        if (entry == null || entry.sourceUrl.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(entry.sourceUrl))); }
        catch (Exception e) { Toast.makeText(this, "Не удалось открыть статью", Toast.LENGTH_SHORT).show(); }
    }

    private void openFullscreen() {
        if (entry == null) return;
        Intent intent = new Intent(this, FullscreenActivity.class);
        intent.putExtra("qid", entry.qid);
        startActivity(intent);
    }

    private void setButtonsEnabled(boolean enabled) {
        installButton.setEnabled(enabled);
        favoriteButton.setEnabled(enabled);
        dislikeButton.setEnabled(enabled);
    }

    private Button button(String text, boolean primary) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15, primary ? 0xFF007AFF : borderColor));
        b.setMinHeight(0);
        return b;
    }

    private GradientDrawable rounded(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(50));
        p.setMargins(0, 0, 0, dp(8));
        return p;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFEDEDEF;
        borderColor = dark ? 0xFF38383A : 0xFFD1D1D6;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
