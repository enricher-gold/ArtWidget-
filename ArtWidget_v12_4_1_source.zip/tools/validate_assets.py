#!/usr/bin/env python3
"""Offline structural validation for Art Widget 12.4.1 assets."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"


def load_items(name: str) -> list[dict]:
    data = json.loads((ASSETS / name).read_text(encoding="utf-8"))
    items = data.get("items")
    if not isinstance(items, list):
        raise SystemExit(f"{name}: items is not an array")
    return items


def is_jpeg(path: Path) -> bool:
    data = path.read_bytes()
    return len(data) > 1000 and data.startswith(b"\xff\xd8") and data.endswith(b"\xff\xd9")


def main() -> None:
    for name in ("filter_catalog.json", "nsfw_catalog.json"):
        items = load_items(name)
        assert len(items) == 1000, f"{name}: {len(items)} instead of 1000"
        identities = [str(x.get("stable_id") or x.get("qid") or "").strip() for x in items]
        assert all(identities), f"{name}: empty identity"
        assert len(set(identities)) == len(identities), f"{name}: duplicate identity"
        print(f"OK {name}: {len(items)}")

    starters = load_items("starter_catalog.json")
    safe = [x for x in starters if not x.get("explicit_content")]
    nsfw = [x for x in starters if x.get("explicit_content")]
    assert len(safe) == 10 and len(nsfw) == 10, f"starters: {len(safe)} + {len(nsfw)}"

    ids: set[str] = set()
    for item in starters:
        qid = str(item.get("qid") or "").strip()
        assert qid and qid not in ids, f"duplicate or empty starter id: {qid}"
        ids.add(qid)
        assert str(item.get("description") or "").strip(), f"{qid}: no description"
        assert "wikipedia.org/wiki/" in str(item.get("source_page_url") or ""), f"{qid}: bad source"
        image = ASSETS / str(item.get("asset_path") or "")
        assert image.is_file() and is_jpeg(image), f"{qid}: invalid starter image {image}"
    print(f"OK starter_catalog.json: {len(safe)} FILTER + {len(nsfw)} NSFW")


if __name__ == "__main__":
    main()
