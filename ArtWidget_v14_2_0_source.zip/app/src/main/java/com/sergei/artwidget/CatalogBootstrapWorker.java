package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Проверяет встроенные assets и выполняет лёгкую миграцию пользовательских данных. */
public class CatalogBootstrapWorker extends Worker {
    public CatalogBootstrapWorker(@NonNull Context context,
                                  @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        long started = System.currentTimeMillis();
        try {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            repo.initializeStorageInBackground();
            CatalogWorkScheduler.scheduleNsfwDiscovery(getApplicationContext(), false);
            CatalogWorkScheduler.scheduleGeneralDiscovery(getApplicationContext(), false);
            AppLogger.log(getApplicationContext(), "catalog-bootstrap", "ok",
                    (System.currentTimeMillis() - started) + " ms");
            return Result.success();
        } catch (Exception e) {
            AppLogger.log(getApplicationContext(), "catalog-bootstrap", "error", e.getMessage());
            // Каталог читается напрямую и будет повторно проверен при следующем
            // запуске. Бесконечный WorkManager retry здесь не нужен.
            return Result.failure();
        }
    }
}
