package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Расширяет общий каталог по авторским спискам картин в русской и английской
 * Wikipedia. В базу попадают только страницы конкретных произведений, которые
 * имеют QID, растровое изображение и явные признаки живописи во вступлении.
 */
public final class WikipediaArtistListCatalogUpdater {
    private static final String USER_AGENT =
            "ArtWidget/14.2.0 Android; Wikipedia artist-list catalog; contact enricherusa@gmail.com";
    private static final int CONNECT_TIMEOUT_MS = 12_000;
    private static final int READ_TIMEOUT_MS = 22_000;
    private static final long RESCAN_INTERVAL_MS = 7L * 24L * 60L * 60L * 1000L;
    private static final int MAX_LINKS_PER_LIST = 250;
    private static final int METADATA_CHUNK = 40;

    private static final Source[] SOURCES = new Source[]{
            new Source("ru", "Категория:Списки картин по художникам", "ru_artist_lists"),
            new Source("en", "Category:Lists of paintings", "en_artist_lists")
    };

    private final Context context;
    private final SharedPreferences prefs;
    private final CatalogStore store;

    public WikipediaArtistListCatalogUpdater(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(ArtRepository.PREFS, Context.MODE_PRIVATE);
        this.store = new CatalogStore(this.context);
    }

    public UpdateResult updateBatch(boolean forceRescan) {
        int before = store.countAll();
        int scannedLists = 0;
        int scannedPages = 0;
        int accepted = 0;
        boolean more = false;
        String error = "";
        for (Source source : SOURCES) {
            try {
                SourceResult result = updateSource(source, forceRescan);
                scannedLists += result.scannedLists;
                scannedPages += result.scannedPages;
                accepted += result.accepted;
                more |= result.moreRemaining;
            } catch (Exception e) {
                error = friendly(e);
                AppLogger.log(context, "artist-lists", "source-error",
                        source.lang + " | " + error);
            }
        }
        int added = Math.max(0, store.countAll() - before);
        String status;
        if (added > 0) {
            status = "Каталог Wikipedia пополнен: добавлено " + added
                    + ", проверено страниц " + scannedPages;
        } else if (!error.isEmpty()) {
            status = "Каталог Wikipedia: временная ошибка — " + error;
        } else if (more) {
            status = "Авторские списки Wikipedia проверяются";
        } else {
            status = "Авторские списки Wikipedia проверены";
        }
        prefs.edit()
                .putString("artist_lists_status_v14_2", status)
                .putLong("artist_lists_updated_at_v14_2", System.currentTimeMillis())
                .apply();
        return new UpdateResult(added, scannedLists, scannedPages, accepted, more, error, status);
    }

    private SourceResult updateSource(Source source, boolean forceRescan) throws Exception {
        String cursorKey = "artist_lists_cursor_v14_2_" + source.key;
        String pendingKey = "artist_lists_pending_v14_2_" + source.key;
        String doneKey = "artist_lists_done_v14_2_" + source.key;
        long now = System.currentTimeMillis();

        List<String> pending = readArray(prefs.getString(pendingKey, "[]"));
        String cursor = prefs.getString(cursorKey, "");
        long doneAt = prefs.getLong(doneKey, 0L);
        if (forceRescan && pending.isEmpty()) {
            cursor = "";
            doneAt = 0L;
            prefs.edit().putString(cursorKey, "").putLong(doneKey, 0L).apply();
        }
        if (pending.isEmpty() && cursor.isEmpty() && doneAt > 0L
                && now - doneAt < RESCAN_INTERVAL_MS && !forceRescan) {
            return new SourceResult(0, 0, 0, false);
        }

        if (pending.isEmpty()) {
            CategoryPage category = fetchCategoryPage(source, cursor, 30);
            for (String title : category.titles) {
                if (isAuthorListTitle(source.lang, title)) pending.add(title);
            }
            cursor = category.nextCursor;
            if (pending.isEmpty() && cursor.isEmpty()) {
                prefs.edit().putString(cursorKey, "").putString(pendingKey, "[]")
                        .putLong(doneKey, now).apply();
                return new SourceResult(0, 0, 0, false);
            }
        }

        if (pending.isEmpty()) {
            prefs.edit().putString(cursorKey, cursor).putString(pendingKey, "[]").apply();
            return new SourceResult(0, 0, 0, !cursor.isEmpty());
        }

        String listTitle = pending.remove(0);
        List<String> links = fetchListLinks(source.lang, listTitle);
        List<ArtEntry> accepted = new ArrayList<>();
        for (int start = 0; start < links.size(); start += METADATA_CHUNK) {
            int end = Math.min(links.size(), start + METADATA_CHUNK);
            accepted.addAll(fetchMetadata(source.lang, links.subList(start, end)));
        }

        int merged = 0;
        for (ArtEntry candidate : accepted) {
            ArtEntry existing = store.getByQid(candidate.qid);
            if (existing != null) {
                boolean existingRu = existing.sourceUrl.contains("ru.wikipedia.org/wiki/");
                boolean candidateRu = candidate.sourceUrl.contains("ru.wikipedia.org/wiki/");
                boolean explicit = existing.explicitContent || candidate.explicitContent;
                ArtEntry preferred = existingRu && !candidateRu ? existing : candidate;
                candidate = copyWithExplicit(preferred, explicit);
                if (existingRu && !candidateRu && existing.explicitContent == explicit) continue;
            }
            List<ArtEntry> one = new ArrayList<>();
            one.add(candidate);
            store.mergeAll(one);
            merged++;
        }

        SharedPreferences.Editor editor = prefs.edit()
                .putString(cursorKey, cursor)
                .putString(pendingKey, toArray(pending));
        boolean more = !pending.isEmpty() || !cursor.isEmpty();
        if (!more) editor.putLong(doneKey, now);
        else editor.putLong(doneKey, 0L);
        editor.apply();
        return new SourceResult(1, links.size(), merged, more);
    }

    private CategoryPage fetchCategoryPage(Source source, String cursor, int limit) throws Exception {
        StringBuilder url = new StringBuilder("https://")
                .append(source.lang).append(".wikipedia.org/w/api.php")
                .append("?action=query&format=json&formatversion=2")
                .append("&list=categorymembers&cmnamespace=0&cmtype=page")
                .append("&cmlimit=").append(limit)
                .append("&cmtitle=").append(enc(source.category));
        if (!cursor.isEmpty()) url.append("&cmcontinue=").append(enc(cursor));
        JSONObject root = requestJson(url.toString());
        JSONObject query = root.optJSONObject("query");
        JSONArray rows = query == null ? null : query.optJSONArray("categorymembers");
        List<String> titles = new ArrayList<>();
        if (rows != null) {
            for (int i = 0; i < rows.length(); i++) {
                JSONObject row = rows.optJSONObject(i);
                if (row == null || row.optInt("ns", -1) != 0) continue;
                String title = row.optString("title", "").trim();
                if (!title.isEmpty()) titles.add(title);
            }
        }
        JSONObject continuation = root.optJSONObject("continue");
        String next = continuation == null ? "" : continuation.optString("cmcontinue", "");
        return new CategoryPage(titles, next);
    }

    private List<String> fetchListLinks(String lang, String listTitle) throws Exception {
        String url = "https://" + lang + ".wikipedia.org/w/api.php"
                + "?action=parse&format=json&formatversion=2&prop=links&page=" + enc(listTitle);
        JSONObject root = requestJson(url);
        JSONObject parse = root.optJSONObject("parse");
        JSONArray links = parse == null ? null : parse.optJSONArray("links");
        List<String> out = new ArrayList<>();
        Set<String> unique = new HashSet<>();
        if (links == null) return out;
        for (int i = 0; i < links.length() && out.size() < MAX_LINKS_PER_LIST; i++) {
            JSONObject link = links.optJSONObject(i);
            if (link == null || link.optInt("ns", -1) != 0) continue;
            String title = link.optString("title", "").trim();
            if (title.isEmpty() || isListOrServicePage(lang, title) || !unique.add(title)) continue;
            out.add(title);
        }
        return out;
    }

    private List<ArtEntry> fetchMetadata(String lang, List<String> titles) throws Exception {
        List<ArtEntry> result = new ArrayList<>();
        if (titles.isEmpty()) return result;
        String joined = join(titles, "|");
        String url = "https://" + lang + ".wikipedia.org/w/api.php"
                + "?action=query&format=json&formatversion=2&redirects=1"
                + "&prop=pageprops%7Cpageimages%7Cextracts%7Cinfo%7Ccategories"
                + "&piprop=original%7Cthumbnail&pithumbsize=1600"
                + "&exintro=1&explaintext=1&inprop=url&cllimit=max"
                + "&titles=" + enc(joined);
        JSONObject root = requestJson(url);
        JSONObject query = root.optJSONObject("query");
        JSONArray pages = query == null ? null : query.optJSONArray("pages");
        if (pages == null) return result;

        Set<String> qids = new HashSet<>();
        for (int i = 0; i < pages.length(); i++) {
            JSONObject page = pages.optJSONObject(i);
            JSONObject props = page == null ? null : page.optJSONObject("pageprops");
            String qid = props == null ? "" : props.optString("wikibase_item", "");
            if (qid.matches("Q\\d+")) qids.add(qid);
        }
        Map<String, ArtistNames> artists = fetchArtists(qids);
        long now = System.currentTimeMillis();
        for (int i = 0; i < pages.length(); i++) {
            JSONObject page = pages.optJSONObject(i);
            if (page == null || page.optBoolean("missing", false) || page.optInt("ns", -1) != 0) continue;
            String articleTitle = page.optString("title", "").trim();
            String extract = normalize(page.optString("extract", ""));
            if (!isPainting(lang, articleTitle, extract)) continue;
            JSONObject props = page.optJSONObject("pageprops");
            String qid = props == null ? "" : props.optString("wikibase_item", "").trim();
            if (!qid.matches("Q\\d+")) continue;

            JSONObject original = page.optJSONObject("original");
            JSONObject thumbnail = page.optJSONObject("thumbnail");
            String originalUrl = original == null ? "" : original.optString("source", "").trim();
            String imageUrl = thumbnail == null ? "" : thumbnail.optString("source", "").trim();
            if (imageUrl.isEmpty()) imageUrl = originalUrl;
            if (originalUrl.isEmpty()) originalUrl = imageUrl;
            if (!isRaster(imageUrl) || !isRaster(originalUrl)) continue;

            String categories = categoriesText(page.optJSONArray("categories"));
            boolean explicit = isExplicit(categories + " " + articleTitle + " " + extract);
            ArtistNames names = artists.get(qid);
            String artistRu = names == null ? "" : names.ru;
            String artistEn = names == null ? "" : names.en;
            String artist = "ru".equals(lang)
                    ? firstNonEmpty(artistRu, artistEn, "Автор неизвестен")
                    : firstNonEmpty(artistEn, artistRu, "Unknown artist");
            String title = ArtEntry.titleForWidget(articleTitle);
            String description = shorten(extract);
            String sourceUrl = page.optString("fullurl", "").trim();
            if (sourceUrl.isEmpty()) sourceUrl = "https://" + lang + ".wikipedia.org/wiki/"
                    + encPath(articleTitle.replace(' ', '_'));
            String genre = "dynamic-list, verified-painting, source-" + lang
                    + (explicit ? ", dynamic-nsfw" : "");
            boolean ru = "ru".equals(lang);
            result.add(new ArtEntry(qid, title, artist, description,
                    ru ? title : "", ru ? "" : title,
                    artistRu, artistEn,
                    ru ? description : "", ru ? "" : description,
                    lang, imageUrl, originalUrl, "", sourceUrl,
                    "painting", "", genre, now, 0L, 0, explicit));
        }
        return result;
    }

    private Map<String, ArtistNames> fetchArtists(Set<String> artworkQids) {
        Map<String, ArtistNames> result = new HashMap<>();
        if (artworkQids.isEmpty()) return result;
        try {
            JSONObject root = requestJson("https://www.wikidata.org/w/api.php"
                    + "?action=wbgetentities&format=json&formatversion=2&props=claims&ids="
                    + enc(join(new ArrayList<>(artworkQids), "|")));
            JSONObject entities = root.optJSONObject("entities");
            Map<String, List<String>> artworkArtists = new HashMap<>();
            Set<String> artistQids = new HashSet<>();
            for (String artwork : artworkQids) {
                JSONObject entity = entities == null ? null : entities.optJSONObject(artwork);
                JSONObject claims = entity == null ? null : entity.optJSONObject("claims");
                JSONArray p170 = claims == null ? null : claims.optJSONArray("P170");
                if (p170 == null) continue;
                List<String> ids = new ArrayList<>();
                for (int i = 0; i < p170.length(); i++) {
                    JSONObject claim = p170.optJSONObject(i);
                    JSONObject snak = claim == null ? null : claim.optJSONObject("mainsnak");
                    JSONObject data = snak == null ? null : snak.optJSONObject("datavalue");
                    JSONObject value = data == null ? null : data.optJSONObject("value");
                    String id = value == null ? "" : value.optString("id", "");
                    if (id.matches("Q\\d+") && !ids.contains(id)) {
                        ids.add(id);
                        artistQids.add(id);
                    }
                }
                if (!ids.isEmpty()) artworkArtists.put(artwork, ids);
            }
            if (artistQids.isEmpty()) return result;
            JSONObject labelsRoot = requestJson("https://www.wikidata.org/w/api.php"
                    + "?action=wbgetentities&format=json&formatversion=2&props=labels"
                    + "&languages=ru%7Cen&languagefallback=1&ids="
                    + enc(join(new ArrayList<>(artistQids), "|")));
            JSONObject labelEntities = labelsRoot.optJSONObject("entities");
            Map<String, ArtistNames> labels = new HashMap<>();
            for (String id : artistQids) {
                JSONObject entity = labelEntities == null ? null : labelEntities.optJSONObject(id);
                JSONObject values = entity == null ? null : entity.optJSONObject("labels");
                labels.put(id, new ArtistNames(label(values, "ru"), label(values, "en")));
            }
            for (Map.Entry<String, List<String>> row : artworkArtists.entrySet()) {
                List<String> ru = new ArrayList<>();
                List<String> en = new ArrayList<>();
                for (String id : row.getValue()) {
                    ArtistNames names = labels.get(id);
                    if (names == null) continue;
                    addDistinct(ru, names.ru);
                    addDistinct(en, names.en);
                }
                result.put(row.getKey(), new ArtistNames(join(ru, ", "), join(en, ", ")));
            }
        } catch (Exception e) {
            AppLogger.log(context, "artist-lists", "artist-error", friendly(e));
        }
        return result;
    }

    private boolean isAuthorListTitle(String lang, String title) {
        String value = title.toLowerCase(Locale.ROOT).replace('ё', 'е').trim();
        if ("ru".equals(lang)) {
            return value.startsWith("список картин ")
                    || value.startsWith("список произведений ")
                    || value.contains("список картин по ");
        }
        return value.startsWith("list of paintings by ")
                || value.startsWith("list of works by ")
                || value.startsWith("list of artworks by ")
                || value.startsWith("catalogue raisonné of ")
                || value.startsWith("catalogue raisonne of ");
    }

    private boolean isListOrServicePage(String lang, String title) {
        String value = title.toLowerCase(Locale.ROOT).replace('ё', 'е');
        if (value.matches(".*\\b(1[0-9]{3}|20[0-9]{2})\\b.*")) return true;
        if ("ru".equals(lang)) {
            return value.startsWith("список ") || value.startsWith("категория:")
                    || value.contains("художник") && !value.contains("картина");
        }
        return value.startsWith("list of ") || value.startsWith("category:")
                || value.startsWith("timeline of ");
    }

    private boolean isPainting(String lang, String title, String extract) {
        String text = (title + " " + extract).toLowerCase(Locale.ROOT).replace('ё', 'е');
        String intro = text.length() > 700 ? text.substring(0, 700) : text;
        String[] reject = new String[]{"sculpture", "statue", "photograph", "engraving",
                "etching", "drawing", "lithograph", "woodcut", "poster", "building",
                "architecture", "скульптур", "стату", "фотограф", "гравюр", "офорт",
                "рисунок", "литограф", "плакат", "здание", "архитектур"};
        for (String value : reject) if (intro.contains(value)) return false;
        if ("ru".equals(lang)) {
            return intro.contains(" — картина") || intro.contains(" - картина")
                    || intro.contains("является картиной") || intro.contains("живописное полотно")
                    || intro.contains("масло на холсте") || intro.contains("холст, масло")
                    || intro.matches(".*\\bкартина\\b.{0,120}\\bхудожник.*");
        }
        return intro.matches(".*\\bis (?:an? |the )?[^.]{0,120}\\bpainting\\b.*")
                || intro.contains("painting by ") || intro.contains("oil on canvas")
                || intro.contains("panel painting") || intro.contains("fresco painting");
    }

    private boolean isExplicit(String value) {
        String text = value.toLowerCase(Locale.ROOT).replace('ё', 'е');
        String[] markers = new String[]{"nude paintings", "nude painting", "nudity in art",
                "erotic painting", "erotic art", "обнаженная натура", "обнаженные женщины",
                "обнаженные мужчины", "эротическая живопись", "картины с обнаженными"};
        for (String marker : markers) if (text.contains(marker)) return true;
        return false;
    }

    private String categoriesText(JSONArray categories) {
        if (categories == null) return "";
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < categories.length(); i++) {
            JSONObject row = categories.optJSONObject(i);
            if (row == null) continue;
            if (out.length() > 0) out.append(' ');
            out.append(row.optString("title", ""));
        }
        return out.toString();
    }

    private JSONObject requestJson(String urlValue) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(urlValue).openConnection();
            connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
            connection.setReadTimeout(READ_TIMEOUT_MS);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", USER_AGENT);
            connection.setRequestProperty("Accept", "application/json");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("Wikipedia HTTP " + code);
            try (InputStream input = new BufferedInputStream(connection.getInputStream());
                 ByteArrayOutputStream output = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192];
                int read;
                while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
                return new JSONObject(output.toString(StandardCharsets.UTF_8.name()));
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private static ArtEntry copyWithExplicit(ArtEntry entry, boolean explicit) {
        String genre = entry.genreLabel == null ? "" : entry.genreLabel;
        if (explicit && !genre.toLowerCase(Locale.ROOT).contains("dynamic-nsfw")) {
            genre = genre.trim().isEmpty() ? "dynamic-nsfw" : genre + ", dynamic-nsfw";
        }
        return new ArtEntry(entry.qid, entry.title, entry.artist, entry.description,
                entry.titleRu, entry.titleEn, entry.artistRu, entry.artistEn,
                entry.descriptionRu, entry.descriptionEn, entry.sourceLanguage,
                entry.imageUrl, entry.originalImageUrl, entry.localPath, entry.sourceUrl,
                entry.instanceLabel, entry.materialLabel, genre,
                entry.addedAt, entry.lastShownAt, entry.showCount, explicit);
    }

    private static String label(JSONObject labels, String lang) {
        JSONObject row = labels == null ? null : labels.optJSONObject(lang);
        return row == null ? "" : normalize(row.optString("value", ""));
    }

    private static void addDistinct(List<String> target, String value) {
        String clean = normalize(value);
        if (clean.isEmpty()) return;
        for (String current : target) if (current.equalsIgnoreCase(clean)) return;
        target.add(clean);
    }

    private static String firstNonEmpty(String first, String second, String fallback) {
        if (first != null && !first.trim().isEmpty()) return first.trim();
        if (second != null && !second.trim().isEmpty()) return second.trim();
        return fallback;
    }

    private static boolean isRaster(String value) {
        String lower = value == null ? "" : value.toLowerCase(Locale.ROOT);
        int query = lower.indexOf('?');
        if (query >= 0) lower = lower.substring(0, query);
        return lower.endsWith(".jpg") || lower.endsWith(".jpeg")
                || lower.endsWith(".png") || lower.endsWith(".webp");
    }

    private static String shorten(String value) {
        String text = normalize(value);
        if (text.length() <= 760) return text;
        int cut = text.lastIndexOf(' ', 760);
        if (cut < 500) cut = 760;
        return text.substring(0, cut).trim() + "…";
    }

    private static String normalize(String value) {
        return value == null ? "" : value.replaceAll("\\s+", " ").trim();
    }

    private static String join(List<String> values, String separator) {
        StringBuilder out = new StringBuilder();
        for (String value : values) {
            if (value == null || value.trim().isEmpty()) continue;
            if (out.length() > 0) out.append(separator);
            out.append(value.trim());
        }
        return out.toString();
    }

    private static List<String> readArray(String json) {
        List<String> out = new ArrayList<>();
        try {
            JSONArray array = new JSONArray(json == null ? "[]" : json);
            for (int i = 0; i < array.length(); i++) {
                String value = array.optString(i, "").trim();
                if (!value.isEmpty()) out.add(value);
            }
        } catch (Exception ignored) { }
        return out;
    }

    private static String toArray(List<String> values) {
        JSONArray array = new JSONArray();
        for (String value : values) array.put(value);
        return array.toString();
    }

    private static String enc(String value) {
        try { return URLEncoder.encode(value == null ? "" : value, StandardCharsets.UTF_8.name()); }
        catch (Exception e) { return ""; }
    }

    private static String encPath(String value) {
        String[] parts = (value == null ? "" : value).split("/", -1);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) out.append('/');
            out.append(enc(parts[i]).replace("+", "%20"));
        }
        return out.toString();
    }

    private static String friendly(Exception e) {
        if (e == null) return "unknown error";
        String value = e.getMessage();
        return value == null || value.trim().isEmpty() ? e.getClass().getSimpleName() : value.trim();
    }

    public static final class UpdateResult {
        public final int added;
        public final int scannedLists;
        public final int scannedPages;
        public final int accepted;
        public final boolean moreRemaining;
        public final String error;
        public final String status;

        UpdateResult(int added, int scannedLists, int scannedPages, int accepted,
                     boolean moreRemaining, String error, String status) {
            this.added = added;
            this.scannedLists = scannedLists;
            this.scannedPages = scannedPages;
            this.accepted = accepted;
            this.moreRemaining = moreRemaining;
            this.error = error == null ? "" : error;
            this.status = status == null ? "" : status;
        }
    }

    private static final class Source {
        final String lang;
        final String category;
        final String key;
        Source(String lang, String category, String key) {
            this.lang = lang;
            this.category = category;
            this.key = key;
        }
    }

    private static final class CategoryPage {
        final List<String> titles;
        final String nextCursor;
        CategoryPage(List<String> titles, String nextCursor) {
            this.titles = titles;
            this.nextCursor = nextCursor == null ? "" : nextCursor;
        }
    }

    private static final class SourceResult {
        final int scannedLists;
        final int scannedPages;
        final int accepted;
        final boolean moreRemaining;
        SourceResult(int scannedLists, int scannedPages, int accepted, boolean moreRemaining) {
            this.scannedLists = scannedLists;
            this.scannedPages = scannedPages;
            this.accepted = accepted;
            this.moreRemaining = moreRemaining;
        }
    }

    private static final class ArtistNames {
        final String ru;
        final String en;
        ArtistNames(String ru, String en) {
            this.ru = ru == null ? "" : ru.trim();
            this.en = en == null ? "" : en.trim();
        }
    }
}
