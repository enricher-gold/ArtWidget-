package com.sergei.artwidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ArtScheduler {
    public static final String PREFS = "art_widget_prefs";
    public static final String KEY_INTERVAL_SECONDS = "interval_seconds";
    public static final String KEY_NEXT_AT_MILLIS = "next_update_at_millis";
    public static final int DEFAULT_INTERVAL_SECONDS = 60 * 60;
    public static final int MIN_INTERVAL_SECONDS = 10;
    public static final int MAX_INTERVAL_SECONDS = 60 * 60 * 24 * 30;

    public static int getIntervalSeconds(Context context) {
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int seconds = prefs.getInt(KEY_INTERVAL_SECONDS, DEFAULT_INTERVAL_SECONDS);

        // Миграция со старой версии, где были только часы.
        if (!prefs.contains(KEY_INTERVAL_SECONDS) && prefs.contains("interval_hours")) {
            int oldHours = prefs.getInt("interval_hours", 1);
            seconds = oldHours * 60 * 60;
            setIntervalSeconds(context, seconds);
        }

        if (seconds < MIN_INTERVAL_SECONDS || seconds > MAX_INTERVAL_SECONDS) return DEFAULT_INTERVAL_SECONDS;
        return seconds;
    }

    public static void setIntervalSeconds(Context context, int seconds) {
        if (seconds < MIN_INTERVAL_SECONDS) seconds = MIN_INTERVAL_SECONDS;
        if (seconds > MAX_INTERVAL_SECONDS) seconds = MAX_INTERVAL_SECONDS;
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putInt(KEY_INTERVAL_SECONDS, seconds)
                .apply();
        scheduleNext(context);
    }

    public static void scheduleNext(Context context) {
        Context app = context.getApplicationContext();
        AlarmManager alarmManager = (AlarmManager) app.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        PendingIntent pi = pendingIntent(app);
        alarmManager.cancel(pi);

        long delay = getIntervalSeconds(app) * 1000L;
        long triggerAt = System.currentTimeMillis() + delay;
        app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putLong(KEY_NEXT_AT_MILLIS, triggerAt)
                .apply();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            } else {
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi);
        }
    }

    public static void cancel(Context context) {
        AlarmManager alarmManager = (AlarmManager) context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) alarmManager.cancel(pendingIntent(context.getApplicationContext()));
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .remove(KEY_NEXT_AT_MILLIS)
                .apply();
    }

    public static boolean canScheduleExact(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager alarmManager = (AlarmManager) context.getApplicationContext().getSystemService(Context.ALARM_SERVICE);
        return alarmManager != null && alarmManager.canScheduleExactAlarms();
    }

    public static long getNextAtMillis(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getLong(KEY_NEXT_AT_MILLIS, 0L);
    }

    public static String nextUpdateText(Context context) {
        long next = getNextAtMillis(context);
        if (next <= 0) return "следующее автообновление не запланировано";
        SimpleDateFormat fmt = new SimpleDateFormat("HH:mm", Locale.getDefault());
        return "следующее автообновление около " + fmt.format(new Date(next));
    }

    public static String exactAlarmHint(Context context) {
        if (canScheduleExact(context)) return "";
        return "Android не дал разрешение на точные будильники, поэтому автообновление может срабатывать с задержкой.";
    }

    public static String intervalText(int seconds) {
        if (seconds < 60) return seconds + " сек.";
        if (seconds % 3600 == 0) {
            int h = seconds / 3600;
            if (h == 1) return "1 час";
            if (h >= 2 && h <= 4) return h + " часа";
            return h + " часов";
        }
        if (seconds % 60 == 0) {
            int m = seconds / 60;
            if (m == 1) return "1 минута";
            if (m >= 2 && m <= 4) return m + " минуты";
            return m + " минут";
        }
        return seconds + " сек.";
    }

    private static PendingIntent pendingIntent(Context context) {
        Intent intent = new Intent(context, ArtWidgetProvider.class);
        intent.setAction(ArtWidgetProvider.ACTION_SCHEDULED_UPDATE);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, 12001, intent, flags);
    }
}
