package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private ImageView previewImage;
    private TextView status;
    private TextView article;
    private TextView cacheInfo;
    private Button refreshButton;
    private Button previousButton;
    private Button clearCacheButton;
    private Button saveIntervalButton;
    private Button exactAlarmButton;
    private Spinner unitSpinner;
    private EditText intervalValue;
    private String currentSourceUrl = "";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupThemeColors();
        setContentView(createLayout());
        updateUiFromCache();
        ArtWidgetProvider.updateAllWidgets(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUiFromCache();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }

    private void setupThemeColors() {
        boolean dark = isDarkMode();
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFE9E9EB;
        borderColor = dark ? 0xFF2C2C2E : 0xFFD1D1D6;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;

        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bgColor);
        int pad = dp(18);
        root.setPadding(pad, dp(54), pad, pad);
        scroll.addView(root);

        previewImage = new ImageView(this);
        previewImage.setAdjustViewBounds(true);
        previewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewImage.setBackgroundColor(0x00000000);
        previewImage.setContentDescription("Текущая картина");
        previewImage.setOnClickListener(v -> openCurrentArticle());
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(260)
        );
        previewParams.setMargins(0, 0, 0, dp(14));
        root.addView(previewImage, previewParams);

        TextView source = new TextView(this);
        source.setText("Источник: русская Википедия / Wikimedia.");
        source.setTextSize(14);
        source.setPadding(0, 0, 0, dp(10));
        styleText(source, false);
        root.addView(source, matchWrap());

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 0, 0, dp(10));
        status.setLinkTextColor(linkColor);
        styleText(status, false);
        root.addView(status, matchWrap());

        TextView articleTitle = new TextView(this);
        articleTitle.setText("О картине");
        articleTitle.setTextSize(18);
        articleTitle.setTypeface(Typeface.DEFAULT_BOLD);
        articleTitle.setPadding(0, dp(4), 0, dp(4));
        styleText(articleTitle, true);
        root.addView(articleTitle, matchWrap());

        article = new TextView(this);
        article.setTextSize(15);
        article.setPadding(0, 0, 0, dp(12));
        styleText(article, false);
        root.addView(article, matchWrap());

        cacheInfo = new TextView(this);
        cacheInfo.setTextSize(14);
        cacheInfo.setPadding(0, 0, 0, dp(12));
        styleText(cacheInfo, false);
        root.addView(cacheInfo, matchWrap());

        refreshButton = makeButton("Обновить картину сейчас", true);
        refreshButton.setOnClickListener(v -> refreshNow());
        root.addView(refreshButton, buttonParams());

        previousButton = makeButton("Вернуться к предыдущей картине", false);
        previousButton.setOnClickListener(v -> previous());
        root.addView(previousButton, buttonParams());

        clearCacheButton = makeButton("Очистить кэш", false);
        clearCacheButton.setOnClickListener(v -> clearCache());
        root.addView(clearCacheButton, buttonParams());

        TextView intervalLabel = new TextView(this);
        intervalLabel.setText("Автообновление:");
        intervalLabel.setTextSize(16);
        intervalLabel.setPadding(0, dp(20), 0, dp(6));
        styleText(intervalLabel, false);
        root.addView(intervalLabel, matchWrap());

        LinearLayout intervalRow = new LinearLayout(this);
        intervalRow.setOrientation(LinearLayout.HORIZONTAL);
        intervalRow.setGravity(Gravity.CENTER_VERTICAL);

        intervalValue = new EditText(this);
        intervalValue.setInputType(InputType.TYPE_CLASS_NUMBER);
        intervalValue.setSingleLine(true);
        intervalValue.setSelectAllOnFocus(true);
        intervalValue.setTextSize(16);
        intervalValue.setTextColor(textColor);
        intervalValue.setHintTextColor(subTextColor);
        intervalValue.setBackground(roundedDrawable(fieldColor, dp(12), borderColor, 1));
        intervalValue.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        valueParams.setMargins(0, 0, dp(10), 0);
        intervalRow.addView(intervalValue, valueParams);

        unitSpinner = new Spinner(this);
        String[] units = new String[]{"секунд", "минут", "часов"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, units) {
            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(textColor);
                    ((TextView) v).setTextSize(16);
                }
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                View v = super.getDropDownView(position, convertView, parent);
                if (v instanceof TextView) {
                    ((TextView) v).setTextColor(textColor);
                    v.setBackgroundColor(bgColor);
                }
                return v;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitSpinner.setAdapter(adapter);
        unitSpinner.setBackground(roundedDrawable(fieldColor, dp(12), borderColor, 1));
        intervalRow.addView(unitSpinner, new LinearLayout.LayoutParams(0, dp(48), 1f));
        root.addView(intervalRow, matchWrap());

        applyIntervalToControls(ArtScheduler.getIntervalSeconds(this));
        unitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View view, int position, long id) { }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        saveIntervalButton = makeButton("Сохранить интервал", true);
        saveIntervalButton.setOnClickListener(v -> saveInterval());
        root.addView(saveIntervalButton, buttonParams());

        exactAlarmButton = makeButton("Разрешить точное автообновление", false);
        exactAlarmButton.setOnClickListener(v -> openExactAlarmSettings());
        root.addView(exactAlarmButton, buttonParams());

        return scroll;
    }

    private void refreshNow() {
        setBusy(true);
        setStatus("Загружаю новую картину…");
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(this);
                repo.fetchNextArtwork();
                ArtScheduler.scheduleNext(this);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    updateUiFromCache();
                    setBusy(false);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setStatus("Ошибка загрузки: " + friendlyError(e));
                    setBusy(false);
                });
            }
        });
    }

    private void previous() {
        try {
            ArtRepository repo = new ArtRepository(this);
            ArtEntry entry = repo.goPrevious();
            ArtWidgetProvider.updateAllWidgets(this);
            if (entry == null) {
                setStatus("Предыдущей картины пока нет. Сначала загрузите несколько картин.");
            } else {
                updateUiFromCache();
            }
        } catch (Exception e) {
            setStatus("Ошибка: " + friendlyError(e));
        }
    }

    private void clearCache() {
        ArtRepository repo = new ArtRepository(this);
        repo.clearCache();
        ArtWidgetProvider.updateAllWidgets(this);
        updateUiFromCache();
    }

    private void saveInterval() {
        int value;
        try {
            value = Integer.parseInt(intervalValue.getText().toString().trim());
        } catch (Exception e) {
            setStatus("Введите число для интервала автообновления.");
            return;
        }
        if (value <= 0) {
            setStatus("Интервал должен быть больше нуля.");
            return;
        }

        long secondsLong = value;
        int unit = unitSpinner.getSelectedItemPosition();
        if (unit == 1) secondsLong *= 60L;
        if (unit == 2) secondsLong *= 3600L;

        if (secondsLong < ArtScheduler.MIN_INTERVAL_SECONDS) secondsLong = ArtScheduler.MIN_INTERVAL_SECONDS;
        if (secondsLong > ArtScheduler.MAX_INTERVAL_SECONDS) secondsLong = ArtScheduler.MAX_INTERVAL_SECONDS;

        int seconds = (int) secondsLong;
        ArtScheduler.setIntervalSeconds(this, seconds);
        applyIntervalToControls(seconds);
        updateUiFromCache();
        Toast.makeText(this, "Интервал сохранён: " + ArtScheduler.intervalText(seconds), Toast.LENGTH_SHORT).show();
    }

    private void updateUiFromCache() {
        ArtRepository repo = new ArtRepository(this);
        ArtEntry current = repo.getCurrent();
        int seconds = ArtScheduler.getIntervalSeconds(this);
        currentSourceUrl = current == null ? "" : current.sourceUrl;
        updatePreview(current);

        String exactHint = ArtScheduler.exactAlarmHint(this);
        if (current == null) {
            setStatus("Картин в кэше пока нет. Нажмите «Обновить картину сейчас».\nИнтервал автообновления: "
                    + ArtScheduler.intervalText(seconds) + ".\n" + ArtScheduler.nextUpdateText(this)
                    + (exactHint.isEmpty() ? "" : "\n" + exactHint));
            article.setText("После загрузки картины здесь появится краткое описание.");
        } else {
            setLinkedStatus(current,
                    "Сейчас в виджете:\n" + current.caption()
                            + "\nОригинал: " + current.originalCaption()
                            + "\nИнтервал автообновления: " + ArtScheduler.intervalText(seconds)
                            + ".\n" + ArtScheduler.nextUpdateText(this)
                            + (exactHint.isEmpty() ? "" : "\n" + exactHint));
            article.setText(current.description == null || current.description.trim().isEmpty() ? "Описание отсутствует." : current.description);
        }
        cacheInfo.setText("Картин в кэше: " + repo.getCacheCount() + " из " + repo.getCacheLimit()
                + ". Каталог: " + repo.getCatalogCount() + ".");
        if (exactAlarmButton != null) {
            exactAlarmButton.setVisibility(ArtScheduler.canScheduleExact(this) ? View.GONE : View.VISIBLE);
        }
    }

    private void updatePreview(ArtEntry current) {
        if (previewImage == null) return;
        if (current == null || current.localPath == null || current.localPath.trim().isEmpty()) {
            previewImage.setImageDrawable(null);
            previewImage.setVisibility(View.GONE);
            return;
        }
        File f = new File(current.localPath);
        if (!f.exists() || f.length() == 0) {
            previewImage.setImageDrawable(null);
            previewImage.setVisibility(View.GONE);
            return;
        }
        Bitmap bitmap = BitmapFactory.decodeFile(f.getAbsolutePath());
        if (bitmap == null) {
            previewImage.setImageDrawable(null);
            previewImage.setVisibility(View.GONE);
            return;
        }
        previewImage.setVisibility(View.VISIBLE);
        previewImage.setImageBitmap(bitmap);
    }

    private void setLinkedStatus(ArtEntry current, String text) {
        if (current == null || current.sourceUrl == null || current.sourceUrl.trim().isEmpty()) {
            setStatus(text);
            return;
        }
        String linkText = current.caption();
        int start = text.indexOf(linkText);
        if (start < 0) {
            setStatus(text);
            return;
        }
        SpannableString sp = new SpannableString(text);
        sp.setSpan(new URLSpan(current.sourceUrl), start, start + linkText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        status.setText(sp);
        status.setTextColor(subTextColor);
        status.setMovementMethod(LinkMovementMethod.getInstance());
    }

    private void openCurrentArticle() {
        if (currentSourceUrl == null || currentSourceUrl.trim().isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentSourceUrl)));
        } catch (Exception ignored) {
        }
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
                setStatus("Не удалось открыть настройки точного автообновления.");
            }
        }
    }

    private void applyIntervalToControls(int seconds) {
        if (seconds < 60) {
            intervalValue.setText(String.valueOf(seconds));
            unitSpinner.setSelection(0);
        } else if (seconds % 3600 == 0) {
            intervalValue.setText(String.valueOf(seconds / 3600));
            unitSpinner.setSelection(2);
        } else {
            intervalValue.setText(String.valueOf(seconds / 60));
            unitSpinner.setSelection(1);
        }
    }

    private void setBusy(boolean busy) {
        refreshButton.setEnabled(!busy);
        previousButton.setEnabled(!busy);
        clearCacheButton.setEnabled(!busy);
        saveIntervalButton.setEnabled(!busy);
        if (exactAlarmButton != null) exactAlarmButton.setEnabled(!busy);
        unitSpinner.setEnabled(!busy);
        intervalValue.setEnabled(!busy);
        float alpha = busy ? 0.55f : 1f;
        refreshButton.setAlpha(alpha);
        previousButton.setAlpha(alpha);
        clearCacheButton.setAlpha(alpha);
        saveIntervalButton.setAlpha(alpha);
        if (exactAlarmButton != null) exactAlarmButton.setAlpha(alpha);
    }

    private void setStatus(String text) {
        status.setMovementMethod(null);
        status.setTextColor(subTextColor);
        status.setText(text == null ? "" : text);
    }

    private String friendlyError(Exception e) {
        String msg = e == null || e.getMessage() == null ? "неизвестная ошибка" : e.getMessage();
        if (msg.contains("Слишком частые запросы")) return msg;
        if (msg.contains("HTTP 429")) return "Слишком частые запросы к Википедии/Wikimedia. Подождите 1–2 минуты.";
        if (msg.length() > 240) return msg.substring(0, 240).trim() + "…";
        return msg;
    }

    private Button makeButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setMinHeight(dp(50));
        b.setPadding(dp(16), 0, dp(16), 0);
        b.setGravity(Gravity.CENTER);
        if (primary) {
            b.setTextColor(Color.WHITE);
            b.setBackground(roundedDrawable(0xFF007AFF, dp(15), 0, 0));
        } else {
            b.setTextColor(textColor);
            b.setBackground(roundedDrawable(fieldColor, dp(15), borderColor, 0));
        }
        return b;
    }

    private void styleText(TextView tv, boolean title) {
        tv.setTextColor(title ? textColor : subTextColor);
    }

    private GradientDrawable roundedDrawable(int color, int radius, int strokeColor, int strokeWidthDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        if (strokeWidthDp > 0) d.setStroke(dp(strokeWidthDp), strokeColor);
        return d;
    }

    private boolean isDarkMode() {
        int mode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0, 0, 0, dp(8));
        return p;
    }

    private LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(50)
        );
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
