package com.sergei.artwidget;

import org.json.JSONException;
import org.json.JSONObject;

public class ArtEntry {
    public final int id;
    public final String title;
    public final String artist;
    public final String originalTitle;
    public final String originalArtist;
    public final String description;
    public final String imageId;
    public final String imageUrl;
    public final String localPath;
    public final String sourceUrl;
    public final String dateDisplay;
    public final String mediumDisplay;

    public ArtEntry(
            int id,
            String title,
            String artist,
            String originalTitle,
            String originalArtist,
            String description,
            String imageId,
            String imageUrl,
            String localPath,
            String sourceUrl,
            String dateDisplay,
            String mediumDisplay
    ) {
        this.id = id;
        this.title = safe(title, "Без названия");
        this.artist = safe(artist, "Неизвестный художник");
        this.originalTitle = safe(originalTitle, this.title);
        this.originalArtist = safe(originalArtist, this.artist);
        this.description = safe(description, "");
        this.imageId = safe(imageId, "");
        this.imageUrl = safe(imageUrl, "");
        this.localPath = safe(localPath, "");
        this.sourceUrl = safe(sourceUrl, "");
        this.dateDisplay = safe(dateDisplay, "");
        this.mediumDisplay = safe(mediumDisplay, "");
    }

    private static String safe(String value, String fallback) {
        if (value == null) return fallback == null ? "" : fallback;
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        return s.isEmpty() ? (fallback == null ? "" : fallback) : s;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("title", title);
        o.put("artist", artist);
        o.put("originalTitle", originalTitle);
        o.put("originalArtist", originalArtist);
        o.put("description", description);
        o.put("imageId", imageId);
        o.put("imageUrl", imageUrl);
        o.put("localPath", localPath);
        o.put("sourceUrl", sourceUrl);
        o.put("dateDisplay", dateDisplay);
        o.put("mediumDisplay", mediumDisplay);
        return o;
    }

    public static ArtEntry fromJson(JSONObject o) {
        String title = o.optString("title", "Без названия");
        String artist = o.optString("artist", "Неизвестный художник");
        return new ArtEntry(
                o.optInt("id", 0),
                title,
                artist,
                o.optString("originalTitle", title),
                o.optString("originalArtist", artist),
                o.optString("description", ""),
                o.optString("imageId", ""),
                o.optString("imageUrl", ""),
                o.optString("localPath", ""),
                o.optString("sourceUrl", ""),
                o.optString("dateDisplay", ""),
                o.optString("mediumDisplay", "")
        );
    }

    public String caption() {
        return artist + " · " + title;
    }

    public String originalCaption() {
        return originalArtist + " · " + originalTitle;
    }
}
