package com.sergei.artwidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;

import java.io.File;

public class ArtRenderer {
    private static final int DEFAULT_W = 512;
    private static final int DEFAULT_H = 512;
    private static final int MAX_LONG_SIDE = 640;
    private static final int MIN_SIDE = 260;

    private static final int PAD = 3;
    private static final int GAP = 7;
    private static final int CAPTION_TEXT_SIZE = 15;
    private static final int CAPTION_BASELINE_OFFSET = 21;
    private static final int BOTTOM_PAD = 5;

    public static Bitmap render(Context context, ArtEntry entry) {
        return render(context, entry, DEFAULT_W, DEFAULT_H);
    }

    public static Bitmap render(Context context, ArtEntry entry, int widgetWidthDp, int widgetHeightDp) {
        int[] size = canvasSize(widgetWidthDp, widgetHeightDp);
        int w = size[0];
        int h = size[1];

        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);

        if (entry == null || entry.localPath == null || !new File(entry.localPath).exists()) {
            drawPlaceholder(canvas, w, h, "Откройте приложение\nи загрузите картину");
            return result;
        }

        Bitmap original = BitmapFactory.decodeFile(entry.localPath);
        if (original == null) {
            drawPlaceholder(canvas, w, h, "Кэш повреждён\nзагрузите картину заново");
            return result;
        }

        RectF artworkRect = drawArtwork(canvas, original, w, h);
        original.recycle();
        drawCaption(canvas, w, h, entry.caption(), artworkRect);
        return result;
    }

    public static Bitmap renderStatus(String text) {
        Bitmap result = Bitmap.createBitmap(DEFAULT_W, DEFAULT_H, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);
        drawPlaceholder(canvas, DEFAULT_W, DEFAULT_H, text);
        return result;
    }

    private static int[] canvasSize(int widthDp, int heightDp) {
        int width = widthDp <= 0 ? DEFAULT_W : widthDp;
        int height = heightDp <= 0 ? DEFAULT_H : heightDp;
        float ratio = height / (float) Math.max(1, width);

        int w;
        int h;
        if (ratio >= 1f) {
            h = MAX_LONG_SIDE;
            w = Math.round(h / ratio);
        } else {
            w = MAX_LONG_SIDE;
            h = Math.round(w * ratio);
        }
        w = Math.max(MIN_SIDE, Math.min(MAX_LONG_SIDE, w));
        h = Math.max(MIN_SIDE, Math.min(MAX_LONG_SIDE, h));
        return new int[]{w, h};
    }

    private static RectF drawArtwork(Canvas canvas, Bitmap original, int w, int h) {
        int maxW = w - PAD * 2;
        int reservedCaptionH = GAP + CAPTION_BASELINE_OFFSET + BOTTOM_PAD;
        int maxH = h - PAD * 2 - reservedCaptionH;
        if (maxH < h / 3) maxH = Math.max(1, h - PAD * 2);

        float scale = Math.min(maxW / (float) original.getWidth(), maxH / (float) original.getHeight());
        int dstW = Math.max(1, Math.round(original.getWidth() * scale));
        int dstH = Math.max(1, Math.round(original.getHeight() * scale));
        int left = (w - dstW) / 2;
        int top = PAD;

        Rect src = new Rect(0, 0, original.getWidth(), original.getHeight());
        RectF dst = new RectF(left, top, left + dstW, top + dstH);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        canvas.drawBitmap(original, src, dst, paint);
        return dst;
    }

    private static void drawCaption(Canvas canvas, int w, int h, String caption, RectF artworkRect) {
        TextPaint paint = baseTextPaint(CAPTION_TEXT_SIZE, true);
        String line = ellipsize(caption, paint, w - PAD * 2);
        float y = artworkRect.bottom + GAP + CAPTION_BASELINE_OFFSET;
        if (y > h - BOTTOM_PAD) y = h - BOTTOM_PAD;
        drawCenteredText(canvas, w, line, y, paint);
    }

    private static TextPaint baseTextPaint(float size, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setColor(Color.WHITE);
        p.setTextSize(size);
        p.setFakeBoldText(bold);
        p.setShadowLayer(5f, 1.5f, 1.5f, Color.BLACK);
        return p;
    }

    private static void drawCenteredText(Canvas canvas, int w, String text, float y, TextPaint paint) {
        float x = (w - paint.measureText(text)) / 2f;
        canvas.drawText(text, x, y, paint);
    }

    private static String ellipsize(String text, Paint paint, int maxWidth) {
        if (text == null || text.trim().isEmpty()) return " ";
        text = text.replace('\n', ' ').replace('\r', ' ').trim();
        if (paint.measureText(text) <= maxWidth) return text;
        String suffix = "…";
        int end = text.length();
        while (end > 0 && paint.measureText(text.substring(0, end) + suffix) > maxWidth) end--;
        return end <= 0 ? suffix : text.substring(0, end).trim() + suffix;
    }

    private static void drawPlaceholder(Canvas canvas, int w, int h, String text) {
        TextPaint paint = baseTextPaint(21, false);
        String[] lines = text == null ? new String[]{"Art Widget"} : text.split("\\n");
        float startY = h / 2f - (lines.length - 1) * 18f;
        for (int i = 0; i < lines.length; i++) {
            String line = ellipsize(lines[i], paint, w - PAD * 2);
            drawCenteredText(canvas, w, line, startY + i * 38f, paint);
        }
    }
}
