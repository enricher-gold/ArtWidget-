package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.BroadcastReceiver.PendingResult;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        updateWidgets(context, appWidgetManager, appWidgetIds);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager, int appWidgetId, Bundle newOptions) {
        super.onAppWidgetOptionsChanged(context, appWidgetManager, appWidgetId, newOptions);
        updateWidget(context, appWidgetManager, appWidgetId);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent == null || intent.getAction() == null) return;

        String action = intent.getAction();
        if (ACTION_SCHEDULED_UPDATE.equals(action) || ACTION_WIDGET_NEXT.equals(action)) {
            updateNextAsync(context);
        } else if (ACTION_WIDGET_PREVIOUS.equals(action)) {
            previousAsync(context);
        }
    }

    private void updateNextAsync(Context context) {
        final PendingResult pendingResult = goAsync();
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(context);
                repo.fetchNextArtwork();
                updateAllWidgets(context);
            } catch (Exception e) {
                updateAllWidgets(context);
            } finally {
                ArtScheduler.scheduleNext(context);
                pendingResult.finish();
                executor.shutdown();
            }
        });
    }

    private void previousAsync(Context context) {
        final PendingResult pendingResult = goAsync();
        ExecutorService executor = Executors.newSingleThreadExecutor();
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(context);
                repo.goPrevious();
                updateAllWidgets(context);
            } catch (Exception e) {
                updateAllWidgets(context);
            } finally {
                pendingResult.finish();
                executor.shutdown();
            }
        });
    }

    public static void updateAllWidgets(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
        ComponentName componentName = new ComponentName(context.getApplicationContext(), ArtWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(componentName);
        updateWidgets(context, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bundle options = manager.getAppWidgetOptions(id);
        int width = Math.max(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250), options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 250));
        int height = Math.max(options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 250), options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 250));
        Bitmap bitmap = ArtRenderer.render(context, entry, width, height);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);
        views.setOnClickPendingIntent(R.id.widget_left_tap_zone, broadcastPendingIntent(context, ACTION_WIDGET_PREVIOUS, 14001));
        views.setOnClickPendingIntent(R.id.widget_right_tap_zone, broadcastPendingIntent(context, ACTION_WIDGET_NEXT, 14002));
        manager.updateAppWidget(id, views);
    }

    @SuppressWarnings("unused")
    public static void updateAllWidgetsWithBitmap(Context context, Bitmap bitmap) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
        ComponentName componentName = new ComponentName(context.getApplicationContext(), ArtWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(componentName);
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
            views.setImageViewBitmap(R.id.widget_image, bitmap);
            views.setOnClickPendingIntent(R.id.widget_left_tap_zone, broadcastPendingIntent(context, ACTION_WIDGET_PREVIOUS, 14001));
            views.setOnClickPendingIntent(R.id.widget_right_tap_zone, broadcastPendingIntent(context, ACTION_WIDGET_NEXT, 14002));
            manager.updateAppWidget(id, views);
        }
    }

    private static PendingIntent broadcastPendingIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, ArtWidgetProvider.class);
        intent.setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }
}
