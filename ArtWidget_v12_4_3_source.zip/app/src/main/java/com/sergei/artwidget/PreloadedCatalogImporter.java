package com.sergei.artwidget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Читает встроенные каталоги непосредственно из assets.
 *
 * Каталог является неизменяемым резервным источником и не требует импорта в
 * SQLite. Записи могут уже содержать точную статью/изображение либо быть
 * подготовленными кандидатами, которые разрешаются через Wikipedia.org только
 * в момент загрузки новой картины.
 */
public final class PreloadedCatalogImporter {
    public static final String FILTER_ASSET = "filter_catalog.json";
    public static final String NSFW_ASSET = "nsfw_catalog.json";
    public static final int EXPECTED_PER_CATALOG = 1000;

    private static final Object LOCK = new Object();
    private static volatile List<ArtEntry> filterCache;
    private static volatile List<ArtEntry> nsfwCache;

    private PreloadedCatalogImporter() { }

    public static List<ArtEntry> loadAll(Context context) throws Exception {
        List<ArtEntry> out = new ArrayList<>(EXPECTED_PER_CATALOG * 2);
        out.addAll(load(context, FILTER_ASSET, false));
        out.addAll(load(context, NSFW_ASSET, true));
        return out;
    }

    public static List<ArtEntry> load(Context context, String assetName, boolean explicit) throws Exception {
        List<ArtEntry> cached = explicit ? nsfwCache : filterCache;
        if (cached != null) return new ArrayList<>(cached);
        synchronized (LOCK) {
            cached = explicit ? nsfwCache : filterCache;
            if (cached == null) {
                cached = Collections.unmodifiableList(readCatalog(context, assetName, explicit));
                if (explicit) nsfwCache = cached;
                else filterCache = cached;
            }
        }
        return new ArrayList<>(cached);
    }

    public static int count(Context context, boolean explicit) {
        try {
            return load(context, explicit ? NSFW_ASSET : FILTER_ASSET, explicit).size();
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static List<ArtEntry> readCatalog(Context context, String assetName, boolean explicit) throws Exception {
        String text = readAsset(context, assetName);
        JSONObject root = new JSONObject(text);
        JSONArray items = root.optJSONArray("items");
        if (items == null || items.length() == 0) {
            throw new IllegalStateException(assetName + ": каталог пуст");
        }

        List<ArtEntry> out = new ArrayList<>(items.length());
        long now = System.currentTimeMillis();
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;

            String qid = item.optString("qid", "").trim();
            String stableId = item.optString("stable_id", "").trim();
            String title = item.optString("title", "Без названия").trim();
            String artist = item.optString("artist", "Автор неизвестен").trim();
            String sourceUrl = item.optString("source_page_url", "").trim();
            String imageUrl = item.isNull("image_url") ? "" : item.optString("image_url", "").trim();
            String originalImageUrl = item.optString("original_image_url", imageUrl).trim();
            String description = item.optString("description_ru",
                    item.optString("description", "")).trim();
            String tags = joinTags(item.optJSONArray("tags"));
            String style = item.optString("style", "").trim();
            String marker = explicit ? "bundled-nsfw" : "bundled-filter";
            String genre = tags.isEmpty() ? marker : marker + ", " + tags;
            if (!style.isEmpty()) genre += ", " + style;

            if (qid.isEmpty()) qid = stableId;
            if (qid.isEmpty()) {
                qid = "asset:" + Integer.toHexString((artist + "|" + title + "|" + i).hashCode());
            }

            out.add(new ArtEntry(
                    qid,
                    title.isEmpty() ? "Без названия" : title,
                    artist.isEmpty() ? "Автор неизвестен" : artist,
                    description,
                    imageUrl,
                    originalImageUrl.isEmpty() ? imageUrl : originalImageUrl,
                    "",
                    sourceUrl,
                    "painting",
                    "",
                    genre,
                    now,
                    0,
                    0,
                    explicit
            ));
        }
        if (out.isEmpty()) throw new IllegalStateException(assetName + ": нет пригодных записей");
        return out;
    }

    private static String joinTags(JSONArray tags) {
        if (tags == null || tags.length() == 0) return "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < tags.length(); i++) {
            String value = tags.optString(i, "").trim();
            if (value.isEmpty()) continue;
            if (sb.length() > 0) sb.append(", ");
            sb.append(value);
        }
        return sb.toString();
    }

    private static String readAsset(Context context, String name) throws Exception {
        StringBuilder sb = new StringBuilder(1_500_000);
        try (InputStream input = context.getAssets().open(name);
             BufferedReader reader = new BufferedReader(new InputStreamReader(input, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int read;
            while ((read = reader.read(buffer)) >= 0) sb.append(buffer, 0, read);
        }
        return sb.toString();
    }
}
