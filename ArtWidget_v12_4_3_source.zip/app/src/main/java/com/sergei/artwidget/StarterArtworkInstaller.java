package com.sergei.artwidget;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Устанавливает небольшой набор готовых картин из APK в постоянный кэш.
 *
 * Эти файлы позволяют приложению показать и переключить произведение сразу
 * после установки, без сети, SQLite и подготовки основного каталога.
 */
public final class StarterArtworkInstaller {
    private static final String CATALOG_ASSET = "starter_catalog.json";
    private static final Object LOCK = new Object();
    private static volatile List<StarterRecord> recordsCache;

    private StarterArtworkInstaller() { }

    public static List<ArtEntry> install(Context context) throws Exception {
        Context appContext = context.getApplicationContext();
        synchronized (LOCK) {
            List<StarterRecord> records = loadRecords(appContext);
            File cacheDir = new File(appContext.getFilesDir(), "art_cache");
            if (!cacheDir.exists() && !cacheDir.mkdirs()) {
                throw new IllegalStateException("Не удалось создать папку стартового кэша");
            }

            List<ArtEntry> installed = new ArrayList<>(records.size());
            long now = System.currentTimeMillis();
            for (StarterRecord record : records) {
                String extension = extensionOf(record.assetPath);
                File destination = new File(cacheDir,
                        "starter_" + safeFileName(record.qid) + extension);
                copyAssetIfNeeded(appContext, record.assetPath, destination);
                installed.add(new ArtEntry(
                        record.qid,
                        record.title,
                        record.artist,
                        record.description,
                        record.imageUrl,
                        record.imageUrl,
                        destination.getAbsolutePath(),
                        record.sourceUrl,
                        "painting",
                        "",
                        record.explicit ? "starter-nsfw" : "starter-filter",
                        now,
                        0L,
                        0,
                        record.explicit
                ));
            }
            return installed;
        }
    }

    public static int count(Context context, boolean explicit) {
        try {
            int count = 0;
            for (StarterRecord record : loadRecords(context.getApplicationContext())) {
                if (record.explicit == explicit) count++;
            }
            return count;
        } catch (Exception ignored) {
            return 0;
        }
    }

    private static List<StarterRecord> loadRecords(Context context) throws Exception {
        List<StarterRecord> cached = recordsCache;
        if (cached != null) return cached;

        StringBuilder text = new StringBuilder(32_000);
        try (InputStream input = context.getAssets().open(CATALOG_ASSET);
             BufferedReader reader = new BufferedReader(
                     new InputStreamReader(input, StandardCharsets.UTF_8))) {
            char[] buffer = new char[4096];
            int read;
            while ((read = reader.read(buffer)) >= 0) text.append(buffer, 0, read);
        }

        JSONArray items = new JSONObject(text.toString()).optJSONArray("items");
        if (items == null || items.length() == 0) {
            throw new IllegalStateException("Стартовый каталог пуст");
        }

        List<StarterRecord> records = new ArrayList<>(items.length());
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.optJSONObject(i);
            if (item == null) continue;
            StarterRecord record = new StarterRecord(
                    item.optString("qid", "starter:" + i).trim(),
                    item.optString("title", "Без названия").trim(),
                    item.optString("artist", "Автор неизвестен").trim(),
                    item.optString("description", "").trim(),
                    item.optString("source_page_url", "").trim(),
                    item.optString("image_url", "").trim(),
                    item.optString("asset_path", "").trim(),
                    item.optBoolean("explicit_content", false)
            );
            if (record.assetPath.isEmpty()) continue;
            records.add(record);
        }
        if (records.isEmpty()) throw new IllegalStateException("Нет стартовых изображений");
        recordsCache = Collections.unmodifiableList(records);
        return recordsCache;
    }

    private static void copyAssetIfNeeded(Context context, String assetPath, File destination)
            throws Exception {
        if (destination.isFile() && destination.length() > 0) return;

        File temp = new File(destination.getParentFile(), destination.getName() + ".tmp");
        if (temp.exists() && !temp.delete()) {
            throw new IllegalStateException("Не удалось очистить временный файл");
        }

        try (InputStream raw = context.getAssets().open(assetPath);
             BufferedInputStream input = new BufferedInputStream(raw, 32 * 1024);
             BufferedOutputStream output = new BufferedOutputStream(
                     new FileOutputStream(temp), 32 * 1024)) {
            byte[] buffer = new byte[32 * 1024];
            int read;
            while ((read = input.read(buffer)) >= 0) output.write(buffer, 0, read);
            output.flush();
        }

        if (!temp.isFile() || temp.length() == 0) {
            temp.delete();
            throw new IllegalStateException("Пустое стартовое изображение: " + assetPath);
        }
        if (destination.exists() && !destination.delete()) {
            temp.delete();
            throw new IllegalStateException("Не удалось заменить стартовое изображение");
        }
        if (!temp.renameTo(destination)) {
            temp.delete();
            throw new IllegalStateException("Не удалось установить стартовое изображение");
        }
    }

    private static String safeFileName(String value) {
        String safe = value == null ? "" : value.replaceAll("[^A-Za-z0-9._-]", "_");
        return safe.isEmpty() ? "art" : safe;
    }

    private static String extensionOf(String assetPath) {
        int dot = assetPath == null ? -1 : assetPath.lastIndexOf('.');
        if (dot < 0 || dot < assetPath.lastIndexOf('/')) return ".img";
        String extension = assetPath.substring(dot).toLowerCase();
        return extension.length() <= 6 ? extension : ".img";
    }

    private static final class StarterRecord {
        final String qid;
        final String title;
        final String artist;
        final String description;
        final String sourceUrl;
        final String imageUrl;
        final String assetPath;
        final boolean explicit;

        StarterRecord(String qid, String title, String artist, String description,
                      String sourceUrl, String imageUrl, String assetPath, boolean explicit) {
            this.qid = qid;
            this.title = title;
            this.artist = artist;
            this.description = description;
            this.sourceUrl = sourceUrl;
            this.imageUrl = imageUrl;
            this.assetPath = assetPath;
            this.explicit = explicit;
        }
    }
}
