package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Фоново добавляет в кэш одно или несколько произведений, не меняя текущую картину. */
public class CatalogUpdateWorker extends Worker {
    public static final String KEY_COUNT = "count";
    public static final String KEY_MANUAL = "manual";

    public CatalogUpdateWorker(@NonNull Context context,
                               @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        ArtRepository repo = new ArtRepository(getApplicationContext());
        int requested = Math.max(1, Math.min(50, getInputData().getInt(KEY_COUNT, 1)));
        boolean manual = getInputData().getBoolean(KEY_MANUAL, false);
        int added = 0;
        try {
            repo.initializeStorageInBackground();
            if (manual && !repo.isDownloadNetworkAllowed()) {
                repo.setManualPrefetchStatus(repo.isWifiOnly()
                        ? "Ожидание подключения к Wi-Fi"
                        : "Ожидание подключения к интернету");
                return Result.retry();
            }
            if (manual) repo.setManualPrefetchStatus("Выполняется: добавлено 0 из " + requested);
            int previousCount = repo.getCacheCount();
            for (int i = 0; i < requested && !isStopped(); i++) {
                boolean loaded = repo.prefetchOneArtwork();
                int currentCount = repo.getCacheCount();
                if (currentCount > previousCount) added += currentCount - previousCount;
                previousCount = currentCount;
                if (manual) repo.setManualPrefetchStatus("Выполняется: добавлено " + added + " из " + requested);
                if (!loaded || currentCount >= ArtRepository.MAX_CACHE_FILES) break;
            }
            if (manual) {
                String result = added > 0
                        ? "Последнее пополнение: добавлено " + added + " картин"
                        : "Последнее пополнение не добавило новых картин";
                repo.setManualPrefetchStatus(result);
            }
            AppLogger.log(getApplicationContext(), "cache-prefetch", "ok",
                    "requested=" + requested + ", added=" + added + ", manual=" + manual);
            return Result.success();
        } catch (Exception e) {
            if (manual) repo.setManualPrefetchStatus(added > 0
                    ? "Загрузка остановлена после " + added + " картин"
                    : "Не удалось пополнить кэш");
            // Ошибка фоновой загрузки не должна запускать бесконечные повторы
            // и никак не влияет на показ уже встроенных изображений.
            AppLogger.log(getApplicationContext(), "cache-prefetch", "error", e.getMessage());
            return Result.success();
        }
    }
}
