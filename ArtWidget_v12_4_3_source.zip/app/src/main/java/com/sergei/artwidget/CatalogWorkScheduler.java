package com.sergei.artwidget;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Constraints;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Проверяет assets и отдельно пополняет кэш, не блокируя интерфейс. */
public final class CatalogWorkScheduler {
    public static final int REFILL_THRESHOLD = 500;
    public static final int TARGET_REMAINING = 1000;

    private static final String WORK_BOOTSTRAP = "art_catalog_bootstrap_v12_4";
    private static final String WORK_PREFETCH = "art_cache_prefetch_v12_4";
    private static final String WORK_MANUAL_PREFETCH = "art_manual_cache_prefetch_v12_4";

    private CatalogWorkScheduler() { }

    public static void ensureInitialized(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.KEEP, request);
    }

    public static void requestManualRefresh(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.REPLACE, request);
    }

    public static void schedulePrefetch(Context context) {
        Constraints constraints = networkConstraints(context);
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogUpdateWorker.class)
                .setConstraints(constraints)
                .setInputData(new Data.Builder()
                        .putInt(CatalogUpdateWorker.KEY_COUNT, 1)
                        .putBoolean(CatalogUpdateWorker.KEY_MANUAL, false)
                        .build())
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_PREFETCH, ExistingWorkPolicy.KEEP, request);
    }

    public static void requestManualPrefetch(Context context, int count) {
        int safeCount = Math.max(1, Math.min(50, count));
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogUpdateWorker.class)
                .setConstraints(networkConstraints(context))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .setInputData(new Data.Builder()
                        .putInt(CatalogUpdateWorker.KEY_COUNT, safeCount)
                        .putBoolean(CatalogUpdateWorker.KEY_MANUAL, true)
                        .build())
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_MANUAL_PREFETCH, ExistingWorkPolicy.KEEP, request);
    }

    private static Constraints networkConstraints(Context context) {
        return new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.CONNECTED)
                .build();
    }

    public static void scheduleRefill(Context context, int mode) {
        schedulePrefetch(context);
    }

    public static void scheduleBothIfNeeded(Context context) {
        ensureInitialized(context);
        schedulePrefetch(context);
    }
}
