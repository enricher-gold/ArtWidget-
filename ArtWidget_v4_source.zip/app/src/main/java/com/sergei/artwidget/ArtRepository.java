package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Random;

public class ArtRepository {
    private static final String PREFS = "art_widget_prefs";
    private static final String KEY_HISTORY = "history";
    private static final String KEY_INDEX = "history_index";
    private static final int MAX_HISTORY = 20;
    private static final int MAX_ATTEMPTS = 28;
    private static final String USER_AGENT = "ArtWidget/4.0 Android; Russian Wikipedia artwork widget";
    private static final Object LOCK = new Object();

    private final Context context;
    private final SharedPreferences prefs;
    private final Random random = new Random();

    public ArtRepository(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public ArtEntry getCurrent() {
        synchronized (LOCK) {
            try {
                JSONArray history = getHistoryArray();
                int index = prefs.getInt(KEY_INDEX, -1);
                if (index < 0 || index >= history.length()) return null;
                ArtEntry entry = ArtEntry.fromJson(history.getJSONObject(index));
                if (entry.localPath == null || entry.localPath.isEmpty()) return null;
                File f = new File(entry.localPath);
                if (!f.exists() || f.length() == 0) return null;
                return entry;
            } catch (Exception e) {
                return null;
            }
        }
    }

    public ArtEntry goPrevious() throws JSONException {
        synchronized (LOCK) {
            JSONArray history = getHistoryArray();
            int index = prefs.getInt(KEY_INDEX, -1);
            if (history.length() == 0 || index <= 0) {
                return getCurrent();
            }
            index--;
            prefs.edit().putInt(KEY_INDEX, index).apply();
            return ArtEntry.fromJson(history.getJSONObject(index));
        }
    }

    public ArtEntry fetchNextArtwork() throws IOException, JSONException {
        synchronized (LOCK) {
            if (!hasNetwork()) {
                ArtEntry current = getCurrent();
                if (current != null) return current;
                throw new IOException("Нет интернета и нет сохранённой картины в кэше.");
            }

            Exception lastError = null;
            for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
                try {
                    Seed seed = pickSeed();
                    ArtEntry entry = downloadFromRussianWikipedia(seed);
                    appendToHistory(entry);
                    return entry;
                } catch (Exception e) {
                    lastError = e;
                }
            }

            if (lastError instanceof IOException) throw (IOException) lastError;
            if (lastError instanceof JSONException) throw (JSONException) lastError;
            throw new IOException("Не удалось загрузить картину из русской Википедии.");
        }
    }

    public int getCacheCount() {
        synchronized (LOCK) {
            try {
                return getHistoryArray().length();
            } catch (Exception e) {
                return 0;
            }
        }
    }

    public void clearCache() {
        synchronized (LOCK) {
            try {
                JSONArray history = getHistoryArray();
                for (int i = 0; i < history.length(); i++) {
                    JSONObject item = history.optJSONObject(i);
                    if (item != null) deleteFileQuietly(item.optString("localPath", ""));
                }
            } catch (Exception ignored) {
            }
            prefs.edit().putString(KEY_HISTORY, "[]").putInt(KEY_INDEX, -1).apply();
            File cacheDir = new File(context.getFilesDir(), "art_cache");
            File[] files = cacheDir.listFiles();
            if (files != null) {
                for (File f : files) {
                    try {
                        //noinspection ResultOfMethodCallIgnored
                        f.delete();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    private ArtEntry downloadFromRussianWikipedia(Seed seed) throws IOException, JSONException {
        String apiUrl = "https://ru.wikipedia.org/w/api.php?action=query"
                + "&format=json"
                + "&formatversion=2"
                + "&redirects=1"
                + "&prop=extracts%7Cpageimages"
                + "&exintro=1"
                + "&explaintext=1"
                + "&piprop=thumbnail%7Coriginal"
                + "&pithumbsize=1200"
                + "&titles=" + urlEncode(seed.pageTitle);

        JSONObject json = readJson(apiUrl);
        JSONObject query = json.optJSONObject("query");
        if (query == null) throw new IOException("Русская Википедия вернула пустой ответ.");
        JSONArray pages = query.optJSONArray("pages");
        if (pages == null || pages.length() == 0) throw new IOException("Страница картины не найдена: " + seed.pageTitle);

        JSONObject page = pages.optJSONObject(0);
        if (page == null || page.optBoolean("missing", false)) {
            throw new IOException("Страница картины не найдена: " + seed.pageTitle);
        }

        String imageUrl = "";
        JSONObject thumbnail = page.optJSONObject("thumbnail");
        if (thumbnail != null) imageUrl = thumbnail.optString("source", "");
        if (imageUrl.isEmpty()) {
            JSONObject original = page.optJSONObject("original");
            if (original != null) imageUrl = original.optString("source", "");
        }
        if (imageUrl.isEmpty()) throw new IOException("У страницы нет изображения: " + seed.pageTitle);
        if (imageUrl.toLowerCase().endsWith(".svg")) throw new IOException("SVG пропущен: " + seed.pageTitle);

        File outFile = prepareOutputFile("ruwiki");
        downloadFile(imageUrl, outFile);
        verifyBitmap(outFile);

        String description = page.optString("extract", "");
        if (description == null || description.trim().isEmpty()) description = seed.descriptionRu;
        description = description.replace('\n', ' ').replace('\r', ' ').trim();
        if (description.length() > 1200) description = description.substring(0, 1200).trim() + "…";

        String finalPageTitle = page.optString("title", seed.pageTitle);
        String sourceUrl = "https://ru.wikipedia.org/wiki/" + encodePath(finalPageTitle.replace(' ', '_'));
        int id = page.optInt("pageid", seed.pageTitle.hashCode());

        return new ArtEntry(
                id,
                seed.titleRu,
                seed.artistRu,
                seed.titleOriginal,
                seed.artistOriginal,
                description,
                seed.pageTitle,
                imageUrl,
                outFile.getAbsolutePath(),
                sourceUrl,
                seed.date,
                "Русская Википедия"
        );
    }

    private Seed pickSeed() throws JSONException {
        boolean avoidDuplicates = getHistoryArray().length() < SEEDS.length;
        Seed fallback = SEEDS[random.nextInt(SEEDS.length)];
        for (int i = 0; i < 40; i++) {
            Seed seed = SEEDS[random.nextInt(SEEDS.length)];
            fallback = seed;
            if (!avoidDuplicates || !historyContainsImage(seed.pageTitle)) return seed;
        }
        return fallback;
    }

    private File prepareOutputFile(String prefix) throws IOException {
        File cacheDir = new File(context.getFilesDir(), "art_cache");
        if (!cacheDir.exists() && !cacheDir.mkdirs()) {
            throw new IOException("Не удалось создать папку кэша.");
        }
        return new File(cacheDir, prefix + "_" + System.currentTimeMillis() + "_" + Math.abs(random.nextInt()) + ".jpg");
    }

    private void verifyBitmap(File outFile) throws IOException {
        if (outFile == null || !outFile.exists() || outFile.length() == 0) {
            deleteFileQuietly(outFile == null ? "" : outFile.getAbsolutePath());
            throw new IOException("Загруженный файл не распознан как изображение.");
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(outFile.getAbsolutePath(), options);
        if (options.outWidth <= 0 || options.outHeight <= 0) {
            deleteFileQuietly(outFile.getAbsolutePath());
            throw new IOException("Загруженный файл не распознан как изображение.");
        }
    }

    private boolean historyContainsImage(String imageId) throws JSONException {
        JSONArray history = getHistoryArray();
        for (int i = 0; i < history.length(); i++) {
            JSONObject item = history.optJSONObject(i);
            if (item != null && imageId.equals(item.optString("imageId", ""))) return true;
        }
        return false;
    }

    private JSONObject readJson(String urlString) throws IOException, JSONException {
        return new JSONObject(readText(urlString));
    }

    private String readText(String urlString) throws IOException {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(12000);
            int code = conn.getResponseCode();
            InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            if (input == null) throw new IOException("HTTP " + code);
            byte[] bytes = readAll(input);
            if (code < 200 || code >= 300) {
                throw new IOException("HTTP " + code + ": " + new String(bytes));
            }
            return new String(bytes, "UTF-8");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private byte[] readAll(InputStream input) throws IOException {
        try (BufferedInputStream in = new BufferedInputStream(input);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return out.toByteArray();
        }
    }

    private void downloadFile(String urlString, File outFile) throws IOException {
        HttpURLConnection conn = null;
        File tmp = new File(outFile.getAbsolutePath() + ".tmp");
        deleteFileQuietly(tmp.getAbsolutePath());
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(16000);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке изображения");
            String type = conn.getContentType();
            if (type != null && !type.toLowerCase().startsWith("image/")) {
                throw new IOException("Сайт вернул не изображение: " + type);
            }
            try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(tmp))) {
                byte[] buffer = new byte[16384];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
            }
            if (!tmp.renameTo(outFile)) {
                throw new IOException("Не удалось сохранить файл кэша.");
            }
        } finally {
            if (conn != null) conn.disconnect();
            deleteFileQuietly(tmp.getAbsolutePath());
        }
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private JSONArray getHistoryArray() throws JSONException {
        return new JSONArray(prefs.getString(KEY_HISTORY, "[]"));
    }

    private void appendToHistory(ArtEntry entry) throws JSONException {
        JSONArray history = getHistoryArray();
        int index = prefs.getInt(KEY_INDEX, history.length() - 1);

        while (history.length() > index + 1 && history.length() > 0) {
            JSONObject removed = history.getJSONObject(history.length() - 1);
            deleteFileQuietly(removed.optString("localPath", ""));
            history.remove(history.length() - 1);
        }

        history.put(entry.toJson());
        while (history.length() > MAX_HISTORY) {
            JSONObject removed = history.getJSONObject(0);
            deleteFileQuietly(removed.optString("localPath", ""));
            history.remove(0);
        }

        prefs.edit()
                .putString(KEY_HISTORY, history.toString())
                .putInt(KEY_INDEX, history.length() - 1)
                .apply();
    }

    private void deleteFileQuietly(String path) {
        try {
            if (path != null && !path.isEmpty()) {
                //noinspection ResultOfMethodCallIgnored
                new File(path).delete();
            }
        } catch (Exception ignored) {
        }
    }

    private static String urlEncode(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8");
    }

    private static String encodePath(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
    }

    private static class Seed {
        final String pageTitle;
        final String titleRu;
        final String artistRu;
        final String titleOriginal;
        final String artistOriginal;
        final String date;
        final String descriptionRu;

        Seed(String pageTitle, String titleRu, String artistRu, String titleOriginal, String artistOriginal, String date, String descriptionRu) {
            this.pageTitle = pageTitle;
            this.titleRu = titleRu;
            this.artistRu = artistRu;
            this.titleOriginal = titleOriginal;
            this.artistOriginal = artistOriginal;
            this.date = date;
            this.descriptionRu = descriptionRu;
        }
    }

    private static final Seed[] SEEDS = new Seed[]{
            new Seed("Мона Лиза", "Мона Лиза", "Леонардо да Винчи", "Mona Lisa", "Leonardo da Vinci", "ок. 1503–1519", "Портрет Лизы Герардини, один из самых узнаваемых образов европейского Возрождения."),
            new Seed("Тайная вечеря (Леонардо да Винчи)", "Тайная вечеря", "Леонардо да Винчи", "The Last Supper", "Leonardo da Vinci", "1490-е", "Фреска Леонардо показывает драматический момент последней трапезы Христа с апостолами."),
            new Seed("Сотворение Адама", "Сотворение Адама", "Микеланджело", "The Creation of Adam", "Michelangelo", "ок. 1511", "Фрагмент росписи потолка Сикстинской капеллы с образом сотворения человека."),
            new Seed("Рождение Венеры", "Рождение Венеры", "Сандро Боттичелли", "The Birth of Venus", "Sandro Botticelli", "ок. 1485", "Один из главных образов итальянского Возрождения, основанный на античном мифе."),
            new Seed("Девушка с жемчужной серёжкой", "Девушка с жемчужной серёжкой", "Ян Вермеер", "Girl with a Pearl Earring", "Johannes Vermeer", "ок. 1665", "Портрет-трони с мягким светом и прямым взглядом модели."),
            new Seed("Ночной дозор", "Ночной дозор", "Рембрандт", "The Night Watch", "Rembrandt", "1642", "Групповой портрет амстердамской стрелковой роты, построенный как динамичная сцена."),
            new Seed("Менины", "Менины", "Диего Веласкес", "Las Meninas", "Diego Velázquez", "1656", "Сложная придворная композиция, где художник играет со взглядом зрителя и зеркальным отражением."),
            new Seed("Плот «Медузы»", "Плот «Медузы»", "Теодор Жерико", "The Raft of the Medusa", "Théodore Géricault", "1818–1819", "Монументальная картина о катастрофе фрегата «Медуза» и борьбе людей за спасение."),
            new Seed("Свобода, ведущая народ", "Свобода, ведущая народ", "Эжен Делакруа", "Liberty Leading the People", "Eugène Delacroix", "1830", "Аллегорический образ революции, где фигура Свободы ведёт людей через баррикады."),
            new Seed("Большая волна в Канагаве", "Большая волна в Канагаве", "Кацусика Хокусай", "The Great Wave off Kanagawa", "Katsushika Hokusai", "ок. 1831", "Гравюра из серии видов Фудзи, где волна становится почти самостоятельным героем композиции."),
            new Seed("Впечатление. Восходящее солнце", "Впечатление. Восходящее солнце", "Клод Моне", "Impression, Sunrise", "Claude Monet", "1872", "От названия этой картины произошло слово «импрессионизм»."),
            new Seed("Завтрак на траве", "Завтрак на траве", "Эдуар Мане", "Le Déjeuner sur l'herbe", "Édouard Manet", "1863", "Картина Мане вызвала скандал и стала важным поворотом к современному искусству."),
            new Seed("Олимпия (картина)", "Олимпия", "Эдуар Мане", "Olympia", "Édouard Manet", "1863", "Мане переосмыслил традиционный образ Венеры в современном парижском контексте."),
            new Seed("Звёздная ночь", "Звёздная ночь", "Винсент ван Гог", "The Starry Night", "Vincent van Gogh", "1889", "Ночное небо у Ван Гога превращено в вихревое движение света и цвета."),
            new Seed("Звёздная ночь над Роной", "Звёздная ночь над Роной", "Винсент ван Гог", "Starry Night Over the Rhône", "Vincent van Gogh", "1888", "Ночной вид Арля с отражением газовых фонарей в воде Роны."),
            new Seed("Подсолнухи (серия картин)", "Подсолнухи", "Винсент ван Гог", "Sunflowers", "Vincent van Gogh", "1887–1889", "Серия картин Ван Гога с подсолнухами, ставшая одним из символов художника."),
            new Seed("Ирисы (картина Ван Гога)", "Ирисы", "Винсент ван Гог", "Irises", "Vincent van Gogh", "1889", "Картина написана Ван Гогом в лечебнице Сен-Реми."),
            new Seed("Крик (картина)", "Крик", "Эдвард Мунк", "The Scream", "Edvard Munch", "1893", "Образ тревоги, где фигура и пейзаж сливаются в одно эмоциональное состояние."),
            new Seed("Поцелуй (картина Климта)", "Поцелуй", "Густав Климт", "The Kiss", "Gustav Klimt", "1908–1909", "Ключевое произведение золотого периода Климта."),
            new Seed("Американская готика", "Американская готика", "Грант Вуд", "American Gothic", "Grant Wood", "1930", "Один из самых узнаваемых образов американского искусства XX века."),
            new Seed("Девятый вал", "Девятый вал", "Иван Айвазовский", "The Ninth Wave", "Ivan Aivazovsky", "1850", "Морская катастрофа у Айвазовского соединена с рассветным светом и надеждой."),
            new Seed("Бурлаки на Волге", "Бурлаки на Волге", "Илья Репин", "Barge Haulers on the Volga", "Ilya Repin", "1870–1873", "Репин показывает тяжёлый труд бурлаков как сильный социальный и психологический образ."),
            new Seed("Запорожцы (картина)", "Запорожцы", "Илья Репин", "Reply of the Zaporozhian Cossacks", "Ilya Repin", "1880–1891", "Многофигурная сцена с яркими характерами и энергией коллективного действия."),
            new Seed("Иван Грозный и сын его Иван 16 ноября 1581 года", "Иван Грозный и сын его Иван", "Илья Репин", "Ivan the Terrible and His Son Ivan", "Ilya Repin", "1885", "Трагический исторический образ ужаса и запоздалого раскаяния."),
            new Seed("Богатыри (картина)", "Богатыри", "Виктор Васнецов", "Bogatyrs", "Viktor Vasnetsov", "1881–1898", "Три героя русского былинного эпоса представлены как защитники земли."),
            new Seed("Утро в сосновом лесу", "Утро в сосновом лесу", "Иван Шишкин", "Morning in a Pine Forest", "Ivan Shishkin", "1889", "Один из самых известных русских лесных пейзажей."),
            new Seed("Грачи прилетели", "Грачи прилетели", "Алексей Саврасов", "The Rooks Have Come Back", "Alexei Savrasov", "1871", "Тихий весенний мотив стал образом обновления природы."),
            new Seed("Девочка с персиками", "Девочка с персиками", "Валентин Серов", "Girl with Peaches", "Valentin Serov", "1887", "Светлый портрет Веры Мамонтовой с ощущением живого мгновения."),
            new Seed("Царевна-Лебедь", "Царевна-Лебедь", "Михаил Врубель", "The Swan Princess", "Mikhail Vrubel", "1900", "Сказочный образ на границе человека и птицы."),
            new Seed("Последний день Помпеи", "Последний день Помпеи", "Карл Брюллов", "The Last Day of Pompeii", "Karl Bryullov", "1830–1833", "Монументальная историческая сцена гибели города при извержении Везувия."),
            new Seed("Боярыня Морозова", "Боярыня Морозова", "Василий Суриков", "Boyarynya Morozova", "Vasily Surikov", "1884–1887", "Суриков показывает драму раскола через столкновение героини и толпы."),
            new Seed("Лунная ночь на Днепре", "Лунная ночь на Днепре", "Архип Куинджи", "Moonlit Night on the Dnieper", "Arkhip Kuindzhi", "1880", "Пейзаж построен на контрасте темноты и холодного лунного сияния."),
            new Seed("Явление Христа народу", "Явление Христа народу", "Александр Иванов", "The Appearance of Christ Before the People", "Alexander Ivanov", "1837–1857", "Большая историко-религиозная композиция, над которой Иванов работал около двадцати лет."),
            new Seed("Чёрный квадрат", "Чёрный квадрат", "Казимир Малевич", "Black Square", "Kazimir Malevich", "1915", "Один из главных символов русского авангарда и супрематизма."),
            new Seed("Неизвестная (картина Крамского)", "Неизвестная", "Иван Крамской", "Unknown Woman", "Ivan Kramskoi", "1883", "Портрет женщины в экипаже, ставший одним из самых известных образов русского искусства."),
            new Seed("Опять двойка", "Опять двойка", "Фёдор Решетников", "Low Marks Again", "Fyodor Reshetnikov", "1952", "Жанровая сцена советской школы и семейной реакции на неудачную оценку."),
            new Seed("Охотники на привале", "Охотники на привале", "Василий Перов", "Hunters at Rest", "Vasily Perov", "1871", "Жанровая сцена с рассказчиком и слушателями после охоты."),
            new Seed("Апофеоз войны", "Апофеоз войны", "Василий Верещагин", "The Apotheosis of War", "Vasily Vereshchagin", "1871", "Антивоенный образ, где пирамида черепов становится символом разрушения."),
            new Seed("Утро стрелецкой казни", "Утро стрелецкой казни", "Василий Суриков", "Morning of the Streltsy Execution", "Vasily Surikov", "1881", "Историческая сцена перед казнью стрельцов после стрелецкого бунта."),
            new Seed("Алёнушка (картина)", "Алёнушка", "Виктор Васнецов", "Alyonushka", "Viktor Vasnetsov", "1881", "Васнецов создал лирический сказочный образ одиночества и печали."),
            new Seed("Купание красного коня", "Купание красного коня", "Кузьма Петров-Водкин", "Bathing of a Red Horse", "Kuzma Petrov-Vodkin", "1912", "Яркий символический образ, связанный с русским модернизмом начала XX века.")
    };
}
