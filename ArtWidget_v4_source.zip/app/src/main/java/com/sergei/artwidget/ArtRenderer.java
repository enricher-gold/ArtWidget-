package com.sergei.artwidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;

import java.io.File;

public class ArtRenderer {
    private static final int W = 512;
    private static final int H = 512;
    private static final int PAD = 16;
    private static final int TEXT_AREA = 42;

    public static Bitmap render(Context context, ArtEntry entry) {
        Bitmap result = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);

        if (entry == null || entry.localPath == null || !new File(entry.localPath).exists()) {
            drawPlaceholder(canvas, "Откройте приложение\nи загрузите картину");
            return result;
        }

        Bitmap original = BitmapFactory.decodeFile(entry.localPath);
        if (original == null) {
            drawPlaceholder(canvas, "Кэш повреждён\nзагрузите картину заново");
            return result;
        }

        drawArtwork(canvas, original);
        original.recycle();
        drawCaption(canvas, entry.caption());
        return result;
    }

    public static Bitmap renderStatus(String text) {
        Bitmap result = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);
        drawPlaceholder(canvas, text);
        return result;
    }

    private static void drawArtwork(Canvas canvas, Bitmap original) {
        int maxW = W - PAD * 2;
        int maxH = H - TEXT_AREA - PAD * 2;
        float scale = Math.min(maxW / (float) original.getWidth(), maxH / (float) original.getHeight());
        int dstW = Math.max(1, Math.round(original.getWidth() * scale));
        int dstH = Math.max(1, Math.round(original.getHeight() * scale));
        int left = (W - dstW) / 2;
        int top = PAD + (maxH - dstH) / 2;
        Rect src = new Rect(0, 0, original.getWidth(), original.getHeight());
        RectF dst = new RectF(left, top, left + dstW, top + dstH);

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        canvas.drawBitmap(original, src, dst, paint);
    }

    private static void drawCaption(Canvas canvas, String caption) {
        TextPaint paint = baseTextPaint(15, true);
        String line = ellipsize(caption, paint, W - PAD * 2);
        drawCenteredText(canvas, line, H - 20, paint);
    }

    private static TextPaint baseTextPaint(float size, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setColor(Color.WHITE);
        p.setTextSize(size);
        p.setFakeBoldText(bold);
        p.setShadowLayer(5f, 1.5f, 1.5f, Color.BLACK);
        return p;
    }

    private static void drawCenteredText(Canvas canvas, String text, float y, TextPaint paint) {
        float x = (W - paint.measureText(text)) / 2f;
        canvas.drawText(text, x, y, paint);
    }

    private static String ellipsize(String text, Paint paint, int maxWidth) {
        if (text == null || text.trim().isEmpty()) return " ";
        text = text.replace('\n', ' ').replace('\r', ' ').trim();
        if (paint.measureText(text) <= maxWidth) return text;
        String suffix = "…";
        int end = text.length();
        while (end > 0 && paint.measureText(text.substring(0, end) + suffix) > maxWidth) {
            end--;
        }
        return end <= 0 ? suffix : text.substring(0, end).trim() + suffix;
    }

    private static void drawPlaceholder(Canvas canvas, String text) {
        TextPaint paint = baseTextPaint(21, false);
        String[] lines = text == null ? new String[]{"Art Widget"} : text.split("\\n");
        float startY = H / 2f - (lines.length - 1) * 18f;
        for (int i = 0; i < lines.length; i++) {
            String line = ellipsize(lines[i], paint, W - PAD * 2);
            drawCenteredText(canvas, line, startY + i * 38f, paint);
        }
    }
}
