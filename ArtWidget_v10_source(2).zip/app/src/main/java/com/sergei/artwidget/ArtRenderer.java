package com.sergei.artwidget;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;

import java.io.File;

public final class ArtRenderer {
    private static final int DEFAULT_W = 560;
    private static final int DEFAULT_H = 560;
    private static final int MAX_LONG_SIDE = 820;
    private static final int MIN_SIDE = 180;

    private ArtRenderer() { }

    public static Bitmap render(Context context, ArtEntry entry, int widgetWidthDp, int widgetHeightDp) {
        int[] size = canvasSize(widgetWidthDp, widgetHeightDp);
        int w = size[0];
        int h = size[1];
        Bitmap result = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);

        if (entry == null || !fileExists(entry.localPath)) {
            drawPlaceholder(canvas, w, h, "Откройте приложение\nи загрузите картину");
            return result;
        }

        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inPreferredConfig = Bitmap.Config.ARGB_8888;
        Bitmap original = BitmapFactory.decodeFile(entry.localPath, options);
        if (original == null) {
            drawPlaceholder(canvas, w, h, "Изображение недоступно");
            return result;
        }

        // Размер текста рассчитывается относительно фактического холста виджета.
        // Ранее верхний предел 25 px делал подпись заметно мельче подписей
        // приложений на рабочем столе, особенно после масштабирования Bitmap.
        float textSize = clamp(Math.min(w, h) / 16.5f, 28f, 46f);
        TextPaint captionPaint = textPaint(textSize, true);
        float captionHeight = Math.max(48f, textSize * 1.65f);
        float gap = Math.max(4f, textSize * 0.28f);
        float sidePad = Math.max(2f, w * 0.012f);
        float topPad = Math.max(1f, h * 0.006f);
        float bottomPad = Math.max(2f, h * 0.006f);

        float maxW = w - sidePad * 2f;
        float maxH = h - topPad - bottomPad - captionHeight - gap;
        if (maxH < h * 0.35f) maxH = h - topPad - bottomPad;

        float scale = Math.min(maxW / original.getWidth(), maxH / original.getHeight());
        float dstW = Math.max(1f, original.getWidth() * scale);
        float dstH = Math.max(1f, original.getHeight() * scale);
        float left = (w - dstW) / 2f;
        float top = topPad;
        RectF artwork = new RectF(left, top, left + dstW, top + dstH);
        Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
        canvas.drawBitmap(original, new Rect(0, 0, original.getWidth(), original.getHeight()), artwork, imagePaint);
        original.recycle();

        String caption = ellipsize(entry.caption(), captionPaint, w - sidePad * 2f);
        Paint.FontMetrics fm = captionPaint.getFontMetrics();
        float baseline = artwork.bottom + gap - fm.ascent;
        float maxBaseline = h - bottomPad - fm.descent;
        if (baseline > maxBaseline) baseline = maxBaseline;
        drawCentered(canvas, w, caption, baseline, captionPaint);
        return result;
    }

    public static Bitmap renderStatus(String text) {
        Bitmap result = Bitmap.createBitmap(DEFAULT_W, DEFAULT_H, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(result);
        canvas.drawColor(Color.TRANSPARENT);
        drawPlaceholder(canvas, DEFAULT_W, DEFAULT_H, text);
        return result;
    }

    private static int[] canvasSize(int widthDp, int heightDp) {
        int width = widthDp > 0 ? widthDp : DEFAULT_W;
        int height = heightDp > 0 ? heightDp : DEFAULT_H;
        float ratio = height / (float) Math.max(1, width);
        int w;
        int h;
        if (ratio >= 1f) {
            h = MAX_LONG_SIDE;
            w = Math.round(h / ratio);
        } else {
            w = MAX_LONG_SIDE;
            h = Math.round(w * ratio);
        }
        w = Math.max(MIN_SIDE, Math.min(MAX_LONG_SIDE, w));
        h = Math.max(MIN_SIDE, Math.min(MAX_LONG_SIDE, h));
        return new int[]{w, h};
    }

    private static TextPaint textPaint(float size, boolean bold) {
        TextPaint p = new TextPaint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        p.setColor(Color.WHITE);
        p.setTextSize(size);
        p.setFakeBoldText(bold);
        p.setShadowLayer(Math.max(4f, size / 4f), 1.5f, 1.5f, Color.BLACK);
        return p;
    }

    private static void drawPlaceholder(Canvas canvas, int w, int h, String text) {
        // Заглушка должна читаться так же уверенно, как подписи ярлыков лаунчера.
        // Две строки допустимы, но фиксированный мелкий размер не используется.
        float textSize = clamp(Math.min(w, h) / 16.0f, 30f, 46f);
        TextPaint p = textPaint(textSize, true);
        String[] lines = text == null ? new String[]{"Art Widget"} : text.split("\\n");
        Paint.FontMetrics fm = p.getFontMetrics();
        float lineHeight = (fm.descent - fm.ascent) * 1.25f;
        float y = h / 2f - (lines.length - 1) * lineHeight / 2f - fm.ascent / 2f;
        for (String line : lines) {
            drawCentered(canvas, w, ellipsize(line, p, w - 12f), y, p);
            y += lineHeight;
        }
    }

    private static void drawCentered(Canvas canvas, int w, String text, float baseline, Paint paint) {
        float x = (w - paint.measureText(text)) / 2f;
        canvas.drawText(text, x, baseline, paint);
    }

    private static String ellipsize(String text, Paint paint, float maxWidth) {
        String value = text == null ? "" : text.replace('\n', ' ').replace('\r', ' ').trim();
        if (value.isEmpty()) return " ";
        if (paint.measureText(value) <= maxWidth) return value;
        String suffix = "…";
        int low = 0;
        int high = value.length();
        while (low < high) {
            int mid = (low + high + 1) / 2;
            if (paint.measureText(value.substring(0, mid) + suffix) <= maxWidth) low = mid;
            else high = mid - 1;
        }
        return low <= 0 ? suffix : value.substring(0, low).trim() + suffix;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static boolean fileExists(String path) {
        if (path == null || path.trim().isEmpty()) return false;
        File f = new File(path);
        return f.exists() && f.length() > 0;
    }
}
