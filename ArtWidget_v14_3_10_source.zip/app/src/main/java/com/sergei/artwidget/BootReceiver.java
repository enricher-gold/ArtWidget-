package com.sergei.artwidget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        try {
            String action = intent.getAction();
            if (Intent.ACTION_CONFIGURATION_CHANGED.equals(action)) {
                ArtWidgetProvider.updateAllWidgets(context);
                AppLogger.log(context, "widget-size", "configuration-changed", action);
                return;
            }
            if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                    || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                    || Intent.ACTION_TIME_CHANGED.equals(action)
                    || Intent.ACTION_TIMEZONE_CHANGED.equals(action)) {
                try { ArtScheduler.restoreAfterSystemEvent(context, action); }
                catch (Throwable error) { AppLogger.log(context, "boot-scheduler", "error", String.valueOf(error)); }
                try { CatalogWorkScheduler.ensureInitialized(context); }
                catch (Throwable error) { AppLogger.log(context, "boot-catalog", "error", String.valueOf(error)); }
                try { CatalogWorkScheduler.scheduleBothIfNeeded(context); }
                catch (Throwable error) { AppLogger.log(context, "boot-catalog-schedule", "error", String.valueOf(error)); }
                ArtWidgetProvider.updateAllWidgets(context);
                AppLogger.log(context, "boot", "rescheduled", action);
            }
        } catch (Throwable error) {
            try { AppLogger.log(context, "boot", "error", String.valueOf(error)); }
            catch (Throwable ignored) { }
        }
    }
}
