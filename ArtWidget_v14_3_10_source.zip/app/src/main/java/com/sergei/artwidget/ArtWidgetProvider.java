package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.ArrayMap;
import android.util.SizeF;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";
    private static final ExecutorService RENDER_EXECUTOR = Executors.newSingleThreadExecutor();
    private static final float CAPTION_SP = 13f;

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> {
            try {
                updateWidgets(app, manager, ids);
            } catch (Throwable error) {
                logRenderFailure(app, "onUpdate", error);
            }
        });
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> safeUpdateWidget(app, manager, appWidgetId));
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    public static void performScheduledUpdate(Context context) {
        ArtScheduler.enqueueAutomaticUpdate(context, "provider");
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> {
            try {
                renderAllWidgetsNow(app);
            } catch (Throwable error) {
                logRenderFailure(app, "updateAllWidgets", error);
            }
        });
    }

    static void renderAllWidgetsNow(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) safeUpdateWidget(context, manager, id);
    }

    private static void safeUpdateWidget(Context context, AppWidgetManager manager, int id) {
        try {
            updateWidget(context, manager, id);
        } catch (Throwable error) {
            logRenderFailure(context, "id=" + id, error);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bitmap bitmap = ArtRenderer.render(context, entry);
        String caption = cleanCaption(entry == null
                ? ""
                : entry.widgetCaption(LanguageManager.getLanguage(context)));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && bitmap != null) {
            try {
                ArrayList<SizeF> sizes = exactSizes(manager, id);
                if (sizes != null && !sizes.isEmpty()) {
                    Map<SizeF, RemoteViews> mapping = new ArrayMap<>();
                    for (SizeF size : sizes) {
                        if (size == null || size.getWidth() <= 0f || size.getHeight() <= 0f) {
                            continue;
                        }
                        mapping.put(size, createExactViews(context, bitmap, caption, size, id));
                    }
                    if (!mapping.isEmpty()) {
                        manager.updateAppWidget(id, new RemoteViews(mapping));
                        AppLogger.log(context, "widget-render", "exact-size-map-caption-13sp",
                                "id=" + id + ", sizes=" + sizesToString(sizes)
                                        + ", bitmap=" + bitmap.getWidth() + "x" + bitmap.getHeight());
                        return;
                    }
                }
            } catch (Throwable exactLayoutError) {
                logRenderFailure(context, "exact-layout-id=" + id, exactLayoutError);
                // Не завершаем процесс: ниже используется безопасный legacy-layout.
            }
        }

        RemoteViews views = createLegacyViews(context, bitmap, caption, id);
        manager.updateAppWidget(id, views);
        AppLogger.log(context, "widget-render", "legacy-fit-center-caption-13sp", "id=" + id);
    }

    private static RemoteViews createExactViews(Context context, Bitmap bitmap,
                                                String caption, SizeF size, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget_exact);
        views.setImageViewBitmap(R.id.widget_image, bitmap);

        int widgetWidthDp = Math.max(1, Math.round(size.getWidth()));
        int widgetHeightDp = Math.max(1, Math.round(size.getHeight()));
        int captionHeightDp = caption.isEmpty() ? 0 : captionHeightDp(context);
        int availableHeightDp = Math.max(1, widgetHeightDp - captionHeightDp);

        float imageAspect = bitmap.getWidth() / (float) bitmap.getHeight();
        float availableAspect = widgetWidthDp / (float) availableHeightDp;
        int imageWidthDp;
        int imageHeightDp;
        if (availableAspect > imageAspect) {
            imageHeightDp = availableHeightDp;
            imageWidthDp = Math.max(1, Math.round(imageHeightDp * imageAspect));
        } else {
            imageWidthDp = widgetWidthDp;
            imageHeightDp = Math.max(1, Math.round(imageWidthDp / imageAspect));
        }

        int contentHeightDp = imageHeightDp + captionHeightDp;
        views.setViewLayoutWidth(R.id.widget_content,
                imageWidthDp, TypedValue.COMPLEX_UNIT_DIP);
        views.setViewLayoutHeight(R.id.widget_content,
                contentHeightDp, TypedValue.COMPLEX_UNIT_DIP);
        views.setViewLayoutWidth(R.id.widget_image,
                imageWidthDp, TypedValue.COMPLEX_UNIT_DIP);
        views.setViewLayoutHeight(R.id.widget_image,
                imageHeightDp, TypedValue.COMPLEX_UNIT_DIP);
        views.setViewLayoutWidth(R.id.widget_caption,
                imageWidthDp, TypedValue.COMPLEX_UNIT_DIP);
        if (!caption.isEmpty()) {
            views.setViewLayoutHeight(R.id.widget_caption,
                    captionHeightDp, TypedValue.COMPLEX_UNIT_DIP);
        }

        bindCaption(views, caption);
        views.setOnClickPendingIntent(R.id.widget_open_tap_zone,
                openAppIntent(context, 16001 + id));
        return views;
    }

    private static RemoteViews createLegacyViews(Context context, Bitmap bitmap,
                                                 String caption, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);
        bindCaption(views, caption);
        views.setOnClickPendingIntent(R.id.widget_open_tap_zone,
                openAppIntent(context, 16001 + id));
        return views;
    }

    private static void bindCaption(RemoteViews views, String caption) {
        if (caption.isEmpty()) {
            views.setViewVisibility(R.id.widget_caption, View.GONE);
            views.setTextViewText(R.id.widget_caption, "");
        } else {
            views.setViewVisibility(R.id.widget_caption, View.VISIBLE);
            views.setTextViewText(R.id.widget_caption, caption);
            views.setTextViewTextSize(R.id.widget_caption,
                    TypedValue.COMPLEX_UNIT_SP, CAPTION_SP);
        }
    }

    private static int captionHeightDp(Context context) {
        float fontScale = Math.max(1f,
                context.getResources().getConfiguration().fontScale);
        return Math.max(20, Math.round(CAPTION_SP * fontScale * 1.35f) + 4);
    }

    private static String cleanCaption(String caption) {
        return caption == null
                ? ""
                : caption.replace('\n', ' ').replace('\r', ' ').trim();
    }

    @SuppressWarnings("deprecation")
    private static ArrayList<SizeF> exactSizes(AppWidgetManager manager, int id) {
        try {
            Bundle options = manager == null ? null : manager.getAppWidgetOptions(id);
            if (options == null) return null;

            ArrayList<SizeF> sizes = options.getParcelableArrayList(
                    AppWidgetManager.OPTION_APPWIDGET_SIZES);
            if (sizes != null && !sizes.isEmpty()) return sizes;

            // Fallback for Android 12+ launchers that do not provide
            // OPTION_APPWIDGET_SIZES. Supply both orientation pairs instead of
            // pretending that maxWidth and maxHeight belong to one current size.
            int minWidth = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int maxWidth = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0);
            int minHeight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
            int maxHeight = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);

            ArrayList<SizeF> fallback = new ArrayList<>();
            if (minWidth > 0 && maxHeight > 0) {
                fallback.add(new SizeF(minWidth, maxHeight));
            }
            if (maxWidth > 0 && minHeight > 0
                    && (maxWidth != minWidth || minHeight != maxHeight)) {
                fallback.add(new SizeF(maxWidth, minHeight));
            }
            return fallback;
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static String sizesToString(ArrayList<SizeF> sizes) {
        if (sizes == null || sizes.isEmpty()) return "[]";
        StringBuilder out = new StringBuilder("[");
        for (int i = 0; i < sizes.size(); i++) {
            SizeF size = sizes.get(i);
            if (i > 0) out.append(',');
            if (size == null) out.append("null");
            else out.append(Math.round(size.getWidth()))
                    .append('x').append(Math.round(size.getHeight()));
        }
        return out.append(']').toString();
    }

    private static void logRenderFailure(Context context, String stage, Throwable error) {
        try {
            AppLogger.log(context, "widget-render", "error", stage + " | "
                    + error.getClass().getSimpleName() + ": "
                    + String.valueOf(error.getMessage()));
        } catch (Throwable ignored) { }
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
