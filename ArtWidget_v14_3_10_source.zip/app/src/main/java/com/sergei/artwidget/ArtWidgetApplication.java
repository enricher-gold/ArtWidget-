package com.sergei.artwidget;

import android.app.Application;

public class ArtWidgetApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        try {
            StartupRecovery.run(this);
        } catch (Throwable ignored) { }
    }
}
