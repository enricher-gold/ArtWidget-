package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.File;
import java.util.Map;

/** Одноразовое восстановление после резервного копирования/понижения версии. */
public final class StartupRecovery {
    private static final String MARKER = "startup_recovery_v14_3_10";

    private StartupRecovery() { }

    public static void run(Context context) {
        Context app = context.getApplicationContext();
        File marker = new File(app.getNoBackupFilesDir(), MARKER);
        if (marker.exists()) return;

        synchronized (StartupRecovery.class) {
            if (marker.exists()) return;

            // Android/Huawei может восстановить внутреннюю базу WorkManager после
            // удаления приложения. Старые незавершённые Worker'ы и схема БД могут
            // аварийно завершать процесс сразу после запуска. Задачи будут созданы
            // заново штатными планировщиками.
            try { app.deleteDatabase("androidx.work.workdb"); } catch (Throwable ignored) { }
            deleteDatabaseSidecars(app, "androidx.work.workdb");

            SharedPreferences prefs = app.getSharedPreferences(ArtRepository.PREFS, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            sanitizeType(prefs.getAll(), editor, "artwork_language_v12_4_4", String.class);
            sanitizeType(prefs.getAll(), editor, ArtScheduler.KEY_INTERVAL_SECONDS, Integer.class);
            sanitizeType(prefs.getAll(), editor, ArtScheduler.KEY_ENABLED, Boolean.class);
            sanitizeType(prefs.getAll(), editor, ArtScheduler.KEY_START_HOUR, Integer.class);
            sanitizeType(prefs.getAll(), editor, ArtScheduler.KEY_START_MINUTE, Integer.class);
            sanitizeType(prefs.getAll(), editor, ArtScheduler.KEY_ANCHOR_AT_MILLIS, Long.class);
            sanitizeType(prefs.getAll(), editor, ArtScheduler.KEY_NEXT_AT_MILLIS, Long.class);
            editor.remove(ArtScheduler.KEY_NEXT_AT_MILLIS)
                    .remove(ArtScheduler.KEY_LAST_ATTEMPT_AT)
                    .remove(ArtScheduler.KEY_LAST_RESULT)
                    .remove(ArtScheduler.KEY_LAST_ERROR)
                    .remove(ArtScheduler.KEY_LAST_REASON)
                    .apply();

            try {
                File parent = marker.getParentFile();
                if (parent != null && !parent.exists()) parent.mkdirs();
                marker.createNewFile();
            } catch (Throwable ignored) { }
        }
    }

    private static void sanitizeType(Map<String, ?> all, SharedPreferences.Editor editor,
                                     String key, Class<?> expected) {
        Object value = all.get(key);
        if (value != null && !expected.isInstance(value)) editor.remove(key);
    }

    private static void deleteDatabaseSidecars(Context app, String name) {
        try {
            File db = app.getDatabasePath(name);
            new File(db.getPath() + "-shm").delete();
            new File(db.getPath() + "-wal").delete();
            new File(db.getPath() + "-journal").delete();
        } catch (Throwable ignored) { }
    }
}
