package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;

public final class LanguageManager {
    public static final String RU = "ru";
    public static final String EN = "en";
    private static final String KEY = "artwork_language_v12_4_4";

    private LanguageManager() { }

    public static String getLanguage(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(ArtRepository.PREFS, Context.MODE_PRIVATE);
        try {
            String value = prefs.getString(KEY, RU);
            return EN.equals(value) ? EN : RU;
        } catch (ClassCastException corruptedPreference) {
            prefs.edit().remove(KEY).apply();
            return RU;
        }
    }

    public static boolean isEnglish(Context context) {
        return EN.equals(getLanguage(context));
    }

    public static void setLanguage(Context context, String language) {
        String value = EN.equals(language) ? EN : RU;
        context.getApplicationContext().getSharedPreferences(ArtRepository.PREFS, Context.MODE_PRIVATE)
                .edit().putString(KEY, value).apply();
    }
}
