package com.sergei.artwidget;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Random;

public class ArtRepository {
    private static final String PREFS = "art_widget_prefs";
    private static final String KEY_HISTORY = "history";
    private static final String KEY_INDEX = "history_index";
    private static final int MAX_HISTORY = 20;
    private static final int MAX_ATTEMPTS = 18;
    private static final String USER_AGENT = "ArtWidget/3.0 Android; Wikimedia Commons image viewer";
    private static final Object LOCK = new Object();

    private final Context context;
    private final SharedPreferences prefs;
    private final Random random = new Random();

    public ArtRepository(Context context) {
        this.context = context.getApplicationContext();
        this.prefs = this.context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public ArtEntry getCurrent() {
        synchronized (LOCK) {
            try {
                JSONArray history = getHistoryArray();
                int index = prefs.getInt(KEY_INDEX, -1);
                if (index < 0 || index >= history.length()) return null;
                ArtEntry entry = ArtEntry.fromJson(history.getJSONObject(index));
                if (entry.localPath == null || entry.localPath.isEmpty()) return null;
                File f = new File(entry.localPath);
                if (!f.exists() || f.length() == 0) return null;
                return entry;
            } catch (Exception e) {
                return null;
            }
        }
    }

    public ArtEntry goPrevious() throws JSONException {
        synchronized (LOCK) {
            JSONArray history = getHistoryArray();
            int index = prefs.getInt(KEY_INDEX, -1);
            if (history.length() == 0 || index <= 0) {
                return getCurrent();
            }
            index--;
            prefs.edit().putInt(KEY_INDEX, index).apply();
            return ArtEntry.fromJson(history.getJSONObject(index));
        }
    }

    public ArtEntry fetchNextArtwork() throws IOException, JSONException {
        synchronized (LOCK) {
            if (!hasNetwork()) {
                ArtEntry current = getCurrent();
                if (current != null) return current;
                throw new IOException("Нет интернета и нет сохранённой картины в кэше.");
            }

            Exception lastError = null;

            for (int attempt = 0; attempt < MAX_ATTEMPTS; attempt++) {
                try {
                    ArtEntry entry = downloadCuratedSeed();
                    appendToHistory(entry);
                    return entry;
                } catch (Exception e) {
                    lastError = e;
                }
            }

            for (int attempt = 0; attempt < 6; attempt++) {
                try {
                    ArtEntry entry = downloadFromCommonsCategory();
                    appendToHistory(entry);
                    return entry;
                } catch (Exception e) {
                    lastError = e;
                }
            }

            if (lastError instanceof IOException) throw (IOException) lastError;
            if (lastError instanceof JSONException) throw (JSONException) lastError;
            throw new IOException("Не удалось загрузить изображение с Wikimedia Commons.");
        }
    }

    public int getCacheCount() {
        synchronized (LOCK) {
            try {
                return getHistoryArray().length();
            } catch (Exception e) {
                return 0;
            }
        }
    }

    public void clearCache() {
        synchronized (LOCK) {
            try {
                JSONArray history = getHistoryArray();
                for (int i = 0; i < history.length(); i++) {
                    JSONObject item = history.optJSONObject(i);
                    if (item != null) deleteFileQuietly(item.optString("localPath", ""));
                }
            } catch (Exception ignored) {
            }
            prefs.edit().putString(KEY_HISTORY, "[]").putInt(KEY_INDEX, -1).apply();
            File cacheDir = new File(context.getFilesDir(), "art_cache");
            File[] files = cacheDir.listFiles();
            if (files != null) {
                for (File f : files) {
                    try {
                        //noinspection ResultOfMethodCallIgnored
                        f.delete();
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    private ArtEntry downloadCuratedSeed() throws IOException, JSONException {
        Seed seed = pickSeed();
        String imageUrl = commonsFilePathUrl(seed.fileTitle, 1100);
        String sourceUrl = commonsFilePageUrl(seed.fileTitle);
        File outFile = prepareOutputFile("commons");
        downloadFile(imageUrl, outFile);
        verifyBitmap(outFile);

        return new ArtEntry(
                seed.fileTitle.hashCode(),
                seed.titleRu,
                seed.artistRu,
                seed.titleOriginal,
                seed.artistOriginal,
                seed.descriptionRu,
                seed.fileTitle,
                imageUrl,
                outFile.getAbsolutePath(),
                sourceUrl,
                seed.date,
                "Wikimedia Commons"
        );
    }

    private Seed pickSeed() throws JSONException {
        boolean avoidDuplicates = getHistoryArray().length() < SEEDS.length;
        Seed fallback = SEEDS[random.nextInt(SEEDS.length)];
        for (int i = 0; i < 30; i++) {
            Seed seed = SEEDS[random.nextInt(SEEDS.length)];
            fallback = seed;
            if (!avoidDuplicates || !historyContainsImage(seed.fileTitle)) return seed;
        }
        return fallback;
    }

    private ArtEntry downloadFromCommonsCategory() throws IOException, JSONException {
        CategorySeed category = CATEGORIES[random.nextInt(CATEGORIES.length)];
        String apiUrl = "https://commons.wikimedia.org/w/api.php?action=query"
                + "&generator=categorymembers"
                + "&gcmtitle=" + urlEncode(category.categoryTitle)
                + "&gcmnamespace=6"
                + "&gcmtype=file"
                + "&gcmlimit=50"
                + "&prop=imageinfo"
                + "&iiprop=url%7Cmime"
                + "&iiurlwidth=1100"
                + "&format=json";
        JSONObject json = readJson(apiUrl);
        JSONObject query = json.optJSONObject("query");
        if (query == null) throw new IOException("Commons API вернул пустой ответ.");
        JSONObject pages = query.optJSONObject("pages");
        if (pages == null || pages.length() == 0) throw new IOException("В категории Commons нет файлов.");

        JSONArray keys = pages.names();
        if (keys == null || keys.length() == 0) throw new IOException("В категории Commons нет файлов.");

        for (int i = 0; i < 20; i++) {
            JSONObject page = pages.optJSONObject(keys.optString(random.nextInt(keys.length())));
            if (page == null) continue;
            String fileTitle = page.optString("title", "");
            if (fileTitle.startsWith("File:")) fileTitle = fileTitle.substring(5);
            if (fileTitle.toLowerCase().endsWith(".svg") || fileTitle.toLowerCase().endsWith(".tif") || fileTitle.toLowerCase().endsWith(".tiff")) {
                continue;
            }
            JSONArray imageInfo = page.optJSONArray("imageinfo");
            if (imageInfo == null || imageInfo.length() == 0) continue;
            JSONObject info = imageInfo.optJSONObject(0);
            if (info == null) continue;
            String imageUrl = info.optString("thumburl", info.optString("url", ""));
            String mime = info.optString("mime", "");
            if (imageUrl.isEmpty() || (!mime.isEmpty() && !mime.startsWith("image/"))) continue;
            if (historyContainsImage(fileTitle) && getHistoryArray().length() < MAX_HISTORY) continue;

            File outFile = prepareOutputFile("commons_cat");
            downloadFile(imageUrl, outFile);
            verifyBitmap(outFile);

            String cleanedTitle = cleanFileTitle(fileTitle);
            String description = "Картина выбрана из открытой категории Wikimedia Commons. Русского музейного описания для этой карточки в приложении нет. Автор: "
                    + category.artistRu + ". Оригинальное имя файла: " + cleanedTitle + ".";

            return new ArtEntry(
                    fileTitle.hashCode(),
                    cleanedTitle,
                    category.artistRu,
                    cleanedTitle,
                    category.artistOriginal,
                    description,
                    fileTitle,
                    imageUrl,
                    outFile.getAbsolutePath(),
                    commonsFilePageUrl(fileTitle),
                    "",
                    "Wikimedia Commons"
            );
        }
        throw new IOException("Не удалось выбрать подходящий файл из категории Commons.");
    }

    private String cleanFileTitle(String fileTitle) {
        String s = fileTitle == null ? "" : fileTitle;
        int dot = s.lastIndexOf('.');
        if (dot > 0) s = s.substring(0, dot);
        s = s.replace('_', ' ');
        s = s.replaceAll("(?i)google art project", "");
        s = s.replaceAll("(?i)wikimedia commons", "");
        s = s.replaceAll("\\s+", " ").trim();
        if (s.length() > 80) s = s.substring(0, 80).trim() + "…";
        return s.isEmpty() ? "Без названия" : s;
    }

    private File prepareOutputFile(String prefix) throws IOException {
        File cacheDir = new File(context.getFilesDir(), "art_cache");
        if (!cacheDir.exists() && !cacheDir.mkdirs()) {
            throw new IOException("Не удалось создать папку кэша.");
        }
        return new File(cacheDir, prefix + "_" + System.currentTimeMillis() + "_" + Math.abs(random.nextInt()) + ".jpg");
    }

    private void verifyBitmap(File outFile) throws IOException {
        if (outFile == null || !outFile.exists() || outFile.length() == 0) {
            deleteFileQuietly(outFile == null ? "" : outFile.getAbsolutePath());
            throw new IOException("Загруженный файл не распознан как изображение.");
        }
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(outFile.getAbsolutePath(), options);
        if (options.outWidth <= 0 || options.outHeight <= 0) {
            deleteFileQuietly(outFile.getAbsolutePath());
            throw new IOException("Загруженный файл не распознан как изображение.");
        }
    }

    private boolean historyContainsImage(String imageId) throws JSONException {
        JSONArray history = getHistoryArray();
        for (int i = 0; i < history.length(); i++) {
            JSONObject item = history.optJSONObject(i);
            if (item != null && imageId.equals(item.optString("imageId", ""))) return true;
        }
        return false;
    }

    private String commonsFilePathUrl(String fileTitle, int width) throws IOException {
        return "https://commons.wikimedia.org/wiki/Special:FilePath/" + encodePath(fileTitle) + "?width=" + width;
    }

    private String commonsFilePageUrl(String fileTitle) throws IOException {
        return "https://commons.wikimedia.org/wiki/File:" + encodePath(fileTitle.replace(' ', '_'));
    }

    private JSONObject readJson(String urlString) throws IOException, JSONException {
        return new JSONObject(readText(urlString));
    }

    private String readText(String urlString) throws IOException {
        HttpURLConnection conn = null;
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(12000);
            int code = conn.getResponseCode();
            InputStream input = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
            if (input == null) throw new IOException("HTTP " + code);
            byte[] bytes = readAll(input);
            if (code < 200 || code >= 300) {
                throw new IOException("HTTP " + code + ": " + new String(bytes));
            }
            return new String(bytes, "UTF-8");
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private byte[] readAll(InputStream input) throws IOException {
        try (BufferedInputStream in = new BufferedInputStream(input);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return out.toByteArray();
        }
    }

    private void downloadFile(String urlString, File outFile) throws IOException {
        HttpURLConnection conn = null;
        File tmp = new File(outFile.getAbsolutePath() + ".tmp");
        deleteFileQuietly(tmp.getAbsolutePath());
        try {
            URL url = new URL(urlString);
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(16000);
            int code = conn.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code + " при загрузке изображения");
            String type = conn.getContentType();
            if (type != null && !type.toLowerCase().startsWith("image/")) {
                throw new IOException("Commons вернул не изображение: " + type);
            }
            try (BufferedInputStream in = new BufferedInputStream(conn.getInputStream());
                 BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(tmp))) {
                byte[] buffer = new byte[16384];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
            }
            if (!tmp.renameTo(outFile)) {
                throw new IOException("Не удалось сохранить файл кэша.");
            }
        } finally {
            if (conn != null) conn.disconnect();
            deleteFileQuietly(tmp.getAbsolutePath());
        }
    }

    private boolean hasNetwork() {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return true;
            NetworkInfo info = cm.getActiveNetworkInfo();
            return info != null && info.isConnected();
        } catch (Exception e) {
            return true;
        }
    }

    private JSONArray getHistoryArray() throws JSONException {
        return new JSONArray(prefs.getString(KEY_HISTORY, "[]"));
    }

    private void appendToHistory(ArtEntry entry) throws JSONException {
        JSONArray history = getHistoryArray();
        int index = prefs.getInt(KEY_INDEX, history.length() - 1);

        while (history.length() > index + 1 && history.length() > 0) {
            JSONObject removed = history.getJSONObject(history.length() - 1);
            deleteFileQuietly(removed.optString("localPath", ""));
            history.remove(history.length() - 1);
        }

        history.put(entry.toJson());
        while (history.length() > MAX_HISTORY) {
            JSONObject removed = history.getJSONObject(0);
            deleteFileQuietly(removed.optString("localPath", ""));
            history.remove(0);
        }

        prefs.edit()
                .putString(KEY_HISTORY, history.toString())
                .putInt(KEY_INDEX, history.length() - 1)
                .apply();
    }

    private void deleteFileQuietly(String path) {
        try {
            if (path != null && !path.isEmpty()) {
                //noinspection ResultOfMethodCallIgnored
                new File(path).delete();
            }
        } catch (Exception ignored) {
        }
    }

    private static String urlEncode(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8");
    }

    private static String encodePath(String value) throws IOException {
        return URLEncoder.encode(value, "UTF-8").replace("+", "%20");
    }

    private static class Seed {
        final String fileTitle;
        final String titleRu;
        final String artistRu;
        final String titleOriginal;
        final String artistOriginal;
        final String date;
        final String descriptionRu;

        Seed(String fileTitle, String titleRu, String artistRu, String titleOriginal, String artistOriginal, String date, String descriptionRu) {
            this.fileTitle = fileTitle;
            this.titleRu = titleRu;
            this.artistRu = artistRu;
            this.titleOriginal = titleOriginal;
            this.artistOriginal = artistOriginal;
            this.date = date;
            this.descriptionRu = descriptionRu;
        }
    }

    private static class CategorySeed {
        final String categoryTitle;
        final String artistRu;
        final String artistOriginal;

        CategorySeed(String categoryTitle, String artistRu, String artistOriginal) {
            this.categoryTitle = categoryTitle;
            this.artistRu = artistRu;
            this.artistOriginal = artistOriginal;
        }
    }

    private static final CategorySeed[] CATEGORIES = new CategorySeed[]{
            new CategorySeed("Category:Paintings by Claude Monet", "Клод Моне", "Claude Monet"),
            new CategorySeed("Category:Paintings by Vincent van Gogh", "Винсент ван Гог", "Vincent van Gogh"),
            new CategorySeed("Category:Paintings by Pierre-Auguste Renoir", "Пьер Огюст Ренуар", "Pierre-Auguste Renoir"),
            new CategorySeed("Category:Paintings by Rembrandt", "Рембрандт ван Рейн", "Rembrandt"),
            new CategorySeed("Category:Paintings by Ivan Aivazovsky", "Иван Айвазовский", "Ivan Aivazovsky"),
            new CategorySeed("Category:Paintings by Ilya Repin", "Илья Репин", "Ilya Repin"),
            new CategorySeed("Category:Paintings by Isaac Levitan", "Исаак Левитан", "Isaac Levitan"),
            new CategorySeed("Category:Paintings by Valentin Serov", "Валентин Серов", "Valentin Serov")
    };

    private static final Seed[] SEEDS = new Seed[]{
            new Seed("Mona Lisa.jpg", "Мона Лиза", "Леонардо да Винчи", "Mona Lisa", "Leonardo da Vinci", "ок. 1503–1519", "Портрет Лизы Герардини считается одной из самых узнаваемых картин европейского Возрождения. Главный эффект картины — сдержанная полуулыбка и мягкая светотеневая моделировка лица."),
            new Seed("The Last Supper.jpg", "Тайная вечеря", "Леонардо да Винчи", "The Last Supper", "Leonardo da Vinci", "1490-е", "Фреска изображает момент, когда Христос сообщает ученикам о будущем предательстве. Композиция построена так, что все линии ведут взгляд к центральной фигуре Христа."),
            new Seed("Lady with an Ermine.jpg", "Дама с горностаем", "Леонардо да Винчи", "Lady with an Ermine", "Leonardo da Vinci", "ок. 1489–1490", "Портрет Чечилии Галлерани известен сложным поворотом фигуры и живой психологической характеристикой. Горностай усиливает ощущение движения и внутренней напряжённости образа."),
            new Seed("The Birth of Venus.jpg", "Рождение Венеры", "Сандро Боттичелли", "The Birth of Venus", "Sandro Botticelli", "ок. 1485", "Картина показывает появление Венеры из морской пены. Линейный ритм, плавные контуры и условная красота делают её одним из символов итальянского Ренессанса."),
            new Seed("Primavera-Botticelli.jpg", "Весна", "Сандро Боттичелли", "Primavera", "Sandro Botticelli", "ок. 1482", "Аллегорическая композиция с Венерой, Меркурием, грациями и Флорой. Картина насыщена гуманистическими символами и построена как торжественная сцена пробуждения природы."),
            new Seed("The Arnolfini Portrait.jpg", "Портрет четы Арнольфини", "Ян ван Эйк", "The Arnolfini Portrait", "Jan van Eyck", "1434", "Один из наиболее известных нидерландских портретов XV века. В картине важны бытовые детали, зеркало на задней стене и сложная система символов брака и достатка."),
            new Seed("Girl with a Pearl Earring.jpg", "Девушка с жемчужной серёжкой", "Ян Вермеер", "Girl with a Pearl Earring", "Johannes Vermeer", "ок. 1665", "Это не строгий портрет, а тронье — изображение типа или характера. Контраст тёмного фона, светлого лица и блеска жемчужины создаёт сильный камерный эффект."),
            new Seed("The Milkmaid.jpg", "Молочница", "Ян Вермеер", "The Milkmaid", "Johannes Vermeer", "ок. 1658–1661", "Вермеер превращает простую бытовую сцену в почти монументальный образ. Свет из окна, фактура хлеба и молока подчёркивают тишину и собранность момента."),
            new Seed("The Night Watch.jpg", "Ночной дозор", "Рембрандт ван Рейн", "The Night Watch", "Rembrandt van Rijn", "1642", "Групповой портрет стрелковой роты написан как динамическая сцена выхода отряда. Рембрандт нарушил статичность традиционного портрета и сделал композицию драматичной."),
            new Seed("Las Meninas.jpg", "Менины", "Диего Веласкес", "Las Meninas", "Diego Velázquez", "1656", "Картина соединяет придворный портрет, сцену из мастерской и размышление о взгляде зрителя. Веласкес помещает себя внутри пространства картины и усложняет отношения между моделью, художником и зрителем."),
            new Seed("The Surrender of Breda.jpg", "Сдача Бреды", "Диего Веласкес", "The Surrender of Breda", "Diego Velázquez", "1634–1635", "Историческая сцена представлена не как унижение побеждённых, а как жест достоинства и уважения между противниками. Копья на заднем плане дали картине второе название — «Копья»."),
            new Seed("Saturn Devouring His Son.jpg", "Сатурн, пожирающий своего сына", "Франсиско Гойя", "Saturn Devouring His Son", "Francisco Goya", "1819–1823", "Одна из «чёрных картин» Гойи. Мифологический сюжет превращён в предельно мрачный образ страха, безумия и разрушительной власти."),
            new Seed("The Third of May 1808.jpg", "Третье мая 1808 года в Мадриде", "Франсиско Гойя", "The Third of May 1808", "Francisco Goya", "1814", "Гойя показывает расстрел испанских повстанцев как трагедию мирных людей перед безличной военной машиной. Картина стала одним из ключевых антивоенных образов XIX века."),
            new Seed("Liberty Leading the People.jpg", "Свобода, ведущая народ", "Эжен Делакруа", "Liberty Leading the People", "Eugène Delacroix", "1830", "Аллегория революции объединяет реальных участников уличного боя и символическую фигуру Свободы. Картина стала одним из главных образов французского романтизма."),
            new Seed("The Raft of the Medusa.jpg", "Плот «Медузы»", "Теодор Жерико", "The Raft of the Medusa", "Théodore Géricault", "1818–1819", "Монументальная сцена кораблекрушения основана на реальном событии. Жерико усилил драму через диагональное построение, контраст тел и надежду на спасение вдали."),
            new Seed("The Death of Socrates.jpg", "Смерть Сократа", "Жак-Луи Давид", "The Death of Socrates", "Jacques-Louis David", "1787", "Неоклассическая композиция показывает Сократа перед казнью. Герой изображён спокойным и убеждённым, а ученики вокруг него переживают трагедию по-разному."),
            new Seed("Oath of the Horatii.jpg", "Клятва Горациев", "Жак-Луи Давид", "Oath of the Horatii", "Jacques-Louis David", "1784", "Картина стала образцом гражданского пафоса неоклассицизма. Мужские фигуры выстроены строго и напряжённо, женская группа противопоставлена им мягкостью и скорбью."),
            new Seed("Wanderer above the sea of fog.jpg", "Странник над морем тумана", "Каспар Давид Фридрих", "Wanderer above the Sea of Fog", "Caspar David Friedrich", "ок. 1818", "Фигура человека стоит спиной к зрителю перед огромным пространством тумана и гор. Картина стала символом романтического переживания природы и одиночества."),
            new Seed("The Fighting Temeraire.jpg", "Последний рейс корабля «Отважный»", "Уильям Тёрнер", "The Fighting Temeraire", "J. M. W. Turner", "1839", "Тёрнер показывает старый военный корабль, который буксируют на разборку. Закатный свет превращает сцену в размышление о конце эпохи парусного флота."),
            new Seed("The Hay Wain.jpg", "Воз сена", "Джон Констебл", "The Hay Wain", "John Constable", "1821", "Пейзаж английской сельской местности написан с вниманием к небу, воде и повседневной работе. Картина стала одним из главных образов английского пейзажа."),
            new Seed("Impression, Sunrise.jpg", "Впечатление. Восходящее солнце", "Клод Моне", "Impression, Sunrise", "Claude Monet", "1872", "От названия этой картины произошло слово «импрессионизм». Моне фиксирует не детальное описание гавани, а мгновенное впечатление света, тумана и цвета."),
            new Seed("Woman with a Parasol - Madame Monet and Her Son.jpg", "Женщина с зонтиком", "Клод Моне", "Woman with a Parasol", "Claude Monet", "1875", "Фигура Камиллы Моне и ребёнка написана на открытом воздухе. Важны движение ветра, яркий свет и ощущение мгновенности, характерное для импрессионизма."),
            new Seed("Water Lilies and Japanese Bridge.jpg", "Водяные лилии и японский мостик", "Клод Моне", "Water Lilies and Japanese Bridge", "Claude Monet", "1899", "Моне много раз писал пруд в своём саду в Живерни. В этих работах отражения, вода и растения почти растворяют предметный мир в цвете."),
            new Seed("Bal du moulin de la Galette.jpg", "Бал в Мулен де ла Галетт", "Пьер Огюст Ренуар", "Bal du moulin de la Galette", "Pierre-Auguste Renoir", "1876", "Ренуар изображает воскресный танец на Монмартре. Свет, проходящий через листву, дробится на одежде и лицах, создавая живую атмосферу праздника."),
            new Seed("The Ballet Class.jpg", "Балетный класс", "Эдгар Дега", "The Ballet Class", "Edgar Degas", "1870-е", "Дега показывает не сценический блеск, а повседневную репетицию танцовщиц. Композиция напоминает случайный взгляд, но построена очень точно."),
            new Seed("Le Déjeuner sur l'herbe.jpg", "Завтрак на траве", "Эдуар Мане", "Le Déjeuner sur l'herbe", "Édouard Manet", "1863", "Картина вызвала скандал из-за соединения современной сцены и мотивов старых мастеров. Мане намеренно разрушает привычные академические правила."),
            new Seed("Olympia.jpg", "Олимпия", "Эдуар Мане", "Olympia", "Édouard Manet", "1863", "Мане переосмыслил традицию изображения Венеры и перенёс её в современный парижский контекст. Прямой взгляд героини сделал картину особенно провокационной для своего времени."),
            new Seed("A Sunday on La Grande Jatte.jpg", "Воскресный день на острове Гранд-Жатт", "Жорж Сёра", "A Sunday on La Grande Jatte", "Georges Seurat", "1884–1886", "Сёра построил сцену прогулки через систему мелких цветовых точек. Картина стала главным примером пуантилизма и научного подхода к цвету."),
            new Seed("The Starry Night.jpg", "Звёздная ночь", "Винсент ван Гог", "The Starry Night", "Vincent van Gogh", "1889", "Ван Гог написал ночное небо как вихревое движение света и цвета. Контраст спокойной деревни и напряжённого неба делает картину эмоционально сильной."),
            new Seed("Sunflowers.jpg", "Подсолнухи", "Винсент ван Гог", "Sunflowers", "Vincent van Gogh", "1888", "Серия с подсолнухами была создана для украшения комнаты Поля Гогена в Арле. Жёлтая гамма и густая фактура стали одной из визитных карточек Ван Гога."),
            new Seed("Irises-Vincent van Gogh.jpg", "Ирисы", "Винсент ван Гог", "Irises", "Vincent van Gogh", "1889", "Картина написана в лечебнице Сен-Реми. Ритм листьев и цветов показывает, как Ван Гог превращал наблюдение природы в энергичную декоративную композицию."),
            new Seed("Van Gogh - Self-Portrait with Bandaged Ear.jpg", "Автопортрет с перевязанным ухом", "Винсент ван Гог", "Self-Portrait with Bandaged Ear", "Vincent van Gogh", "1889", "Автопортрет создан после тяжёлого личного кризиса художника. Спокойная поза контрастирует с напряжённой историей, скрытой за изображением."),
            new Seed("Where Do We Come From? What Are We? Where Are We Going?.jpg", "Откуда мы пришли? Кто мы? Куда мы идём?", "Поль Гоген", "Where Do We Come From? What Are We? Where Are We Going?", "Paul Gauguin", "1897–1898", "Большая таитянская композиция Гогена построена как философский вопрос о жизни человека. Сцена читается справа налево и соединяет бытовое, мифологическое и символическое."),
            new Seed("The Card Players.jpg", "Игроки в карты", "Поль Сезанн", "The Card Players", "Paul Cézanne", "1890-е", "Сезанн превращает простую жанровую сцену в строгую конструкцию из объёмов и цветовых отношений. Эта серия важна для перехода от импрессионизма к искусству XX века."),
            new Seed("The Dream by Henri Rousseau.jpg", "Сон", "Анри Руссо", "The Dream", "Henri Rousseau", "1910", "Фантастические джунгли Руссо написаны художником, который никогда не видел тропиков. Наивная точность деталей сочетается с загадочной театральностью сцены."),
            new Seed("The Scream.jpg", "Крик", "Эдвард Мунк", "The Scream", "Edvard Munch", "1893", "Мунк создал образ тревоги, в котором пейзаж и человеческая фигура становятся частью одного эмоционального состояния. Волнообразные линии усиливают ощущение внутреннего крика."),
            new Seed("The Kiss - Gustav Klimt.jpg", "Поцелуй", "Густав Климт", "The Kiss", "Gustav Klimt", "1907–1908", "Золотой фон, орнаментальные одежды и статичная поза превращают сцену объятия в декоративный символ любви. Картина относится к зрелому «золотому периоду» Климта."),
            new Seed("American Gothic.jpg", "Американская готика", "Грант Вуд", "American Gothic", "Grant Wood", "1930", "Картина показывает фермера с вилами и женщину перед домом в неоготическом стиле. Образ стал одним из самых узнаваемых символов американской культуры."),
            new Seed("Arrangement in Grey and Black No.1.jpg", "Портрет матери художника", "Джеймс Уистлер", "Arrangement in Grey and Black No. 1", "James McNeill Whistler", "1871", "Строгая композиция в серо-чёрной гамме известна как «Мать Уистлера». Художник подчёркивал музыкальность тональных отношений, а не только портретное сходство."),
            new Seed("The Great Wave off Kanagawa.jpg", "Большая волна в Канагаве", "Кацусика Хокусай", "The Great Wave off Kanagawa", "Katsushika Hokusai", "ок. 1831", "Гравюра из серии «Тридцать шесть видов Фудзи». Волна изображена как мощная форма, почти нависающая над лодками, а гора Фудзи видна маленькой и далёкой."),
            new Seed("The Ninth Wave.jpg", "Девятый вал", "Иван Айвазовский", "The Ninth Wave", "Ivan Aivazovsky", "1850", "Айвазовский показывает людей после кораблекрушения на фоне гигантской волны и рассветного света. Драма моря соединена с надеждой на спасение."),
            new Seed("Reply of the Zaporozhian Cossacks.jpg", "Запорожцы пишут письмо турецкому султану", "Илья Репин", "Reply of the Zaporozhian Cossacks", "Ilya Repin", "1880–1891", "Репин создал многофигурную сцену с яркими характерами. Смех, жесты и плотная композиция передают энергию коллективного действия."),
            new Seed("Ivan the Terrible and His Son Ivan.jpg", "Иван Грозный и сын его Иван", "Илья Репин", "Ivan the Terrible and His Son Ivan", "Ilya Repin", "1885", "Картина показывает трагический момент после смертельного удара царя сыну. Репин концентрирует внимание на ужасе и запоздалом раскаянии."),
            new Seed("Bogatyrs.jpg", "Богатыри", "Виктор Васнецов", "Bogatyrs", "Viktor Vasnetsov", "1881–1898", "Васнецов изображает трёх героев русского былинного эпоса как защитников земли. Картина соединяет историческую условность, фольклор и монументальный образ силы."),
            new Seed("Morning in a Pine Forest.jpg", "Утро в сосновом лесу", "Иван Шишкин", "Morning in a Pine Forest", "Ivan Shishkin", "1889", "Шишкин написал лесной пейзаж с точным знанием природы, а медвежат в композицию внёс Константин Савицкий. Картина стала одним из самых известных русских пейзажей."),
            new Seed("Golden Autumn.jpg", "Золотая осень", "Исаак Левитан", "Golden Autumn", "Isaac Levitan", "1895", "Левитан передаёт ясный осенний день через контраст золотой листвы, синей воды и холодного неба. Пейзаж звучит светло, но сохраняет лирическую сдержанность."),
            new Seed("The Rooks Have Come Back.jpg", "Грачи прилетели", "Алексей Саврасов", "The Rooks Have Come Back", "Alexei Savrasov", "1871", "Саврасов сделал обычный весенний мотив образом тихого обновления. Именно с этой картины часто связывают становление русского лирического пейзажа."),
            new Seed("Girl with Peaches.jpg", "Девочка с персиками", "Валентин Серов", "Girl with Peaches", "Valentin Serov", "1887", "Портрет Веры Мамонтовой написан свободно и светло. Серов соединяет живую непосредственность модели с тонкой работой цвета и воздуха."),
            new Seed("The Swan Princess.jpg", "Царевна-Лебедь", "Михаил Врубель", "The Swan Princess", "Mikhail Vrubel", "1900", "Врубель создал сказочный образ на границе человека и птицы. Переливчатая живопись и необычный взгляд героини придают картине тревожную загадочность."),
            new Seed("The Last Day of Pompeii.jpg", "Последний день Помпеи", "Карл Брюллов", "The Last Day of Pompeii", "Karl Bryullov", "1830–1833", "Монументальная историческая картина показывает гибель города во время извержения Везувия. Брюллов сочетает античный сюжет, драму катастрофы и театральную выразительность фигур."),
            new Seed("Boyarynya Morozova.jpg", "Боярыня Морозова", "Василий Суриков", "Boyarynya Morozova", "Vasily Surikov", "1884–1887", "Суриков изображает раскольницу Феодосию Морозову, увозимую на санях. Толпа вокруг неё не фон, а сложная среда разных реакций и характеров."),
            new Seed("Moonlit Night on the Dnieper.jpg", "Лунная ночь на Днепре", "Архип Куинджи", "Moonlit Night on the Dnieper", "Arkhip Kuindzhi", "1880", "Куинджи добивается почти светящегося эффекта луны и воды. Картина строится на сильном контрасте темноты и холодного сияния."),
            new Seed("At the Dressing-Table. Self-Portrait.jpg", "За туалетом. Автопортрет", "Зинаида Серебрякова", "At the Dressing-Table", "Zinaida Serebriakova", "1909", "Серебрякова показывает себя перед зеркалом в естественный утренний момент. Образ светлый, живой и лишённый позы, что делает портрет особенно непосредственным.")
    };
}
