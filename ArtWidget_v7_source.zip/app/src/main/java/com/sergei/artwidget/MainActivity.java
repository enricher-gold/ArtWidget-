package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.method.LinkMovementMethod;
import android.text.style.URLSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private ImageView previewImage;
    private TextView status;
    private TextView article;
    private TextView cacheInfo;
    private Button refreshButton;
    private Button previousButton;
    private Button clearCacheButton;
    private Button saveIntervalButton;
    private Button exactAlarmButton;
    private Spinner unitSpinner;
    private EditText intervalValue;
    private String currentSourceUrl = "";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(createLayout());
        updateUiFromCache();
        ArtWidgetProvider.updateAllWidgets(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUiFromCache();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        executor.shutdown();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(18);
        root.setPadding(pad, dp(54), pad, pad);
        scroll.addView(root);

        previewImage = new ImageView(this);
        previewImage.setAdjustViewBounds(true);
        previewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewImage.setBackgroundColor(0x00000000);
        previewImage.setContentDescription("Текущая картина");
        previewImage.setOnClickListener(v -> openCurrentArticle());
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(260)
        );
        previewParams.setMargins(0, 0, 0, dp(12));
        root.addView(previewImage, previewParams);

        TextView source = new TextView(this);
        source.setText("Источник: русская Википедия.");
        source.setTextSize(14);
        source.setPadding(0, 0, 0, dp(10));
        root.addView(source, matchWrap());

        status = new TextView(this);
        status.setTextSize(16);
        status.setPadding(0, 0, 0, dp(10));
        status.setLinkTextColor(0xFF1565C0);
        root.addView(status, matchWrap());

        TextView articleTitle = new TextView(this);
        articleTitle.setText("О картине");
        articleTitle.setTextSize(18);
        articleTitle.setTypeface(Typeface.DEFAULT_BOLD);
        articleTitle.setPadding(0, dp(4), 0, dp(4));
        root.addView(articleTitle, matchWrap());

        article = new TextView(this);
        article.setTextSize(15);
        article.setPadding(0, 0, 0, dp(12));
        root.addView(article, matchWrap());

        cacheInfo = new TextView(this);
        cacheInfo.setTextSize(14);
        cacheInfo.setPadding(0, 0, 0, dp(12));
        root.addView(cacheInfo, matchWrap());

        refreshButton = new Button(this);
        refreshButton.setText("Обновить картину сейчас");
        refreshButton.setAllCaps(false);
        refreshButton.setOnClickListener(v -> refreshNow());
        root.addView(refreshButton, matchWrap());

        previousButton = new Button(this);
        previousButton.setText("Вернуться к предыдущей картине");
        previousButton.setAllCaps(false);
        previousButton.setOnClickListener(v -> previous());
        root.addView(previousButton, matchWrap());

        clearCacheButton = new Button(this);
        clearCacheButton.setText("Очистить кэш");
        clearCacheButton.setAllCaps(false);
        clearCacheButton.setOnClickListener(v -> clearCache());
        root.addView(clearCacheButton, matchWrap());

        TextView intervalLabel = new TextView(this);
        intervalLabel.setText("Автообновление:");
        intervalLabel.setTextSize(16);
        intervalLabel.setPadding(0, dp(18), 0, dp(6));
        root.addView(intervalLabel, matchWrap());

        LinearLayout intervalRow = new LinearLayout(this);
        intervalRow.setOrientation(LinearLayout.HORIZONTAL);
        intervalRow.setGravity(Gravity.CENTER_VERTICAL);

        intervalValue = new EditText(this);
        intervalValue.setInputType(InputType.TYPE_CLASS_NUMBER);
        intervalValue.setSingleLine(true);
        intervalValue.setSelectAllOnFocus(true);
        intervalValue.setTextSize(16);
        LinearLayout.LayoutParams valueParams = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        valueParams.setMargins(0, 0, dp(10), 0);
        intervalRow.addView(intervalValue, valueParams);

        unitSpinner = new Spinner(this);
        String[] units = new String[]{"секунд", "минут", "часов"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, units);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitSpinner.setAdapter(adapter);
        intervalRow.addView(unitSpinner, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(intervalRow, matchWrap());

        applyIntervalToControls(ArtScheduler.getIntervalSeconds(this));
        unitSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        saveIntervalButton = new Button(this);
        saveIntervalButton.setText("Сохранить интервал");
        saveIntervalButton.setAllCaps(false);
        saveIntervalButton.setOnClickListener(v -> saveInterval());
        root.addView(saveIntervalButton, matchWrap());

        exactAlarmButton = new Button(this);
        exactAlarmButton.setText("Разрешить точное автообновление");
        exactAlarmButton.setAllCaps(false);
        exactAlarmButton.setOnClickListener(v -> openExactAlarmSettings());
        root.addView(exactAlarmButton, matchWrap());

        return scroll;
    }

    private void refreshNow() {
        setBusy(true);
        setStatus("Загружаю новую картину…");
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(this);
                repo.fetchNextArtwork();
                ArtScheduler.scheduleNext(this);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    updateUiFromCache();
                    setBusy(false);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setStatus("Ошибка загрузки: " + e.getMessage());
                    setBusy(false);
                });
            }
        });
    }

    private void previous() {
        try {
            ArtRepository repo = new ArtRepository(this);
            ArtEntry entry = repo.goPrevious();
            ArtWidgetProvider.updateAllWidgets(this);
            if (entry == null) {
                setStatus("Предыдущей картины пока нет. Сначала загрузите несколько картин.");
            } else {
                updateUiFromCache();
            }
        } catch (Exception e) {
            setStatus("Ошибка: " + e.getMessage());
        }
    }

    private void clearCache() {
        ArtRepository repo = new ArtRepository(this);
        repo.clearCache();
        ArtWidgetProvider.updateAllWidgets(this);
        updateUiFromCache();
    }

    private void saveInterval() {
        int value;
        try {
            value = Integer.parseInt(intervalValue.getText().toString().trim());
        } catch (Exception e) {
            setStatus("Введите число для интервала автообновления.");
            return;
        }
        if (value <= 0) {
            setStatus("Интервал должен быть больше нуля.");
            return;
        }

        long secondsLong = value;
        int unit = unitSpinner.getSelectedItemPosition();
        if (unit == 1) secondsLong *= 60L;
        if (unit == 2) secondsLong *= 3600L;

        if (secondsLong < ArtScheduler.MIN_INTERVAL_SECONDS) {
            secondsLong = ArtScheduler.MIN_INTERVAL_SECONDS;
        }
        if (secondsLong > ArtScheduler.MAX_INTERVAL_SECONDS) {
            secondsLong = ArtScheduler.MAX_INTERVAL_SECONDS;
        }

        int seconds = (int) secondsLong;
        ArtScheduler.setIntervalSeconds(this, seconds);
        applyIntervalToControls(seconds);
        updateUiFromCache();
        Toast.makeText(this, "Интервал сохранён: " + ArtScheduler.intervalText(seconds), Toast.LENGTH_SHORT).show();
    }

    private void updateUiFromCache() {
        ArtRepository repo = new ArtRepository(this);
        ArtEntry current = repo.getCurrent();
        int seconds = ArtScheduler.getIntervalSeconds(this);
        currentSourceUrl = current == null ? "" : current.sourceUrl;
        updatePreview(current);

        String exactHint = ArtScheduler.exactAlarmHint(this);
        if (current == null) {
            setStatus("Картин в кэше пока нет. Нажмите «Обновить картину сейчас».\nИнтервал автообновления: "
                    + ArtScheduler.intervalText(seconds) + ".\n" + ArtScheduler.nextUpdateText(this)
                    + (exactHint.isEmpty() ? "" : "\n" + exactHint));
            article.setText("После загрузки картины здесь появится краткое описание.");
        } else {
            setLinkedStatus(current,
                    "Сейчас в виджете:\n" + current.caption()
                            + "\nОригинал: " + current.originalCaption()
                            + "\nИнтервал автообновления: " + ArtScheduler.intervalText(seconds)
                            + ".\n" + ArtScheduler.nextUpdateText(this)
                            + (exactHint.isEmpty() ? "" : "\n" + exactHint));
            article.setText(current.description == null || current.description.trim().isEmpty() ? "Описание отсутствует." : current.description);
        }
        cacheInfo.setText("Картин в кэше: " + repo.getCacheCount() + " из 20.");
        if (exactAlarmButton != null) {
            exactAlarmButton.setVisibility(ArtScheduler.canScheduleExact(this) ? View.GONE : View.VISIBLE);
        }
    }

    private void updatePreview(ArtEntry current) {
        if (previewImage == null) return;
        if (current == null || current.localPath == null || current.localPath.trim().isEmpty()) {
            previewImage.setImageDrawable(null);
            previewImage.setVisibility(View.GONE);
            return;
        }
        File f = new File(current.localPath);
        if (!f.exists() || f.length() == 0) {
            previewImage.setImageDrawable(null);
            previewImage.setVisibility(View.GONE);
            return;
        }
        Bitmap bitmap = BitmapFactory.decodeFile(f.getAbsolutePath());
        if (bitmap == null) {
            previewImage.setImageDrawable(null);
            previewImage.setVisibility(View.GONE);
            return;
        }
        previewImage.setVisibility(View.VISIBLE);
        previewImage.setImageBitmap(bitmap);
    }

    private void setLinkedStatus(ArtEntry current, String text) {
        if (current == null || current.sourceUrl == null || current.sourceUrl.trim().isEmpty()) {
            setStatus(text);
            return;
        }
        String linkText = current.caption();
        int start = text.indexOf(linkText);
        if (start < 0) {
            setStatus(text);
            return;
        }
        SpannableString sp = new SpannableString(text);
        sp.setSpan(new URLSpan(current.sourceUrl), start, start + linkText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        status.setText(sp);
        status.setMovementMethod(LinkMovementMethod.getInstance());
    }

    private void openCurrentArticle() {
        if (currentSourceUrl == null || currentSourceUrl.trim().isEmpty()) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentSourceUrl)));
        } catch (Exception ignored) {
        }
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName())));
            } catch (Exception ignored) {
                setStatus("Не удалось открыть настройки точного автообновления.");
            }
        }
    }

    private void applyIntervalToControls(int seconds) {
        if (seconds < 60) {
            intervalValue.setText(String.valueOf(seconds));
            unitSpinner.setSelection(0);
        } else if (seconds % 3600 == 0) {
            intervalValue.setText(String.valueOf(seconds / 3600));
            unitSpinner.setSelection(2);
        } else {
            intervalValue.setText(String.valueOf(seconds / 60));
            unitSpinner.setSelection(1);
        }
    }

    private void setBusy(boolean busy) {
        refreshButton.setEnabled(!busy);
        previousButton.setEnabled(!busy);
        clearCacheButton.setEnabled(!busy);
        saveIntervalButton.setEnabled(!busy);
        if (exactAlarmButton != null) exactAlarmButton.setEnabled(!busy);
        unitSpinner.setEnabled(!busy);
        intervalValue.setEnabled(!busy);
    }

    private void setStatus(String text) {
        status.setMovementMethod(null);
        status.setText(text == null ? "" : text);
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0, 0, 0, dp(8));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
