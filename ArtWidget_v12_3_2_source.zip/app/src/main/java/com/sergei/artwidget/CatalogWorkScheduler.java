package com.sergei.artwidget;

import android.content.Context;

import androidx.work.BackoffPolicy;
import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.util.concurrent.TimeUnit;

/** Инициализация и проверка встроенного каталога без сетевого пополнения. */
public final class CatalogWorkScheduler {
    public static final int REFILL_THRESHOLD = 0;
    public static final int TARGET_REMAINING = 1000;

    private static final String WORK_BOOTSTRAP = "art_catalog_bootstrap_v12_3_2";
    private static final String WORK_FILTER = "art_catalog_filter_check_v12_3_2";
    private static final String WORK_NSFW = "art_catalog_nsfw_check_v12_3_2";

    private CatalogWorkScheduler() { }

    public static void ensureInitialized(Context context) {
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogBootstrapWorker.class)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context.getApplicationContext())
                .enqueueUniqueWork(WORK_BOOTSTRAP, ExistingWorkPolicy.KEEP, request);
    }

    public static void requestManualRefresh(Context context) {
        enqueueCheck(context, false);
        enqueueCheck(context, true);
    }

    public static void scheduleRefill(Context context, int mode) {
        // Каталог 12.3.2 встроен в APK и не требует фонового пополнения.
    }

    public static void scheduleBothIfNeeded(Context context) {
        ensureInitialized(context);
    }

    private static void enqueueCheck(Context context, boolean adult) {
        Data input = new Data.Builder()
                .putBoolean(CatalogUpdateWorker.KEY_ADULT, adult)
                .putBoolean(CatalogUpdateWorker.KEY_FORCE, true)
                .build();
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(CatalogUpdateWorker.class)
                .setInputData(input)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .build();
        WorkManager.getInstance(context.getApplicationContext()).enqueueUniqueWork(
                adult ? WORK_NSFW : WORK_FILTER, ExistingWorkPolicy.REPLACE, request);
    }
}
