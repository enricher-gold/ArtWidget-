#!/usr/bin/env python3
"""Build a ready-to-use Art Widget catalog from exact Wikipedia painting articles.

The script never searches by a guessed title. It reads article members from the
Russian category "Картины по алфавиту" first, then uses English "Paintings" as
fallback. Every accepted record must have an exact article, Wikidata QID,
raster image and introductory extract.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable
from urllib.parse import quote

import requests

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"
USER_AGENT = "ArtWidget/14.2.4 catalog builder; contact enricherusa@gmail.com"
TIMEOUT = (10, 30)
CATEGORY_BATCH = 100
METADATA_BATCH = 20

SOURCES = (
    ("ru", "Категория:Картины по алфавиту"),
    ("en", "Category:Paintings"),
)

REJECT = (
    "sculpture", "statue", "photograph", "engraving", "etching", "drawing",
    "lithograph", "woodcut", "poster", "building", "architecture",
    "скульптур", "стату", "фотограф", "гравюр", "офорт", "рисунок",
    "литограф", "плакат", "здание", "архитектур",
)
EXPLICIT = (
    "nude paintings", "nude painting", "nudity in art", "erotic painting",
    "erotic art", "обнаженная натура", "обнаженные женщины",
    "обнаженные мужчины", "эротическая живопись", "картины с обнаженными",
)


def request_json(session: requests.Session, url: str, params: dict[str, Any]) -> dict[str, Any]:
    last: Exception | None = None
    for attempt in range(6):
        try:
            response = session.get(url, params=params, timeout=TIMEOUT)
            if response.status_code == 429:
                time.sleep(min(30, 2 ** attempt))
                continue
            response.raise_for_status()
            return response.json()
        except Exception as exc:  # noqa: BLE001
            last = exc
            time.sleep(min(12, 1.5 * (attempt + 1)))
    raise RuntimeError(f"request failed: {url}: {last}")


def chunks(values: list[str], size: int) -> Iterable[list[str]]:
    for start in range(0, len(values), size):
        yield values[start:start + size]


def normalize(value: str | None) -> str:
    return re.sub(r"\s+", " ", value or "").strip()


def raster(url: str) -> bool:
    clean = url.lower().split("?", 1)[0]
    return clean.endswith((".jpg", ".jpeg", ".png", ".webp"))


def is_painting(lang: str, title: str, extract: str) -> bool:
    intro = normalize(f"{title} {extract}").lower().replace("ё", "е")[:900]
    if any(marker in intro for marker in REJECT):
        return False
    if lang == "ru":
        return (
            " — картина" in intro
            or " - картина" in intro
            or "является картиной" in intro
            or "живописное полотно" in intro
            or "масло на холсте" in intro
            or "холст, масло" in intro
            or bool(re.search(r"\bкартина\b.{0,160}\bхудожник", intro))
        )
    return (
        bool(re.search(r"\bis (?:an? |the )?[^.]{0,160}\bpainting\b", intro))
        or "painting by " in intro
        or "oil on canvas" in intro
        or "panel painting" in intro
        or "fresco painting" in intro
    )


def is_explicit(text: str) -> bool:
    value = text.lower().replace("ё", "е")
    return any(marker in value for marker in EXPLICIT)


def category_titles(session: requests.Session, lang: str, category: str) -> Iterable[list[str]]:
    endpoint = f"https://{lang}.wikipedia.org/w/api.php"
    cursor = ""
    while True:
        params: dict[str, Any] = {
            "action": "query",
            "format": "json",
            "formatversion": 2,
            "list": "categorymembers",
            "cmnamespace": 0,
            "cmtype": "page",
            "cmlimit": CATEGORY_BATCH,
            "cmtitle": category,
        }
        if cursor:
            params["cmcontinue"] = cursor
        data = request_json(session, endpoint, params)
        rows = data.get("query", {}).get("categorymembers", [])
        titles = [normalize(row.get("title")) for row in rows if row.get("ns") == 0]
        titles = [title for title in titles if title and not title.lower().startswith(("список ", "list of "))]
        if titles:
            yield titles
        cursor = data.get("continue", {}).get("cmcontinue", "")
        if not cursor:
            break


def artist_labels(session: requests.Session, artwork_qids: list[str]) -> dict[str, tuple[str, str]]:
    if not artwork_qids:
        return {}
    endpoint = "https://www.wikidata.org/w/api.php"
    data = request_json(session, endpoint, {
        "action": "wbgetentities", "format": "json", "formatversion": 2,
        "props": "claims", "ids": "|".join(artwork_qids),
    })
    artwork_to_artists: dict[str, list[str]] = {}
    all_artist_qids: set[str] = set()
    for artwork in artwork_qids:
        entity = data.get("entities", {}).get(artwork, {})
        claims = entity.get("claims", {}).get("P170", [])
        ids: list[str] = []
        for claim in claims:
            value = claim.get("mainsnak", {}).get("datavalue", {}).get("value", {})
            qid = value.get("id", "") if isinstance(value, dict) else ""
            if re.fullmatch(r"Q\d+", qid) and qid not in ids:
                ids.append(qid)
                all_artist_qids.add(qid)
        if ids:
            artwork_to_artists[artwork] = ids
    if not all_artist_qids:
        return {}

    labels: dict[str, tuple[str, str]] = {}
    for batch in chunks(sorted(all_artist_qids), 50):
        result = request_json(session, endpoint, {
            "action": "wbgetentities", "format": "json", "formatversion": 2,
            "props": "labels", "languages": "ru|en", "languagefallback": 1,
            "ids": "|".join(batch),
        })
        for qid, entity in result.get("entities", {}).items():
            values = entity.get("labels", {})
            labels[qid] = (
                normalize(values.get("ru", {}).get("value")),
                normalize(values.get("en", {}).get("value")),
            )

    output: dict[str, tuple[str, str]] = {}
    for artwork, ids in artwork_to_artists.items():
        ru = [labels.get(qid, ("", ""))[0] for qid in ids]
        en = [labels.get(qid, ("", ""))[1] for qid in ids]
        output[artwork] = (
            ", ".join(dict.fromkeys(x for x in ru if x)),
            ", ".join(dict.fromkeys(x for x in en if x)),
        )
    return output


def metadata(session: requests.Session, lang: str, titles: list[str], excluded_qids: set[str]) -> list[dict[str, Any]]:
    endpoint = f"https://{lang}.wikipedia.org/w/api.php"
    data = request_json(session, endpoint, {
        "action": "query", "format": "json", "formatversion": 2, "redirects": 1,
        "prop": "pageprops|pageimages|extracts|info|categories",
        "piprop": "original|thumbnail", "pithumbsize": 1600,
        "exintro": 1, "explaintext": 1, "inprop": "url", "cllimit": "max",
        "titles": "|".join(titles),
    })
    pages = data.get("query", {}).get("pages", [])
    qids = []
    for page in pages:
        qid = page.get("pageprops", {}).get("wikibase_item", "")
        if re.fullmatch(r"Q\d+", qid):
            qids.append(qid)
    artists = artist_labels(session, qids)

    result: list[dict[str, Any]] = []
    for page in pages:
        if page.get("missing") or page.get("ns") != 0:
            continue
        title = normalize(page.get("title"))
        extract = normalize(page.get("extract"))
        qid = normalize(page.get("pageprops", {}).get("wikibase_item"))
        if not re.fullmatch(r"Q\d+", qid) or qid in excluded_qids:
            continue
        if not is_painting(lang, title, extract):
            continue
        image_url = normalize(page.get("thumbnail", {}).get("source"))
        original_url = normalize(page.get("original", {}).get("source"))
        if not image_url:
            image_url = original_url
        if not original_url:
            original_url = image_url
        if not extract or not raster(image_url) or not raster(original_url):
            continue
        categories = " ".join(normalize(x.get("title")) for x in page.get("categories", []))
        if is_explicit(f"{categories} {title} {extract}"):
            continue
        artist_ru, artist_en = artists.get(qid, ("", ""))
        artist = artist_ru if lang == "ru" else artist_en
        if not artist:
            artist = artist_en or artist_ru or ("Автор неизвестен" if lang == "ru" else "Unknown artist")
        source_url = normalize(page.get("fullurl"))
        if not source_url:
            source_url = f"https://{lang}.wikipedia.org/wiki/{quote(title.replace(' ', '_'), safe='/')}"
        title_widget = re.sub(r"\s*\([^)]*\)\s*$", "", title).strip() or title
        digest = hashlib.sha1(qid.encode("utf-8")).hexdigest()[:20]
        ru = lang == "ru"
        result.append({
            "catalog_index": 0,
            "stable_id": f"wikipedia:{digest}",
            "dedupe_key": qid,
            "qid": qid,
            "title": title_widget,
            "title_ru": title_widget if ru else "",
            "title_en": "" if ru else title_widget,
            "artist": artist,
            "artist_ru": artist_ru,
            "artist_en": artist_en,
            "description_ru": extract[:760] if ru else "",
            "description_en": "" if ru else extract[:760],
            "source_language": lang,
            "style": "painting",
            "tags": ["verified Wikipedia", "exact article"],
            "content_mode": "FILTER",
            "content_confidence": "exact-article-qid-image",
            "content_reason": "exact Wikipedia article with Wikidata QID, raster page image and introductory extract",
            "source_provider": "Wikipedia",
            "source_page_url": source_url,
            "image_url": image_url,
            "original_image_url": original_url,
            "resolver_order": [f"{lang}wiki_exact_article", "exact_qid_p18"],
            "image_resolver": {
                "type": "wikipedia_article_pageimage",
                "allow_wikiart": False,
                "allow_commons_title_search": False,
                "allow_exact_qid_p18": True,
            },
            "requires_image_resolution": False,
        })
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=int, default=1000)
    parser.add_argument("--min-items", type=int, default=200)
    parser.add_argument("--output", type=Path, default=ASSETS / "filter_catalog.json")
    args = parser.parse_args()

    nsfw_data = json.loads((ASSETS / "nsfw_catalog.json").read_text(encoding="utf-8"))
    excluded = {str(item.get("qid", "")) for item in nsfw_data.get("items", [])}
    seen = set(excluded)
    items: list[dict[str, Any]] = []

    session = requests.Session()
    session.headers.update({"User-Agent": USER_AGENT, "Accept": "application/json"})

    for lang, category in SOURCES:
        for title_batch in category_titles(session, lang, category):
            for batch in chunks(title_batch, METADATA_BATCH):
                for item in metadata(session, lang, batch, excluded):
                    qid = item["qid"]
                    if qid in seen:
                        continue
                    seen.add(qid)
                    items.append(item)
                    if len(items) >= args.target:
                        break
                if len(items) >= args.target:
                    break
                time.sleep(0.12)
            print(f"{lang}: collected {len(items)}", flush=True)
            if len(items) >= args.target:
                break
        if len(items) >= args.target:
            break

    if len(items) < args.min_items:
        raise SystemExit(f"only {len(items)} exact entries collected; minimum is {args.min_items}")
    for index, item in enumerate(items, 1):
        item["catalog_index"] = index

    payload = {
        "schema_version": 10,
        "catalog_name": "Art Widget exact safe Wikipedia catalog",
        "catalog_mode": "FILTER",
        "catalog_version": "14.2.4",
        "generated_at_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "item_count": len(items),
        "production_status": "build-time exact article catalog",
        "source_priority": ["ru.wikipedia.org", "en.wikipedia.org"],
        "items": items,
        "catalog_note": "Every entry has an exact Wikipedia article, Wikidata QID, raster image and article introduction. Search seeds are forbidden.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {len(items)} exact entries to {args.output}")


if __name__ == "__main__":
    main()
