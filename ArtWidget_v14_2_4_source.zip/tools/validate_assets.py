#!/usr/bin/env python3
"""Offline structural validation for Art Widget 14.2.4 assets."""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "app" / "src" / "main" / "assets"


def load_items(name: str) -> list[dict]:
    data = json.loads((ASSETS / name).read_text(encoding="utf-8"))
    items = data.get("items")
    if not isinstance(items, list):
        raise SystemExit(f"{name}: items is not an array")
    return items


def main() -> None:
    general = load_items("filter_catalog.json")
    general_ids = []
    for item in general:
        qid = str(item.get("qid") or "").strip()
        page = str(item.get("source_page_url") or "").strip()
        image = str(item.get("image_url") or "").strip()
        description = str(item.get("description_ru") or item.get("description_en") or "").strip()
        assert qid.startswith("Q") and qid[1:].isdigit(), f"filter_catalog.json: invalid QID {qid}"
        assert page.startswith(("https://ru.wikipedia.org/wiki/", "https://en.wikipedia.org/wiki/")), page
        assert image.startswith("https://"), f"filter_catalog.json: missing image for {qid}"
        assert description, f"filter_catalog.json: missing description for {qid}"
        assert item.get("requires_image_resolution") is False, f"filter_catalog.json: unresolved item {qid}"
        general_ids.append(qid)
    assert len(set(general_ids)) == len(general_ids), "filter_catalog.json: duplicate QID"

    nsfw = load_items("nsfw_catalog.json")
    assert len(nsfw) >= 40, f"nsfw_catalog.json: only {len(nsfw)} strict entries"
    nsfw_ids = [str(x.get("qid") or x.get("stable_id") or "").strip() for x in nsfw]
    assert all(x.startswith("Q") and x[1:].isdigit() for x in nsfw_ids), "nsfw_catalog.json: invalid QID"
    assert len(set(nsfw_ids)) == len(nsfw_ids), "nsfw_catalog.json: duplicate QID"
    for item in nsfw:
        page = str(item.get("source_page_url") or "")
        assert page.startswith(("https://ru.wikipedia.org/wiki/", "https://en.wikipedia.org/wiki/")), page
        assert item.get("style") == "painting"
        assert item.get("content_mode") == "NSFW"
        resolver = item.get("image_resolver") or {}
        assert resolver.get("allow_wikiart") is False
        assert resolver.get("allow_commons_title_search") is False
    direct = sum(bool(x.get("image_url")) for x in nsfw)
    assert direct >= 40, f"nsfw_catalog.json: only {direct} pre-resolved image URLs"

    assert not (ASSETS / "starter_catalog.json").exists(), "starter_catalog.json must be absent"
    assert not (ASSETS / "starter_images").exists(), "starter_images must be absent"
    manifest = json.loads((ASSETS / "catalog_manifest.json").read_text(encoding="utf-8"))
    assert manifest.get("app_version") == "14.2.4"
    print(f"OK filter_catalog.json: {len(general)} exact entries; unresolved seeds absent")
    print(f"OK nsfw_catalog.json: {len(nsfw)}, direct images: {direct}")
    print("OK starter gallery: absent")


if __name__ == "__main__":
    main()
