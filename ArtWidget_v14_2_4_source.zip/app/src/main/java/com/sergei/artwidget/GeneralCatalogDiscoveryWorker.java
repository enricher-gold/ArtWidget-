package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Постепенно наполняет общий каталог точными статьями о картинах Wikipedia. */
public final class GeneralCatalogDiscoveryWorker extends Worker {
    public static final String KEY_FORCE_RESCAN = "force_rescan";

    public GeneralCatalogDiscoveryWorker(@NonNull Context context,
                                         @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        try {
            boolean force = getInputData().getBoolean(KEY_FORCE_RESCAN, false);
            WikipediaExactPaintingCatalogUpdater.UpdateResult result =
                    new WikipediaExactPaintingCatalogUpdater(getApplicationContext()).updateBatch(force);
            new ArtRepository(getApplicationContext())
                    .onDynamicGeneralCatalogUpdated(result.added, result.status);
            if (result.moreRemaining) {
                CatalogWorkScheduler.scheduleGeneralDiscoveryContinuation(getApplicationContext());
            }
            return Result.success();
        } catch (Exception e) {
            AppLogger.log(getApplicationContext(), "exact-catalog", "worker-error", e.getMessage());
            return Result.retry();
        }
    }
}
