package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.SizeF;
import android.widget.RemoteViews;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";
    private static final ExecutorService RENDER_EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidgets(app, manager, ids));
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> {
            updateWidget(app, manager, appWidgetId);
            // Некоторые лаунчеры публикуют окончательные размеры с небольшой задержкой.
            try { Thread.sleep(220L); } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            updateWidget(app, manager, appWidgetId);
        });
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    public static void performScheduledUpdate(Context context) {
        ArtScheduler.enqueueAutomaticUpdate(context, "provider");
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> renderAllWidgetsNow(app));
    }

    static void renderAllWidgetsNow(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bundle options = manager.getAppWidgetOptions(id);
        int[] size = resolveWidgetSize(context, options);
        int width = size[0];
        int height = size[1];
        Bitmap bitmap = ArtRenderer.render(context, entry, width, height);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);
        PendingIntent openApp = openAppIntent(context, 16001 + id);
        // Единая прозрачная зона перекрывает весь виджет: любой тап открывает Activity.
        views.setOnClickPendingIntent(R.id.widget_open_tap_zone, openApp);
        manager.updateAppWidget(id, views);
        AppLogger.log(context, "widget-size", "render", "id=" + id + ", " + width + "x" + height + " dp");
    }

    private static int[] resolveWidgetSize(Context context, Bundle options) {
        int minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        int maxW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, minW);
        int minH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 250);
        int maxH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, minH);
        boolean landscape = context.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;

        int targetW = landscape ? Math.max(minW, maxW) : Math.min(minW, maxW);
        int targetH = landscape ? Math.min(minH, maxH) : Math.max(minH, maxH);
        targetW = Math.max(120, targetW);
        targetH = Math.max(120, targetH);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ArrayList<SizeF> sizes = options.getParcelableArrayList(AppWidgetManager.OPTION_APPWIDGET_SIZES);
            if (sizes != null && !sizes.isEmpty()) {
                SizeF best = null;
                double bestScore = Double.MAX_VALUE;
                for (SizeF candidate : sizes) {
                    if (candidate == null || candidate.getWidth() <= 0 || candidate.getHeight() <= 0) continue;
                    double dw = (candidate.getWidth() - targetW) / Math.max(1.0, targetW);
                    double dh = (candidate.getHeight() - targetH) / Math.max(1.0, targetH);
                    double score = dw * dw + dh * dh;
                    if (score < bestScore) {
                        bestScore = score;
                        best = candidate;
                    }
                }
                if (best != null) {
                    targetW = Math.max(120, Math.round(best.getWidth()));
                    targetH = Math.max(120, Math.round(best.getHeight()));
                }
            }
        }
        return new int[]{targetW, targetH};
    }

    private static void openMainActivity(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        try {
            context.startActivity(intent);
        } catch (Exception e) {
            AppLogger.log(context, "widget-open", "error", e.getMessage());
        }
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
