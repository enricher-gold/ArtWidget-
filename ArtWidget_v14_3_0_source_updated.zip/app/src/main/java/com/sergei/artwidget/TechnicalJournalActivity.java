package com.sergei.artwidget;

import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class TechnicalJournalActivity extends LocalizedActivity {
    private TextView summaryView;
    private TextView logView;
    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        setContentView(createLayout());
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        root.setBackgroundColor(bgColor);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                v.setPadding(dp(16), insets.getSystemWindowInsetTop() + dp(16),
                        dp(16), insets.getSystemWindowInsetBottom() + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        Button back = AppNavigation.backButton(this, textColor, v -> finish());
        bar.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        TextView title = textView(22, true, textColor);
        title.setText(tr("Технический журнал", "Technical log"));
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams barParams = new LinearLayout.LayoutParams(-1, -2);
        barParams.setMargins(0, 0, 0, dp(8));
        root.addView(bar, barParams);

        LinearLayout statusCard = card();
        TextView statusTitle = textView(17, true, textColor);
        statusTitle.setText(tr("Состояние автообновления", "Automatic update status"));
        statusCard.addView(statusTitle, new LinearLayout.LayoutParams(-1, -2));
        summaryView = textView(14, false, textColor);
        summaryView.setLineSpacing(0f, 1.18f);
        LinearLayout.LayoutParams summaryParams = new LinearLayout.LayoutParams(-1, -2);
        summaryParams.setMargins(0, dp(8), 0, 0);
        statusCard.addView(summaryView, summaryParams);
        root.addView(statusCard, sectionParams());

        LinearLayout logCard = card();
        TextView logTitle = textView(17, true, textColor);
        logTitle.setText(tr("Записи", "Entries"));
        logCard.addView(logTitle, new LinearLayout.LayoutParams(-1, -2));
        logView = textView(12, false, subTextColor);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setLineSpacing(0f, 1.08f);
        LinearLayout.LayoutParams logParams = new LinearLayout.LayoutParams(-1, -2);
        logParams.setMargins(0, dp(8), 0, dp(12));
        logCard.addView(logView, logParams);

        Button clear = button(tr("Очистить журнал", "Clear log"));
        clear.setOnClickListener(v -> {
            AppLogger.clear(this);
            refresh();
            Toast.makeText(this, tr("Журнал очищен", "Log cleared"), Toast.LENGTH_SHORT).show();
        });
        logCard.addView(clear, new LinearLayout.LayoutParams(-1, dp(50)));
        root.addView(logCard, sectionParams());
        return scroll;
    }

    private void refresh() {
        if (summaryView != null) summaryView.setText(ArtScheduler.technicalSummary(this));
        if (logView != null) logView.setText(AppLogger.read(this));
    }

    private LinearLayout card() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(rounded(fieldColor, 18, borderColor, 1));
        return card;
    }

    private Button button(String text) {
        Button value = new Button(this);
        value.setText(text);
        value.setAllCaps(false);
        value.setTextSize(15);
        value.setTextColor(textColor);
        value.setMinHeight(0);
        value.setBackground(rounded(fieldColor, 15, borderColor, 1));
        return value;
    }

    private TextView textView(int size, boolean bold, int color) {
        TextView value = new TextView(this);
        value.setTextSize(size);
        value.setTextColor(color);
        if (bold) value.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return value;
    }

    private LinearLayout.LayoutParams sectionParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, 0, 0, dp(12));
        return params;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        borderColor = dark ? 0xFF38383A : 0xFFD9D9DE;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }
}
