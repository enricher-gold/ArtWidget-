package com.sergei.artwidget;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

/** Надёжно выполняет плановую смену картины вне BroadcastReceiver. */
public final class ScheduledArtworkUpdateWorker extends Worker {
    public static final String KEY_REASON = "reason";

    public ScheduledArtworkUpdateWorker(@NonNull Context context,
                                         @NonNull WorkerParameters params) {
        super(context, params);
    }

    @NonNull
    @Override
    public Result doWork() {
        Context app = getApplicationContext();
        if (!ArtScheduler.isEnabled(app)) return Result.success();
        String reason = getInputData().getString(KEY_REASON);
        ArtScheduler.recordAutomaticAttempt(app, reason);
        if (!UpdateCoordinator.tryBegin()) {
            AppLogger.log(app, "auto-update", "busy", "another update is running");
            return Result.retry();
        }
        try {
            ArtRepository repository = new ArtRepository(app);
            ArtEntry before = repository.getCurrent();
            ArtEntry after = repository.fetchNextArtwork();
            ArtWidgetProvider.renderAllWidgetsNow(app);
            String details = after == null ? "success" : after.canonicalKey();
            if (before != null && after != null && before.sameArtwork(after)) {
                throw new IllegalStateException(I18n.t(app,
                        "Автообновление завершилось без смены картины",
                        "Automatic update finished without changing the artwork"));
            }
            ArtScheduler.recordAutomaticSuccess(app, details);
            AppLogger.log(app, "auto-update", "success", details);
            return Result.success();
        } catch (Exception e) {
            String message = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
            ArtScheduler.recordAutomaticError(app, message);
            AppLogger.log(app, "auto-update", "error",
                    "attempt=" + getRunAttemptCount() + " | " + message);
            return Result.retry();
        } finally {
            UpdateCoordinator.finish();
        }
    }
}
