package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";
    private static final ExecutorService RENDER_EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> updateWidgets(app, manager, ids));
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager,
                                          int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        Context app = context.getApplicationContext();
        // Не вычисляем размер bitmap по AppWidget options: некоторые лаунчеры
        // сообщают приблизительный диапазон, из-за чего изображение уменьшалось
        // после отпускания границы. Фактическое масштабирование выполняет layout.
        RENDER_EXECUTOR.execute(() -> updateWidget(app, manager, appWidgetId));
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.ensureScheduled(context);
        CatalogWorkScheduler.ensureInitialized(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    public static void performScheduledUpdate(Context context) {
        ArtScheduler.enqueueAutomaticUpdate(context, "provider");
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        RENDER_EXECUTOR.execute(() -> renderAllWidgetsNow(app));
    }

    static void renderAllWidgetsNow(Context app) {
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bitmap bitmap = ArtRenderer.render(context, entry);

        WidgetSize widgetSize = currentWidgetSize(context, manager, id);
        boolean exactLayout = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
                && widgetSize != null
                && bitmap != null
                && bitmap.getWidth() > 0
                && bitmap.getHeight() > 0;

        boolean landscapeArtwork = bitmap != null
                && bitmap.getWidth() > bitmap.getHeight();
        int layoutId;
        if (exactLayout) {
            layoutId = R.layout.art_widget_exact;
        } else {
            layoutId = landscapeArtwork
                    ? R.layout.art_widget_landscape
                    : R.layout.art_widget;
        }

        RemoteViews views = new RemoteViews(context.getPackageName(), layoutId);
        views.setImageViewBitmap(R.id.widget_image, bitmap);

        if (exactLayout) {
            int[] rendered = renderedArtworkSize(context, widgetSize,
                    bitmap.getWidth(), bitmap.getHeight());
            int imageWidthDp = rendered[0];
            int imageHeightDp = rendered[1];

            views.setViewLayoutWidth(R.id.widget_content,
                    imageWidthDp, TypedValue.COMPLEX_UNIT_DIP);
            views.setViewLayoutWidth(R.id.widget_image,
                    imageWidthDp, TypedValue.COMPLEX_UNIT_DIP);
            views.setViewLayoutHeight(R.id.widget_image,
                    imageHeightDp, TypedValue.COMPLEX_UNIT_DIP);
            views.setViewLayoutWidth(R.id.widget_caption,
                    imageWidthDp, TypedValue.COMPLEX_UNIT_DIP);
        }

        String caption = entry == null
                ? ""
                : entry.widgetCaption(LanguageManager.getLanguage(context));
        caption = caption == null
                ? ""
                : caption.replace('\n', ' ').replace('\r', ' ').trim();
        if (caption.isEmpty()) {
            views.setViewVisibility(R.id.widget_caption, View.GONE);
            views.setTextViewText(R.id.widget_caption, "");
        } else {
            views.setViewVisibility(R.id.widget_caption, View.VISIBLE);
            views.setTextViewText(R.id.widget_caption, caption);
            views.setTextViewTextSize(R.id.widget_caption,
                    TypedValue.COMPLEX_UNIT_SP, 13f);
        }

        views.setOnClickPendingIntent(R.id.widget_open_tap_zone,
                openAppIntent(context, 16001 + id));
        manager.updateAppWidget(id, views);

        String details = "id=" + id
                + ", layout=" + (exactLayout ? "exact" : "legacy")
                + ", widget=" + (widgetSize == null ? "unknown"
                        : widgetSize.widthDp + "x" + widgetSize.heightDp + "dp")
                + ", bitmap=" + (bitmap == null ? "null"
                        : bitmap.getWidth() + "x" + bitmap.getHeight());
        AppLogger.log(context, "widget-render",
                exactLayout ? "exact-fit-caption-attached-13sp"
                        : "legacy-fit-caption-13sp",
                details);
    }

    private static int[] renderedArtworkSize(Context context, WidgetSize widget,
                                               int bitmapWidth, int bitmapHeight) {
        float fontScale = context.getResources().getConfiguration().fontScale;
        int captionHeightDp = Math.max(20,
                Math.round(13f * Math.max(1f, fontScale) * 1.35f) + 4);
        int availableWidth = Math.max(1, widget.widthDp);
        int availableHeight = Math.max(1, widget.heightDp - captionHeightDp);

        float artworkAspect = bitmapWidth / (float) bitmapHeight;
        float availableAspect = availableWidth / (float) availableHeight;
        int width;
        int height;
        if (availableAspect > artworkAspect) {
            height = availableHeight;
            width = Math.max(1, Math.round(height * artworkAspect));
        } else {
            width = availableWidth;
            height = Math.max(1, Math.round(width / artworkAspect));
        }
        return new int[]{width, height};
    }

    private static WidgetSize currentWidgetSize(Context context,
                                                AppWidgetManager manager, int id) {
        try {
            Bundle options = manager == null ? null : manager.getAppWidgetOptions(id);
            if (options == null) return null;

            int minWidth = options.getInt(
                    AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 0);
            int maxWidth = options.getInt(
                    AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, 0);
            int minHeight = options.getInt(
                    AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 0);
            int maxHeight = options.getInt(
                    AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, 0);

            int orientation = context.getResources().getConfiguration().orientation;
            int width;
            int height;
            if (orientation == android.content.res.Configuration.ORIENTATION_LANDSCAPE) {
                width = maxWidth > 0 ? maxWidth : minWidth;
                height = minHeight > 0 ? minHeight : maxHeight;
            } else {
                width = minWidth > 0 ? minWidth : maxWidth;
                height = maxHeight > 0 ? maxHeight : minHeight;
            }
            if (width <= 0 || height <= 0) return null;
            return new WidgetSize(width, height);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static final class WidgetSize {
        final int widthDp;
        final int heightDp;

        WidgetSize(int widthDp, int heightDp) {
            this.widthDp = widthDp;
            this.heightDp = heightDp;
        }
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP
                | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
