package com.sergei.artwidget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends LocalizedActivity {
    private static final int SPACE = 8;
    private static final int OUTER = 16;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final ExecutorService imageExecutor = Executors.newSingleThreadExecutor();

    private ImageView previewImage;
    private TextView captionView;
    private TextView descriptionView;
    private TextView statusView;
    private Button nextButton;
    private ImageButton previousButton;
    private ImageButton forwardButton;
    private Button addWidgetButton;
    private ImageButton likeButton;
    private ImageButton dislikeButton;
    private ArtEntry currentEntry;
    private boolean busy;
    private boolean descriptionRefreshRunning;
    private String descriptionRefreshFailedQid = "";
    private int previewRequestId;
    private int uiRequestId;
    private boolean firstResume = true;
    private boolean canGoBack;
    private boolean canGoForward;

    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;
    private int dangerColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        setContentView(createLayout());
        showInitialState();
        updateUi();

        // WorkManager и перерисовка виджета не должны задерживать первый кадр Activity.
        executor.execute(() -> {
            CatalogWorkScheduler.ensureInitialized(getApplicationContext());
            ArtWidgetProvider.updateAllWidgets(getApplicationContext());
        });
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        // singleTask возвращает уже открытый экран вместо создания второй копии.
        // Текущая операция поиска продолжает выполняться тем же экземпляром Activity.
        if (!busy) updateUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (firstResume) {
            firstResume = false;
        } else {
            updateUi();
        }
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        imageExecutor.shutdownNow();
        super.onDestroy();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(OUTER), dp(OUTER), dp(OUTER), dp(24));
        root.setBackgroundColor(bgColor);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(OUTER), top + dp(OUTER), dp(OUTER), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }

        LinearLayout appBar = horizontalRow();
        TextView title = textView(22, true, textColor);
        title.setText("Art Widget");
        title.setGravity(Gravity.CENTER_VERTICAL);
        appBar.addView(title, new LinearLayout.LayoutParams(0, dp(48), 1f));

        ImageButton settingsButton = new ImageButton(this);
        settingsButton.setImageResource(R.drawable.ic_settings);
        settingsButton.setImageTintList(ColorStateList.valueOf(textColor));
        settingsButton.setScaleType(ImageView.ScaleType.CENTER);
        settingsButton.setPadding(dp(12), dp(12), dp(12), dp(12));
        settingsButton.setBackgroundColor(Color.TRANSPARENT);
        settingsButton.setContentDescription(tr("Настройки", "Settings"));
        settingsButton.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        appBar.addView(settingsButton, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout.LayoutParams appBarParams = matchWrap();
        appBarParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(appBar, appBarParams);

        previewImage = new ImageView(this);
        previewImage.setAdjustViewBounds(true);
        previewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewImage.setBackgroundColor(Color.TRANSPARENT);
        previewImage.setContentDescription(tr("Текущая картина", "Current artwork"));
        previewImage.setOnClickListener(v -> openFullscreen());
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(320));
        imageParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(previewImage, imageParams);

        LinearLayout reactionRow = horizontalRow();
        reactionRow.setGravity(Gravity.CENTER_VERTICAL);
        dislikeButton = makeIconButton(R.drawable.ic_heart_broken, tr("Не нравится", "Dislike"));
        likeButton = makeIconButton(R.drawable.ic_heart_outline, tr("Добавить в избранное", "Add to favorites"));
        reactionRow.addView(dislikeButton, new LinearLayout.LayoutParams(dp(52), dp(48)));
        reactionRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        reactionRow.addView(likeButton, new LinearLayout.LayoutParams(dp(52), dp(48)));
        LinearLayout.LayoutParams reactionParams = matchWrap();
        reactionParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(reactionRow, reactionParams);
        dislikeButton.setOnClickListener(v -> runOperation(Operation.DISLIKE));
        likeButton.setOnClickListener(v -> toggleFavorite());

        captionView = textView(20, true, linkColor);
        captionView.setGravity(Gravity.CENTER_HORIZONTAL);
        captionView.setPadding(dp(4), 0, dp(4), dp(4));
        captionView.setCompoundDrawablePadding(dp(6));
        captionView.setOnClickListener(v -> openArticle());
        root.addView(captionView, matchWrap());

        TextView sourceView = textView(13, false, subTextColor);
        sourceView.setGravity(Gravity.CENTER_HORIZONTAL);
        sourceView.setText(tr("Источник: Wikipedia.org", "Source: Wikipedia.org"));
        LinearLayout.LayoutParams sourceParams = matchWrap();
        sourceParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(sourceView, sourceParams);

        // Навигация закреплена до описания, поэтому её положение не зависит
        // от длины текста статьи.
        LinearLayout navigationCard = sectionCard();
        navigationCard.addView(sectionTitle(tr("Навигация", "Navigation")), matchWrap());
        nextButton = makeButton(tr("Обновить картину на виджете", "Update artwork on widget"), true);
        LinearLayout.LayoutParams updateParams = new LinearLayout.LayoutParams(-1, dp(52));
        updateParams.setMargins(0, dp(SPACE), 0, dp(SPACE));
        navigationCard.addView(nextButton, updateParams);

        LinearLayout navRow = horizontalRow();
        previousButton = makeIconButton(R.drawable.ic_history_back, tr("Предыдущая картина", "Previous artwork"));
        forwardButton = makeIconButton(R.drawable.ic_history_forward, tr("Следующая картина из истории", "Next artwork from history"));
        navRow.addView(previousButton, weightedButtonParams());
        LinearLayout.LayoutParams forwardParams = weightedButtonParams();
        forwardParams.setMargins(dp(SPACE), 0, 0, 0);
        navRow.addView(forwardButton, forwardParams);
        navigationCard.addView(navRow, matchWrap());

        addWidgetButton = makeButton(tr("Добавить виджет на экран", "Add widget to home screen"), false);
        LinearLayout.LayoutParams addWidgetParams = new LinearLayout.LayoutParams(-1, dp(50));
        addWidgetParams.setMargins(0, dp(SPACE), 0, 0);
        navigationCard.addView(addWidgetButton, addWidgetParams);
        root.addView(navigationCard, sectionParams());
        previousButton.setOnClickListener(v -> runOperation(Operation.PREVIOUS));
        nextButton.setOnClickListener(v -> runOperation(Operation.NEXT));
        forwardButton.setOnClickListener(v -> runOperation(Operation.FORWARD));
        addWidgetButton.setOnClickListener(v -> WidgetPinHelper.requestPinWidget(this));

        statusView = textView(14, false, subTextColor);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackground(rounded(fieldColor, 13, borderColor, 1));
        statusView.setVisibility(View.GONE);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.setMargins(0, 0, 0, dp(12));
        root.addView(statusView, statusParams);

        LinearLayout aboutCard = sectionCard();
        aboutCard.addView(sectionTitle(tr("О картине", "About the artwork")), matchWrap());
        descriptionView = textView(15, false, textColor);
        descriptionView.setLineSpacing(0f, 1.18f);
        LinearLayout.LayoutParams descParams = matchWrap();
        descParams.setMargins(0, dp(SPACE), 0, 0);
        aboutCard.addView(descriptionView, descParams);
        root.addView(aboutCard, sectionParams());

        return scroll;
    }

    private void runOperation(Operation operation) {
        if (!UpdateCoordinator.tryBegin()) {
            showStatus(tr("Обновление уже выполняется", "An update is already in progress"));
            return;
        }
        setBusy(true);
        boolean onlyNew = operation == Operation.NEXT
                && new ArtRepository(this).isOnlyNewMode();
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(this);
                if (operation == Operation.NEXT) repo.fetchNextArtworkForManualRequest();
                else if (operation == Operation.PREVIOUS) repo.goPrevious();
                else if (operation == Operation.FORWARD) repo.goForward();
                else if (operation == Operation.DISLIKE) repo.dislikeCurrentAndFetchNext();
                ArtScheduler.scheduleNext(this);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    hideStatus();
                    setBusy(false);
                    updateUi();
                });
            } catch (Exception e) {
                AppLogger.log(this, operation.name(), "error", e.getMessage());
                runOnUiThread(() -> {
                    showStatus(friendlyError(e));
                    setBusy(false);
                    updateUi();
                });
            } finally {
                UpdateCoordinator.finish();
            }
        });
    }

    private void toggleFavorite() {
        if (currentEntry == null) return;
        ArtRepository repo = new ArtRepository(this);
        boolean value = repo.toggleFavorite(currentEntry);
        Toast.makeText(this, value ? tr("Добавлено в избранное", "Added to favorites") : tr("Удалено из избранного", "Removed from favorites"), Toast.LENGTH_SHORT).show();
        updateUi();
    }

    private void showInitialState() {
        previewImage.setVisibility(View.GONE);
        captionView.setText(tr("Загрузка…", "Loading…"));
        descriptionView.setText("");
        dislikeButton.setEnabled(false);
        likeButton.setEnabled(false);
        previousButton.setEnabled(false);
        nextButton.setEnabled(false);
        forwardButton.setEnabled(false);
        setReactionState(false, false);
    }

    /** Чтение истории и пользовательских списков выполняется вне главного потока. */
    private void updateUi() {
        if (executor.isShutdown()) return;
        final int requestId = ++uiRequestId;
        executor.execute(() -> {
            ArtRepository repo = new ArtRepository(getApplicationContext());
            ArtEntry entry = repo.getCurrent();
            boolean favorite = entry != null && repo.isFavorite(entry);
            boolean disliked = entry != null && repo.isDisliked(entry);
            boolean needsDescription = entry != null && repo.needsWikipediaDescription(entry);
            String language = LanguageManager.getLanguage(getApplicationContext());
            boolean back = repo.canGoPrevious();
            boolean forward = repo.canGoForward();

            runOnUiThread(() -> {
                if (requestId != uiRequestId || isFinishing() || isDestroyed()) return;
                currentEntry = entry;
                canGoBack = back;
                canGoForward = forward;
                updatePreviewAsync(entry);

                if (entry == null) {
                    captionView.setText(tr("Картина пока не загружена", "No artwork has been loaded yet"));
                    captionView.setCompoundDrawables(null, null, null, null);
                    descriptionView.setText(tr("После загрузки здесь появится краткое описание произведения.", "A short description will appear here after the artwork is loaded."));
                    dislikeButton.setEnabled(false);
                    likeButton.setEnabled(false);
                    setReactionState(false, false);
                } else {
                    captionView.setText(entry.caption(language));
                    applyExternalLinkIcon();
                    if (needsDescription) {
                        descriptionView.setText(tr("Загружается описание произведения…", "Loading artwork description…"));
                        refreshWikipediaDescriptionAsync(entry.qid);
                    } else {
                        String localizedDescription = entry.localizedDescription(language);
                        descriptionView.setText(localizedDescription.isEmpty()
                                ? tr("Краткое описание отсутствует", "No description available")
                                : localizedDescription);
                    }
                    dislikeButton.setEnabled(!busy);
                    likeButton.setEnabled(!busy);
                    setReactionState(favorite, disliked);
                }
                updateNavigationAvailability();
            });
        });
    }

    private void refreshWikipediaDescriptionAsync(String qid) {
        if (qid == null || qid.isEmpty() || descriptionRefreshRunning
                || qid.equals(descriptionRefreshFailedQid)) return;
        descriptionRefreshRunning = true;
        executor.execute(() -> {
            try {
                new ArtRepository(this).refreshCurrentWikipediaDescription();
                runOnUiThread(() -> {
                    descriptionRefreshRunning = false;
                    descriptionRefreshFailedQid = "";
                    ArtWidgetProvider.updateAllWidgets(this);
                    updateUi();
                });
            } catch (Exception e) {
                AppLogger.log(this, "description", "error", e.getMessage());
                runOnUiThread(() -> {
                    descriptionRefreshRunning = false;
                    descriptionRefreshFailedQid = qid;
                    if (currentEntry != null && qid.equals(currentEntry.qid)) {
                        descriptionView.setText(tr("Описание произведения в Wikipedia.org недоступно.", "The artwork description is unavailable on Wikipedia.org."));
                    }
                });
            }
        });
    }

    private void updateNavigationAvailability() {
        boolean back = !busy && canGoBack;
        boolean forward = !busy && canGoForward;
        previousButton.setEnabled(back);
        previousButton.setAlpha(back ? 1f : 0.42f);
        forwardButton.setEnabled(forward);
        forwardButton.setAlpha(forward ? 1f : 0.42f);
        nextButton.setEnabled(!busy);
        nextButton.setAlpha(busy ? 0.55f : 1f);
        updatePrimaryButtonState();
        if (addWidgetButton != null) {
            addWidgetButton.setVisibility(WidgetPinHelper.hasActiveWidgets(this) ? View.GONE : View.VISIBLE);
        }
    }

    private void setReactionState(boolean favorite, boolean disliked) {
        likeButton.setImageResource(favorite ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        likeButton.setColorFilter(favorite ? dangerColor : textColor);
        likeButton.setBackground(rounded(favorite ? withAlpha(dangerColor, 28) : fieldColor, 15,
                favorite ? dangerColor : borderColor, 1));
        likeButton.setContentDescription(favorite ? tr("Удалить из избранного", "Remove from favorites") : tr("Добавить в избранное", "Add to favorites"));

        if (disliked) {
            dislikeButton.setImageResource(R.drawable.ic_heart_broken_filled_black);
            dislikeButton.clearColorFilter();
            dislikeButton.setBackground(rounded(0xFFEDEDEF, 15, 0xFF000000, 1));
        } else {
            dislikeButton.setImageResource(R.drawable.ic_heart_broken_v1426);
            dislikeButton.setColorFilter(textColor);
            dislikeButton.setBackground(rounded(fieldColor, 15, borderColor, 1));
        }
        dislikeButton.setContentDescription(disliked ? tr("Дизлайк установлен", "Disliked") : tr("Не нравится", "Dislike"));
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private void updatePreviewAsync(ArtEntry entry) {
        final int requestId = ++previewRequestId;
        previewImage.setImageDrawable(null);
        if (entry == null || entry.localPath == null || entry.localPath.isEmpty()) {
            previewImage.setVisibility(View.GONE);
            return;
        }
        final String path = entry.localPath;
        imageExecutor.execute(() -> {
            File file = new File(path);
            if (!file.exists() || file.length() == 0) {
                runOnUiThread(() -> {
                    if (requestId == previewRequestId) previewImage.setVisibility(View.GONE);
                });
                return;
            }
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
            BitmapFactory.Options opts = new BitmapFactory.Options();
            int max = Math.max(bounds.outWidth, bounds.outHeight);
            opts.inSampleSize = max > 3000 ? 4 : (max > 1800 ? 2 : 1);
            Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
            runOnUiThread(() -> {
                if (requestId != previewRequestId) {
                    if (bitmap != null) bitmap.recycle();
                    return;
                }
                if (bitmap == null) {
                    previewImage.setVisibility(View.GONE);
                } else {
                    previewImage.setVisibility(View.VISIBLE);
                    previewImage.setImageBitmap(bitmap);
                }
            });
        });
    }

    private void openArticle() {
        if (currentEntry == null || currentEntry.sourceUrl.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentEntry.sourceUrl))); }
        catch (Exception e) { showStatus(tr("Не удалось открыть статью", "Could not open the article")); }
    }

    private void openFullscreen() {
        if (currentEntry == null) return;
        Intent intent = new Intent(this, FullscreenActivity.class);
        intent.putExtra("qid", currentEntry.qid);
        startActivity(intent);
    }

    private void setBusy(boolean busy) {
        this.busy = busy;
        for (View v : new View[]{dislikeButton, likeButton}) {
            if (v != null) {
                v.setEnabled(!busy);
                v.setAlpha(busy ? 0.55f : 1f);
            }
        }
        updatePrimaryButtonState();
        updateNavigationAvailability();
    }

    private void showStatus(String text) {
        statusView.setText(text == null ? "" : text);
        statusView.setVisibility(View.VISIBLE);
    }

    private void hideStatus() {
        statusView.setVisibility(View.GONE);
    }

    private String friendlyError(Exception e) {
        String msg = e == null ? null : e.getMessage();
        if (msg == null || msg.trim().isEmpty()) return tr("Не удалось выполнить операцию", "The operation could not be completed");
        if (msg.contains("HTTP 429") || msg.contains("Слишком частые") || msg.contains("Too many requests")) return tr("Слишком частые запросы. Повторите позже", "Too many requests. Try again later");
        if (msg.contains("Unable to resolve host") || msg.contains("No address associated") || msg.contains("Не удалось определить адрес")) {
            return tr("Нет подключения к интернету или DNS временно недоступен", "No internet connection or DNS is temporarily unavailable");
        }
        if (msg.toLowerCase().contains("timeout") || msg.contains("не ответил вовремя")) return tr("Сервер не ответил вовремя. Повторите позже", "The server did not respond in time. Try again later");
        return msg.length() > 220 ? msg.substring(0, 220) + "…" : msg;
    }


    private void applyExternalLinkIcon() {
        Drawable icon = getResources().getDrawable(R.drawable.ic_external_open);
        if (icon != null) {
            icon.setBounds(0, 0, dp(21), dp(21));
            icon.setTint(linkColor);
        }
        captionView.setCompoundDrawables(null, null, icon, null);
    }

    private void updatePrimaryButtonState() {
        if (nextButton == null) return;
        if (busy) {
            nextButton.setText(tr("Обновляю…", "Updating…"));
            Drawable brush = getResources().getDrawable(R.drawable.ic_brush);
            if (brush != null) {
                brush.setBounds(0, 0, dp(20), dp(20));
                brush.setTint(Color.WHITE);
            }
            nextButton.setCompoundDrawablePadding(dp(8));
            nextButton.setCompoundDrawables(null, null, brush, null);
        } else {
            nextButton.setText(tr("Обновить картину на виджете", "Update artwork on widget"));
            nextButton.setCompoundDrawables(null, null, null, null);
        }
    }

    private Button makeButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15, primary ? 0xFF007AFF : borderColor, 1));
        return b;
    }

    private ImageButton makeIconButton(int iconRes, String description) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(iconRes);
        b.setColorFilter(textColor);
        b.setContentDescription(description);
        b.setPadding(dp(11), dp(9), dp(11), dp(9));
        b.setBackground(rounded(fieldColor, 15, borderColor, 1));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setImageTintList(ColorStateList.valueOf(textColor));
            b.setImageTintList(null);
        }
        return b;
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(rounded(fieldColor, 18, borderColor, 1));
        return card;
    }

    private TextView sectionTitle(String title) {
        TextView tv = textView(17, true, textColor);
        tv.setText(title);
        return tv;
    }

    private LinearLayout.LayoutParams sectionParams() {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private TextView textView(int size, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setTextSize(size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        return new LinearLayout.LayoutParams(0, dp(48), 1f);
    }

    private LinearLayout.LayoutParams weightedButtonParamsWithMargins() {
        LinearLayout.LayoutParams p = weightedButtonParams();
        p.setMargins(dp(SPACE), 0, dp(SPACE), 0);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        borderColor = dark ? 0xFF38383A : 0xFFD9D9DE;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;
        dangerColor = 0xFFFF3B30;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private enum Operation { NEXT, PREVIOUS, FORWARD, DISLIKE }
}
