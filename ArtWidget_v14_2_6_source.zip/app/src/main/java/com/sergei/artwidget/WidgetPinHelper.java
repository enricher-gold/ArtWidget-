package com.sergei.artwidget;

import android.app.Activity;
import android.app.AlertDialog;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class WidgetPinHelper {
    private WidgetPinHelper() { }

    public static boolean hasActiveWidgets(Context context) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context.getApplicationContext());
            int[] ids = manager.getAppWidgetIds(new ComponentName(context.getApplicationContext(), ArtWidgetProvider.class));
            return ids != null && ids.length > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean canRequestPin(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return false;
        try {
            return AppWidgetManager.getInstance(context.getApplicationContext()).isRequestPinAppWidgetSupported();
        } catch (Exception ignored) {
            return false;
        }
    }

    public static void requestPinWidget(Activity activity) {
        if (activity == null || activity.isFinishing()) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && canRequestPin(activity)) {
            try {
                AppWidgetManager manager = AppWidgetManager.getInstance(activity.getApplicationContext());
                ComponentName provider = new ComponentName(activity.getApplicationContext(), ArtWidgetProvider.class);
                manager.requestPinAppWidget(provider, null, null);
                return;
            } catch (Exception e) {
                AppLogger.log(activity, "pin-widget", "error", e.getMessage());
            }
        }
        showManualInstruction(activity);
    }

    private static void showManualInstruction(Activity activity) {
        new AlertDialog.Builder(activity)
                .setTitle(I18n.t(activity, "Добавление виджета", "Adding a widget"))
                .setMessage(I18n.t(activity,
                        "Этот экран телефона не поддерживает автоматическое добавление виджета. Добавьте его вручную: удерживайте пустое место на главном экране, выберите «Виджеты» и найдите Art Widget.",
                        "This home screen does not support automatic widget pinning. Add it manually: long-press an empty area on the home screen, choose Widgets, and find Art Widget."))
                .setPositiveButton(I18n.t(activity, "Понятно", "OK"), null)
                .show();
    }
}
