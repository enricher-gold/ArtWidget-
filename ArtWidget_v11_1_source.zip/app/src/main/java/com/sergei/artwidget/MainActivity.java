package com.sergei.artwidget;

import android.app.Activity;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int SPACE = 8;
    private static final int OUTER = 16;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private ImageView previewImage;
    private TextView captionView;
    private TextView descriptionView;
    private TextView statusView;
    private TextView cacheInfoView;
    private TextView nextUpdateView;
    private Button nextButton;
    private Button previousButton;
    private Button forwardButton;
    private ImageButton likeButton;
    private ImageButton dislikeButton;
    private Button cacheButton;
    private Button saveIntervalButton;
    private Button exactAlarmButton;
    private Button filterButton;
    private Button allButton;
    private Button adultButton;
    private Button logButton;
    private EditText intervalValue;
    private Spinner unitSpinner;
    private ArtEntry currentEntry;

    private int bgColor;
    private int textColor;
    private int subTextColor;
    private int fieldColor;
    private int borderColor;
    private int linkColor;
    private int dangerColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setupColors();
        setContentView(createLayout());
        updateUi();
        ArtWidgetProvider.updateAllWidgets(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateUi();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private View createLayout() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(bgColor);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(OUTER), dp(OUTER), dp(OUTER), dp(24));
        root.setBackgroundColor(bgColor);
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            root.setOnApplyWindowInsetsListener((v, insets) -> {
                int top = insets.getSystemWindowInsetTop();
                int bottom = insets.getSystemWindowInsetBottom();
                v.setPadding(dp(OUTER), top + dp(OUTER), dp(OUTER), bottom + dp(24));
                return insets;
            });
            root.requestApplyInsets();
        }

        previewImage = new ImageView(this);
        previewImage.setAdjustViewBounds(true);
        previewImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        previewImage.setBackgroundColor(Color.TRANSPARENT);
        previewImage.setContentDescription("Текущая картина");
        previewImage.setOnClickListener(v -> openFullscreen());
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(300));
        imageParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(previewImage, imageParams);

        LinearLayout reactionRow = horizontalRow();
        reactionRow.setGravity(Gravity.CENTER_VERTICAL);
        dislikeButton = makeIconButton(com.sergei.artwidget.R.drawable.ic_heart_off, "Не нравится");
        likeButton = makeIconButton(com.sergei.artwidget.R.drawable.ic_heart_outline, "Добавить в избранное");
        reactionRow.addView(dislikeButton, new LinearLayout.LayoutParams(dp(52), dp(48)));
        reactionRow.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        reactionRow.addView(likeButton, new LinearLayout.LayoutParams(dp(52), dp(48)));
        LinearLayout.LayoutParams reactionParams = matchWrap();
        reactionParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(reactionRow, reactionParams);
        dislikeButton.setOnClickListener(v -> runOperation(Operation.DISLIKE));
        likeButton.setOnClickListener(v -> toggleFavorite());

        captionView = textView(20, true, linkColor);
        captionView.setGravity(Gravity.CENTER_HORIZONTAL);
        captionView.setPadding(dp(4), 0, dp(4), dp(4));
        captionView.setOnClickListener(v -> openArticle());
        root.addView(captionView, matchWrap());

        TextView sourceView = textView(13, false, subTextColor);
        sourceView.setGravity(Gravity.CENTER_HORIZONTAL);
        sourceView.setText("Источник: русская Википедия / Wikimedia Commons");
        LinearLayout.LayoutParams sourceParams = matchWrap();
        sourceParams.setMargins(0, 0, 0, dp(16));
        root.addView(sourceView, sourceParams);

        LinearLayout aboutCard = sectionCard();
        aboutCard.addView(sectionTitle("О картине"), matchWrap());
        descriptionView = textView(15, false, textColor);
        descriptionView.setLineSpacing(0f, 1.18f);
        LinearLayout.LayoutParams descParams = matchWrap();
        descParams.setMargins(0, dp(6), 0, 0);
        aboutCard.addView(descriptionView, descParams);
        root.addView(aboutCard, sectionParams());

        statusView = textView(14, false, subTextColor);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackground(rounded(fieldColor, 13, borderColor, 1));
        statusView.setVisibility(View.GONE);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.setMargins(0, 0, 0, dp(SPACE));
        root.addView(statusView, statusParams);

        LinearLayout navigationCard = sectionCard();
        navigationCard.addView(sectionTitle("Навигация"), matchWrap());
        LinearLayout navRow = horizontalRow();
        previousButton = makeButton("Назад", false);
        nextButton = makeButton("Новая", true);
        forwardButton = makeButton("Вперёд", false);
        navRow.addView(previousButton, weightedButtonParams());
        navRow.addView(nextButton, weightedButtonParamsWithMargins());
        navRow.addView(forwardButton, weightedButtonParams());
        LinearLayout.LayoutParams navParams = matchWrap();
        navParams.setMargins(0, dp(SPACE), 0, 0);
        navigationCard.addView(navRow, navParams);
        root.addView(navigationCard, sectionParams());
        previousButton.setOnClickListener(v -> runOperation(Operation.PREVIOUS));
        nextButton.setOnClickListener(v -> runOperation(Operation.NEXT));
        forwardButton.setOnClickListener(v -> runOperation(Operation.FORWARD));

        LinearLayout contentCard = sectionCard();
        contentCard.addView(sectionTitle("Контент"), matchWrap());
        LinearLayout segment = horizontalRow();
        filterButton = makeSegment("Фильтр");
        allButton = makeSegment("Все");
        adultButton = makeSegment("18+");
        segment.addView(filterButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        segment.addView(allButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        segment.addView(adultButton, new LinearLayout.LayoutParams(0, dp(46), 1f));
        LinearLayout.LayoutParams segmentParams = matchWrap();
        segmentParams.setMargins(0, dp(SPACE), 0, 0);
        contentCard.addView(segment, segmentParams);
        root.addView(contentCard, sectionParams());
        filterButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_FILTER));
        allButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_ALL));
        adultButton.setOnClickListener(v -> setContentMode(ArtRepository.CONTENT_ADULT_ONLY));

        LinearLayout galleryCard = sectionCard();
        galleryCard.addView(sectionTitle("Локальные изображения"), matchWrap());
        cacheInfoView = textView(14, false, subTextColor);
        LinearLayout.LayoutParams cacheInfoParams = matchWrap();
        cacheInfoParams.setMargins(0, dp(6), 0, dp(SPACE));
        galleryCard.addView(cacheInfoView, cacheInfoParams);
        cacheButton = makeButton("Галерея кэша", false);
        galleryCard.addView(cacheButton, new LinearLayout.LayoutParams(-1, dp(50)));
        root.addView(galleryCard, sectionParams());
        cacheButton.setOnClickListener(v -> startActivity(new Intent(this, GalleryActivity.class)));

        LinearLayout intervalCard = sectionCard();
        intervalCard.addView(sectionTitle("Автообновление"), matchWrap());
        LinearLayout intervalRow = horizontalRow();
        intervalValue = new EditText(this);
        intervalValue.setInputType(InputType.TYPE_CLASS_NUMBER);
        intervalValue.setSingleLine(true);
        intervalValue.setTextColor(textColor);
        intervalValue.setTextSize(16);
        intervalValue.setPadding(dp(14), 0, dp(14), 0);
        intervalValue.setBackground(rounded(fieldColor, 13, borderColor, 1));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(48), 1f);
        inputParams.setMargins(0, 0, dp(SPACE), 0);
        intervalRow.addView(intervalValue, inputParams);

        unitSpinner = new Spinner(this);
        String[] units = new String[]{"секунд", "минут", "часов"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, units) {
            @Override
            public View getView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getView(position, convertView, parent);
                if (view instanceof TextView) {
                    ((TextView) view).setTextColor(textColor);
                    ((TextView) view).setTextSize(16);
                }
                return view;
            }

            @Override
            public View getDropDownView(int position, View convertView, android.view.ViewGroup parent) {
                View view = super.getDropDownView(position, convertView, parent);
                if (view instanceof TextView) ((TextView) view).setTextColor(textColor);
                view.setBackgroundColor(bgColor);
                return view;
            }
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitSpinner.setAdapter(adapter);
        unitSpinner.setBackground(rounded(fieldColor, 13, borderColor, 1));
        intervalRow.addView(unitSpinner, new LinearLayout.LayoutParams(0, dp(48), 1f));
        LinearLayout.LayoutParams intervalRowParams = matchWrap();
        intervalRowParams.setMargins(0, dp(SPACE), 0, dp(SPACE));
        intervalCard.addView(intervalRow, intervalRowParams);

        saveIntervalButton = makeButton("Сохранить интервал", true);
        intervalCard.addView(saveIntervalButton, new LinearLayout.LayoutParams(-1, dp(50)));
        saveIntervalButton.setOnClickListener(v -> saveInterval());

        nextUpdateView = textView(14, false, subTextColor);
        LinearLayout.LayoutParams nextUpdateParams = matchWrap();
        nextUpdateParams.setMargins(dp(4), dp(SPACE), dp(4), 0);
        intervalCard.addView(nextUpdateView, nextUpdateParams);

        exactAlarmButton = makeButton("Разрешить точное автообновление", false);
        LinearLayout.LayoutParams exactParams = new LinearLayout.LayoutParams(-1, dp(50));
        exactParams.setMargins(0, dp(SPACE), 0, 0);
        intervalCard.addView(exactAlarmButton, exactParams);
        exactAlarmButton.setOnClickListener(v -> openExactAlarmSettings());
        root.addView(intervalCard, sectionParams());

        logButton = makeButton("Журнал", false);
        LinearLayout.LayoutParams logParams = new LinearLayout.LayoutParams(-1, dp(50));
        logParams.setMargins(0, dp(8), 0, 0);
        root.addView(logButton, logParams);
        logButton.setOnClickListener(v -> startActivity(new Intent(this, LogActivity.class)));

        applyIntervalToControls(ArtScheduler.getIntervalSeconds(this));
        return scroll;
    }

    private void runOperation(Operation operation) {
        if (!UpdateCoordinator.tryBegin()) {
            showStatus("Обновление уже выполняется");
            return;
        }
        setBusy(true);
        if (operation == Operation.NEXT) showStatus("Загружаю новую картину…");
        executor.execute(() -> {
            try {
                ArtRepository repo = new ArtRepository(this);
                if (operation == Operation.NEXT) repo.fetchNextArtwork();
                else if (operation == Operation.PREVIOUS) repo.goPrevious();
                else if (operation == Operation.FORWARD) repo.goForward();
                else if (operation == Operation.DISLIKE) repo.dislikeCurrentAndFetchNext();
                ArtScheduler.scheduleNext(this);
                runOnUiThread(() -> {
                    ArtWidgetProvider.updateAllWidgets(this);
                    hideStatus();
                    setBusy(false);
                    updateUi();
                });
            } catch (Exception e) {
                if (operation != Operation.NEXT) AppLogger.log(this, operation.name(), "error", e.getMessage());
                runOnUiThread(() -> {
                    showStatus(friendlyError(e));
                    setBusy(false);
                    updateUi();
                });
            } finally {
                UpdateCoordinator.finish();
            }
        });
    }

    private void toggleFavorite() {
        if (currentEntry == null) return;
        ArtRepository repo = new ArtRepository(this);
        boolean value = repo.toggleFavorite(currentEntry);
        Toast.makeText(this, value ? "Добавлено в избранное" : "Удалено из избранного", Toast.LENGTH_SHORT).show();
        updateUi();
    }

    private void setContentMode(int mode) {
        new ArtRepository(this).setContentMode(mode);
        updateSegments(mode);
        Toast.makeText(this, mode == 0 ? "Откровенные произведения скрыты" : mode == 1 ? "Показываются все произведения" : "Показываются только 18+", Toast.LENGTH_SHORT).show();
    }

    private void saveInterval() {
        int value;
        try {
            value = Integer.parseInt(intervalValue.getText().toString().trim());
        } catch (Exception e) {
            showStatus("Введите число для интервала автообновления");
            return;
        }
        if (value <= 0) {
            showStatus("Интервал должен быть больше нуля");
            return;
        }
        long seconds = value;
        int unit = unitSpinner.getSelectedItemPosition();
        if (unit == 1) seconds *= 60L;
        if (unit == 2) seconds *= 3600L;
        seconds = Math.max(ArtScheduler.MIN_INTERVAL_SECONDS, Math.min(ArtScheduler.MAX_INTERVAL_SECONDS, seconds));
        ArtScheduler.setIntervalSeconds(this, (int) seconds);
        applyIntervalToControls((int) seconds);
        nextUpdateView.setText(ArtScheduler.nextUpdateDisplay(this));
        hideStatus();
        Toast.makeText(this, "Интервал сохранён", Toast.LENGTH_SHORT).show();
    }

    private void updateUi() {
        ArtRepository repo = new ArtRepository(this);
        currentEntry = repo.getCurrent();
        updatePreview(currentEntry);
        if (currentEntry == null) {
            captionView.setText("Картина пока не загружена");
            descriptionView.setText("После загрузки здесь появится краткое описание произведения.");
            dislikeButton.setEnabled(false);
            likeButton.setEnabled(false);
            setReactionState(false, false);
        } else {
            captionView.setText(currentEntry.caption());
            String description = currentEntry.description == null || currentEntry.description.trim().isEmpty()
                    ? "Краткое описание отсутствует" : currentEntry.description;
            descriptionView.setText(description);
            dislikeButton.setEnabled(true);
            likeButton.setEnabled(true);
            setReactionState(repo.isFavorite(currentEntry.qid), repo.isDisliked(currentEntry.qid));
        }
        cacheInfoView.setText("Кэш: " + repo.getCacheCount() + " из " + ArtRepository.MAX_CACHE_FILES
                + " · Каталог: " + repo.getCatalogCount()
                + " · История: " + Math.max(0, repo.getHistoryIndex() + 1) + " из " + repo.getHistoryCount());
        nextUpdateView.setText(ArtScheduler.nextUpdateDisplay(this));
        exactAlarmButton.setVisibility(ArtScheduler.canScheduleExact(this) ? View.GONE : View.VISIBLE);
        updateSegments(repo.getContentMode());
    }

    private void setReactionState(boolean favorite, boolean disliked) {
        likeButton.setImageResource(favorite ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
        likeButton.setColorFilter(favorite ? dangerColor : textColor);
        likeButton.setBackground(rounded(favorite ? withAlpha(dangerColor, 28) : fieldColor, 15,
                favorite ? dangerColor : borderColor, 1));
        likeButton.setContentDescription(favorite ? "Удалить из избранного" : "Добавить в избранное");

        dislikeButton.setImageResource(R.drawable.ic_heart_off);
        dislikeButton.setColorFilter(disliked ? dangerColor : textColor);
        dislikeButton.setBackground(rounded(disliked ? withAlpha(dangerColor, 28) : fieldColor, 15,
                disliked ? dangerColor : borderColor, 1));
        dislikeButton.setContentDescription(disliked ? "Дизлайк установлен" : "Не нравится");
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private void updatePreview(ArtEntry entry) {
        previewImage.setImageDrawable(null);
        if (entry == null || entry.localPath == null || entry.localPath.isEmpty()) {
            previewImage.setVisibility(View.GONE);
            return;
        }
        File file = new File(entry.localPath);
        if (!file.exists() || file.length() == 0) {
            previewImage.setVisibility(View.GONE);
            return;
        }
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(file.getAbsolutePath(), bounds);
        BitmapFactory.Options opts = new BitmapFactory.Options();
        int max = Math.max(bounds.outWidth, bounds.outHeight);
        opts.inSampleSize = max > 2000 ? 2 : 1;
        Bitmap bitmap = BitmapFactory.decodeFile(file.getAbsolutePath(), opts);
        if (bitmap == null) {
            previewImage.setVisibility(View.GONE);
            return;
        }
        previewImage.setVisibility(View.VISIBLE);
        previewImage.setImageBitmap(bitmap);
    }

    private void openArticle() {
        if (currentEntry == null || currentEntry.sourceUrl.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(currentEntry.sourceUrl))); }
        catch (Exception e) { showStatus("Не удалось открыть статью"); }
    }

    private void openFullscreen() {
        if (currentEntry == null) return;
        Intent intent = new Intent(this, FullscreenActivity.class);
        intent.putExtra("qid", currentEntry.qid);
        startActivity(intent);
    }

    private void openExactAlarmSettings() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return;
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName())));
        }
    }

    private void updateSegments(int mode) {
        styleSegment(filterButton, mode == ArtRepository.CONTENT_FILTER, true, false);
        styleSegment(allButton, mode == ArtRepository.CONTENT_ALL, false, false);
        styleSegment(adultButton, mode == ArtRepository.CONTENT_ADULT_ONLY, false, true);
    }

    private void styleSegment(Button button, boolean active, boolean first, boolean last) {
        int color = active ? 0xFF007AFF : fieldColor;
        int stroke = active ? 0xFF007AFF : borderColor;
        button.setTextColor(active ? Color.WHITE : textColor);
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setStroke(dp(1), stroke);
        float r = dp(13);
        float[] radii = new float[]{first ? r : 0, first ? r : 0, last ? r : 0, last ? r : 0,
                last ? r : 0, last ? r : 0, first ? r : 0, first ? r : 0};
        shape.setCornerRadii(radii);
        button.setBackground(shape);
    }

    private Button makeSegment(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setMinHeight(0);
        return b;
    }

    private void setBusy(boolean busy) {
        for (View v : new View[]{nextButton, previousButton, forwardButton, dislikeButton, likeButton, cacheButton,
                saveIntervalButton, exactAlarmButton, filterButton, allButton, adultButton, intervalValue, unitSpinner, logButton}) {
            if (v != null) {
                v.setEnabled(!busy);
                v.setAlpha(busy ? 0.55f : 1f);
            }
        }
    }

    private void showStatus(String text) {
        statusView.setText(text == null ? "" : text);
        statusView.setVisibility(View.VISIBLE);
    }

    private void hideStatus() {
        statusView.setVisibility(View.GONE);
    }

    private String friendlyError(Exception e) {
        String msg = e == null ? null : e.getMessage();
        if (msg == null || msg.trim().isEmpty()) return "Не удалось выполнить операцию";
        if (msg.contains("HTTP 429") || msg.contains("Слишком частые")) return "Слишком частые запросы. Повторите позже";
        if (msg.contains("Unable to resolve host") || msg.contains("No address associated") || msg.contains("Не удалось определить адрес")) {
            return "Нет подключения к интернету или DNS временно недоступен";
        }
        if (msg.toLowerCase().contains("timeout") || msg.contains("не ответил вовремя")) return "Сервер не ответил вовремя. Повторите позже";
        return msg.length() > 220 ? msg.substring(0, 220) + "…" : msg;
    }

    private void applyIntervalToControls(int seconds) {
        if (seconds < 60) {
            intervalValue.setText(String.valueOf(seconds));
            unitSpinner.setSelection(0);
        } else if (seconds % 3600 == 0) {
            intervalValue.setText(String.valueOf(seconds / 3600));
            unitSpinner.setSelection(2);
        } else {
            intervalValue.setText(String.valueOf(Math.max(1, seconds / 60)));
            unitSpinner.setSelection(1);
        }
    }

    private Button makeButton(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setMinHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setTextColor(primary ? Color.WHITE : textColor);
        b.setBackground(rounded(primary ? 0xFF007AFF : fieldColor, 15, primary ? 0xFF007AFF : borderColor, 1));
        return b;
    }

    private ImageButton makeIconButton(int iconRes, String description) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(iconRes);
        b.setColorFilter(textColor);
        b.setContentDescription(description);
        b.setPadding(dp(11), dp(9), dp(11), dp(9));
        b.setBackground(rounded(fieldColor, 15, borderColor, 1));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            b.setImageTintList(ColorStateList.valueOf(textColor));
            b.setImageTintList(null);
        }
        return b;
    }

    private LinearLayout sectionCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(14), dp(14), dp(14));
        card.setBackground(rounded(fieldColor, 18, borderColor, 1));
        return card;
    }

    private TextView sectionTitle(String title) {
        TextView tv = textView(17, true, textColor);
        tv.setText(title);
        return tv;
    }

    private LinearLayout.LayoutParams sectionParams() {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(0, 0, 0, dp(12));
        return p;
    }

    private TextView textView(int size, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setTextSize(size);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return tv;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        return row;
    }

    private GradientDrawable rounded(int color, int radiusDp, int strokeColor, int strokeDp) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) drawable.setStroke(dp(strokeDp), strokeColor);
        return drawable;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private LinearLayout.LayoutParams weightedButtonParams() {
        return new LinearLayout.LayoutParams(0, dp(48), 1f);
    }

    private LinearLayout.LayoutParams weightedButtonParamsWithMargins() {
        LinearLayout.LayoutParams p = weightedButtonParams();
        p.setMargins(dp(SPACE), 0, dp(SPACE), 0);
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setupColors() {
        boolean dark = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        bgColor = dark ? 0xFF0B0B0D : 0xFFF7F7F8;
        textColor = dark ? 0xFFF2F2F7 : 0xFF1C1C1E;
        subTextColor = dark ? 0xFFAEAEB2 : 0xFF6E6E73;
        fieldColor = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        borderColor = dark ? 0xFF38383A : 0xFFD9D9DE;
        linkColor = dark ? 0xFF64A9FF : 0xFF007AFF;
        dangerColor = 0xFFFF3B30;
        getWindow().setStatusBarColor(bgColor);
        getWindow().setNavigationBarColor(bgColor);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (dark) flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            else flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private enum Operation { NEXT, PREVIOUS, FORWARD, DISLIKE }
}
