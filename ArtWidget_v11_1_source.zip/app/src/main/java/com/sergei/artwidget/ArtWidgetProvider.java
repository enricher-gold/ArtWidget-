package com.sergei.artwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver.PendingResult;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.TypedValue;
import android.widget.RemoteViews;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ArtWidgetProvider extends AppWidgetProvider {
    private static final int CAPTION_HEIGHT_DP = 28;
    private static final float CAPTION_TEXT_SP = 12f;
    public static final String ACTION_SCHEDULED_UPDATE = "com.sergei.artwidget.SCHEDULED_UPDATE";
    public static final String ACTION_WIDGET_NEXT = "com.sergei.artwidget.WIDGET_NEXT";
    public static final String ACTION_WIDGET_PREVIOUS = "com.sergei.artwidget.WIDGET_PREVIOUS";
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor();

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        updateWidgets(context, manager, ids);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager manager, int appWidgetId, Bundle options) {
        super.onAppWidgetOptionsChanged(context, manager, appWidgetId, options);
        updateWidget(context, manager, appWidgetId);
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        ArtScheduler.scheduleNext(context);
    }

    @Override
    public void onDisabled(Context context) {
        super.onDisabled(context);
        ArtScheduler.cancel(context);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent == null || intent.getAction() == null) return;
        String action = intent.getAction();
        if (ACTION_SCHEDULED_UPDATE.equals(action) || ACTION_WIDGET_NEXT.equals(action)) {
            performAsync(context, true);
        } else if (ACTION_WIDGET_PREVIOUS.equals(action)) {
            performAsync(context, false);
        }
    }

    private void performAsync(Context context, boolean next) {
        final PendingResult result = goAsync();
        final Context app = context.getApplicationContext();
        EXECUTOR.execute(() -> {
            boolean acquired = UpdateCoordinator.tryBegin();
            try {
                if (!acquired) {
                    AppLogger.log(app, "widget", "skip", "Обновление уже выполняется");
                    return;
                }
                ArtRepository repo = new ArtRepository(app);
                if (next) repo.fetchNextArtwork();
                else repo.goPrevious();
                updateAllWidgets(app);
            } catch (Exception e) {
                AppLogger.log(app, next ? "widget-next" : "widget-previous", "error", e.getMessage());
                updateAllWidgets(app);
            } finally {
                if (acquired) UpdateCoordinator.finish();
                if (next) ArtScheduler.scheduleNext(app);
                result.finish();
            }
        });
    }

    public static void updateAllWidgets(Context context) {
        Context app = context.getApplicationContext();
        AppWidgetManager manager = AppWidgetManager.getInstance(app);
        int[] ids = manager.getAppWidgetIds(new ComponentName(app, ArtWidgetProvider.class));
        updateWidgets(app, manager, ids);
    }

    private static void updateWidgets(Context context, AppWidgetManager manager, int[] ids) {
        if (ids == null) return;
        for (int id : ids) updateWidget(context, manager, id);
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        ArtRepository repo = new ArtRepository(context);
        ArtEntry entry = repo.getCurrent();
        Bundle options = manager.getAppWidgetOptions(id);
        int minW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 250);
        int maxW = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH, minW);
        int minH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 250);
        int maxH = options.getInt(AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT, minH);
        boolean landscape = context.getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_LANDSCAPE;
        // AppWidgetOptions хранит пары размеров для портретной и альбомной
        // ориентации. Нельзя объединять maxWidth и maxHeight: такая комбинация
        // не соответствует реальному прямоугольнику на экране и приводит к
        // лишним полям. Берём согласованную пару для текущей ориентации.
        int width = landscape ? Math.max(minW, maxW) : Math.min(minW, maxW);
        int height = landscape ? Math.min(minH, maxH) : Math.max(minH, maxH);
        width = Math.max(120, width);
        height = Math.max(120, height);
        int artworkHeight = Math.max(92, height - CAPTION_HEIGHT_DP);
        Bitmap bitmap = ArtRenderer.render(context, entry, width, artworkHeight);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.art_widget);
        views.setImageViewBitmap(R.id.widget_image, bitmap);
        String caption = entry == null ? "Art Widget" : entry.widgetCaption();
        views.setTextViewText(R.id.widget_caption, caption);
        // 12 sp визуально близко к стандартным подписям ярлыков Android и
        // автоматически учитывает системный fontScale пользователя.
        views.setTextViewTextSize(R.id.widget_caption, TypedValue.COMPLEX_UNIT_SP, CAPTION_TEXT_SP);
        // Для RemoteViews используем безопасное однострочное сокращение.
        // Программный запуск marquee через setSelected/setMarqueeRepeatLimit
        // несовместим с рядом лаунчеров и может ломать загрузку виджета.
        views.setOnClickPendingIntent(R.id.widget_left_tap_zone,
                broadcastIntent(context, ACTION_WIDGET_PREVIOUS, 14001 + id));
        views.setOnClickPendingIntent(R.id.widget_right_tap_zone,
                broadcastIntent(context, ACTION_WIDGET_NEXT, 15001 + id));
        views.setOnClickPendingIntent(R.id.widget_open_tap_zone,
                openAppIntent(context, 16001 + id));
        manager.updateAppWidget(id, views);
    }

    private static PendingIntent broadcastIntent(Context context, String action, int requestCode) {
        Intent intent = new Intent(context, ArtWidgetProvider.class);
        intent.setAction(action);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, requestCode, intent, flags);
    }

    private static PendingIntent openAppIntent(Context context, int requestCode) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getActivity(context, requestCode, intent, flags);
    }
}
