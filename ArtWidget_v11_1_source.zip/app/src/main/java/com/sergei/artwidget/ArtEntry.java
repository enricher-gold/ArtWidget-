package com.sergei.artwidget;

import org.json.JSONException;
import org.json.JSONObject;

public class ArtEntry {
    public final String qid;
    public final String title;
    public final String artist;
    public final String description;
    public final String imageUrl;
    public final String originalImageUrl;
    public final String localPath;
    public final String sourceUrl;
    public final String instanceLabel;
    public final String materialLabel;
    public final String genreLabel;
    public final long addedAt;
    public final long lastShownAt;
    public final int showCount;
    public final boolean explicitContent;

    public ArtEntry(
            String qid,
            String title,
            String artist,
            String description,
            String imageUrl,
            String originalImageUrl,
            String localPath,
            String sourceUrl,
            String instanceLabel,
            String materialLabel,
            String genreLabel,
            long addedAt,
            long lastShownAt,
            int showCount,
            boolean explicitContent
    ) {
        this.qid = safe(qid, stableFallback(title, sourceUrl, imageUrl));
        this.title = safe(title, "Без названия");
        this.artist = sanitizeArtist(artist);
        this.description = safe(description, "");
        this.imageUrl = safe(imageUrl, "");
        this.originalImageUrl = safe(originalImageUrl, this.imageUrl);
        this.localPath = safe(localPath, "");
        this.sourceUrl = safe(sourceUrl, "");
        this.instanceLabel = safe(instanceLabel, "");
        this.materialLabel = safe(materialLabel, "");
        this.genreLabel = safe(genreLabel, "");
        this.addedAt = addedAt > 0 ? addedAt : System.currentTimeMillis();
        this.lastShownAt = lastShownAt > 0 ? lastShownAt : this.addedAt;
        this.showCount = Math.max(0, showCount);
        this.explicitContent = explicitContent;
    }

    public static ArtEntry catalog(
            String qid,
            String title,
            String artist,
            String description,
            String imageUrl,
            String sourceUrl,
            String instanceLabel,
            String materialLabel,
            String genreLabel,
            boolean explicitContent
    ) {
        return new ArtEntry(qid, title, artist, description, imageUrl, imageUrl, "", sourceUrl,
                instanceLabel, materialLabel, genreLabel, 0L, 0L, 0, explicitContent);
    }

    public ArtEntry withDownloadedData(String descriptionValue, String standardUrl, String originalUrl, String path) {
        long now = System.currentTimeMillis();
        return new ArtEntry(qid, title, artist,
                safe(descriptionValue, description),
                safe(standardUrl, imageUrl),
                safe(originalUrl, standardUrl),
                path,
                sourceUrl,
                instanceLabel,
                materialLabel,
                genreLabel,
                addedAt,
                now,
                showCount + 1,
                explicitContent);
    }

    public ArtEntry withLocalPath(String path) {
        return new ArtEntry(qid, title, artist, description, imageUrl, originalImageUrl, path,
                sourceUrl, instanceLabel, materialLabel, genreLabel, addedAt, lastShownAt,
                showCount, explicitContent);
    }

    public ArtEntry markedShown() {
        return new ArtEntry(qid, title, artist, description, imageUrl, originalImageUrl, localPath,
                sourceUrl, instanceLabel, materialLabel, genreLabel, addedAt,
                System.currentTimeMillis(), showCount + 1, explicitContent);
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("qid", qid);
        o.put("title", title);
        o.put("artist", artist);
        o.put("description", description);
        o.put("imageUrl", imageUrl);
        o.put("originalImageUrl", originalImageUrl);
        o.put("localPath", localPath);
        o.put("sourceUrl", sourceUrl);
        o.put("instanceLabel", instanceLabel);
        o.put("materialLabel", materialLabel);
        o.put("genreLabel", genreLabel);
        o.put("addedAt", addedAt);
        o.put("lastShownAt", lastShownAt);
        o.put("showCount", showCount);
        o.put("explicitContent", explicitContent);
        return o;
    }

    public static ArtEntry fromJson(JSONObject o) {
        String title = o.optString("title", o.optString("titleRu", o.optString("pageTitle", "Без названия")));
        String source = o.optString("sourceUrl", "");
        String image = o.optString("imageUrl", o.optString("directImageUrl", ""));
        String qid = o.optString("qid", "");
        if (qid.isEmpty()) {
            String itemUrl = o.optString("itemUrl", "");
            int slash = itemUrl.lastIndexOf('/');
            String itemId = slash >= 0 ? itemUrl.substring(slash + 1) : itemUrl;
            if (itemId.matches("Q\\d+")) qid = itemId;
        }
        if (qid.isEmpty()) {
            int legacyId = o.optInt("id", 0);
            qid = legacyId != 0 ? "legacy:" + legacyId : stableFallback(title, source, image);
        }
        String artist = o.optString("artist", o.optString("artistRu", o.optString("originalArtist", "Автор неизвестен")));
        String description = o.optString("description", o.optString("descriptionRu", ""));
        String original = o.optString("originalImageUrl", image);
        return new ArtEntry(
                qid,
                title,
                artist,
                description,
                image,
                original,
                o.optString("localPath", ""),
                source,
                o.optString("instanceLabel", ""),
                o.optString("materialLabel", o.optString("mediumDisplay", "")),
                o.optString("genreLabel", ""),
                o.optLong("addedAt", System.currentTimeMillis()),
                o.optLong("lastShownAt", System.currentTimeMillis()),
                o.optInt("showCount", 0),
                o.optBoolean("explicitContent", false)
        );
    }

    public String caption() {
        if (isUnknownArtist(artist)) return "Автор неизвестен · " + title;
        return artist + " · " + title;
    }

    /**
     * Короткая подпись только для рабочего стола. Заголовки статей Википедии
     * часто содержат служебные уточнения в конце, например
     * «Даная (картина Тициана)». В приложении сохраняется полное название,
     * а на виджете используется компактный вариант без таких уточнений.
     */
    public String widgetCaption() {
        String shortTitle = titleForWidget(title);
        if (isUnknownArtist(artist)) return "Автор неизвестен · " + shortTitle;
        return artist + " · " + shortTitle;
    }

    public static String titleForWidget(String value) {
        String result = safe(value, "Без названия");
        // Удаляем только завершающие уточнения в круглых скобках. Скобки внутри
        // основного названия не затрагиваются. Несколько хвостовых групп
        // удаляются последовательно.
        for (int i = 0; i < 4; i++) {
            String cleaned = result.replaceFirst("\\s*[\\(（][^\\)）]{1,180}[\\)）]\\s*$", "").trim();
            if (cleaned.equals(result) || cleaned.isEmpty()) break;
            result = cleaned;
        }
        result = result.replaceAll("\\s{2,}", " ").trim();
        return result.isEmpty() ? "Без названия" : result;
    }

    public static String sanitizeArtist(String value) {
        String s = safe(value, "Автор неизвестен");
        String lower = s.toLowerCase();
        if (lower.startsWith("http://") || lower.startsWith("https://")
                || lower.contains("wikidata.org") || lower.contains("/.well-known/genid/")
                || lower.matches("q\\d+")) {
            return "Автор неизвестен";
        }
        if (s.length() > 160) return "Автор неизвестен";
        return s;
    }

    public static boolean isUnknownArtist(String value) {
        if (value == null) return true;
        String s = value.trim().toLowerCase();
        return s.isEmpty() || s.equals("автор неизвестен") || s.equals("неизвестный художник")
                || s.equals("unknown") || s.equals("anonymous") || s.equals("аноним");
    }

    private static String safe(String value, String fallback) {
        if (value == null) return fallback == null ? "" : fallback;
        String s = value.replace('\n', ' ').replace('\r', ' ').trim();
        return s.isEmpty() ? (fallback == null ? "" : fallback) : s;
    }

    private static String stableFallback(String title, String source, String image) {
        String key = safe(source, "");
        if (key.isEmpty()) key = safe(image, "");
        if (key.isEmpty()) key = safe(title, "Без названия");
        return "local:" + Integer.toHexString(key.hashCode());
    }
}
